package com.alinma.rating.domain;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonProperty;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class RateCategoryRes implements Serializable{
	private static final long serialVersionUID = -3419316272241138475L;
	 
	@JsonProperty("RateCategories")
	private List<RateCategory> list;
	@JsonProperty("result")
	private ResultMessage result;
	
	public ResultMessage getResult() {
		return result;
	}
	public void setResult(ResultMessage result) {
		this.result = result;
	}
	public List<RateCategory> getList() {
		return list;
	}
	public void setList(List<RateCategory> list) {
		this.list = list;
	}
	
	
	
}
