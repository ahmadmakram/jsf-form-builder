package com.alinma.rating.domain;

import java.util.Hashtable;
import java.util.Map;







public enum ActionIdParam {
	ADD_RATE("1"),
	UPDATE_RATE("2"),
	GET_CATEGORIES("3"),
	GET_LATEST_RATE("4")
	;
	
	 
	
	private String code;
	private static Map<String, ActionIdParam> map;
	ActionIdParam(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}
	static {
		map = new Hashtable<String, ActionIdParam>();
		for(ActionIdParam value: ActionIdParam.values()) {
			map.put(value.getCode(), value);
		}
	}
	public static ActionIdParam getByCode(String code){
		if(map == null) {
			return null;
		}
		return map.get(code);
	}
}
