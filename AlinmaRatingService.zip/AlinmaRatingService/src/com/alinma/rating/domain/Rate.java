package com.alinma.rating.domain;

import java.io.Serializable;
import java.util.Arrays;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Rate implements Serializable {
	private static final long serialVersionUID = -9087637209028016236L;
	@JsonProperty("ChannelID")
	private String channelId;
	@JsonProperty("UserID")
	private String userId;
	@JsonProperty("CIF")
	private String CIF;
	@JsonProperty("SessionID")
	private String sessionId;
	@JsonProperty("PageName")
	private String pageName;
	@JsonProperty("RateValue")
	private int rateValue;
	@JsonProperty("RateComment")
	private String rateComment;
	private String[] categoriesId;
	private String categoriesIdStr;
	@JsonProperty("RateID")
    private String rateId;
	 
	@JsonProperty("RateChannelID")
	private String rateChannelId;
	
	@JsonProperty("ChannelVersion")
	private String channelVersion;

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCIF() {
		return CIF;
	}

	public void setCIF(String cIF) {
		CIF = cIF;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public int getRateValue() {
		return rateValue;
	}

	public void setRateValue(int rateValue) {
		this.rateValue = rateValue;
	}

	public String getRateComment() {
		return rateComment;
	}

	public void setRateComment(String rateComment) {
		this.rateComment = rateComment;
	}

	public String[] getCategoriesId() {
		return categoriesId;
	}

	public void setCategoriesId(String[] categoriesId) {
		this.categoriesId = categoriesId;
	}

	public String getCategoriesIdStr() {
		return categoriesIdStr;
	}

	public void setCategoriesIdStr(String categoriesIdStr) {
		this.categoriesIdStr = categoriesIdStr;
	}

	public String getRateId() {
		return rateId;
	}

	public void setRateId(String rateId) {
		this.rateId = rateId;
	}

	public String getRateChannelId() {
		return rateChannelId;
	}

	public void setRateChannelId(String rateChannelId) {
		this.rateChannelId = rateChannelId;
	}

	public String getChannelVersion() {
		return channelVersion;
	}

	public void setChannelVersion(String channelVersion) {
		this.channelVersion = channelVersion;
	}

	@Override
	public String toString() {
		return "Rate [channelId=" + channelId + ", userId=" + userId + ", CIF="
				+ CIF + ", sessionId=" + sessionId + ", pageName=" + pageName
				+ ", rateValue=" + rateValue + ", rateComment=" + rateComment
				+ ", categoriesId=" + Arrays.toString(categoriesId)
				+ ", categoriesIdStr=" + categoriesIdStr + ", rateId=" + rateId
				+ ", rateChannelId=" + rateChannelId + ", channelVersion="
				+ channelVersion + "]";
	}
		
	
}
