package com.alinma.rating.domain;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class UpdateRateRes implements Serializable{
	private static final long serialVersionUID = 7806850636760283348L;
	@JsonProperty("result")
	private ResultMessage result;
	public ResultMessage getResult() {
		return result;
	}
	public void setResult(ResultMessage result) {
		this.result = result;
	}
	
}
