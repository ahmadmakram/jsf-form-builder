package com.alinma.rating.domain;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonProperty;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class CreateRateRes  implements Serializable{

	private static final long serialVersionUID = 7175785823649987796L;
	@JsonProperty("RateID")
	private String rateId;
	@JsonProperty("result")
	private ResultMessage result;
	public String getRateId() {
		return rateId;
	}
	public void setRateId(String rateId) {
		this.rateId = rateId;
	}
	public ResultMessage getResult() {
		return result;
	}
	public void setResult(ResultMessage result) {
		this.result = result;
	}
	
	
	
}
