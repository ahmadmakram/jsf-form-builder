package com.alinma.rating.domain;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class LatestRateRes implements Serializable{
	private static final long serialVersionUID = 3168848620630239968L;
	@JsonProperty("Rate")
	private Rate rate;
    @JsonProperty("result")
   private ResultMessage result;
	public Rate getRate() {
		return rate;
	}
	public void setRate(Rate rate) {
		this.rate = rate;
	}
	public ResultMessage getResult() {
		return result;
	}
	public void setResult(ResultMessage result) {
		this.result = result;
	}
	
    
    
}
