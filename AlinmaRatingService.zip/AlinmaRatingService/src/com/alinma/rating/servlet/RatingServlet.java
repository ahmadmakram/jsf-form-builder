package com.alinma.rating.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.alinma.rating.dao.RateDAO;
import com.alinma.rating.domain.ActionIdParam;
import com.alinma.rating.domain.CreateRateRes;
import com.alinma.rating.domain.Rate;
import com.alinma.rating.domain.RateCategoryRes;
import com.alinma.rating.domain.ResultMessage;
import com.alinma.rating.domain.UpdateRateRes;

/**
 * Servlet implementation class RatingServlet
 */

public class RatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static ObjectMapper mapper = new ObjectMapper();
	private static final Logger LOGGER = Logger.getLogger("RateServlet");       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RatingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    private void updateRate(HttpServletRequest request, HttpServletResponse response,PrintWriter out) throws IOException, IllegalAccessException, InvocationTargetException{
    	Rate rate=new Rate();
    	BeanUtils.populate(rate, request.getParameterMap());
    	UpdateRateRes res =RateDAO.getInstance().updateRate(rate);
    	out.write(mapper.writeValueAsString(res));
    }
    
    private void addRate(HttpServletRequest request, HttpServletResponse response,PrintWriter out) throws IOException, IllegalAccessException, InvocationTargetException{
    	Rate rate=new Rate();
    	BeanUtils.populate(rate, request.getParameterMap());
    	rate.setSessionId(request.getSession().getId());
    	String rateId=RateDAO.getInstance().createRate(rate);
    	CreateRateRes createRateRes=new CreateRateRes();
    	createRateRes.setRateId(rateId);
    	out.write(mapper.writeValueAsString(createRateRes));
    }
    private void getLatestRate(HttpServletRequest request, HttpServletResponse response,PrintWriter out) throws IOException{
    	Rate rate=RateDAO.getInstance().getLatestRate(request.getParameter("userId"));
    	out.write(mapper.writeValueAsString(rate));
    }
    private   void   getRateCategories(HttpServletRequest request, HttpServletResponse response,PrintWriter out) throws IOException{
    	//TODO Add object caching 
    	RateCategoryRes rateCategoryRes=RateDAO.getInstance().getRateCategories();
    	out.write(mapper.writeValueAsString(rateCategoryRes));
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter  out=null;
		try{
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			out=response.getWriter();
			if(!validateInputParameters(request,response,out)){
				ResultMessage errorMessage=new ResultMessage();
				errorMessage.setMessage("Invalid Parameters");
				errorMessage.setStatusCode("errorCode");
				LOGGER.error("Eror Occured  invalid parameters,out="+mapper.writeValueAsString(errorMessage));
				out.write(mapper.writeValueAsString(errorMessage));
				return;
			}
			ActionIdParam actionId= ActionIdParam.getByCode(request.getParameter("actionId"));
			 
		    switch (actionId) {
			case ADD_RATE:
				addRate(request, response, out);
				break;
			case UPDATE_RATE:
				updateRate(request, response, out);
				break;
			case GET_CATEGORIES:
				getRateCategories(request, response, out);
				break;
				
			case GET_LATEST_RATE:
				getLatestRate(request, response, out);
				break;
			default:
				break;
			}
		}catch(Exception e){
			e.printStackTrace();
			LOGGER.error(e);
			ResultMessage errorMessage=new ResultMessage();
			errorMessage.setMessage("Error");
			errorMessage.setStatusCode("errorCode");
			LOGGER.error("Eror Occured ,out="+mapper.writeValueAsString(errorMessage));
			out.write(mapper.writeValueAsString(errorMessage));
			
		}
	}

	private boolean validateInputParameters(HttpServletRequest request, HttpServletResponse response,PrintWriter out)throws Exception{
		String actionIdStr=request.getParameter("actionId");
		Rate rate=null;
		
		if(isEmpty(actionIdStr))
			return false;
		ActionIdParam actionId= ActionIdParam.getByCode(actionIdStr);
		switch (actionId) {
		case ADD_RATE:
			 rate=new Rate();
	    	BeanUtils.populate(rate, request.getParameterMap());
	    	if (isEmpty(rate.getUserId()) ||
	    		isEmpty(rate.getCIF())	||
	    		isEmpty(rate.getPageName()) 
	    		//isEmpty(rate.getRateValue())
	    		)
	    		return false;
			break;
		case UPDATE_RATE:
			 rate=new Rate();
	    	BeanUtils.populate(rate, request.getParameterMap());
	    	if (isEmpty(rate.getRateId()) &&(
	    		isEmpty(rate.getRateComment())	||
	    		isEmpty(rate.getCategoriesIdStr())) 
	    		) 
	    		return false;
			break;
			
		case GET_LATEST_RATE:
			if(isEmpty(request.getParameter("userId")))
				return false;
			break;
		default:
			break;
		}
		
		return true;
	}
	 
	
	private boolean isEmpty(String str){
		if(str==null || str.length()==0)
			return true;
		else return false;
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
