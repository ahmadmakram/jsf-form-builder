package com.alinma.rating.servlet.offline;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.alinma.rating.domain.CreateRateRes;
import com.alinma.rating.domain.Rate;
import com.alinma.rating.domain.RateCategory;
import com.alinma.rating.domain.RateCategoryRes;
import com.alinma.rating.domain.ResultMessage;
import com.alinma.rating.domain.UpdateRateRes;


public class RatingServletOffline extends HttpServlet {

	
	private static ObjectMapper mapper = new ObjectMapper();
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.setContentType("application/json");
		res.setCharacterEncoding("UTF-8");
		PrintWriter out = res.getWriter();
		
		
		try {
			String channelID = null, userID = null, channelVersion = null, CIF = null, sessionId = null;
			String pageName = null, rateComment = null, rateValue = null,rateId=null,catsId=null;
			String actionId = req.getParameter("actionId");
			 switch (actionId){
				case "1":
					channelID = req.getParameter("channelID");
					userID = req.getParameter("userID");
					CIF = req.getParameter("CIF");
					channelVersion = req.getParameter("channelVersion");
					sessionId = req.getParameter("sessionID");
					pageName = req.getParameter("PageName");
					rateValue = req.getParameter("rateValue");
					CreateRateRes createRateRes = addRate(channelID,channelVersion, userID, CIF, sessionId, pageName, rateValue);
					out.write(mapper.writeValueAsString(createRateRes));
					break;
				case "2":
					rateId = req.getParameter("rateID");
					rateComment = req.getParameter("rateComment");
					catsId = req.getParameter("categoriesID");
					UpdateRateRes updateRateRes = updateRate(rateId, rateComment,catsId);
					ResultMessage errorMessage=new ResultMessage();
					errorMessage.setMessage("Error");
					errorMessage.setStatusCode("errorCode");
					out.write(mapper.writeValueAsString(errorMessage));
					break;
				case "3":
					channelID = req.getParameter("channelID");				
					RateCategoryRes rateCategoryRes = getRateCategories(channelID);
					out.write(mapper.writeValueAsString(rateCategoryRes));
					break;
				case "4"	:
					channelID = req.getParameter("channelID");
					userID = req.getParameter("userID");
					Rate rate = getLatestRate(channelID, userID);
					out.write(mapper.writeValueAsString(rate));
					break;
			 }
			
		} catch (Exception e) {
			e.printStackTrace();
			ResultMessage errorMessage=new ResultMessage();
			errorMessage.setMessage("Error");
			errorMessage.setStatusCode("errorCode");
			out.write(mapper.writeValueAsString(errorMessage));
		} finally {
			out.flush();
		}
	}

	private CreateRateRes addRate(String channelID,String channelVersion, String userID, String CIF, String sessionId, String pageName, String ratevalue) {
		Map<String, String> data = new HashMap<>();
		Random rn = new Random();
		int rNum = rn.nextInt(1000000);
		data.put("RateID", rNum+"");
		data.put("StatusCode",  "I000000");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" add rating ~~~~~~~~ ratevalue=" + ratevalue);
		System.out.println(" add rating ~~~~~~~~ pageName=" + pageName);
		System.out.println(" add rating ~~~~~~~~ channelID=" + channelID);
		System.out.println(" add rating ~~~~~~~~ channelVersion=" + channelVersion);
		System.out.println(" add rating ~~~~~~~~ userID=" + userID);
		System.out.println(" add rating ~~~~~~~~ CIF=" + CIF);
		System.out.println(" add rating ~~~~~~~~ sessionId=" + sessionId);
		System.out.println(" add rating ~~~~~~~~ rateId=" + rNum);
		CreateRateRes createRateRes=new CreateRateRes();
    	createRateRes.setRateId(rNum+"");
		return createRateRes;
	}

	private Rate  getLatestRate(String channelID, String userID) {
		Rate rate = new Rate();
		Random rn = new Random();
		int rNum = rn.nextInt(5);
		rate.setRateValue(0);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("channelID=" + channelID + "  >>>>>>> userID=" + userID + "  ~~~~~~~~ raNum=" + rNum);
		System.out.println("channelID=" + channelID + "  >>>>>>> userID=" + userID + "  ~~~~~~~~ raNum=" + rNum);
		return rate;
	}
	
	private UpdateRateRes updateRate(String rateId, String rateComment,String catsId) {
		
		Random rn = new Random();
		int rNum = rn.nextInt(5);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("rateId=" + rateId + "  >>>>>>> rateComment=" + rateComment + "  ~~~~~~~~ catsId=" + catsId);	
		UpdateRateRes res= new UpdateRateRes();
		ResultMessage result= new ResultMessage();
		result.setStatusCode("I0000000");
		result.setMessage("update success");

		return res;
	}
	
	private RateCategoryRes getRateCategories(String channelID) throws JsonGenerationException, JsonMappingException, IOException {
		Map<String, String> data = new HashMap<>();
		List<RateCategory> cats=new ArrayList<RateCategory>();
		RateCategory cat=new RateCategory();
		cat.setCategoryID("1");
		cat.setCategoryNameEn("Ease of Use");
		cat.setCategoryNameAr("\u0633\u0647\u0648\u0644\u0629 \u0627\u0644\u0625\u0633\u062A\u062E\u062F\u0627\u0645");
		cats.add(cat);
		cat=new RateCategory();
		cat.setCategoryID("2");
		cat.setCategoryNameEn("Techncal Issues");
		cat.setCategoryNameAr("\u0645\u0634\u0627\u0643\u0644 \u062A\u0642\u0646\u064A\u0629");
		cats.add(cat);
		cat=new RateCategory();
		cat.setCategoryID("3");
		cat.setCategoryNameEn("Additional Services");
		cat.setCategoryNameAr("\u062E\u062F\u0645\u0627\u062A \u0625\u0636\u0627\u0641\u064A\u0629");
		cats.add(cat);
		data.put("Cats", mapper.writeValueAsString(cats));
		System.out.println("getRateCategories ------- channelID=" +  channelID  );
		RateCategoryRes rateCategoryRes =new RateCategoryRes();
		rateCategoryRes.setList(cats);
		return rateCategoryRes;
	}
}
