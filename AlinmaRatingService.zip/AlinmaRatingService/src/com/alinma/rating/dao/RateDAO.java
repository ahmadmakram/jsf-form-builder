package com.alinma.rating.dao;


import java.io.IOException;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.apache.wink.client.RestClient;
import javax.ws.rs.core.MediaType;
import org.apache.wink.client.Resource;

import org.apache.wink.client.ClientResponse;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.alinma.rating.domain.CreateRateRes;
import com.alinma.rating.domain.LatestRateRes;
import com.alinma.rating.domain.Rate;
import com.alinma.rating.domain.RateCategoryRes;
import com.alinma.rating.domain.UpdateRateRes;
import com.alinma.rating.util.ConfigPropLoader;

public class RateDAO {
	private static final Logger LOGGER = Logger.getLogger("RatingServiceAppender");
	//private static final Logger RESTLOGGER = Logger.getLogger("RateREST");
	private static RateDAO instance;
	private String channelID;
	private String channelVersion;
	private ObjectMapper mapper = new ObjectMapper();
	private RateDAO(){
		//read channelId from property file
		 channelID=ConfigPropLoader.getInstance().getProperty("channelId");
		 channelVersion=ConfigPropLoader.getInstance().getProperty("channelVersion");
		 LOGGER.info("channeld loaded from config file with value="+channelID);
		 LOGGER.info("channelVersion loaded from config file with value="+channelVersion);
	}
	
	
	public static synchronized RateDAO  getInstance( ) {
		if(instance==null)
			instance=new RateDAO();
		return instance;
	}
	
	public Rate getLatestRate(String userId) throws JsonParseException, JsonMappingException, IOException{
	LOGGER.info("getLatestRate has been started with userId="+userId);	
	RestClient client = new RestClient();
	LatestRateRes latestRateRes ; 
	Resource resource = client.resource(ConfigPropLoader.getInstance().getProperty("rate_resource_url"));
	resource.queryParam("RequestID", generateRequestID());
	resource.queryParam("ChannelVersion","1");
	resource.queryParam("ChannelID", channelID).queryParam("UserID", userId);
	ClientResponse response = resource.contentType(MediaType.APPLICATION_JSON).get();
	if(response.getStatusCode()!=200)
		throw new RuntimeException("Invalid Response from server with code="+response.getStatusCode());
	
	//Rate rate=response.getEntity(Rate.class);
	System.out.println("response="+response.getEntity(String.class));
	latestRateRes=mapper.readValue(response.getEntity(String.class),LatestRateRes.class);     
	if(latestRateRes.getResult().getStatusCode()!=null&&latestRateRes.getResult().getStatusCode().startsWith("E"))
		throw new RuntimeException("Received Error code from the server ="+latestRateRes.getResult().getStatusCode());
	return latestRateRes.getRate();
	
	
	}
	
	
	//ChannelID=1&ChannelVersion=1&UserID=1&CIF=CIF&SessionID=12&PageName=aas&RateValue=1&RateComment=1&CategoriesID=&RequestID=1
	public  String createRate(Rate rate) throws JsonParseException, JsonMappingException, IOException{
		
		String requestId=generateRequestID();
		LOGGER.info(requestId+" createRate has been started with rate="+rate);
		String rateID="";
		RestClient client = new RestClient();
		Resource resource = client.resource(ConfigPropLoader.getInstance().getProperty("rate_resource_url"));
		resource.queryParam("ChannelID", channelID);
		resource.queryParam("ChannelVersion",channelVersion);
		resource.queryParam("UserID", rate.getUserId());
		resource.queryParam("CIF", rate.getCIF());
		resource.queryParam("SessionID", rate.getSessionId());
		resource.queryParam("PageName", rate.getPageName());
		resource.queryParam("RateValue", rate.getRateValue());
		resource.queryParam("RateComment", "");
		resource.queryParam("RequestID", requestId);
		resource.queryParam("CategoriesID", "");
		ClientResponse response =  resource.contentType(MediaType.APPLICATION_JSON)
	            .accept(MediaType.APPLICATION_JSON).post("");
		LOGGER.info(requestId+" response StatusCode="+response.getStatusCode());
		LOGGER.info(requestId+" response message="+response.getMessage());
		LOGGER.info(requestId+" response body="+response.getEntity(String.class));
		
		if(response.getStatusCode()!=201)
		throw new RuntimeException("Invalid Response from server with code="+response.getStatusCode());
		
		CreateRateRes result=mapper.readValue(response.getEntity(String.class),CreateRateRes.class);
		rateID=result.getRateId();
		if (result.getResult().getStatusCode().startsWith("E"))
			throw new RuntimeException("Received Error code from the server ="+result.getResult().getStatusCode());
		
		
		return rateID;
	}
	
	public  UpdateRateRes updateRate(Rate rate) throws JsonParseException, JsonMappingException, IOException{
		String requestId=generateRequestID();
		LOGGER.info(requestId+" updateRate has been started with rate="+rate);
		RestClient client = new RestClient();
		Resource resource = client.resource(ConfigPropLoader.getInstance().getProperty("rate_resource_url"));//+"/"+rate.getRateID()
		resource.queryParam("RequestID", requestId);
		resource.queryParam("ChannelID", channelID);
		resource.queryParam("ChannelVersion",channelVersion);
		resource.queryParam("RateID", rate.getRateId());
		resource.queryParam("RateComment", rate.getRateComment());
		resource.queryParam("CategoriesID", rate.getCategoriesIdStr());
		ClientResponse response =  resource.contentType(MediaType.APPLICATION_JSON)
	            .accept(MediaType.APPLICATION_JSON).put("");
		LOGGER.info(requestId+" response StatusCode="+response.getStatusCode());
		LOGGER.info(requestId+" response message="+response.getMessage());
		LOGGER.info(requestId+" response body="+response.getEntity(String.class));
		if(response.getStatusCode()!=200)
		throw new RuntimeException("Invalid Response from server with code="+response.getStatusCode());
		//System.out.println("response="+response.getEntity(String.class));
		UpdateRateRes result=mapper.readValue(response.getEntity(String.class),UpdateRateRes.class);
		if (result.getResult().getStatusCode().startsWith("E"))
			throw new RuntimeException("Received Error code from the server ="+result.getResult().getStatusCode());
		return result;
	}
	
	private  boolean isSuccessStatusCode(String statusCode){
		if(statusCode!=null)
			if(statusCode.equals("I000000"))
				return true;
		return false;
	}
	
	private String generateRequestID(){
		return UUID.randomUUID().toString().replace("-", "");
	}
	public  RateCategoryRes getRateCategories() throws JsonParseException, JsonMappingException, IOException{
		String requestId=generateRequestID();
		LOGGER.info(requestId+" getRateCategories has been started with rate=");
		RateCategoryRes rateCategoryRes=null;
		RestClient client = new RestClient();
		Resource resource = client.resource(ConfigPropLoader.getInstance().getProperty("rate_cat_resource_url"));
		resource.queryParam("ChannelID", channelID);
		resource.queryParam("RequestID", generateRequestID());
		ClientResponse response = resource.contentType(MediaType.APPLICATION_JSON).get();
		LOGGER.info(requestId+" response StatusCode="+response.getStatusCode());
		LOGGER.info(requestId+" response message="+response.getMessage());
		LOGGER.info(requestId+" response body="+response.getEntity(String.class));
		if(response.getStatusCode()!=200)
			throw new RuntimeException("Invalid Response from server with code="+response.getStatusCode());
	            
		//System.out.println("response="+response.getEntity(String.class));
		rateCategoryRes=mapper.readValue(response.getEntity(String.class),RateCategoryRes.class);     
				//response.getEntity(RateCategoryRes.class);
		if(!isSuccessStatusCode(rateCategoryRes.getResult().getStatusCode()))
			throw new RuntimeException("Invalid Response from server with code="+response.getStatusCode());
		
		return rateCategoryRes;
	}
}
