package com.alinma.rating.dao;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.alinma.rating.domain.Rate;

@javax.ws.rs.Path("/rate")
public class RateServerDAO {
 	    @GET
	    @Produces( MediaType.APPLICATION_JSON )
	    public Response getLatestRate(String userId) {
	        Rate rate=new Rate();
	       // rate.setUserID(userId);
	        return Response.ok( rate ).build();
	    }
 	    
 	    
 	    
 	    
 	    
 	    
 	    
 	    
}
