package com.alinma.rating.util;

import java.util.Properties;




public class ConfigPropLoader {

	private static ConfigPropLoader instance;
	private Properties props=new Properties();
	private ConfigPropLoader(){
		try{
			props.load(ConfigPropLoader.class.getClassLoader().getResourceAsStream("/rating-service-config.properties"));
		}catch(Exception e){
			System.out.println("Not able to loads config-core.properties ,please check the classpath .");
			e.printStackTrace();
		}
	}
	public static synchronized ConfigPropLoader  getInstance( ) {
		if(instance==null)
			instance=new ConfigPropLoader();
		return instance;
	}
	
	
	public String getProperty(String key){
		return props.getProperty(key);
	}
	
}
