package com.rating.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

public class RatingServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.setContentType("application/json");
		res.setCharacterEncoding("UTF-8");
		PrintWriter out = res.getWriter();
		Gson gson = new Gson();
		Map<String, String> data = new HashMap<>();
		try {
			String channelID = null, userID = null, channelVersion = null, CIF = null, sessionId = null;
			String pageName = null, rateComment = null, rateValue = null,rateId=null;
			String methodName = req.getParameter("methodName");
			if (methodName.equals("addRate")) {
				channelID = req.getParameter("CHANNEL_ID");
				userID = req.getParameter("USER_ID");
				CIF = req.getParameter("CIF");
				channelVersion = req.getParameter("CHANNEL_VERSION");
				sessionId = req.getParameter("SESSION_ID");
				pageName = req.getParameter("PAGE_NAME");
				rateComment = req.getParameter("RATE_COMMENT");
			Object	catsId = req.getParameter("CATS_IDs");
				rateValue = req.getParameter("RATE_VAL");
				data = addRate(channelID,channelVersion, userID, CIF, sessionId, pageName, rateComment, rateValue,catsId);
			}
			if (methodName.equals("getLatestRate")) {
				channelID = req.getParameter("CHANNEL_ID");
				userID = req.getParameter("USER_ID");
				data = getLatestRate(channelID, userID);
			}
			if (methodName.equals("updateRate")) {
				rateId = req.getParameter("RATE_ID");
				rateComment = req.getParameter("RATE_COMMENT");
				String[]	catsId = req.getParameterValues("CATS_IDs[]");
				data = updateRate(rateId, rateComment,catsId);
			}
			
			if (methodName.equals("getRateCategories")) {
				channelID = req.getParameter("CHANNEL_ID");				
				data = getRateCategories(channelID);
			}
			out.write(gson.toJson(data));
		} catch (Exception e) {
			out.write(e.getMessage());
		} finally {
			out.flush();
		}
	}

	private Map<String, String> addRate(String channelID,String channelVersion, String userID, String CIF, String sessionId, String pageName, String rateComment, String ratevalue,Object catsId) {
		Map<String, String> data = new HashMap<>();
		Random rn = new Random();
		int rNum = rn.nextInt(1000000);
		data.put("RateID", rNum+"");
		data.put("StatusCode",  "I000000");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" add rating ~~~~~~~~ ratevalue=" + ratevalue);
		System.out.println(" add rating ~~~~~~~~ pageName=" + pageName);
		return data;
	}

	private Map<String, String> getLatestRate(String channelID, String userID) {
		Map<String, String> data = new HashMap<>();
		Random rn = new Random();
		int rNum = rn.nextInt(5);
		data.put("pervRating", rNum + "");
		System.out.println("channelID=" + channelID + "  >>>>>>> userID=" + userID + "  ~~~~~~~~ raNum=" + rNum);
		return data;
	}
	
	private Map<String, String> updateRate(String rateId, String rateComment,String[] catsId) {
		Map<String, String> data = new HashMap<>();
		Random rn = new Random();
		int rNum = rn.nextInt(5);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("rateId=" + rateId + "  >>>>>>> rateComment=" + rateComment + "  ~~~~~~~~ catsId=" + catsId);	
		if(catsId!=null){
		   for (int i=0;i<catsId.length;i++){ 
			   System.out.println("catsId="+ catsId[i]);
		   } 
		}
		
		data.put("StatusCode", rNum + "");
		return data;
	}
	
	private Map<String, String> getRateCategories(String channelID) {
		Map<String, String> data = new HashMap<>();
		Random rn = new Random();
		int rNum = rn.nextInt(5);
		List<RatingCategories> cats=new ArrayList<RatingCategories>();
		RatingCategories cat=new RatingCategories();
		cat.setCategoryId("1");
		cat.setCategoryNameEn("cat1");
		cat.setCategoryNameAr("\u0631\u0642\u0645 1");
		cats.add(cat);
		cat=new RatingCategories();
		cat.setCategoryId("2");
		cat.setCategoryNameEn("cat2");
		cat.setCategoryNameAr("\u0631\u0642\u0645 2");
		cats.add(cat);
		data.put("Cats", new Gson().toJson(cats));
		System.out.println("channelID=" +  channelID + "  >>>>>>> rateComment" );
		return data;
	}
}
