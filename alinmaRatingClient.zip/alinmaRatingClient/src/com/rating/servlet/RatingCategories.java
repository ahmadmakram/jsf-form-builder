package com.rating.servlet;




public class RatingCategories  {

	private String categoryNameAr;
	private String categoryNameEn;
	private String categoryId;
	private String statusCode;
	
	public String getCategoryNameAr() {
		return categoryNameAr;
	}
	
	public void setCategoryNameAr(String categoryNameAr) {
		this.categoryNameAr = categoryNameAr;
	}
	
	public String getCategoryNameEn() {
		return categoryNameEn;
	}
	
	public void setCategoryNameEn(String categoryNameEn) {
		this.categoryNameEn = categoryNameEn;
	}
	
	public String getCategoryId() {
		return categoryId;
	}
	
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
	public String getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	
}
