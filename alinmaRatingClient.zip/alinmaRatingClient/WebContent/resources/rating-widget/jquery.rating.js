/******************************************************************************
  Rating jQuery UI Widget

  This plugin should provide a simple way to convert elements (DIV, SELECT and RANGE)
  to an interactive rating mechanism. Fully customizable via CSS. Degrades gracefully
  to regular HTML elements.

  DEPENDENCIES
  * jQuery 1.4.2+
  * jQuery UI 1.8.7+ (Core + Widget Factory)

  Author:   Mina Mikhail (@fightingtheboss)
  Code:     http://github.com/fightingtheboss/jquery-ui-rating

  Based on: http://rateit.codeplex.com (@gjunge)
            http://www.fyneworks.com/jquery/star-rating/

  Default icons: famfamfam.com

******************************************************************************/
var script = document.currentScript;
var fullUrl = script.src;
var filePath = fullUrl.substring(0, fullUrl.lastIndexOf('/'));
 var ratingValue=0;
 var feedbackText;
 var descKey;
 var sucessMsgKey;
 var failMsgKey;
 var submitCommentBtnKey;
 var closeCommentBtnKey;
 var categoryDiv;
 var catsBoxs = [];
 var lang;
 var rateId;
 var serverMsg;
 var serverMsgClass;
 var keysMap;
 
(function($) {
  $.widget('ui.rating', {
    options: {
      min: 0,
      max: 5,
      step: 0.5,
      resetable: true,
      readOnly: false,
      showText: false,
      starWidth: 16,
      starHeight: 16,  
    },

    _create: function() {
      // First time setup for widget
      // Initialize the plugin
      var self = this,
          node = this.element[0],
          nodeParams = {};      
      this.options.ltr = this.element.css('direction') != 'rtl';
      lang=this.options.local ;
      keysMap=this.options.resourceKeysMap;
     
      // Read the Latest Rate
      console.log ("ratingValue0000: " +ratingValue);
      getLatestRate(this.options.channelID,this.options.userID,this.options.servletName);
      debugger;
      console.log ("ratingValue111111111: " +ratingValue);
      this.options.value=ratingValue;
      // Are we attached to a range input?
      // (Range inputs are rendered as text input in all browsers that don't support range.)
      if ( node.nodeName == "INPUT" && ( node.type == "range" || node.type == "text" ) ) {
        nodeParams = {
          min: parseInt(this.element.attr('min'), 10) || this.options.min,
          max: parseInt(this.element.attr('max'), 10) || this.options.max,
          step: parseInt(this.element.attr('step'), 10) || this.options.step,
          value: this.element.val()
        };
      }

      // Are we attached to a select input?
      else if ( node.nodeName == "SELECT" && node.options.length > 1 ) {
        nodeParams = {
          min: parseInt(node.options[0].value, 10),
          max: parseInt(node.options[node.options.length - 1].value, 10),
          step: parseInt(node.options[1].value - node.options[0].value, 10),
          value: this.element.val()
        };
      }

      // Update the options based on the actual control we're binding to
      // This will override user-provided options in favour of the values on the source control
      $.extend( this.options, nodeParams );

      //Create the needed tags.
      this.element.addClass('rating');
      this._container = $('<div class="rating-container"></div>')
      .appendTo(this.element);
    
      this._container.append(  $('<div></div>', { 'class': 'rating-component' }) );     
      $(".rating-component").append( $('<div id="rating-range" class="rating-range"></div>')
    		  .append( $('<div></div>', { 'class': 'rating-selected' }).css( 'height', this.options.starHeight + 'px' ))
    		  .append( $('<div></div>', { 'class': 'rating-hover' }).css( 'height', this.options.starHeight + 'px' ))    		 
      );      
      $(".rating-component").append( $('<div class="rating-title"></div>') );
      $(".rating-component").append( $('<div id="rating-loading" class="rating-loading" style="display:none;"></div>') );
      this._container.append( $('<div class="rating-Comment" style="display:none;"></div>')) ;
      

      // Store references to frequently used elements
      this.container = this.element.parent();
      this.range = $('.rating-range', this.container);
      this.selected = $('.rating-selected', this.container);
      this.hover = $('.rating-hover', this.container);
      this.text = $('.rating-text', this.container);
      this.titleText = $('.rating-title', this.container);     
      this.comment = $('.rating-Comment', this.container); 
      this.titleText.text(keysMap["startTitle"]);     
      //if we are in RTL mode, we have to change the float of the "reset button"
      if ( !this.options.ltr ) {
        this.text.css('float', 'left');
        this.selected.addClass('rating-selected-rtl');
        this.hover.addClass('rating-hover-rtl');
      }

      // Set the correct width on the rating area
      this.range.width( this.options.starWidth * ( this.options.max - this.options.min) ).height( this.options.starHeight );

      // Set the rating if it's available
      if ( this.options.value ) {
        this.selected.width( (this.options.value - this.options.min) * this.options.starWidth );
        if (this.options.showText ) 
        this.text.text( this.options.value );
      }

      if ( !this.options.showText ) {
        this.text.hide();
      }

      if ( !this.options.readOnly ) {
        this.range
          .bind( 'mousemove.rating', function( e ) {
            self._hover( e );
          })
          .bind( 'mouseleave.rating', function( e ) {
            self._blur( e );
          })
          .bind( 'click.rating', function( e ) {
            self.rate( null, e );
          });
      }
      getRateCategories(this.options.channelID,this.options.servletName);
      this._trigger("create");
    },

    _init: function() {
      // Called every time the widget is called without params
      this._trigger("init");
    },

    _setOption: function( key, value ) {
    	debugger;
      // Allows the user to set options after the widget has been instantiated
      var oldValue = this.options[key];

      switch( key ) {
        case 'readonly':
          // Toggle readonly and update the control
          if ( value === true ) {
            this.range.unbind('.rating');
          } 
        break;

        case 'value':
          // Set the value of the control and update the stars
          this.rate( value );
        break;
      }

      $.Widget.prototype._setOption.apply( this, arguments );

      // The widget factory doesn't fire a callback for option changes by default
      // In order to allow the user to respond, fire our own callback
      this._trigger("setOption", { type: "setOption" }, {
        option: key,
        original: oldValue,
        current: value
      });
    },

    _hover: function( event ) {
      var self = this,
          offsetX = event.pageX - self.range.offset().left;

      if ( !this.options.ltr ) offsetX = self.range.width() - offsetX;

      var w = Math.ceil( offsetX / self.options.starWidth * (1 / self.options.step) ) * self.options.starWidth * self.options.step;

      if ( self.options.hoverWidth != w ) {
          self.selected.hide();
          self.hover.width(w).show();
          self.options.hoverWidth = w;
      }
    },

    _blur: function( event ) {
      this.hover.hide().width(0);
      this.selected.show();
    },
    
    rate: function( rating, event ) {
    
   $('.rating-title').html(keysMap["ratingProcessingTitle"]); 
   $("#rating-range").addClass("disabled-rating");
  
      var self = this,
          oldRating = self.options.value,
          numerator = 0;     
      if ( rating === null ) {
        offsetX = event.pageX - self.range.offset().left;

        if ( !this.options.ltr ) numerator = self.range.width() - offsetX;
        numerator = offsetX / self.options.starWidth;
      } else {
        // Set the rating directly
        numerator = rating;
      }

      var value = Math.ceil( numerator / self.options.step ),
          normalizedValue = (value * self.options.step) + self.options.min,
          widthValue = value * self.options.starWidth * self.options.step;

      if ( rating === null ) rating = normalizedValue;

      self.options.value = rating;
      self.element.val( rating );
      self.text.text(rating);
      self.hover.hide();
      self.selected.width( widthValue ).show();

      self._trigger('rate', event, {
        previous: oldRating,
        current: rating
      });
      
      ratingValue=rating;
      $('#rating-loading').show();
      setTimeout( addRate(this.options.channelID,this.options.channelVersion,this.options.userID,this.options.CIF,this.options.sessionId,this.options.pageName,rating,"comment",this.options.servletName), 10);
    
      //add new  Rate      
      $('.rating-title').html(keysMap["startTitle"]);         
      console.log ("add rating Value: " +rating);
     
     
    },

    _reset: function( resetable ) {
      var self = this;
    },

    clear: function( event ) {
      var self = this;

      self.options.value = self.options.min;
      self.element.val( self.options.min );
      self.selected.width(0).show();
      self.hover.hide().width(0);
      self.text.text( self.options.min );

      self._trigger('clear', event );
    },

    destroy: function() {
      // Removes all traces of the widget from the page
      this.range.remove();
      this.text.remove();
      this.element.unwrap( '.rating' );
      this.element.unbind( '.rating' );
      this.element.show();

      $.Widget.prototype.destroy.apply( this );

      this._trigger( 'destroy', { type: 'destroy' }, { options: this.options } );
    }
  });
})(jQuery);


function setRatingOption(rating_div,key,value) {
	debugger;
	$('#'+rating_div).rating("option", key, value);
}

function addRate(channelId,channelVersion,userId,CIF,sessionId,pageName,rateValue,rateComment,catsId,servletName) {
	var  context = window.location.pathname.split("/")[1];
	
		 $.ajax({		    	
				type : "GET",
				url : "/"+context+servletName,
				data : {
					actionId : "1",
					channelID : channelId,
					userID : userId,
					channelVersion : channelVersion,
					CIF : CIF,
					sessionID : sessionId,
					PageName : pageName,
					rateValue : rateValue,
					rateComment : rateComment,
					categoriesID : catsId
				},
				dataType : "json",
				success : function(data, textStatus, jqXHR) {
					console.log ("add rating success");
					
					for ( var key in data) {
						if (data.hasOwnProperty(key)) {
							if (key == "RateID") {
								console.log ("add rate >>>>> RateID: " + data[key]);
								rateId= data[key];  											
							} ;
							if (key == "StatusCode") {
								console.log ("add rate >>>>> statusCode: " + data[key]);
								serverMsg= data[key];
								serverMsgClass="rating-success-msg";								
							} ;	
						};
					};	
					
					$(".rating-Comment").show();
					$(".rating-Comment").append( $('<div ><button type="button" class="rating-feedbackClose-x" onclick="enableRating(); clearCommentDiv(); ">&#215;</button></div>' ));
		    		$(".rating-Comment").append($('<div > <output name="serverMsg" class="serverMsg ' + serverMsgClass +'">'+ keysMap["sucessRatingMsgKey"]+'</output> <h4 class="rating-inlineHead">'+keysMap["descKey"]+'</h4></div>'));
		    		$(".rating-Comment").append($(categoryDiv , { 'class': 'rating-category' }));
		    		$(".rating-Comment").append( $('<div > <textarea class="feedbackText" rows="4" cols="40"></textarea></div>' ));
		    		$(".rating-Comment").append( $('<div class="rating-buttons"> <div id="rating-comment-loading" class="rating-comment-loading" style="display:none;"></div> <button type="button" class="rating-feedbackSubmit" onclick="updateRate('+servletName+'); enableRating();">'+keysMap["submitCommentBtnKey"]+'</button> <button type="button" class="rating-feedbackClose" onclick="enableRating();  clearCommentDiv(); ">'+keysMap["closeCommentBtnKey"]+'</button></div>' ));    		  
				    	
				},
				error : function(jqXHR, textStatus, errorThrown) {
					console.log ("add rating Error: " + textStatus);
					serverMsg= ("Error! " + textStatus);
					serverMsgClass="rating-error-msg";
					$(".rating-Comment").empty();					
					$(".rating-Comment").append( $('<div ><button type="button" class="rating-feedbackClose-x" onclick="enableRating(); this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode); return false; ">&#215;</button></div>' ));
		    		 $(".rating-Comment").append($('<div > <output name="serverMsg" class="serverMsg ' + serverMsgClass +'">'+keysMap["failRatingMsgKey"]+'</output> <p>'+keysMap["descKey"]+'</p></div>'));
		    		
				},
				complete : function(jqXHR, textStatus) {
					console.log("add rating Completed");
					 $(".rating-loading").css("display","none"); 
				}
			});	
		
}

function getLatestRate(channelId,userId,servletName) {
	var  context = window.location.pathname.split("/")[1];
    $.ajax({
  	async: false,  
		type : "GET",
		url : "/"+context+servletName,
		data : {
			actionId : "4",
			channelID : channelId,
			userID : userId
		},
		dataType : "json",
		success : function(data, textStatus, jqXHR) {
			console.log ("load rating success");
			
			for ( var key in data) {
				if (data.hasOwnProperty(key)) {
					if (key == "pervRating") {
						console.log ("Servelt: " + data[key]);
						 ratingValue= data[key];  											
					} ;	
				};
			};	 			
		},
		error : function(jqXHR, textStatus, errorThrown) {
			console.log ("load rating Error: " + textStatus);
		},
		complete : function(jqXHR, textStatus) {
			console.log("load rating Completed");			
		}
	});	
}

function updateRate(servletName) {

	$('#rating-comment-loading').show();
	var catsId='';	
	for(var i=0; i<catsBoxs.length; i++) {
		if(document.getElementById(catsBoxs[i]).checked){
			catsId+=document.getElementById(catsBoxs[i]).value;
			catsId+=',';
		}		
	}
	console.log ("update rating parameters:"+ rateId +"   "+$('.feedbackText').val()+"   "+catsId );
	if($('.feedbackText').val()==""){
		alert("please add your comment:"+$('.feedbackText').val());
		return;
	}
	if (typeof catsId == 'undefined' || catsId.length == 0) {
		alert("please select at least one Category:");
		return;
	}
	var  context = window.location.pathname.split("/")[1];
    $.ajax({ 	
		type : "GET",
		url : "/"+context+servletName,
		data : {
			actionId : "2",
			rateID : rateId,
			rateComment : $('.feedbackText').val(),
			categoriesID : catsId
		},
		dataType : "json",
		success : function(data, textStatus, jqXHR) {
			console.log ("update rating success");
			
			for ( var key in data) {
				if (data.hasOwnProperty(key)) {
					if (key == "StatusCode") {
						console.log ("Servelt: " + data[key]);	
						
						$(".rating-Comment").empty();
						$(".rating-Comment").append($('<div class="rating-fb-msg"></div>'));
						$(".rating-fb-msg").append( $('<div "><button type="button" class="rating-feedbackClose-x" onclick="enableRating(); clearCommentDiv(); ">&#215;</button></div>' ));
						$(".rating-fb-msg").append($('<div class="rating-msg rating-fb-success-msg"> <output name="serverMsg" class="serverMsg">'+ keysMap["sucessCommentKey"]+'</output></div>'));
						$(".serverMsg").addClass( "rating-fb-success-text" );
					} ;	
				};
			};	 			
		},
		error : function(jqXHR, textStatus, errorThrown) {
			console.log ("update rating Error: " + textStatus);
			$(".rating-Comment").empty();
			$(".rating-Comment").append($('<div class="rating-fb-msg"></div>'));
			$(".rating-fb-msg").append( $('<div "><button type="button" class="rating-feedbackClose-x" onclick="enableRating(); clearCommentDiv(); ">'+closeCommentBtnKey+'</button></div>' ));
			$(".rating-fb-msg").append($('<div clas="rating-msg rating-fb-error-msg"> <output name="serverMsg" class="serverMsg"> ERROR! '+keysMap["failCommentMsgKey"]+'</output>'));			
			$(".serverMsg").addClass( "rating-fb-error-msg" );
		},
		complete : function(jqXHR, textStatus) {
			$('#rating-comment-loading').hide();
			console.log("update rating Completed");			
		}
	});	
    
}
function enableRating() {
	console.log("try to remove");	
	 $("#rating-range").removeClass("disabled-rating"); 
}

function clearCommentDiv() {
	console.log("Clear Comment DIV");
	$(".rating-Comment").empty();
	$(".rating-Comment").hide();
	
}
function getRateCategories(channelId,servletName) {

	
	var  context = window.location.pathname.split("/")[1];
    $.ajax({
  	async: false,  
		type : "GET",
		url : "/"+context+servletName,
		data : {
			actionId : "3",
			channelID : channelId   		
		},
		dataType : "json",
		success : function(data, textStatus, jqXHR) {
			console.log ("rating Categories success");
			for ( var key in data) {
				if (data.hasOwnProperty(key)) {
					if (key == "StatusCode") {
						console.log ("Servelt: " + data[key]);						
						// $(".serverMsg").html(data[key]);
						 alert("rating="+ratingValue + " -------- text:"+$('.feedbackText').val());
					} ;	
					if (key == "Cats") {
					 var catList = $.parseJSON(data[key]);
					 drawCategoryDiv(catList);
					}
				};
			};	 			
		},
		error : function(jqXHR, textStatus, errorThrown) {
			console.log ("rating Categories Error: " + textStatus);
		},
		complete : function(jqXHR, textStatus) {
			console.log("rating Categories Completed");			
		}
	});	
}
function drawCategoryDiv(catList) {
	categoryDiv='<div class="rating-category clearfix">';
	$.each(catList, function(index, category) {
		if(!$.isEmptyObject(category)){
			if(lang == "en"){
				categoryDiv +=	'<label><input type="checkbox" id="catCheckbox'+index+'" value="'+category.categoryId+'"><span>' +category.categoryNameEn+'</span></label>';				
			}
			else
				categoryDiv +=	'<label><input type="checkbox" id="catCheckbox'+index+'" value="'+category.categoryId+'"><span>' +category.categoryNameAr+'</span></label>';
			}	
		catsBoxs.push("catCheckbox"+index);
	});
	categoryDiv+="</div>";	
	console.log("categoryDiv:"+categoryDiv);	
}