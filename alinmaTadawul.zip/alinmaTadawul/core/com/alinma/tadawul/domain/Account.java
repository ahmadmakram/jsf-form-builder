/**
 * 
 */
package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.Language;

/**
 * @author mbrins
 * 
 */
public class Account extends BusinessObject {

	private String accountNumber;
	private EntityKey accountType;
	private String iban;
	private String accountName;
	private String shortDesc;
	private String accountNickName;
	private EntityKey accountStatus;
	private EntityKey accountCurrency;
	private Double availableBalance;
	private Double ledgerBalance;
	private Double currentBalance;
	private Boolean subUsrEnabled;
	private String acctFuncsAccess;
	private EntityKey deliveryOption;
	private String deliveryLocation;
	private Language stmtPreferredLang;
	private String branchId;
	private Boolean atmCardExist;
	private String signId;
	private EntityKey countryCode;
	private EntityKey bankCode;
	private String mnemonicName;

	public EntityKey getAccountType() {
		return accountType;
	}

	public void setAccountType(EntityKey accountType) {
		this.accountType = accountType;
	}

	public String getIban() {
		return iban;
	}

	public String getFormatedIban() {
		String formatedIban = "";
		if (iban != null) {
			char[] ibanArray = iban.toCharArray();
			for (int i = 0; i < ibanArray.length; i++) {
				formatedIban = formatedIban + ibanArray[i];
				if (i == 3 || i == 7 || i == 11 || i == 15 || i == 19) {
					formatedIban = formatedIban + " ";
				}
			}
		}
		return formatedIban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public String getAccountNickName() {
		return accountNickName;
	}

	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}

	public EntityKey getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(EntityKey accountStatus) {
		this.accountStatus = accountStatus;
	}

	public EntityKey getAccountCurrency() {
		return accountCurrency;
	}

	public void setAccountCurrency(EntityKey accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	public Double getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance = availableBalance;
	}

	public Double getLedgerBalance() {
		return ledgerBalance;
	}

	public void setLedgerBalance(Double ledgerBalance) {
		this.ledgerBalance = ledgerBalance;
	}

	public Double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public Boolean getSubUsrEnabled() {
		return subUsrEnabled;
	}

	public void setSubUsrEnabled(Boolean subUsrEnabled) {
		this.subUsrEnabled = subUsrEnabled;
	}

	public String getAcctFuncsAccess() {
		return acctFuncsAccess;
	}

	public void setAcctFuncsAccess(String acctFuncsAccess) {
		this.acctFuncsAccess = acctFuncsAccess;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public EntityKey getDeliveryOption() {
		return deliveryOption != null ? deliveryOption : new EntityDefaultKey("NONE");
	}

	public void setDeliveryOption(EntityKey deliveryOption) {
		this.deliveryOption = deliveryOption;
	}

	public String getDeliveryLocation() {
		return deliveryLocation;
	}

	public void setDeliveryLocation(String deliveryLocation) {
		this.deliveryLocation = deliveryLocation;
	}

	public Language getStmtPreferredLang() {
		return stmtPreferredLang;
	}

	public void setStmtPreferredLang(Language stmtPreferredLang) {
		this.stmtPreferredLang = stmtPreferredLang;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public Boolean getATMCardExist() {
		return atmCardExist;
	}

	public void setATMCardExist(Boolean cardExist) {
		atmCardExist = cardExist;
	}

	public String getSignId() {
		return signId;
	}

	public void setSignId(String signId) {
		this.signId = signId;
	}

	public static Account createAccount() {
		return new Account();
	}

	public EntityKey getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(EntityKey countryCode) {
		this.countryCode = countryCode;
	}

	public EntityKey getBankCode() {
		return bankCode;
	}

	public void setBankCode(EntityKey bankCode) {
		this.bankCode = bankCode;
	}

	public void setMnemonicName(String mnemonicName) {
		this.mnemonicName = mnemonicName;
	}

	public String getMnemonicName() {
		return mnemonicName;
	}
}
