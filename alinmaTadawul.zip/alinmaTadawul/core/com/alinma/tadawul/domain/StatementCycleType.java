package com.alinma.tadawul.domain;

import java.util.Hashtable;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum StatementCycleType implements EntityKey {
	STATEMENT("1"), CURRENT_CYCLE("2"), HISTORICAL("3");

	private String code;
	private static Map<String, StatementCycleType> map;
	static {
		map = new Hashtable<String, StatementCycleType>();
		for (StatementCycleType value : StatementCycleType.values()) {
			map.put(value.getCode(), value);
		}
	}

	StatementCycleType(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static StatementCycleType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
