package com.alinma.tadawul.domain;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum Priority implements EntityKey {
	HIGH("HIGH"), MEDIUM("MEDIUM"), LOW("LOW");

	private String code;
	private static Map<String, Priority> map;
	static {
		map = new Hashtable<String, Priority>();
		for (Priority value : Priority.values()) {
			map.put(value.getCode(), value);
		}
	}

	Priority(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static Priority getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
