package com.alinma.tadawul.domain;

import org.hibernate.validator.NotNull;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.lov.AccountId;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class BankAccount extends BusinessObject {

	private SurrogateKey surrogateKey;
	private EntityKey bankId;
	private AccountId accountId;

	@NotNull(message = "{account.bankName.required}")
	public EntityKey getBankId() {
		return bankId;
	}

	public void setBankId(EntityKey bankId) {
		this.bankId = bankId;
	}

	public AccountId getAccountId() {
		if (this.accountId == null) {
			this.accountId = createAccountId();
		}
		return accountId;
	}

	public AccountId createAccountId() {
		return (AccountId) ApplicationContextFactory.getApplicationContext().getBean("accountId");
	}

	public void setAccountId(AccountId accountId) {
		this.accountId = accountId;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}
}
