package com.alinma.tadawul.domain;

import java.util.List;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.ReserveDeletedList;
import com.alinma.tadawul.ApplicationContextFactory;

public class CustomerEssentialCoreInfo extends BusinessObject {

	private CustomerAddress homeAddress;
	private CustomerContact homeContacts;
	private List<CustomerIdDoc> idDocs;

	public CustomerAddress getHomeAdrress() {
		if (homeAddress == null) {
			homeAddress = createHomeAddress();
		}
		return homeAddress;
	}

	public CustomerAddress createHomeAddress() {
		return (CustomerAddress) ApplicationContextFactory.getApplicationContext().getBean("customerAddress");
	}

	public void setHomeAdrress(CustomerAddress homeAddress) {
		this.homeAddress = homeAddress;
	}

	public CustomerContact getHomeContacts() {
		if (homeContacts == null) {
			homeContacts = createHomeContact();
		}
		return homeContacts;
	}

	public CustomerContact createHomeContact() {
		return (CustomerContact) ApplicationContextFactory.getApplicationContext().getBean("customerContact");
	}

	public void setHomeContacts(CustomerContact homeContacts) {
		this.homeContacts = homeContacts;
	}

	public List<CustomerIdDoc> getIdDocs() {
		if (this.idDocs == null) {
			this.idDocs = new ReserveDeletedList<CustomerIdDoc>();
		}
		return idDocs;
	}

	public void setIdDocs(List<CustomerIdDoc> idDocs) {
		this.idDocs = idDocs;
	}

	public void addIdDoc() {
		if (this.idDocs == null) {
			this.idDocs = new ReserveDeletedList<CustomerIdDoc>();
		}
		this.idDocs.add(createIdDoc());
	}

	public CustomerIdDoc createIdDoc() {
		return (CustomerIdDoc) ApplicationContextFactory.getApplicationContext().getBean("customerIdDoc");
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (homeAddress != null) {
			homeAddress.CommitUpdates();
		}
		if (homeContacts != null) {
			homeContacts.CommitUpdates();
		}
		if (idDocs != null) {
			((ReserveDeletedList) idDocs).CommitUpdates();
		}
	}
}
