package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public class Bank extends BusinessObject {

	private EntityKey code;
	private String bankName;
	private String branch;
	private EntityKey branchId;
	private String address;
	private EntityKey city;

	public EntityKey getCode() {
		return code;
	}

	public void setCode(EntityKey code) {
		this.code = code;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public EntityKey getCity() {
		return city;
	}

	public void setCity(EntityKey city) {
		this.city = city;
	}

	public EntityKey getBranchId() {
		return branchId;
	}

	public void setBranchId(EntityKey branchId) {
		this.branchId = branchId;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getBranchName() {
		if (getBranchId() != null) {
			return this.branchId.getCode();
		} else if (getBranch() != null) {
			return branch;
		}
		return "";
	}

	public void setBranchName() {
	}
}
