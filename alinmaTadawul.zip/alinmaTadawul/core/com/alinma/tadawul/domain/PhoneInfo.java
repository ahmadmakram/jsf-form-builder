package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * Holds the phone information record.
 * 
 * @author Hani Younis
 * 
 */
public class PhoneInfo extends BusinessObject {

	private String phoneCityCode;
	private EntityKey phoneCountryCode;
	private String phoneExtension;
	private String phoneNumber;
	private EntityKey phoneCategory;
	private EntityKey phoneType;

	/**
	 * @return the phoneCityCode
	 */
	public String getPhoneCityCode() {
		return phoneCityCode;
	}

	/**
	 * @param phoneCityCode
	 *            the phoneCityCode to set
	 */
	public void setPhoneCityCode(String phoneCityCode) {
		this.phoneCityCode = phoneCityCode;
	}

	/**
	 * @return the phoneCountryCode
	 */
	public EntityKey getPhoneCountryCode() {
		return phoneCountryCode;
	}

	/**
	 * @param phoneCountryCode
	 *            the phoneCountryCode to set
	 */
	public void setPhoneCountryCode(EntityKey phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}

	/**
	 * @return the phoneExtension
	 */
	public String getPhoneExtension() {
		return phoneExtension;
	}

	/**
	 * @param phoneExtension
	 *            the phoneExtension to set
	 */
	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber
	 *            the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFullPhoneNumber() {
		String fullPhoneNumber = "";
		if (phoneCountryCode != null && phoneCountryCode.getCode() != null) {
			fullPhoneNumber += phoneCountryCode.getCode() + "-";
		}
		fullPhoneNumber += (phoneCityCode == null ? "" : (phoneCityCode + "-"));
		fullPhoneNumber += (phoneNumber == null ? "" : phoneNumber);
		fullPhoneNumber += (phoneExtension == null ? "" : phoneExtension);
		return fullPhoneNumber;
	}

	public static PhoneInfo createPhoneInfo() {
		return new PhoneInfo();
	}
}
