package com.alinma.tadawul.domain;

import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.IdDocKey;

/**
 * 
 * @author Hani Younis
 * 
 */
public class RegistrationInfo {

	private Account account;
	private String captchaText;
	private TadawulUser user;
	private EntityKey targetChannel;
	private String activationCode;

	public Account getAccount() {
		if (account == null) {
			this.account = createAccount();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public void setCaptchaText(String captchaText) {
		this.captchaText = captchaText;
	}

	public String getCaptchaText() {
		return captchaText;
	}

	public Card createCard() {
		return new Card();
	}

	public Account createAccount() {
		return new Account();
	}

	public IdDocKey createIdDocKey() {
		return new IdDocKey();
	}

	public TadawulUser getUser() {
		if (user == null) {
			this.user = createTadawulUser();
		}
		return user;
	}

	private TadawulUser createTadawulUser() {
		return new TadawulUser();
	}

	public void setUser(TadawulUser user) {
		this.user = user;
	}

	public void setTargetChannel(EntityKey targetChannel) {
		this.targetChannel = targetChannel;
	}

	public EntityKey getTargetChannel() {
		return targetChannel;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public String getActivationCode() {
		return activationCode;
	}
}
