package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

public class CustomerBankInfo extends BusinessObject {

	private String SAMAApprovalNum;
	private CombinedDate SAMAApprovalDate;
	private Boolean blackListed;
	private EntityKey SAMARiskCategory;
	private EntityKey creationBranch;
	private EntityKey SAMAStatus;
	private CombinedDate customerStatusDate;
	private EntityKey customerStatus;
	private CombinedDate statusChangeDate;
	private EntityKey statusChangeReason;
	private String statusReasonExplanation;
	private CombinedDate lastAmendmentDate;
	private String lastAmendmentUser;
	private Integer recordVersion;
	private Boolean finalExitVisaFlag;
	private CombinedDate finalExitVisaDate;

	public String getSAMAApprovalNum() {
		return SAMAApprovalNum;
	}

	public void setSAMAApprovalNum(String approvalNum) {
		SAMAApprovalNum = approvalNum;
	}

	public CombinedDate getSAMAApprovalDate() {
		return SAMAApprovalDate;
	}

	public void setSAMAApprovalDate(CombinedDate approvalDate) {
		SAMAApprovalDate = approvalDate;
	}

	public Boolean getBlackListed() {
		return blackListed;
	}

	public void setBlackListed(Boolean blackListed) {
		this.blackListed = blackListed;
	}

	// @NotNull(message="{customerBankInfo.samaRiskCategoryRequired}")
	public EntityKey getSAMARiskCategory() {
		return SAMARiskCategory;
	}

	public void setSAMARiskCategory(EntityKey riskCategory) {
		SAMARiskCategory = riskCategory;
	}

	public EntityKey getCreationBranch() {
		return creationBranch;
	}

	public void setCreationBranch(EntityKey creationBranch) {
		this.creationBranch = creationBranch;
	}

	public EntityKey getSAMAStatus() {
		return SAMAStatus;
	}

	public void setSAMAStatus(EntityKey status) {
		SAMAStatus = status;
	}

	public EntityKey getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(EntityKey customerStatus) {
		this.customerStatus = customerStatus;
	}

	public CombinedDate getStatusChangeDate() {
		return statusChangeDate;
	}

	public void setStatusChangeDate(CombinedDate statusChangeDate) {
		this.statusChangeDate = statusChangeDate;
	}

	public EntityKey getStatusChangeReason() {
		return statusChangeReason;
	}

	public void setStatusChangeReason(EntityKey statusChangeReason) {
		this.statusChangeReason = statusChangeReason;
	}

	public void setStatusReasonExplanation(String statusReasonExplanation) {
		this.statusReasonExplanation = statusReasonExplanation;
	}

	public String getStatusReasonExplanation() {
		return statusReasonExplanation;
	}

	public CombinedDate getLastAmendmentDate() {
		return lastAmendmentDate;
	}

	public void setLastAmendmentDate(CombinedDate lastAmendmentDate) {
		this.lastAmendmentDate = lastAmendmentDate;
	}

	public String getLastAmendmentUser() {
		return lastAmendmentUser;
	}

	public void setLastAmendmentUser(String lastAmendmentUser) {
		this.lastAmendmentUser = lastAmendmentUser;
	}

	/**
	 * @return the recordVersion
	 */
	public Integer getRecordVersion() {
		return recordVersion;
	}

	/**
	 * @param recordVersion
	 *            the recordVersion to set
	 */
	public void setRecordVersion(Integer recordVersion) {
		this.recordVersion = recordVersion;
	}

	/**
	 * @return the customerStatusDate
	 */
	public CombinedDate getCustomerStatusDate() {
		return customerStatusDate;
	}

	/**
	 * @param customerStatusDate
	 *            the customerStatusDate to set
	 */
	public void setCustomerStatusDate(CombinedDate customerStatusDate) {
		this.customerStatusDate = customerStatusDate;
	}

	/**
	 * @return the finalExitVisaFlag
	 */
	public Boolean getFinalExitVisaFlag() {
		return finalExitVisaFlag;
	}

	/**
	 * @param finalExitVisaFlag
	 *            the finalExitVisaFlag to set
	 */
	public void setFinalExitVisaFlag(Boolean finalExitVisaFlag) {
		this.finalExitVisaFlag = finalExitVisaFlag;
	}

	/**
	 * @return the finalExitVisaDate
	 */
	public CombinedDate getFinalExitVisaDate() {
		return finalExitVisaDate;
	}

	/**
	 * @param finalExitVisaDate
	 *            the finalExitVisaDate to set
	 */
	public void setFinalExitVisaDate(CombinedDate finalExitVisaDate) {
		this.finalExitVisaDate = finalExitVisaDate;
	}
}
