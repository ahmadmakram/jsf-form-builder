package com.alinma.tadawul.domain;

import org.hibernate.validator.NotNull;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

public class CustomerProfessionalInfo extends BusinessObject {

	private EntityKey educationLevel;
	private EntityKey employmentIndicator; // Employment Status
	private Boolean bankEmployee;
	private EntityKey businessSector;
	private EntityKey occupation;
	private String employerName;
	// TODO add to domain
	private PartyRelation employerId;
	private CombinedDate employmentDate;
	private String jobTitle;
	private EntityKey employmentIndustry;
	private EntityKey employmentSubIndustry;

	public EntityKey getEducationLevel() {
		return educationLevel;
	}

	public void setEducationLevel(EntityKey educationLevel) {
		this.educationLevel = educationLevel;
	}

	public EntityKey getEmploymentIndicator() {
		return employmentIndicator;
	}

	public void setEmploymentIndicator(EntityKey employmentIndicator) {
		this.employmentIndicator = employmentIndicator;
	}

	public Boolean getBankEmployee() {
		return bankEmployee;
	}

	public void setBankEmployee(Boolean bankEmployee) {
		this.bankEmployee = bankEmployee;
	}

	public EntityKey getOccupation() {
		return occupation;
	}

	public void setOccupation(EntityKey occupation) {
		this.occupation = occupation;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public PartyRelation getEmployerId() {
		if (employerId == null) {
			employerId = createEmployerId();
		}
		return employerId;
	}

	public PartyRelation createEmployerId() {
		return (PartyRelation) ApplicationContextFactory.getApplicationContext().getBean("partyRelation");
	}

	public void setEmployerId(PartyRelation employerId) {
		this.employerId = employerId;
	}

	public CombinedDate getEmploymentDate() {
		return employmentDate;
	}

	public void setEmploymentDate(CombinedDate employmentDate) {
		this.employmentDate = employmentDate;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	@NotNull(message = "{customerProfessionalInfo.industryRequired}")
	public EntityKey getEmploymentIndustry() {
		return employmentIndustry;
	}

	public void setEmploymentIndustry(EntityKey employmentIndustry) {
		if (employmentIndustry == null) {
			return;
		}
		this.employmentIndustry = employmentIndustry;
	}

	@NotNull(message = "{customerProfessionalInfo.subIndustryRequired}")
	public EntityKey getEmploymentSubIndustry() {
		return employmentSubIndustry;
	}

	public void setEmploymentSubIndustry(EntityKey employmentSubIndustry) {
		if (employmentSubIndustry == null) {
			return;
		}
		this.employmentSubIndustry = employmentSubIndustry;
	}

	/**
	 * @return the businessSector
	 */
	public EntityKey getBusinessSector() {
		return businessSector;
	}

	/**
	 * @param businessSector
	 *            the businessSector to set
	 */
	public void setBusinessSector(EntityKey businessSector) {
		this.businessSector = businessSector;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (employerId != null) {
			employerId.CommitUpdates();
		}
	}
}
