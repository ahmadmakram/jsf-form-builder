package com.alinma.tadawul.domain;

import com.alinma.tadawul.domain.lov.NotificationMethodType;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author mahamoda
 * 
 */
public class RetainedMsg extends BusinessObject {

	private EntityKey msgId;
	private NotificationMethodType notificationMethod;
	private String msgHeader;
	private Boolean readMsg;
	private Boolean deletedMsg;
	private CombinedDate receivedDate;
	private String msgBody;
	private String unReadMsgs;
	private boolean msgSelected = false;

	public boolean isMsgSelected() {
		return msgSelected;
	}

	public void setMsgSelected(boolean msgSelected) {
		this.msgSelected = msgSelected;
	}

	public EntityKey getMsgId() {
		return msgId;
	}

	public void setMsgId(EntityKey msgId) {
		this.msgId = msgId;
	}

	public NotificationMethodType getNotificationMethod() {
		return notificationMethod;
	}

	public void setNotificationMethod(NotificationMethodType notificationMethod) {
		this.notificationMethod = notificationMethod;
	}

	public String getMsgHeader() {
		return msgHeader;
	}

	public void setMsgHeader(String msgHeader) {
		this.msgHeader = msgHeader;
	}

	public Boolean getReadMsg() {
		return readMsg;
	}

	public void setReadMsg(Boolean readMsg) {
		this.readMsg = readMsg;
	}

	public Boolean getDeletedMsg() {
		return deletedMsg;
	}

	public void setDeletedMsg(Boolean deletedMsg) {
		this.deletedMsg = deletedMsg;
	}

	public CombinedDate getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(CombinedDate receivedDate) {
		this.receivedDate = receivedDate;
	}

	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}

	public String getMsgBody() {
		return msgBody;
	}

	public void setUnReadMsgs(String unReadMsgs) {
		this.unReadMsgs = unReadMsgs;
	}

	public String getUnReadMsgs() {
		return unReadMsgs;
	}
}
