package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class Income extends BusinessObject {

	private Boolean applicability = false;
	private Float amount; // A flag if the current income is applicable
	// Not applicable in all types of income, for example in the case of end service income
	private EntityKey frequence;
	// Not applicable in all types of income, for example in the case of end service income
	private EntityKey receivingMethod; // The method with which the income is received.
	private String description;

	/**
	 * @return the amount
	 */
	public Float getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(Float amount) {
		this.amount = amount;
	}

	/**
	 * @return the applicable
	 */
	public Boolean getApplicability() {
		return applicability;
	}

	/**
	 * @param applicable
	 *            the applicable to set
	 */
	public void setApplicability(Boolean applicable) {
		this.applicability = applicable;
	}

	/**
	 * @return the incomeFrequence
	 */
	public EntityKey getFrequence() {
		return frequence;
	}

	/**
	 * @param incomeFrequence
	 *            the incomeFrequence to set
	 */
	public void setFrequence(EntityKey frequence) {
		this.frequence = frequence;
	}

	/**
	 * @return the receivingMethod
	 */
	public EntityKey getReceivingMethod() {
		return receivingMethod;
	}

	/**
	 * @param receivingMethod
	 *            the receivingMethod to set
	 */
	public void setReceivingMethod(EntityKey receivingMethod) {
		this.receivingMethod = receivingMethod;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
