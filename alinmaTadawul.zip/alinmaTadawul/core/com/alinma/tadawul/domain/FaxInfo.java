package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class FaxInfo extends BusinessObject {

	private String faxCityCode;
	private EntityKey faxCountryCode;
	private String faxExtension;
	private String faxNumber;

	public String getFaxCityCode() {
		return faxCityCode;
	}

	public void setFaxCityCode(String faxCityCode) {
		this.faxCityCode = faxCityCode;
	}

	public EntityKey getFaxCountryCode() {
		return faxCountryCode;
	}

	public void setFaxCountryCode(EntityKey faxCountryCode) {
		this.faxCountryCode = faxCountryCode;
	}

	public String getFaxExtension() {
		return faxExtension;
	}

	public void setFaxExtension(String faxExtension) {
		this.faxExtension = faxExtension;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
}
