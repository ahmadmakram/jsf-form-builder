package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.Bank;
import com.alinma.tadawul.domain.lov.BeneficiaryType;
import com.alinma.tadawul.domain.lov.BeneficiaryStatus;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.PaginationInRec;

/**
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiariesReqMsgCore implements MessageBodyCore {

	private EntityKey country;
	private EntityKey currency;
	private String userId;
	private String functionId;
	private PaginationInRec paginationInRec;
	private BeneficiaryType beneficiaryType;
	private Bank bank;
	private BeneficiaryStatus beneficiaryStatus;

	public EntityKey getCountry() {
		return country;
	}

	public void setCountry(EntityKey country) {
		this.country = country;
	}

	public EntityKey getCurrency() {
		return currency;
	}

	public void setCurrency(EntityKey currency) {
		this.currency = currency;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public PaginationInRec getPaginationInRec() {
		return paginationInRec;
	}

	public void setPaginationInRec(PaginationInRec paginationInRec) {
		this.paginationInRec = paginationInRec;
	}

	public void setBeneficiaryType(BeneficiaryType beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}

	public BeneficiaryType getBeneficiaryType() {
		return beneficiaryType;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBeneficiaryStatus(BeneficiaryStatus beneficiaryStatus) {
		this.beneficiaryStatus = beneficiaryStatus;
	}

	public BeneficiaryStatus getBeneficiaryStatus() {
		return beneficiaryStatus;
	}
}
