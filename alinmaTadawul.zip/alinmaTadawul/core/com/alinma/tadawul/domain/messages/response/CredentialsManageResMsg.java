/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Hani Younis
 * 
 */
public class CredentialsManageResMsg extends ResponseMessage<CredentialsManageResMsgCore> {

	public CredentialsManageResMsg() {
		super();
	}
}
