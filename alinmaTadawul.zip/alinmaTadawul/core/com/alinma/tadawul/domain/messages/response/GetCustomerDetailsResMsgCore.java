/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * The response message core for the Get Customer Details.
 * 
 * @author Hani Younis
 * 
 */
public class GetCustomerDetailsResMsgCore implements MessageBodyCore {

	private TadawulUser user;

	public void setUser(TadawulUser user) {
		this.user = user;
	}

	public TadawulUser getUser() {
		return user;
	}
}
