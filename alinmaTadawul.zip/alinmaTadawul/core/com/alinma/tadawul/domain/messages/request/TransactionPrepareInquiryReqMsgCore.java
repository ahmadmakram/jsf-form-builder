package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.Amount;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class TransactionPrepareInquiryReqMsgCore implements MessageBodyCore {

	private static final int EX_RATE_DIMEN_LENGTH = 3;
	private static final int FEE_DIMEN_LENGTH = 3;
	private static final int AUTHENT_METHOD_DIMEN_LENGTH = 3;
	private String funcId;
	private String[] exRateDimen = new String[EX_RATE_DIMEN_LENGTH];
	private String[] feeDimen = new String[FEE_DIMEN_LENGTH];
	private String[] authentMethodDimen = new String[AUTHENT_METHOD_DIMEN_LENGTH];
	private Amount sourceCurrencyAmount;
	private Amount targetCurrencyAmount;

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String[] getExRateDimen() {
		return exRateDimen;
	}

	public void setExRateDimen(String[] exRateDimen) {
		this.exRateDimen = exRateDimen;
	}

	public String[] getFeeDimen() {
		return feeDimen;
	}

	public void setFeeDimen(String[] feeDimen) {
		this.feeDimen = feeDimen;
	}

	public String[] getAuthentMethodDimen() {
		return authentMethodDimen;
	}

	public void setAuthentMethodDimen(String[] authentMethodDimen) {
		this.authentMethodDimen = authentMethodDimen;
	}

	public Amount getSourceCurrencyAmount() {
		return sourceCurrencyAmount;
	}

	public void setSourceCurrencyAmount(Amount sourceCurrencyAmount) {
		this.sourceCurrencyAmount = sourceCurrencyAmount;
	}

	public Amount getTargetCurrencyAmount() {
		return targetCurrencyAmount;
	}

	public void setTargetCurrencyAmount(Amount targetCurrencyAmount) {
		this.targetCurrencyAmount = targetCurrencyAmount;
	}
}
