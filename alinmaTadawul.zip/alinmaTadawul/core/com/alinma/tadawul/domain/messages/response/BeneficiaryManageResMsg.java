package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageResMsg extends ResponseMessage<BeneficiaryManageResMsgCore> {

	public BeneficiaryManageResMsg() {
		super();
	}
}
