/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.LogoutType;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class SessionTerminationReqMsgCore implements MessageBodyCore {

	private LogoutType logoutType;
	private String logoutReason;

	public LogoutType getLogoutType() {
		return logoutType;
	}

	public void setLogoutType(LogoutType logoutType) {
		this.logoutType = logoutType;
	}

	public String getLogoutReason() {
		return logoutReason;
	}

	public void setLogoutReason(String logoutReason) {
		this.logoutReason = logoutReason;
	}
}
