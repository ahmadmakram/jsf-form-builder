package com.alinma.tadawul.domain.messages.request;

import java.util.List;

import com.alinma.tadawul.domain.TransactionCredential;
import com.alinma.tadawul.domain.UserCredential;
import com.ejada.commons.dao.messages.MessageBodyCore;

public class UserAuthenticationReqMsgCore implements MessageBodyCore {

	protected UserCredential userCredential;
	private List<TransactionCredential> credentialInfoList;

	public UserCredential getUserCredential() {
		return userCredential;
	}

	public void setUserCredential(UserCredential userCredential) {
		this.userCredential = userCredential;
	}

	public List<TransactionCredential> getCredentialInfoList() {
		return credentialInfoList;
	}

	public void setCredentialInfoList(List<TransactionCredential> credentialInfoList) {
		this.credentialInfoList = credentialInfoList;
	}
}
