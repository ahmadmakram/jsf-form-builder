/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.PaginationInRec;
import com.alinma.tadawul.domain.FunctionAuthentMethod;

import com.alinma.tadawul.domain.UserCredential;

/**
 * @author Hani Younis
 * 
 */
public class FunctionAuthentMethodReqMsgCore implements MessageBodyCore {

	private String funcId;
	private String[] functionAuthentDimensions = new String[FunctionAuthentMethod.DIMENSOIONSSIZE];
	private String sourceCurrencyAmount;
	private EntityKey currency;
	private String localCurrencyAmount;

	public String getFuncId() {
		return funcId;
	}

	public String[] getFunctionAuthentDimensions() {
		return functionAuthentDimensions;
	}

	public String getSourceCurrencyAmount() {
		return sourceCurrencyAmount;
	}

	public String getLocalCurrencyAmount() {
		return localCurrencyAmount;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public void setFunctionAuthentDimensions(String[] functionAuthentDimensions) {
		this.functionAuthentDimensions = functionAuthentDimensions;
	}

	public void setSourceCurrencyAmount(String sourceCurrencyAmount) {
		this.sourceCurrencyAmount = sourceCurrencyAmount;
	}

	public void setLocalCurrencyAmount(String localCurrencyAmount) {
		this.localCurrencyAmount = localCurrencyAmount;
	}

	public void setCurrency(EntityKey currency) {
		this.currency = currency;
	}

	public EntityKey getCurrency() {
		return currency;
	}
}
