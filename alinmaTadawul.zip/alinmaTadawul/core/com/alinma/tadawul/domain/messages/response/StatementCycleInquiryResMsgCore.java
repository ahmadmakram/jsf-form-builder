package com.alinma.tadawul.domain.messages.response;

import java.util.List;

import com.alinma.tadawul.domain.StatementCycle;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementCycleInquiryResMsgCore implements MessageBodyCore {

	private List<StatementCycle> StatementCycleList;
	private PaginationOutRec paginationOutRec;

	public List<StatementCycle> getStatementCycleList() {
		return StatementCycleList;
	}

	public void setStatementCycleList(List<StatementCycle> statementCycleList) {
		StatementCycleList = statementCycleList;
	}

	public PaginationOutRec getPaginationOutRec() {
		return paginationOutRec;
	}

	public void setPaginationOutRec(PaginationOutRec paginationOutRec) {
		this.paginationOutRec = paginationOutRec;
	}
}
