package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.Beneficiary;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageReqMsgCore implements MessageBodyCore {

	private Beneficiary beneficiary;

	public Beneficiary getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Beneficiary beneficiary) {
		this.beneficiary = beneficiary;
	}
}
