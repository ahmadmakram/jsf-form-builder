package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.alinma.tadawul.domain.TadawulUser;

/**
 * @author Hani.Younis
 * 
 */
public class UserDetailsInquiryResMsgCore implements MessageBodyCore {

	private TadawulUser tadawulUser;

	public void setTadawulUser(TadawulUser tadawulUser) {
		this.tadawulUser = tadawulUser;
	}

	public TadawulUser getTadawulUser() {
		return tadawulUser;
	}
}
