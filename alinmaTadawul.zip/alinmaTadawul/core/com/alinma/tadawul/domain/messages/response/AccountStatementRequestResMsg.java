package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Mohammad Suliman
 * 
 */
public class AccountStatementRequestResMsg extends ResponseMessage<AccountStatementRequestResMsgCore> {

	public AccountStatementRequestResMsg() {
		super();
	}
}
