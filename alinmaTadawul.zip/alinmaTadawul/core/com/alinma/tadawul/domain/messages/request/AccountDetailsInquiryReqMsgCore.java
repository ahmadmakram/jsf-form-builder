package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.Account;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class AccountDetailsInquiryReqMsgCore implements MessageBodyCore {

	private Account account;

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
}
