package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.Card;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Mohammad Suliman
 * 
 */
public class AccountStatementRequestReqMsgCore implements MessageBodyCore {

	private EntityKey statementDelivery;
	private Account account;
	private Card card;
	private CombinedDate startDate;
	private CombinedDate endDate;
	private String statementPeriod;
	private boolean dateFromList = true;

	public boolean isDateFromList() {
		return dateFromList;
	}

	public void setDateFromList(boolean dateFromList) {
		this.dateFromList = dateFromList;
	}

	public EntityKey getStatementDelivery() {
		return statementDelivery;
	}

	public void setStatementDelivery(EntityKey statementDelivery) {
		this.statementDelivery = statementDelivery;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Card getCard() {
		return card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public CombinedDate getStartDate() {
		return startDate;
	}

	public void setStartDate(CombinedDate startDate) {
		this.startDate = startDate;
	}

	public CombinedDate getEndDate() {
		return endDate;
	}

	public void setEndDate(CombinedDate endDate) {
		this.endDate = endDate;
	}

	public String getStatementPeriod() {
		return statementPeriod;
	}

	public void setStatementPeriod(String statementPeriod) {
		this.statementPeriod = statementPeriod;
	}
}
