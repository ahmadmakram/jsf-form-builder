/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class SessionTerminationReqMsg extends RequestMessage<SessionTerminationReqMsgCore> {

	public SessionTerminationReqMsg() {
		super();
	}
}
