package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Hani.Younis
 * 
 */
public class UserManageResMsgCore implements MessageBodyCore {

	private TadawulUser TadawulUser;

	public TadawulUser getTadawulUser() {
		return TadawulUser;
	}

	public void setTadawulUser(TadawulUser tadawulUser) {
		TadawulUser = tadawulUser;
	}
}
