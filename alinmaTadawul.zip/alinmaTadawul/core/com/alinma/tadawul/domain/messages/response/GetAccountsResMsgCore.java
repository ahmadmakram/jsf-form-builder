/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import java.util.List;

import com.alinma.tadawul.domain.Account;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;

/**
 * @author mbrins
 * 
 */
public class GetAccountsResMsgCore implements MessageBodyCore {

	private List<Account> accounts;
	private PaginationOutRec paginationOut;

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public PaginationOutRec getPaginationOut() {
		return paginationOut;
	}

	public void setPaginationOut(PaginationOutRec paginationOut) {
		this.paginationOut = paginationOut;
	}
}
