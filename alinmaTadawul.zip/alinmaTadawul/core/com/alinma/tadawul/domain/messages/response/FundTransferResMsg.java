package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class FundTransferResMsg extends ResponseMessage<FundTransferResMsgCore> {

	public FundTransferResMsg() {
		super();
	}
}
