package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageReqMsg extends RequestMessage<BeneficiaryManageReqMsgCore> {

	public BeneficiaryManageReqMsg() {
		super();
	}
}
