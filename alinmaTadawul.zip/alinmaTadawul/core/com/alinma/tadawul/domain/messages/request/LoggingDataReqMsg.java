/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Mahmoud AL selwadi
 * 
 */
public class LoggingDataReqMsg extends RequestMessage<LoggingDataReqMsgCore> {

	public LoggingDataReqMsg() {
		super();
	}
}
