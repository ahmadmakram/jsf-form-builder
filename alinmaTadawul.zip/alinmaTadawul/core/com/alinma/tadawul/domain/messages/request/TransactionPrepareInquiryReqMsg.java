package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class TransactionPrepareInquiryReqMsg extends RequestMessage<TransactionPrepareInquiryReqMsgCore> {
}
