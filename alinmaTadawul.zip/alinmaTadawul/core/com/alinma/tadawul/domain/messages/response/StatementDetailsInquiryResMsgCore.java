package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.StatementDetails;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryResMsgCore implements MessageBodyCore {

	private StatementDetails statementDetails;
	private PaginationOutRec paginationOutRec;

	public StatementDetails getStatementDetails() {
		return statementDetails;
	}

	public void setStatementDetails(StatementDetails statementDetails) {
		this.statementDetails = statementDetails;
	}

	public PaginationOutRec getPaginationOutRec() {
		return paginationOutRec;
	}

	public void setPaginationOutRec(PaginationOutRec paginationOutRec) {
		this.paginationOutRec = paginationOutRec;
	}
}
