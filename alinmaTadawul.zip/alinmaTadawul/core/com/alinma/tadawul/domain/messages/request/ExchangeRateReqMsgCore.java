/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

//import com.alinma.tadawul.domain.Account;
import com.ejada.commons.dao.messages.MessageBodyCore;

//import com.ejada.commons.domain.EntityKey;
/**
 * @author Hani Younis
 * 
 */
public class ExchangeRateReqMsgCore implements MessageBodyCore {

	public static final int DIMENSOIONSSIZE = 3;
	private String[] exchangeRateDimensions = new String[DIMENSOIONSSIZE];
	private String functionId;
	private String currecnyAmountSource;
	private String currecnySource;
	private String currecnyAmountTarget;
	private String currecnyTarget;
	private String accountNumberSource;
	private String accountNumberTarger;

	public String getAccountNumberSource() {
		return accountNumberSource;
	}

	public void setAccountNumberSource(String accountNumberSource) {
		this.accountNumberSource = accountNumberSource;
	}

	public String getAccountNumberTarger() {
		return accountNumberTarger;
	}

	public void setAccountNumberTarger(String accountNumberTarger) {
		this.accountNumberTarger = accountNumberTarger;
	}

	public String[] getExchangeRateDimensions() {
		return exchangeRateDimensions;
	}

	public String getFunctionId() {
		return functionId;
	}

	public String getCurrecnyAmountSource() {
		return currecnyAmountSource;
	}

	public String getCurrecnyAmountTarget() {
		return currecnyAmountTarget;
	}

	public void setExchangeRateDimensions(String[] exchangeRateDimensions) {
		this.exchangeRateDimensions = exchangeRateDimensions;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public void setCurrecnyAmountSource(String currecnyAmountSource) {
		this.currecnyAmountSource = currecnyAmountSource;
	}

	public void setCurrecnyAmountTarget(String currecnyAmountTarget) {
		this.currecnyAmountTarget = currecnyAmountTarget;
	}

	public void setCurrecnySource(String currecnySource) {
		this.currecnySource = currecnySource;
	}

	public String getCurrecnySource() {
		return currecnySource;
	}

	public void setCurrecnyTarget(String currecnyTarget) {
		this.currecnyTarget = currecnyTarget;
	}

	public String getCurrecnyTarget() {
		return currecnyTarget;
	}
}
