/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.CurrencyInfo;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Hani.Younis
 * 
 */
public class ExchangeRateResMsgCore implements MessageBodyCore {

	private CurrencyInfo currencyInfo;

	public void setCurrencyInfo(CurrencyInfo currencyInfo) {
		this.currencyInfo = currencyInfo;
	}

	public CurrencyInfo getCurrencyInfo() {
		return currencyInfo;
	}
}
