/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Ahmad al saqqa
 * 
 */
public class BeneficiariesAccessResMsg extends ResponseMessage<BeneficiariesAccessResMsgCore> {

	public BeneficiariesAccessResMsg() {
		super();
	}
}
