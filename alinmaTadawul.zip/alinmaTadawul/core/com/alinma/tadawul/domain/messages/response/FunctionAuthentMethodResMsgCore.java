/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import java.util.ArrayList;
import java.util.List;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;
import com.alinma.tadawul.domain.FunctionAuthentMethod;

/**
 * @author Hani.Younis
 * 
 */
public class FunctionAuthentMethodResMsgCore implements MessageBodyCore {

	private List<FunctionAuthentMethod> functionAuthentMethods = new ArrayList<FunctionAuthentMethod>();

	public void setFunctionAuthentMethods(List<FunctionAuthentMethod> functionAuthentMethods) {
		this.functionAuthentMethods = functionAuthentMethods;
	}

	public List<FunctionAuthentMethod> getFunctionAuthentMethods() {
		return functionAuthentMethods;
	}
}
