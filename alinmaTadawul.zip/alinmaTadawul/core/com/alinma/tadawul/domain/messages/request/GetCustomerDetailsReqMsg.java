/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Waleed Tayea
 * 
 */
public class GetCustomerDetailsReqMsg extends RequestMessage<GetCustomerDetailsReqMsgCore> {

	public GetCustomerDetailsReqMsg() {
		super();
	}
}
