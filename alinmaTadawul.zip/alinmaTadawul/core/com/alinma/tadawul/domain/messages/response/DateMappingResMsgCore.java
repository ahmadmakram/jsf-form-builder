/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import java.util.List;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author M. Ali Hammam
 * 
 */
public class DateMappingResMsgCore implements MessageBodyCore {

	List<String> dateMapped;

	/**
	 * @return the dateMapped
	 */
	public List<String> getDateMapped() {
		return dateMapped;
	}

	/**
	 * @param dateMapped
	 *            the dateMapped to set
	 */
	public void setDateMapped(List<String> dateMapped) {
		this.dateMapped = dateMapped;
	}
}
