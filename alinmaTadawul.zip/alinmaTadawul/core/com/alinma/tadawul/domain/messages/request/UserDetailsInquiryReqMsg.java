/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Hani Younis
 * 
 */
public class UserDetailsInquiryReqMsg extends RequestMessage<UserDetailsInquiryReqMsgCore> {

	public UserDetailsInquiryReqMsg() {
		super();
	}
}
