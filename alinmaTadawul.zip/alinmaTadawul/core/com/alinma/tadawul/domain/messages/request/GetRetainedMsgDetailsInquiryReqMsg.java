package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * 
 * @author Hani Younis
 * 
 */
public class GetRetainedMsgDetailsInquiryReqMsg extends RequestMessage<GetRetainedMsgDetailsInquiryReqMsgCore> {

	public GetRetainedMsgDetailsInquiryReqMsg() {
		super();
	}
}
