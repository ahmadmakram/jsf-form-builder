/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import java.util.List;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.alinma.tadawul.domain.lov.DateMappingType;

/**
 * @author M. Ali Hammam
 * 
 */
public class DateMappingReqMsgCore implements MessageBodyCore {

	private List<String> dateMapping;
	private DateMappingType dateMappingType;

	/**
	 * @return the dateMapping
	 */
	public List<String> getDateMapping() {
		return dateMapping;
	}

	/**
	 * @param dateMapping
	 *            the dateMapping to set
	 */
	public void setDateMapping(List<String> dateMapping) {
		this.dateMapping = dateMapping;
	}

	/**
	 * @return the dateMappingType
	 */
	public DateMappingType getDateMappingType() {
		return dateMappingType;
	}

	/**
	 * @param dateMappingType
	 *            the dateMappingType to set
	 */
	public void setDateMappingType(DateMappingType dateMappingType) {
		this.dateMappingType = dateMappingType;
	}
}
