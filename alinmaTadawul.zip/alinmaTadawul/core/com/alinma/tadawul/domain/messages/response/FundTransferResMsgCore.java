package com.alinma.tadawul.domain.messages.response;

import java.util.ArrayList;
import java.util.List;

import com.alinma.tadawul.domain.Amount;
import com.alinma.tadawul.domain.Customerlimit;
import com.alinma.tadawul.domain.Fee;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class FundTransferResMsgCore implements MessageBodyCore {

	private Amount currentBalance;
	private Customerlimit customerlimit;
	private Amount amountDebited;
	private Amount amountCredited;
	private String exchangeRate;
	private String statementEntryId;
	private List<Fee> feeList;
	private String referenceNumber;

	public Amount getCurrentBalance() {
		if (currentBalance == null) {
			currentBalance = new Amount();
		}
		return currentBalance;
	}

	public void setCurrentBalance(Amount currBal) {
		this.currentBalance = currBal;
	}

	public Customerlimit getCustomerlimit() {
		if (customerlimit == null) {
			customerlimit = new Customerlimit();
		}
		return customerlimit;
	}

	public void setCustomerlimit(Customerlimit customerlimit) {
		this.customerlimit = customerlimit;
	}

	public Amount getAmountDebited() {
		if (amountDebited == null) {
			amountDebited = new Amount();
		}
		return amountDebited;
	}

	public void setAmountDebited(Amount amountDebited) {
		this.amountDebited = amountDebited;
	}

	public Amount getAmountCredited() {
		if (amountCredited == null) {
			amountCredited = new Amount();
		}
		return amountCredited;
	}

	public void setAmountCredited(Amount amountCredited) {
		this.amountCredited = amountCredited;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getStatementEntryId() {
		return statementEntryId;
	}

	public void setStatementEntryId(String statementEntryId) {
		this.statementEntryId = statementEntryId;
	}

	public List<Fee> getFeeList() {
		if (feeList == null) {
			feeList = new ArrayList<Fee>();
		}
		return feeList;
	}

	public void setFeeList(List<Fee> feeList) {
		this.feeList = feeList;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
}
