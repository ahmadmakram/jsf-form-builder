/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import java.util.List;

import com.alinma.tadawul.domain.Card;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.lov.BackendGroups;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * The request message for Get Customer Details service.
 * 
 * @author Hani Younis
 * 
 */
public class GetCustomerDetailsReqMsgCore implements MessageBodyCore {

	private TadawulUser user;
	private List<BackendGroups> requiredBackendGroups;
	private Card card;

	public void setUser(TadawulUser user) {
		this.user = user;
	}

	public TadawulUser getUser() {
		return user;
	}

	public void setRequiredBackendGroups(List<BackendGroups> requiredBackendGroups) {
		this.requiredBackendGroups = requiredBackendGroups;
	}

	public List<BackendGroups> getRequiredBackendGroups() {
		return requiredBackendGroups;
	}

	public Card getCard() {
		return card;
	}

	public void setCard(Card card) {
		this.card = card;
	}
}
