/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.PaginationInRec;

/**
 * @author mbrins
 * 
 */
public class GetAccountsReqMsgCore implements MessageBodyCore {

	private String cif;
	private String functionId;
	private EntityKey functionMode;
	private EntityKey accountStatus;
	private EntityKey accountType;
	private EntityKey accountCurrency;
	private String usrId;
	private PaginationInRec recordControlInput;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public EntityKey getFunctionMode() {
		return functionMode;
	}

	public void setFunctionMode(EntityKey functionMode) {
		this.functionMode = functionMode;
	}

	public EntityKey getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(EntityKey accountStatus) {
		this.accountStatus = accountStatus;
	}

	public EntityKey getAccountType() {
		return accountType;
	}

	public void setAccountType(EntityKey accountType) {
		this.accountType = accountType;
	}

	public EntityKey getAccountCurrency() {
		return accountCurrency;
	}

	public void setAccountCurrency(EntityKey accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	public String getUsrId() {
		return usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

	public PaginationInRec getRecordControlInput() {
		return recordControlInput;
	}

	public void setRecordControlInput(PaginationInRec recordControlInput) {
		this.recordControlInput = recordControlInput;
	}
}
