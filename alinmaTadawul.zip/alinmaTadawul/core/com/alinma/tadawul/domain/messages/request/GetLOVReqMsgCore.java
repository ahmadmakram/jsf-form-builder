package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.alinma.tadawul.domain.lov.LOVTypeImpl;

/**
 * 
 * @author Waleed Tayea
 * 
 */
public class GetLOVReqMsgCore implements MessageBodyCore {

	private LOVTypeImpl lovType;
	private String lovTypeCode;
	private String lovCode1;
	private String lovCode2;
	private String lovCode3;
	private String lovCode4;

	public GetLOVReqMsgCore(LOVTypeImpl lovType) {
		this.lovType = lovType;
	}

	public GetLOVReqMsgCore(String lovTypeCode) {
		this.lovTypeCode = lovTypeCode;
	}

	/**
	 * @return the lovCode1
	 */
	public String getLovCode1() {
		return lovCode1;
	}

	/**
	 * @param lovCode1
	 *            the lovCode1 to set
	 */
	public void setLovCode1(String lovCode1) {
		this.lovCode1 = lovCode1;
	}

	/**
	 * @return the lovCode2
	 */
	public String getLovCode2() {
		return lovCode2;
	}

	/**
	 * @param lovCode2
	 *            the lovCode2 to set
	 */
	public void setLovCode2(String lovCode2) {
		this.lovCode2 = lovCode2;
	}

	/**
	 * @return the lovCode3
	 */
	public String getLovCode3() {
		return lovCode3;
	}

	/**
	 * @param lovCode3
	 *            the lovCode3 to set
	 */
	public void setLovCode3(String lovCode3) {
		this.lovCode3 = lovCode3;
	}

	/**
	 * @return the lovCode4
	 */
	public String getLovCode4() {
		return lovCode4;
	}

	/**
	 * @param lovCode4
	 *            the lovCode4 to set
	 */
	public void setLovCode4(String lovCode4) {
		this.lovCode4 = lovCode4;
	}

	public LOVTypeImpl getLovType() {
		return lovType;
	}

	public void setLovType(LOVTypeImpl lovType) {
		this.lovType = lovType;
	}

	public String getLovTypeCode() {
		return lovTypeCode;
	}

	public void setLovTypeCode(String lovTypeCode) {
		this.lovTypeCode = lovTypeCode;
	}
}
