/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Hani Younis
 * 
 */
public class GetUserLimitsReqMsg extends RequestMessage<GetUserLimitsReqMsgCore> {

	public GetUserLimitsReqMsg() {
		super();
	}
}
