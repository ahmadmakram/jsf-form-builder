/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Ahmad al saqqa
 * 
 */
public class BeneficiariesAccessReqMsg extends RequestMessage<BeneficiariesAccessReqMsgCore> {

	public BeneficiariesAccessReqMsg() {
		super();
	}
}
