package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Mahmoud AL selwadi
 * 
 */
public class ErrorMessageReqMsg extends RequestMessage<ErrorMessageReqMsgCore> {

	public ErrorMessageReqMsg() {
		super();
	}
}
