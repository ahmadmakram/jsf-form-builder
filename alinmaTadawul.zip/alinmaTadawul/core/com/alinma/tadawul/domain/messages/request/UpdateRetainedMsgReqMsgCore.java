package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.RetainedMsg;
import com.ejada.commons.dao.messages.MessageBodyCore;

public class UpdateRetainedMsgReqMsgCore implements MessageBodyCore {

	private RetainedMsg retainedMsg;

	public RetainedMsg getRetainedMsg() {
		return retainedMsg;
	}

	public void setRetainedMsg(RetainedMsg retainedMsg) {
		this.retainedMsg = retainedMsg;
	}
}
