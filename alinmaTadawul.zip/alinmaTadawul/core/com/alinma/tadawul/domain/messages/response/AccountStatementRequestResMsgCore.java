package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mohammad Suliman
 * 
 */
public class AccountStatementRequestResMsgCore implements MessageBodyCore {
}
