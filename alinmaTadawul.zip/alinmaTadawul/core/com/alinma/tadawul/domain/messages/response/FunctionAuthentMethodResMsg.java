/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Hani Younis
 * 
 */
public class FunctionAuthentMethodResMsg extends ResponseMessage<FunctionAuthentMethodResMsgCore> {

	public FunctionAuthentMethodResMsg() {
		super();
	}
}
