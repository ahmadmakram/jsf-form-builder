package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.RetainedMsg;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationInRec;

/**
 * 
 * @author mahamoda
 * 
 */
public class GetRetainedMsgsReqMsgCore implements MessageBodyCore {

	private String userId;
	private RetainedMsg retainedMsg;
	private PaginationInRec paginationInRec;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public RetainedMsg getRetainedMsg() {
		return retainedMsg;
	}

	public void setRetainedMsg(RetainedMsg retainedMsg) {
		this.retainedMsg = retainedMsg;
	}

	public PaginationInRec getPaginationInRec() {
		return paginationInRec;
	}

	public void setPaginationInRec(PaginationInRec paginationInRec) {
		this.paginationInRec = paginationInRec;
	}
}
