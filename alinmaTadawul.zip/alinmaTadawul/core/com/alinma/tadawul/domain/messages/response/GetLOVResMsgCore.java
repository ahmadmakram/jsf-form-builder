package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.lov.LOVList;
import com.alinma.tadawul.domain.lov.LOVTypeImpl;

public class GetLOVResMsgCore implements MessageBodyCore {

	private LOVList<LOVTypeImpl> lovList;

	public LOVList<LOVTypeImpl> getLovList() {
		return lovList;
	}

	public void setLovList(LOVList<LOVTypeImpl> lovList) {
		this.lovList = lovList;
	}
}
