package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.StatementCycle;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationInRec;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryReqMsgCore implements MessageBodyCore {

	private String accountNum;
	private String accountType;
	private String cardNum;
	private String cardType;
	private StatementCycle statementCycle;
	private PaginationInRec paginationInRec;

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public StatementCycle getStatementCycle() {
		if (statementCycle == null) {
			return new StatementCycle();
		}
		return statementCycle;
	}

	public void setStatementCycle(StatementCycle statementCycle) {
		this.statementCycle = statementCycle;
	}

	public PaginationInRec getPaginationInRec() {
		return paginationInRec;
	}

	public void setPaginationInRec(PaginationInRec paginationInRec) {
		this.paginationInRec = paginationInRec;
	}
}
