package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * 
 * @author mahamoda
 * 
 */
public class UpdateRetainedMsgsResMsgCore implements MessageBodyCore {
}
