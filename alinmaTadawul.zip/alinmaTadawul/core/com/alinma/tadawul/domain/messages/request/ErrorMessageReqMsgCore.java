package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationInRec;
import com.alinma.tadawul.domain.ErrorMessage;

/**
 * @author Mahmoud Al selwadi
 * 
 */
public class ErrorMessageReqMsgCore implements MessageBodyCore {

	private ErrorMessage errorMessage;

	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(ErrorMessage errorMessage) {
		this.errorMessage = errorMessage;
	}

	private PaginationInRec paginationIn;

	public PaginationInRec getPaginationIn() {
		return paginationIn;
	}

	public void setPaginationIn(PaginationInRec paginationIn) {
		this.paginationIn = paginationIn;
	}
}
