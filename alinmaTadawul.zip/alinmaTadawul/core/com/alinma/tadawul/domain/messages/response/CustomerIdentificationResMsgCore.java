package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.RegistrationInfo;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class CustomerIdentificationResMsgCore implements MessageBodyCore {

	private RegistrationInfo registrationInfo;

	public void setRegistrationInfo(RegistrationInfo registrationInfo) {
		this.registrationInfo = registrationInfo;
	}

	public RegistrationInfo getRegistrationInfo() {
		return registrationInfo;
	}
}
