package com.alinma.tadawul.domain.messages.response.domain;

import com.ejada.commons.domain.EntityKey;

public class BeneficiariesAccessManageResMsgStatus {

	private String statusCode;
	private EntityKey beneficiary;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public void setBeneficiary(EntityKey beneficiary) {
		this.beneficiary = beneficiary;
	}

	public EntityKey getBeneficiary() {
		return beneficiary;
	}
}
