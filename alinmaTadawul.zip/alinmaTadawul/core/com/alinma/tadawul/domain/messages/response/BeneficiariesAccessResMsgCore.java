/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import java.util.ArrayList;
import java.util.List;

import com.alinma.tadawul.domain.messages.response.domain.BeneficiariesAccessManageResMsgStatus;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Ahmad al saqqa
 * 
 */
public class BeneficiariesAccessResMsgCore implements MessageBodyCore {

	private List<BeneficiariesAccessManageResMsgStatus> beneficiariesAccessList;

	public void setBeneficiariesAccessList(List<BeneficiariesAccessManageResMsgStatus> beneficiariesAccessList) {
		beneficiariesAccessList = this.beneficiariesAccessList;
	}

	public List<BeneficiariesAccessManageResMsgStatus> getBeneficiariesAccessList() {
		if (beneficiariesAccessList == null) {
			beneficiariesAccessList = createBeneficiariesAccessList();
		}
		return beneficiariesAccessList;
	}

	private List<BeneficiariesAccessManageResMsgStatus> createBeneficiariesAccessList() {
		return new ArrayList<BeneficiariesAccessManageResMsgStatus>();
	}
}
