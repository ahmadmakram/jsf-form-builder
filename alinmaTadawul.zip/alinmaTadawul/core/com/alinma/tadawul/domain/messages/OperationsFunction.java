package com.alinma.tadawul.domain.messages;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Mahmoud Al selwadi
 * 
 */
public enum OperationsFunction implements EntityKey {
	ALL("A"), CREDIT("C"), DEBIT("D"), VIEW("V"), NONE("N");

	private String code;
	private static Map<String, OperationsFunction> map;
	static {
		map = new Hashtable<String, OperationsFunction>();
		for (OperationsFunction value : OperationsFunction.values()) {
			map.put(value.getCode(), value);
		}
	}

	OperationsFunction(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static OperationsFunction getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
