package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * 
 * @author mahamoda
 * 
 */
public class GetRetainedMsgsReqMsg extends RequestMessage<GetRetainedMsgsReqMsgCore> {

	public GetRetainedMsgsReqMsg() {
		super();
	}
}
