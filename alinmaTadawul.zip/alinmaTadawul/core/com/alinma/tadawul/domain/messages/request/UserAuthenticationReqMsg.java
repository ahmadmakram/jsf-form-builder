package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

public class UserAuthenticationReqMsg extends RequestMessage<UserAuthenticationReqMsgCore> {

	public UserAuthenticationReqMsg() {
		super();
	}
}
