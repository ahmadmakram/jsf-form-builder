package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.lov.AccountCategory;
import com.alinma.tadawul.domain.lov.BranchId;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class AccountManageReqMsgCore implements MessageBodyCore {

	String accountNumber;
	AccountCategory accountCategory;
	String accountCurrency;
	String accountName;
	BranchId branchId;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public AccountCategory getAccountCategory() {
		return accountCategory;
	}

	public void setAccountCategory(AccountCategory accountCategory) {
		this.accountCategory = accountCategory;
	}

	public String getAccountCurrency() {
		return accountCurrency;
	}

	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public BranchId getBranchId() {
		return branchId;
	}

	public void setBranchId(BranchId branchId) {
		this.branchId = branchId;
	}
}
