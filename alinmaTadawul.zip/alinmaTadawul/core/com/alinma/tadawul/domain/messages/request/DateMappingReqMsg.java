package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author M. Ali Hammam
 * 
 */
public class DateMappingReqMsg extends RequestMessage<DateMappingReqMsgCore> {

	public DateMappingReqMsg() {
		super();
	}
}
