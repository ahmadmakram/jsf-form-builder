/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Waleed Tayea
 * 
 */
public class GetLOVReqMsg extends RequestMessage<GetLOVReqMsgCore> {

	public GetLOVReqMsg() {
		super();
	}
}
