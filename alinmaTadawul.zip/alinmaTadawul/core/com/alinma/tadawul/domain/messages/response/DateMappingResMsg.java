/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBody;
import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author M. Ali Hammam
 * 
 */
public class DateMappingResMsg extends ResponseMessage<DateMappingResMsgCore> {
}
