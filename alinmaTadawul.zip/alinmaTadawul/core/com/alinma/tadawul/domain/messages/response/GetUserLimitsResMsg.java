/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.alinma.tadawul.domain.messages.response.GetUserLimitsResMsgCore;

/**
 * @author Hani Younis
 * 
 */
public class GetUserLimitsResMsg extends ResponseMessage<GetUserLimitsResMsgCore> {
}
