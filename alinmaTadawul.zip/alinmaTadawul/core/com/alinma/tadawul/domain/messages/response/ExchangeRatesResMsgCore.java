/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import java.util.ArrayList;
import java.util.List;

import com.alinma.tadawul.domain.CurrencyInfo;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Hani.Younis
 * 
 */
public class ExchangeRatesResMsgCore implements MessageBodyCore {

	private List<CurrencyInfo> exchangeRates = new ArrayList<CurrencyInfo>();

	public void setExchangeRates(List<CurrencyInfo> exchangeRates) {
		this.exchangeRates = exchangeRates;
	}

	public List<CurrencyInfo> getExchangeRatesInquiry() {
		return exchangeRates;
	}
}
