package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class UsersInquiryReqMsgCore implements MessageBodyCore {

	private TadawulUser tadawulUser;

	public TadawulUser getTadawulUser() {
		return tadawulUser;
	}

	public void setTadawulUser(TadawulUser tadawulUser) {
		this.tadawulUser = tadawulUser;
	}
}
