package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.RegistrationInfo;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class CustomerIdentificationReqMsgCore implements MessageBodyCore {

	private RegistrationInfo registrationInfo;

	public RegistrationInfo getRegistrationInfo() {
		return registrationInfo;
	}

	public void setRegistrationInfo(RegistrationInfo registrationInfo) {
		this.registrationInfo = registrationInfo;
	}
}
