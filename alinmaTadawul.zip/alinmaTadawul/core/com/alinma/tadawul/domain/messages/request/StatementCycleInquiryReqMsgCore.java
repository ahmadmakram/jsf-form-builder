package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementCycleInquiryReqMsgCore implements MessageBodyCore {

	private String accountNum;
	private String accountType;
	private String cardNum;
	private String cardType;

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
}
