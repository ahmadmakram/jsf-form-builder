/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * The response message for Get Customer Details service.
 * 
 * @author Hani Younis
 * 
 */
public class GetCustomerDetailsResMsg extends ResponseMessage<GetCustomerDetailsResMsgCore> {
}
