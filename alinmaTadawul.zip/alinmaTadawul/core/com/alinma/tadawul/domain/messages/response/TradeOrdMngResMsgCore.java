package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.Customerlimit;
import com.ejada.commons.dao.messages.MessageBodyCore;

public class TradeOrdMngResMsgCore implements MessageBodyCore {

	private Customerlimit customerlimit;
	private String referenceNumber;

	public Customerlimit getCustomerlimit() {
		return customerlimit;
	}

	public void setCustomerlimit(Customerlimit customerlimit) {
		this.customerlimit = customerlimit;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
}
