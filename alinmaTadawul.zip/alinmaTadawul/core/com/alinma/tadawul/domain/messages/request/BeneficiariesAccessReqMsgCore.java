package com.alinma.tadawul.domain.messages.request;

import java.util.List;

import com.alinma.tadawul.domain.Beneficiary;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Ahmad al saqqa
 * 
 */
public class BeneficiariesAccessReqMsgCore implements MessageBodyCore {

	private String subUserID;
	private List<Beneficiary> beneficiariesAccessList;

	public void setBeneficiariesAccessList(List<Beneficiary> beneficiariesAccessList) {
		this.beneficiariesAccessList = beneficiariesAccessList;
	}

	public List<Beneficiary> getBeneficiariesAccessList() {
		return beneficiariesAccessList;
	}

	public void setSubUserID(String subUserID) {
		this.subUserID = subUserID;
	}

	public String getSubUserID() {
		return subUserID;
	}
}
