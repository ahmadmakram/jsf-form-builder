/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author mbrins
 * 
 */
public class GetAccountsResMsg extends ResponseMessage<GetAccountsResMsgCore> {
}
