package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.lov.ChannelId;

/**
 * @author Hani Younis
 * 
 */
public class UserManageReqMsgCore implements MessageBodyCore {

	private TadawulUser tadawulUser;
	private String subUserId;
	private ChannelId targetChannelId;

	public ChannelId getTargetChannelId() {
		return targetChannelId;
	}

	public void setTargetChannelId(ChannelId targetChannelId) {
		this.targetChannelId = targetChannelId;
	}

	public void setTadawulUser(TadawulUser tadawulUser) {
		this.tadawulUser = tadawulUser;
	}

	public TadawulUser getTadawulUser() {
		return tadawulUser;
	}

	public void setSubUserId(String subUserId) {
		this.subUserId = subUserId;
	}

	public String getSubUserId() {
		return subUserId;
	}
}
