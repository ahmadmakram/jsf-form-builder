/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.RegistrationInfo;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Hani Younis
 * 
 */
public class ManageRegistrationReqMsgCore implements MessageBodyCore {

	private RegistrationInfo registrationInfo;
	private EntityKey channelId;

	public RegistrationInfo getRegistrationInfo() {
		if (registrationInfo == null) {
			registrationInfo = createRegistrationInfo();
		}
		return registrationInfo;
	}

	private RegistrationInfo createRegistrationInfo() {
		return new RegistrationInfo();
	}

	public void setRegistrationInfo(RegistrationInfo registrationInfo) {
		this.registrationInfo = registrationInfo;
	}

	public void setChannelId(EntityKey channelId) {
		this.channelId = channelId;
	}

	public EntityKey getChannelId() {
		return channelId;
	}
}
