/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.PaginationInRec;
import com.alinma.tadawul.domain.RegistrationInfo;
import com.alinma.tadawul.domain.UserCredential;

/**
 * @author Hani Younis
 * 
 */
public class GetUserLimitsReqMsgCore implements MessageBodyCore {

	public static final int DIMENSOIONSSIZE = 3;
	private String subUserId;
	private EntityKey channelId;
	private EntityKey functionGroup;
	private EntityKey currencyGroup;
	private String[] limitsDimensions = new String[DIMENSOIONSSIZE];
	private PaginationInRec paginationIn;

	public String getSubUserId() {
		return subUserId;
	}

	public void setSubUserId(String subUserId) {
		this.subUserId = subUserId;
	}

	public EntityKey getChannelId() {
		return channelId;
	}

	public void setChannelId(EntityKey channelId) {
		this.channelId = channelId;
	}

	public EntityKey getFunctionGroup() {
		return functionGroup;
	}

	public void setFunctionGroupId(EntityKey functionGroup) {
		this.functionGroup = functionGroup;
	}

	public EntityKey getCurrencyGroup() {
		return currencyGroup;
	}

	public void setCurrencyGroup(EntityKey currencyGroup) {
		this.currencyGroup = currencyGroup;
	}

	public String[] getLimitsDimensions() {
		return limitsDimensions;
	}

	public void setLimitsDimensions(String[] limitsDimensions) {
		this.limitsDimensions = limitsDimensions;
	}

	public void setPaginationIn(PaginationInRec paginationIn) {
		this.paginationIn = paginationIn;
	}

	public PaginationInRec getPaginationIn() {
		return paginationIn;
	}
}
