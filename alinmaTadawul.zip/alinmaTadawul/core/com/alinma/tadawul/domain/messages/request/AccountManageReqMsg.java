package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class AccountManageReqMsg extends RequestMessage<AccountManageReqMsgCore> {

	public AccountManageReqMsg() {
		super();
	}
}
