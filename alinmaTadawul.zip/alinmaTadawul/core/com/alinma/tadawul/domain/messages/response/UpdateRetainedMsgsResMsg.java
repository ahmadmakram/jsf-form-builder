package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * 
 * @author mahamoda
 * 
 */
public class UpdateRetainedMsgsResMsg extends ResponseMessage<UpdateRetainedMsgsResMsgCore> {

	public UpdateRetainedMsgsResMsg() {
		super();
	}
}
