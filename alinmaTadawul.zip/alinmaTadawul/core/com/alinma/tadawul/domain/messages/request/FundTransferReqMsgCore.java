package com.alinma.tadawul.domain.messages.request;

import java.util.List;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.Amount;
import com.alinma.tadawul.domain.Beneficiary;
import com.alinma.tadawul.domain.Fee;
import com.alinma.tadawul.domain.lov.FundTransferPurpose;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class FundTransferReqMsgCore implements MessageBodyCore {

	public static final int PMT_DESC_LENGTH = 4;
	private Account sourceAccount;
	private Amount sourceAmount;
	private String sourceTrnDesc;
	private Amount targetAmount;
	private String targetTrnDesc;
	private Account targetAccount;
	private String curCode;
	private Beneficiary beneficiary;
	private FundTransferPurpose fundTransferPurpose;
	private String[] paymentDesc = new String[PMT_DESC_LENGTH];
	private String memo;
	private List<Fee> feeList;

	public Account getSourceAccount() {
		return sourceAccount;
	}

	public void setSourceAccount(Account sourceAccount) {
		this.sourceAccount = sourceAccount;
	}

	public Amount getSourceAmount() {
		return sourceAmount;
	}

	public void setSourceAmount(Amount sourceAmount) {
		this.sourceAmount = sourceAmount;
	}

	public String getSourceTrnDesc() {
		return sourceTrnDesc;
	}

	public void setSourceTrnDesc(String sourceTrnDesc) {
		this.sourceTrnDesc = sourceTrnDesc;
	}

	public Account getTargetAccount() {
		return targetAccount;
	}

	public void setTargetAccount(Account targetAccount) {
		this.targetAccount = targetAccount;
	}

	public Amount getTargetAmount() {
		return targetAmount;
	}

	public void setTargetAmount(Amount targetAmount) {
		this.targetAmount = targetAmount;
	}

	public String getTargetTrnDesc() {
		return targetTrnDesc;
	}

	public void setTargetTrnDesc(String targetTrnDesc) {
		this.targetTrnDesc = targetTrnDesc;
	}

	public Beneficiary getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Beneficiary beneficiary) {
		this.beneficiary = beneficiary;
	}

	public FundTransferPurpose getFundTransferPurpose() {
		return fundTransferPurpose;
	}

	public void setFundTransferPurpose(FundTransferPurpose fundTransferPurpose) {
		this.fundTransferPurpose = fundTransferPurpose;
	}

	public String[] getPaymentDesc() {
		return paymentDesc;
	}

	public void setPaymentDesc(String[] paymentDesc) {
		this.paymentDesc = paymentDesc;
	}

	public List<Fee> getFeeList() {
		return feeList;
	}

	public void setFeeList(List<Fee> feeList) {
		this.feeList = feeList;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}
}
