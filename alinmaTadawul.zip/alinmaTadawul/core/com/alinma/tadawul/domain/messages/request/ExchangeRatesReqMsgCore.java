/**
 * 
 */
package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRatesReqMsgCore implements MessageBodyCore {

	private String currencyCode;

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}
}
