package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.RetainedMsg;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * 
 * @author Hani Younis
 * 
 */
public class GetRetainedMsgDetailsInquiryReqMsgCore implements MessageBodyCore {

	private RetainedMsg retainedMsg;

	public void setRetainedMsg(RetainedMsg retainedMsg) {
		this.retainedMsg = retainedMsg;
	}

	public RetainedMsg getRetainedMsg() {
		return retainedMsg;
	}
}
