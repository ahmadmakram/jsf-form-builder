package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

public class UserAuthenticationResMsg extends ResponseMessage<UserAuthenticationResMsgCore> {

	public UserAuthenticationResMsg() {
		super();
	}
}
