/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import java.util.ArrayList;
import java.util.List;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;
import com.alinma.tadawul.domain.UserLimit;

/**
 * @author Hani.Younis
 * 
 */
public class GetUserLimitsResMsgCore implements MessageBodyCore {

	private List<UserLimit> userLimits = new ArrayList<UserLimit>();
	private PaginationOutRec paginationOutRec;

	public void setUserLimits(List<UserLimit> userLimits) {
		this.userLimits = userLimits;
	}

	public List<UserLimit> getUserLimits() {
		return userLimits;
	}

	public void setPaginationOutRec(PaginationOutRec paginationOutRec) {
		this.paginationOutRec = paginationOutRec;
	}

	public PaginationOutRec getPaginationOutRec() {
		return paginationOutRec;
	}
}
