package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Khalid AlQahtani
 * 
 */
public class IbanVerifyResMsg extends ResponseMessage<IbanVerifyResMsgCore> {

	public IbanVerifyResMsg() {
		super();
	}
}
