package com.alinma.tadawul.domain.messages.request;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Hani Younis
 * 
 */
public class UserDetailsInquiryReqMsgCore implements MessageBodyCore {

	private TadawulUser tadawulUser;
	private EntityKey channelId;

	public void setTadawulUser(TadawulUser ibrUser) {
		this.tadawulUser = ibrUser;
	}

	public TadawulUser getTadawulUser() {
		return tadawulUser;
	}

	public void setChannelId(EntityKey channelId) {
		this.channelId = channelId;
	}

	public EntityKey getChannelId() {
		return channelId;
	}
}
