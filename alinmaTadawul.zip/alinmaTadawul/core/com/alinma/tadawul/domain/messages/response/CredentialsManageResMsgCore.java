/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Hani.Younis
 * 
 */
public class CredentialsManageResMsgCore implements MessageBodyCore {
}
