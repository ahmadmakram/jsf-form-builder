package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.Beneficiary;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageResMsgCore implements MessageBodyCore {

	private Beneficiary beneficiary;

	public Beneficiary getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Beneficiary beneficiary) {
		this.beneficiary = beneficiary;
	}
}
