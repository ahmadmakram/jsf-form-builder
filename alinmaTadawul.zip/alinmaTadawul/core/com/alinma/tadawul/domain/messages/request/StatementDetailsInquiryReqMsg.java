package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryReqMsg extends RequestMessage<StatementDetailsInquiryReqMsgCore> {

	public StatementDetailsInquiryReqMsg() {
		super();
	}
}
