package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementCycleInquiryReqMsg extends RequestMessage<StatementCycleInquiryReqMsgCore> {

	public StatementCycleInquiryReqMsg() {
		super();
	}
}
