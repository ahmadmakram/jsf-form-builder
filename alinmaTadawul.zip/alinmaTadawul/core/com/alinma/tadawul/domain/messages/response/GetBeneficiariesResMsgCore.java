package com.alinma.tadawul.domain.messages.response;

import java.util.List;

import com.alinma.tadawul.domain.Beneficiary;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;

/**
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiariesResMsgCore implements MessageBodyCore {

	private List<Beneficiary> beneficiaries;
	private PaginationOutRec paginationOut;

	public List<Beneficiary> getBeneficiaries() {
		return beneficiaries;
	}

	public void setBeneficiaries(List<Beneficiary> beneficiary) {
		this.beneficiaries = beneficiary;
	}

	public PaginationOutRec getPaginationOut() {
		return paginationOut;
	}

	public void setPaginationOut(PaginationOutRec paginationOut) {
		this.paginationOut = paginationOut;
	}
}
