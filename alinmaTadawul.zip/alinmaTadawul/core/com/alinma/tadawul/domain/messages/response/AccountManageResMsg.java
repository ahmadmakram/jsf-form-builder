package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class AccountManageResMsg extends ResponseMessage<AccountManageResMsgCore> {

	public AccountManageResMsg() {
		super();
	}
}
