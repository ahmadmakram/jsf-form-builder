/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class SessionTerminationResMsgCore implements MessageBodyCore {
}
