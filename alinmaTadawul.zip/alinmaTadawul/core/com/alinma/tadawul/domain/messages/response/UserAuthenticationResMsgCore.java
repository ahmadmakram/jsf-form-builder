package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;

public class UserAuthenticationResMsgCore implements MessageBodyCore {

	private TadawulUser user;

	// Setters and Getters
	public TadawulUser getUser() {
		return user;
	}

	public void setUser(TadawulUser user) {
		this.user = user;
	}
}
