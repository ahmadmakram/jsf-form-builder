package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.lov.SecurityInfoType;

public class CredentialsManageReqMsgCore implements MessageBodyCore {

	private String userId;
	private SecurityInfoType securityInformationType;
	private String loginName;
	private String newSecurityPassword;
	private EntityKey ChannelId;
	private String subUserId;
	private String oldPassword;
	private String functionId;
	private String[] userDef;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getNewSecurityPassword() {
		return newSecurityPassword;
	}

	public void setNewSecurityPassword(String newSecurityPassword) {
		this.newSecurityPassword = newSecurityPassword;
	}

	public EntityKey getChannelId() {
		return ChannelId;
	}

	public void setChannelId(EntityKey channelId) {
		ChannelId = channelId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setSecurityInformationType(SecurityInfoType securityInformationType) {
		this.securityInformationType = securityInformationType;
	}

	public SecurityInfoType getSecurityInformationType() {
		return securityInformationType;
	}

	public void setSubUserId(String subUserId) {
		this.subUserId = subUserId;
	}

	public String getSubUserId() {
		return subUserId;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setUserDef(String[] userDef) {
		this.userDef = userDef;
	}

	public String[] getUserDef() {
		return userDef;
	}
}
