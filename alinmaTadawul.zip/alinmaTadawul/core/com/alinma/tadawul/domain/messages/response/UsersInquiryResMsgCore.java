package com.alinma.tadawul.domain.messages.response;

import java.util.List;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class UsersInquiryResMsgCore implements MessageBodyCore {

	private List<TadawulUser> tadawulUser;

	public List<TadawulUser> getTadawulUser() {
		return tadawulUser;
	}

	public void setTadawulUser(List<TadawulUser> tadawulUser) {
		this.tadawulUser = tadawulUser;
	}
}
