package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryResMsg extends ResponseMessage<StatementDetailsInquiryResMsgCore> {

	public StatementDetailsInquiryResMsg() {
		super();
	}
}
