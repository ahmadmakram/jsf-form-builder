package com.alinma.tadawul.domain.messages.response;

import java.util.ArrayList;
import java.util.List;

import com.alinma.tadawul.domain.Amount;
import com.alinma.tadawul.domain.Fee;
import com.alinma.tadawul.domain.FunctionAuthentMethod;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class TransactionPrepareInquiryResMsgCore implements MessageBodyCore {

	private Amount sourceAmount;
	private Amount targetAmount;
	private List<Fee> fees;
	private List<FunctionAuthentMethod> functionAuthentMethods;

	public Amount getSourceAmount() {
		if (sourceAmount == null) {
			sourceAmount = new Amount();
		}
		return sourceAmount;
	}

	public void setSourceAmount(Amount sourceAmount) {
		this.sourceAmount = sourceAmount;
	}

	public Amount getTargetAmount() {
		if (targetAmount == null) {
			targetAmount = new Amount();
		}
		return targetAmount;
	}

	public void setTargetAmount(Amount targetAmount) {
		this.targetAmount = targetAmount;
	}

	public List<Fee> getFees() {
		if (fees == null) {
			fees = new ArrayList<Fee>();
		}
		return fees;
	}

	public void setFees(List<Fee> fees) {
		this.fees = fees;
	}

	public List<FunctionAuthentMethod> getFunctionAuthentMethods() {
		if (functionAuthentMethods == null) {
			functionAuthentMethods = new ArrayList<FunctionAuthentMethod>();
		}
		return functionAuthentMethods;
	}

	public void setFunctionAuthentMethods(List<FunctionAuthentMethod> functionAuthentMethods) {
		this.functionAuthentMethods = functionAuthentMethods;
	}
}
