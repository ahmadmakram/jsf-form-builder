/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.User;
import com.alinma.tadawul.domain.LogData;

/**
 * @author M. Mahmoud Al selwadi
 * 
 */
public class LoggingDataResMsgCore implements MessageBodyCore {

	protected LogData logData;

	public LogData getLogData() {
		return logData;
	}

	public void setLogData(LogData logData) {
		this.logData = logData;
	}
}
