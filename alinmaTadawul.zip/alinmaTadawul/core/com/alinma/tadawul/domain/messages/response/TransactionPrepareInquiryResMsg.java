package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class TransactionPrepareInquiryResMsg extends ResponseMessage<TransactionPrepareInquiryResMsgCore> {

	public TransactionPrepareInquiryResMsg() {
		super();
	}
}
