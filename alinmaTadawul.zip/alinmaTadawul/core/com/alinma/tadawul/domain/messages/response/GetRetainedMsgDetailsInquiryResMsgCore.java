package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.RetainedMsg;
import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * 
 * @author mahamoda
 * 
 */
public class GetRetainedMsgDetailsInquiryResMsgCore implements MessageBodyCore {

	private RetainedMsg retainedMsg;

	public void setRetainedMsg(RetainedMsg retainedMsg) {
		this.retainedMsg = retainedMsg;
	}

	public RetainedMsg getRetainedMsg() {
		return retainedMsg;
	}
}
