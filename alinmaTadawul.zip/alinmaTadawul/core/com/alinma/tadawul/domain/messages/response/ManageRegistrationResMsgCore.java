/**
 * 
 */
package com.alinma.tadawul.domain.messages.response;

import com.alinma.tadawul.domain.TadawulUser;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.User;

/**
 * @author Hani.Younis
 * 
 */
public class ManageRegistrationResMsgCore implements MessageBodyCore {

	private TadawulUser user;

	/**
	 * @return the user
	 */
	public TadawulUser getUser() {
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(TadawulUser user) {
		this.user = user;
	}
}
