package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.broker.ResponseMessage;

/**
 * 
 * @author mahamoda
 * 
 */
public class GetRetainedMsgDetailsInquiryResMsg extends ResponseMessage<GetRetainedMsgDetailsInquiryResMsgCore> {

	public GetRetainedMsgDetailsInquiryResMsg() {
		super();
	}
}
