package com.alinma.tadawul.domain.messages.request;

import com.ejada.commons.dao.messages.broker.RequestMessage;

/**
 * 
 * @author mahamoda
 * 
 */
public class UpdateRetainedMsgReqMsg extends RequestMessage<UpdateRetainedMsgReqMsgCore> {

	public UpdateRetainedMsgReqMsg() {
		super();
	}
}
