package com.alinma.tadawul.domain.messages;

import com.alinma.tadawul.domain.Account;
import com.ejada.commons.domain.BusinessObject;

/**
 * 
 * @author Mahmoud Al Selwadi
 * 
 */
public class UserFunctionInfo extends BusinessObject {

	private String functionId;
	private String functionNameEn;
	private String functionNameAr;
	private OperationsFunction functionOperation;
	private OperationsFunction userFunctionAccess;
	private Account account;

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getFunctionNameEn() {
		return functionNameEn;
	}

	public void setFunctionNameEn(String functionNameEn) {
		this.functionNameEn = functionNameEn;
	}

	public String getFunctionNameAr() {
		return functionNameAr;
	}

	public void setFunctionNameAr(String functionNameAr) {
		this.functionNameAr = functionNameAr;
	}

	public OperationsFunction getFunctionOperation() {
		return functionOperation;
	}

	public void setFunctionOperation(OperationsFunction functionOperation) {
		this.functionOperation = functionOperation;
	}

	public OperationsFunction getUserFunctionAccess() {
		return userFunctionAccess;
	}

	public void setUserFunctionAccess(OperationsFunction userFunctionAccess) {
		this.userFunctionAccess = userFunctionAccess;
	}

	public Account getAccount() {
		if (account != null) {
			account = new Account();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
}
