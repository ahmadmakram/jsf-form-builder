package com.alinma.tadawul.domain.messages.response;

import java.util.List;

import com.alinma.tadawul.domain.RetainedMsg;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.domain.PaginationOutRec;

/**
 * 
 * @author mahamoda
 * 
 */
public class GetRetainedMsgsResMsgCore implements MessageBodyCore {

	private List<RetainedMsg> retainedMsgs;
	private PaginationOutRec paginationOut;

	// Setters and Getters
	public List<RetainedMsg> getRetainedMsgs() {
		return retainedMsgs;
	}

	public void setRetainedMsgs(List<RetainedMsg> retainedMsgs) {
		this.retainedMsgs = retainedMsgs;
	}

	public PaginationOutRec getPaginationOut() {
		return paginationOut;
	}

	public void setPaginationOut(PaginationOutRec paginationOut) {
		this.paginationOut = paginationOut;
	}
}
