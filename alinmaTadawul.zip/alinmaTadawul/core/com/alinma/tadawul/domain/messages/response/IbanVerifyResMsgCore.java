package com.alinma.tadawul.domain.messages.response;

import com.ejada.commons.dao.messages.MessageBodyCore;

/**
 * @author Khalid AlQahtani
 * 
 */
public class IbanVerifyResMsgCore implements MessageBodyCore {
}
