package com.alinma.tadawul.domain;

import org.hibernate.validator.NotNull;

import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.EntityKey;

public class PartySegment extends DateAwareEntityImpl {

	private SurrogateKey surrogateKey;
	private EntityKey segmentEntity;

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	@NotNull(message = "{customerAdditionalInfo.customerSegmentRequired}")
	public EntityKey getSegmentEntity() {
		return segmentEntity;
	}

	public void setSegmentEntity(EntityKey segmentEntity) {
		this.segmentEntity = segmentEntity;
	}
}
