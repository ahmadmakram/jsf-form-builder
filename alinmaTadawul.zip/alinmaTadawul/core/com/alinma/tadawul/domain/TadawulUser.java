package com.alinma.tadawul.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.lov.BackendGroups;
import com.alinma.tadawul.market.domain.CustBuyingPwr;
import com.alinma.tadawul.market.domain.Portfolio;
import com.alinma.tadawul.market.domain.PortfolioStatement;
import com.alinma.tadawul.market.domain.SubscriptionInfo;
import com.alinma.tadawul.market.domain.TradeSecurity;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.ReserveDeletedList;
import com.ejada.commons.domain.ReserveDeletedMap;
import com.ejada.commons.domain.User;
import com.ejada.commons.domain.lov.ChannelId;
import com.ejada.commons.services.ServiceRequestRec;

/**
 * 
 * @author Hani Younis
 * 
 */
public class TadawulUser extends User {

	private String baseUserProfile;
	private UserContact userContact;
	private boolean blindWitness;
	// Customer Info
	private CustomerStartingInfo customerStartingInfo;
	private CustomerEssentialInfo customerEssentialInfo;
	private CustomerComplementaryInfo customerComplementaryInfo;
	private CustomerCapitalMarketAuthorityInfo customerCapitalMarketAuthorityInfo;
	private List<CustomerProduct> selectedCustomerProducts;
	// Customer Info
	private String alinmaId;
	private EntityKey customerType;
	private EntityKey customerStatus;
	private EntityKey segment;
	private EntityKey SAMAStatus;
	private Boolean oneTimePassword;
	private Boolean secondPassword;
	private String userStatus;
	private Map<ChannelId, ChannelInfo> channelsInfo;
	private Account defaultAccount;
	private ServiceRequestRec serviceRequestRec;
	private List<BackendGroups> retrievedBackendGroups;
	private DefaultIdDoc defaultIdDoc;
	private CombinedDate effectiveIdExpiryDate;
	// added for actual global limit.
	private EntityKey employerType;
	private EntityKey employerSector;
	private EntityKey salaryCalendarType;
	private CombinedDate employerJoinDate;
	private String monthlyBasicSalary;
	private Boolean salaryTransfer;
	private boolean alinmaIBOffer;
	private List<CustomerDependency> customerDependencies;
	// UserServiceSubscriptions all user subscriptions products and its status
	private List<SubscriptionInfo> userSvcsSubscription;
	// list of user portfolios
	private List<Portfolio> portfolios = new ArrayList<Portfolio>();
	private Map<String, CustBuyingPwr> custBuyingPwrMap = new HashMap<String, CustBuyingPwr>();
	private Map<String, Portfolio> portfolioMap = new HashMap<String, Portfolio>();

	public Portfolio getPortfolio(String portfolioNum) {
		return portfolioMap.get(portfolioNum);
	}

	public void setPortfolio(String portfolioNum, Portfolio portfolio) {
		portfolioMap.put(portfolioNum, portfolio);
	}

	public CustBuyingPwr getCustBuyingPwr(String portfolioNum) {
		return custBuyingPwrMap.get(portfolioNum);
	}

	public void setCustBuyingPwr(String portfolioNum, CustBuyingPwr custBuyingPwr) {
		custBuyingPwrMap.put(portfolioNum, custBuyingPwr);
	}

	public List<Portfolio> getPortfolios() {
		return portfolios;
	}

	public void setPortfolios(List<Portfolio> portfolios) {
		this.portfolios = portfolios;
	}

	public Account getDefaultAccount() {
		return defaultAccount;
	}

	public void setDefaultAccount(Account defaultAccount) {
		this.defaultAccount = defaultAccount;
	}

	public ServiceRequestRec getServiceRequestRec() {
		return serviceRequestRec;
	}

	public void setServiceRequestRec(ServiceRequestRec serviceRequestRec) {
		this.serviceRequestRec = serviceRequestRec;
	}

	public void setBaseUserProfile(String baseUserProfile) {
		this.baseUserProfile = baseUserProfile;
	}

	public String getBaseUserProfile() {
		return baseUserProfile;
	}

	public void setUserContact(UserContact userContact) {
		this.userContact = userContact;
	}

	public UserContact getUserContact() {
		if (this.userContact == null) {
			this.userContact = createUserContact();
		}
		return userContact;
	}

	public UserContact createUserContact() {
		return new UserContact();
	}

	public String getAlinmaId() {
		return alinmaId;
	}

	public void setAlinmaId(String alinmaId) {
		this.alinmaId = alinmaId;
	}

	public EntityKey getCustomerType() {
		return customerType;
	}

	public void setCustomerType(EntityKey customerType) {
		this.customerType = customerType;
	}

	public EntityKey getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(EntityKey customerStatus) {
		this.customerStatus = customerStatus;
	}

	public EntityKey getSegment() {
		return segment;
	}

	public void setSegment(EntityKey segment) {
		this.segment = segment;
	}

	public EntityKey getSAMAStatus() {
		return SAMAStatus;
	}

	public void setSAMAStatus(EntityKey status) {
		SAMAStatus = status;
	}

	public Boolean getOneTimePassword() {
		return oneTimePassword;
	}

	public void setOneTimePassword(Boolean oneTimePassword) {
		this.oneTimePassword = oneTimePassword;
	}

	public Boolean getSecondPassword() {
		return secondPassword;
	}

	public void setSecondPassword(Boolean secondPassword) {
		this.secondPassword = secondPassword;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setChannelsInfo(Map<ChannelId, ChannelInfo> channelsInfo) {
		this.channelsInfo = channelsInfo;
	}

	public Map<ChannelId, ChannelInfo> getChannelsInfo() {
		if (this.channelsInfo == null) {
			this.channelsInfo = createChannelsInfo();
		}
		return this.channelsInfo;
	}

	public Map<ChannelId, ChannelInfo> createChannelsInfo() {
		return new ReserveDeletedMap<ChannelId, ChannelInfo>();
	}

	public ChannelInfo createIBChannelInfo() {
		ChannelInfo channelInfo = createChannelInfo();
		channelInfo.setChannelId(ChannelId.TADAWUL);
		return channelInfo;
	}

	public ChannelInfo createChannelInfo() {
		return new ChannelInfo();
	}

	public Map<ChannelId, ChannelInfo> addChannelInfo(ChannelId channelId, ChannelInfo channelInfo) {
		getChannelsInfo().put(channelId, channelInfo);
		return channelsInfo;
	}

	public ChannelInfo getChannelInfo(ChannelId channelId) {
		ChannelInfo channelInfo = null;
		if (this.getChannelsInfo().get(channelId) == null) {
			channelInfo = createIBChannelInfo();
			this.getChannelsInfo().put(channelId, channelInfo);
		}
		channelInfo = this.getChannelsInfo().get(channelId);
		return channelInfo;
	}

	public ChannelInfo getInternetChannelInfo() {
		ChannelInfo channelInfo = null;
		if (this.getChannelsInfo().get(ChannelId.TADAWUL) == null) {
			channelInfo = createIBChannelInfo();
			this.getChannelsInfo().put(ChannelId.TADAWUL, channelInfo);
		}
		channelInfo = this.getChannelsInfo().get(ChannelId.TADAWUL);
		return channelInfo;
	}

	static public Account createAccount() {
		return new Account();
	}

	static public List<Account> createAccountsList() {
		return new ArrayList<Account>();
	}

	/**
	 * @return the retrievedBackendGroups
	 */
	public List<BackendGroups> getRetrievedBackendGroups() {
		if (retrievedBackendGroups == null) {
			retrievedBackendGroups = new ArrayList<BackendGroups>();
		}
		return retrievedBackendGroups;
	}

	/**
	 * @param retrievedBackendGroups
	 *            the retrievedBackendGroups to set
	 */
	public void setRetrievedBackendGroups(List<BackendGroups> retrievedBackendGroups) {
		this.retrievedBackendGroups = retrievedBackendGroups;
	}

	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (userContact != null) {
			userContact.CommitUpdates();
		}
		if (channelsInfo != null && channelsInfo instanceof ReserveDeletedMap) {
			((ReserveDeletedMap<ChannelId, ChannelInfo>) channelsInfo).CommitUpdates();
		}
		if (defaultAccount != null) {
			defaultAccount.CommitUpdates();
		}
	}

	public void CommitUserManageUpdates() {
		super.CommitUpdates();
		if (channelsInfo != null && channelsInfo instanceof ReserveDeletedMap) {
			((ReserveDeletedMap<ChannelId, ChannelInfo>) channelsInfo).CommitUpdates();
		}
		if (userContact != null) {
			userContact.CommitUpdates();
		}
	}

	public void setDefaultIdDoc(DefaultIdDoc defaultIdDoc) {
		this.defaultIdDoc = defaultIdDoc;
	}

	public DefaultIdDoc getDefaultIdDoc() {
		if (defaultIdDoc == null) {
			this.defaultIdDoc = createDefaulrIdDoc();
		}
		return defaultIdDoc;
	}

	private DefaultIdDoc createDefaulrIdDoc() {
		return new DefaultIdDoc();
	}

	public void setEmployerType(EntityKey employerType) {
		this.employerType = employerType;
	}

	public EntityKey getEmployerType() {
		return employerType;
	}

	public void setEmployerSector(EntityKey employerSector) {
		this.employerSector = employerSector;
	}

	public EntityKey getEmployerSector() {
		return employerSector;
	}

	public void setEmployerJoinDate(CombinedDate employerJoinDate) {
		this.employerJoinDate = employerJoinDate;
	}

	public CombinedDate getEmployerJoinDate() {
		return employerJoinDate;
	}

	public void setMonthlyBasicSalary(String monthlyBasicSalary) {
		this.monthlyBasicSalary = monthlyBasicSalary;
	}

	public String getMonthlyBasicSalary() {
		return monthlyBasicSalary;
	}

	public void setSalaryTransfer(Boolean salaryTransfer) {
		this.salaryTransfer = salaryTransfer;
	}

	public Boolean getSalaryTransfer() {
		return salaryTransfer;
	}

	public void setSalaryCalendarType(EntityKey salaryCalendarType) {
		this.salaryCalendarType = salaryCalendarType;
	}

	public EntityKey getSalaryCalendarType() {
		return salaryCalendarType;
	}

	public boolean isBlindWitness() {
		return blindWitness;
	}

	public void setBlindWitness(boolean blindWitness) {
		this.blindWitness = blindWitness;
	}

	public void setEffectiveIdExpiryDate(CombinedDate effectiveIdExpiryDate) {
		this.effectiveIdExpiryDate = effectiveIdExpiryDate;
	}

	public CombinedDate getEffectiveIdExpiryDate() {
		return effectiveIdExpiryDate;
	}

	public void setCustomerDependencies(List<CustomerDependency> customerDependencies) {
		this.customerDependencies = customerDependencies;
	}

	public List<CustomerDependency> getCustomerDependencies() {
		if (this.customerDependencies == null) {
			this.customerDependencies = createCustomerDependencies();
		}
		return customerDependencies;
	}

	private ReserveDeletedList<CustomerDependency> createCustomerDependencies() {
		return new ReserveDeletedList<CustomerDependency>();
	}

	public boolean isAlinmaIBOffer() {
		return alinmaIBOffer;
	}

	public void setAlinmaIBOffer(boolean alinmaIBOffer) {
		this.alinmaIBOffer = alinmaIBOffer;
	}

	public List<CustomerProduct> getSelectedCustomerProducts() {
		if (selectedCustomerProducts == null) {
			this.selectedCustomerProducts = new ReserveDeletedList<CustomerProduct>();
		}
		return selectedCustomerProducts;
	}

	public void setSelectedCustomerProducts(List<CustomerProduct> selectedCustomerProducts) {
		this.selectedCustomerProducts = selectedCustomerProducts;
	}

	public CustomerStartingInfo getCustomerStartingInfo() {
		if (customerStartingInfo == null) {
			this.customerStartingInfo = createCustomerStartingInfo();
		}
		return customerStartingInfo;
	}

	public void setCustomerStartingInfo(CustomerStartingInfo customerStartingInfo) {
		this.customerStartingInfo = customerStartingInfo;
	}

	public CustomerStartingInfo createCustomerStartingInfo() {
		return (CustomerStartingInfo) ApplicationContextFactory.getApplicationContext().getBean("customerStartingInfo");
	}

	public CustomerEssentialInfo getCustomerEssentialInfo() {
		if (customerEssentialInfo == null) {
			this.customerEssentialInfo = createCustomerEssentialInfo();
		}
		return customerEssentialInfo;
	}

	public CustomerEssentialInfo createCustomerEssentialInfo() {
		return (CustomerEssentialInfo) ApplicationContextFactory.getApplicationContext().getBean("customerEssentialInfo");
	}

	public void setCustomerEssentialInfo(CustomerEssentialInfo customerEssentialInfo) {
		this.customerEssentialInfo = customerEssentialInfo;
	}

	public CustomerComplementaryInfo getCustomerComplementaryInfo() {
		if (customerComplementaryInfo == null) {
			this.customerComplementaryInfo = createCustomerComplementaryInfo();
		}
		return customerComplementaryInfo;
	}

	public CustomerComplementaryInfo createCustomerComplementaryInfo() {
		return (CustomerComplementaryInfo) ApplicationContextFactory.getApplicationContext().getBean("customerComplementaryInfo");
	}

	public void setCustomerComplementaryInfo(CustomerComplementaryInfo customerComplementaryInfo) {
		this.customerComplementaryInfo = customerComplementaryInfo;
	}

	public CustomerCapitalMarketAuthorityInfo getCustomerCapitalMarketAuthorityInfo() {
		if (customerCapitalMarketAuthorityInfo == null) {
			this.customerCapitalMarketAuthorityInfo = createCustomerCapitalMarketAuthorityInfo();
		}
		return customerCapitalMarketAuthorityInfo;
	}

	private CustomerCapitalMarketAuthorityInfo createCustomerCapitalMarketAuthorityInfo() {
		return (CustomerCapitalMarketAuthorityInfo) ApplicationContextFactory.getApplicationContext().getBean("customerCapitalMarketAuthorityInfo");
	}

	public void setCustomerCapitalMarketAuthorityInfo(CustomerCapitalMarketAuthorityInfo customerCMAInfo) {
		this.customerCapitalMarketAuthorityInfo = customerCapitalMarketAuthorityInfo;
	}

	public List<SubscriptionInfo> getUserSvcsSubscription() {
		return userSvcsSubscription;
	}

	public void setUserSvcsSubscription(List<SubscriptionInfo> userSvcsSubscription) {
		this.userSvcsSubscription = userSvcsSubscription;
	}
}
