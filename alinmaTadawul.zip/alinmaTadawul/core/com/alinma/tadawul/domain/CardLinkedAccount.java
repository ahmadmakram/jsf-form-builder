/**
 * 
 */
package com.alinma.tadawul.domain;

import com.alinma.tadawul.domain.lov.AllowedAccess;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.Language;

/**
 * @author mbrins
 * 
 */
public class CardLinkedAccount extends Account {

	private String cardLinkedAccountAggregate;
	private Boolean defaultAccountFlag;
	private AllowedAccess allowAccess;
	private Boolean primaryAccountFlag;
	private Boolean secondaryAccountFlag;

	public Boolean getDefaultAccountFlag() {
		return defaultAccountFlag;
	}

	public void setDefaultAccountFlag(Boolean defaultAccountFlag) {
		this.defaultAccountFlag = defaultAccountFlag;
	}

	public AllowedAccess getAllowAccess() {
		return allowAccess;
	}

	public void setAllowAccess(AllowedAccess allowAccessCode) {
		this.allowAccess = allowAccessCode;
	}

	public Boolean getPrimaryAccountFlag() {
		return primaryAccountFlag;
	}

	public void setPrimaryAccountFlag(Boolean primaryAccountFlag) {
		this.primaryAccountFlag = primaryAccountFlag;
	}

	public Boolean getSecondaryAccountFlag() {
		return secondaryAccountFlag;
	}

	public void setSecondaryAccountFlag(Boolean secondaryAccountFlag) {
		this.secondaryAccountFlag = secondaryAccountFlag;
	}

	public void setCardLinkedAccountAggregate(String cardLinkedAccountAggregate) {
		this.cardLinkedAccountAggregate = cardLinkedAccountAggregate;
	}

	public String getCardLinkedAccountAggregate() {
		return cardLinkedAccountAggregate;
	}
}
