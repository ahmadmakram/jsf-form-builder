package com.alinma.tadawul.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ahmed Farouk
 * 
 */
public class HijriCalendar {

	private List<HijriYear> hijriYears;

	public List<HijriYear> getHijriYears() {
		if (hijriYears == null) {
			hijriYears = new ArrayList<HijriYear>();
		}
		return hijriYears;
	}

	public void setHijriYears(List<HijriYear> hijriYears) {
		this.hijriYears = hijriYears;
	}

	public Integer getFirstYear() {
		return getHijriYears().size() == 0 ? null : getHijriYears().get(0).getYear();
	}

	public Integer getLastYear() {
		return getHijriYears().size() == 0 ? null : getHijriYears().get(getHijriYears().size() - 1).getYear();
	}
}
