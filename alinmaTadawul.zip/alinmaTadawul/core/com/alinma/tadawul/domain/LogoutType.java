package com.alinma.tadawul.domain;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Mahmoud Al selwadi
 * 
 */
public enum LogoutType implements EntityKey {
	USER_LOGOUT("1"), SEESION_TERMINATED_UNEXPECTEDLY("2"), SEESION_EXPIRY("3");

	private String code;
	private static Map<String, LogoutType> map;
	static {
		map = new Hashtable<String, LogoutType>();
		for (LogoutType value : LogoutType.values()) {
			map.put(value.getCode(), value);
		}
	}

	LogoutType(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static LogoutType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
