package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;

public class CustomerComplementaryInfo extends BusinessObject {

	private CustomerComplementaryCoreInfo customerComplementaryCoreInfo;
	private CustomerComplementaryAdditionalInfo customerComplementaryAdditionalInfo;

	public CustomerComplementaryCoreInfo getCustomerComplementaryCoreInfo() {
		if (this.customerComplementaryCoreInfo == null) {
			this.customerComplementaryCoreInfo = createCustomerComplementaryCoreInfo();
		}
		return customerComplementaryCoreInfo;
	}

	public CustomerComplementaryCoreInfo createCustomerComplementaryCoreInfo() {
		return (CustomerComplementaryCoreInfo) ApplicationContextFactory.getApplicationContext().getBean("customerComplementaryCoreInfo");
	}

	public void setCustomerComplementaryCoreInfo(CustomerComplementaryCoreInfo customerComplementaryCoreInfo) {
		this.customerComplementaryCoreInfo = customerComplementaryCoreInfo;
	}

	public CustomerComplementaryAdditionalInfo getCustomerComplementaryAdditionalInfo() {
		if (this.customerComplementaryAdditionalInfo == null) {
			this.customerComplementaryAdditionalInfo = createCustomerComplementaryAdditionalInfo();
		}
		return customerComplementaryAdditionalInfo;
	}

	public CustomerComplementaryAdditionalInfo createCustomerComplementaryAdditionalInfo() {
		return (CustomerComplementaryAdditionalInfo) ApplicationContextFactory.getApplicationContext().getBean("customerComplementaryAdditionalInfo");
	}

	public void setCustomerComplementaryAdditionalInfo(CustomerComplementaryAdditionalInfo customerComplementaryAdditionalInfo) {
		this.customerComplementaryAdditionalInfo = customerComplementaryAdditionalInfo;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (customerComplementaryCoreInfo != null) {
			customerComplementaryCoreInfo.CommitUpdates();
		}
		if (customerComplementaryAdditionalInfo != null) {
			customerComplementaryAdditionalInfo.CommitUpdates();
		}
	}
}
