package com.alinma.tadawul.domain;

import org.hibernate.validator.NotNull;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.keys.EmployeeId;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

public class CustomerAdditionalInfo extends BusinessObject {

	private EntityKey occupancy;
	private Integer numberOfSpouse;
	private Integer numberOfDependents;
	private EntityKey mainBranch;
	private EntityKey preferredChannel;
	private EntityKey religion;
	private Boolean statmentCombined;
	private EntityKey acceptedCorrespondance;
	private Boolean designatedPerson;
	private EntityKey transportationType;
	private Integer numberOfCars;
	private EntityKey countryOfResidence;
	private CombinedDate residenceDate;
	private EntityKey lineOfBusiness;
	private String joinReason;
	private EntityKey primeRM; // Prime Relationship Officer employee id to this customer.
	private EntityKey backupRM; // Backup Relationship Officer employee id to this customer.
	private EntityKey introducerBranch;
	private EmployeeId introducerEmployee;
	private EntityKey spokenLanguage;
	private EntityKey preferredLang;
	private PartySegment customerSegment;
	private PartySegment oldCustomerSegment;

	public EntityKey getOccupancy() {
		return occupancy;
	}

	public void setOccupancy(EntityKey occupancy) {
		this.occupancy = occupancy;
	}

	public Integer getNumberOfSpouse() {
		return numberOfSpouse;
	}

	public void setNumberOfSpouse(Integer numberOfSpouse) {
		this.numberOfSpouse = numberOfSpouse;
	}

	public Integer getNumberOfDependents() {
		return numberOfDependents;
	}

	public void setNumberOfDependents(Integer numberOfDependents) {
		this.numberOfDependents = numberOfDependents;
	}

	public EntityKey getMainBranch() {
		return mainBranch;
	}

	public void setMainBranch(EntityKey mainBranch) {
		this.mainBranch = mainBranch;
	}

	public EntityKey getPreferredChannel() {
		return preferredChannel;
	}

	public void setPreferredChannel(EntityKey preferredChannel) {
		this.preferredChannel = preferredChannel;
	}

	public EntityKey getReligion() {
		return religion;
	}

	public void setReligion(EntityKey religion) {
		this.religion = religion;
	}

	public Boolean getStatmentCombined() {
		return statmentCombined;
	}

	public void setStatmentCombined(Boolean statmentCombined) {
		this.statmentCombined = statmentCombined;
	}

	public EntityKey getAcceptedCorrespondance() {
		return acceptedCorrespondance;
	}

	public void setAcceptedCorrespondance(EntityKey acceptedCorrespondance) {
		this.acceptedCorrespondance = acceptedCorrespondance;
	}

	public Boolean getDesignatedPerson() {
		return designatedPerson;
	}

	public void setDesignatedPerson(Boolean designatedPerson) {
		this.designatedPerson = designatedPerson;
	}

	public EntityKey getTransportationType() {
		return transportationType;
	}

	public void setTransportationType(EntityKey transportationType) {
		this.transportationType = transportationType;
	}

	public Integer getNumberOfCars() {
		return numberOfCars;
	}

	public void setNumberOfCars(Integer numberOfCars) {
		this.numberOfCars = numberOfCars;
	}

	@NotNull(message = "{customerAdditionalInfo.countryOfResidence}")
	public EntityKey getCountryOfResidence() {
		return countryOfResidence;
	}

	public void setCountryOfResidence(EntityKey countryOfResidence) {
		this.countryOfResidence = countryOfResidence;
	}

	public CombinedDate getResidenceDate() {
		return residenceDate;
	}

	public void setResidenceDate(CombinedDate residenceDate) {
		this.residenceDate = residenceDate;
	}

	public EntityKey getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(EntityKey lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getJoinReason() {
		return joinReason;
	}

	public void setJoinReason(String joinReason) {
		this.joinReason = joinReason;
	}

	@NotNull(message = "{customerAdditionalInfo.primeRMRequired}")
	public EntityKey getPrimeRM() {
		return primeRM;
	}

	public void setPrimeRM(EntityKey primeRM) {
		this.primeRM = primeRM;
	}

	public EntityKey getBackupRM() {
		return backupRM;
	}

	public void setBackupRM(EntityKey backupRM) {
		this.backupRM = backupRM;
	}

	public EntityKey getIntroducerBranch() {
		return introducerBranch;
	}

	public void setIntroducerBranch(EntityKey introducerBranch) {
		this.introducerBranch = introducerBranch;
	}

	public EmployeeId getIntroducerEmployee() {
		return introducerEmployee;
	}

	public void setIntroducerEmployee(EmployeeId introducerEmployee) {
		this.introducerEmployee = introducerEmployee;
	}

	public EntityKey getSpokenLanguage() {
		return spokenLanguage;
	}

	public void setSpokenLanguage(EntityKey spokenLanguage) {
		this.spokenLanguage = spokenLanguage;
	}

	@NotNull(message = "{customerAdditionalInfo.preferredLangRequired}")
	public EntityKey getPreferredLang() {
		return preferredLang;
	}

	public void setPreferredLang(EntityKey preferredLang) {
		this.preferredLang = preferredLang;
	}

	public PartySegment getCustomerSegment() {
		if (this.customerSegment == null) {
			this.customerSegment = createCustomerSegment();
		}
		return customerSegment;
	}

	public PartySegment createCustomerSegment() {
		return (PartySegment) ApplicationContextFactory.getApplicationContext().getBean("customerSegment");
	}

	public void setCustomerSegment(PartySegment segment) {
		this.customerSegment = segment;
	}

	public PartySegment getOldCustomerSegment() {
		return oldCustomerSegment;
	}

	public void setOldCustomerSegment(PartySegment oldCustomerSegment) {
		this.oldCustomerSegment = oldCustomerSegment;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (introducerEmployee != null) {
			introducerEmployee.CommitUpdates();
		}
		if (customerSegment != null) {
			customerSegment.CommitUpdates();
		}
		if (oldCustomerSegment != null) {
			oldCustomerSegment.CommitUpdates();
		}
	}
}
