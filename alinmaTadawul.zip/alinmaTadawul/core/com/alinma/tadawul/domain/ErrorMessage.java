package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Mahmoud AL selwadi
 * 
 */
public class ErrorMessage extends BusinessObject {

	private String errorCode;
	private String errorDescAr;
	private String errorDescEn;
	private String errorSolutionAr;
	private String errorSolutionEn;
	private int complainFlag;
	private EntityKey priority;
	private static final int ACTIVE = 1;
	private static final int DEACTIVE = 0;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescAr() {
		return errorDescAr;
	}

	public void setErrorDescAr(String errorDescAr) {
		this.errorDescAr = errorDescAr;
	}

	public String getErrorDescEn() {
		return errorDescEn;
	}

	public void setErrorDescEn(String errorDescEn) {
		this.errorDescEn = errorDescEn;
	}

	public String getErrorSolutionAr() {
		return errorSolutionAr;
	}

	public void setErrorSolutionAr(String errorSolutionAr) {
		this.errorSolutionAr = errorSolutionAr;
	}

	public String getErrorSolutionEn() {
		return errorSolutionEn;
	}

	public void setErrorSolutionEn(String errorSolutionEn) {
		this.errorSolutionEn = errorSolutionEn;
	}

	public int getComplainFlag() {
		return complainFlag;
	}

	public void setComplainFlag(int complainFlag) {
		this.complainFlag = complainFlag;
	}

	public void setComplain(boolean complain) {
		if (complain) {
			this.complainFlag = ACTIVE;
		} else {
			this.complainFlag = DEACTIVE;
		}
	}

	public boolean getComplain() {
		if (this.complainFlag == ACTIVE) {
			return true;
		} else {
			return false;
		}
	}

	public EntityKey getPriority() {
		return priority;
	}

	public void setPriority(EntityKey priority) {
		this.priority = priority;
	}

	@Override
	public boolean equals(Object obj) {
		return ((ErrorMessage) obj).getErrorCode().equals(errorCode);
	}
}
