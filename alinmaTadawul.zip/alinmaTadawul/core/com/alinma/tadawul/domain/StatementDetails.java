package com.alinma.tadawul.domain;

import java.util.List;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetails extends BusinessObject {

	private StatementCycle statementCycle;
	private List<AccountTransaction> accountTransactions;
	private String openingBal;
	private String closingBal;
	private String totalDebitAmt;
	private String totalCreditAmt;
	private String trnCount;
	private String cardNum;
	private String acctCreditLimit;
	private EntityKey accountType;
	private String alinmaId;
	private String accountNum;
	private String fullName;
	private String branchId;
	private String address;
	private EntityKey accountCurr;
	private String totalCashAdvance;
	private String numOfCashAdvance;
	private String totalPurchases;
	private String numOfPurchases;

	public StatementCycle getStatementCycle() {
		return statementCycle;
	}

	public void setStatementCycle(StatementCycle statementCycle) {
		this.statementCycle = statementCycle;
	}

	public List<AccountTransaction> getAccountTransactions() {
		return accountTransactions;
	}

	public void setAccountTransactions(List<AccountTransaction> accountTransaction) {
		this.accountTransactions = accountTransaction;
	}

	public String getOpeningBal() {
		return openingBal;
	}

	public void setOpeningBal(String openingBal) {
		this.openingBal = openingBal;
	}

	public String getClosingBal() {
		return closingBal;
	}

	public void setClosingBal(String closingBal) {
		this.closingBal = closingBal;
	}

	public String getTotalDebitAmt() {
		return totalDebitAmt;
	}

	public void setTotalDebitAmt(String totalDebitAmt) {
		this.totalDebitAmt = totalDebitAmt;
	}

	public String getTotalCreditAmt() {
		return totalCreditAmt;
	}

	public void setTotalCreditAmt(String totalCreditAmt) {
		this.totalCreditAmt = totalCreditAmt;
	}

	public String getTrnCount() {
		return trnCount;
	}

	public void setTrnCount(String trnCount) {
		this.trnCount = trnCount;
	}

	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public String getAcctCreditLimit() {
		return acctCreditLimit;
	}

	public void setAcctCreditLimit(String acctCreditLimit) {
		this.acctCreditLimit = acctCreditLimit;
	}

	public EntityKey getAccountType() {
		return accountType;
	}

	public void setAccountType(EntityKey accountType) {
		this.accountType = accountType;
	}

	public String getAlinmaId() {
		return alinmaId;
	}

	public void setAlinmaId(String alinmaId) {
		this.alinmaId = alinmaId;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public EntityKey getAccountCurr() {
		return accountCurr;
	}

	public void setAccountCurr(EntityKey accountCurr) {
		this.accountCurr = accountCurr;
	}

	public String getTotalCashAdvance() {
		return totalCashAdvance;
	}

	public void setTotalCashAdvance(String totalCashAdvance) {
		this.totalCashAdvance = totalCashAdvance;
	}

	public String getNumOfCashAdvance() {
		return numOfCashAdvance;
	}

	public void setNumOfCashAdvance(String numOfCashAdvance) {
		this.numOfCashAdvance = numOfCashAdvance;
	}

	public String getTotalPurchases() {
		return totalPurchases;
	}

	public void setTotalPurchases(String totalPurchases) {
		this.totalPurchases = totalPurchases;
	}

	public String getNumOfPurchases() {
		return numOfPurchases;
	}

	public void setNumOfPurchases(String numOfPurchases) {
		this.numOfPurchases = numOfPurchases;
	}
}
