package com.alinma.tadawul.domain;

import java.io.Serializable;

import com.ejada.commons.domain.CombinedDate;

public class Symbol implements Serializable {

	String id;
	String market;
	String shortDescriptionEn;
	String shortDescriptionAr;
	String descriptionEn;
	String descriptionAr;
	String sector;
	float previousClosed;
	float open;
	float lastTradePrice;
	float change;
	float perce_change;
	float mbp_bid1;
	float mbp_bid1_qty;
	float mbp_ask1;
	float mbp_ask1_qty;
	float noOfTrades;
	float volume;
	float turnOver;
	float vwap;
	float high;
	float low;
	String lastTradeTime;
	boolean tradable;
	boolean loser;
	String losePercentage;
	int settlementDays;
	boolean loserAlert;
	boolean tradableRight;
	boolean tradableRightAlert;
	CombinedDate tradableRightStartDate;
	CombinedDate tradableRightEndDate;
	String inMyShares;

	public String getInMyShares() {
		return inMyShares;
	}

	public void setInMyShares(String inMyShares) {
		this.inMyShares = inMyShares;
	}

	public int getSettlementDays() {
		return settlementDays;
	}

	public void setSettlementDays(int settlementDays) {
		this.settlementDays = settlementDays;
	}

	public String getLosePercentage() {
		return losePercentage;
	}

	public void setLosePercentage(String losePercentage) {
		this.losePercentage = losePercentage;
	}

	public boolean isTradable() {
		return tradable;
	}

	public void setTradable(boolean tradable) {
		this.tradable = tradable;
	}

	public boolean isLoser() {
		return loser;
	}

	public void setLoser(boolean loser) {
		this.loser = loser;
	}

	public boolean isLoserAlert() {
		return loserAlert;
	}

	public void setLoserAlert(boolean loserAlert) {
		this.loserAlert = loserAlert;
	}

	public boolean isTradableRight() {
		return tradableRight;
	}

	public void setTradableRight(boolean tradableRight) {
		this.tradableRight = tradableRight;
	}

	public boolean isTradableRightAlert() {
		return tradableRightAlert;
	}

	public void setTradableRightAlert(boolean tradableRightAlert) {
		this.tradableRightAlert = tradableRightAlert;
	}

	public CombinedDate getTradableRightStartDate() {
		return tradableRightStartDate;
	}

	public void setTradableRightStartDate(CombinedDate tradableRightStartDate) {
		this.tradableRightStartDate = tradableRightStartDate;
	}

	public CombinedDate getTradableRightEndDate() {
		return tradableRightEndDate;
	}

	public void setTradableRightEndDate(CombinedDate tradableRightEndDate) {
		this.tradableRightEndDate = tradableRightEndDate;
	}

	public Symbol() {
	}

	public Symbol(String id, String market) {
		this.id = id;
		this.market = market;
	}

	public Symbol(String id, String market, String shortDescEn, String shortDescAr) {
		this.id = id;
		this.market = market;
		this.shortDescriptionEn = shortDescEn;
		this.shortDescriptionAr = shortDescAr;
	}

	public float getPreviousClosed() {
		return previousClosed;
	}

	public void setPreviousClosed(float previousClosed) {
		this.previousClosed = previousClosed;
	}

	public float getOpen() {
		return open;
	}

	public void setOpen(float open) {
		this.open = open;
	}

	public float getLastTradePrice() {
		return lastTradePrice;
	}

	public void setLastTradePrice(float lastTradePrice) {
		this.lastTradePrice = lastTradePrice;
	}

	public float getChange() {
		return change;
	}

	public void setChange(float change) {
		this.change = change;
	}

	public float getPerce_change() {
		return perce_change;
	}

	public void setPerce_change(float perce_change) {
		this.perce_change = perce_change;
	}

	public float getMbp_bid1() {
		return mbp_bid1;
	}

	public void setMbp_bid1(float mbp_bid1) {
		this.mbp_bid1 = mbp_bid1;
	}

	public float getMbp_bid1_qty() {
		return mbp_bid1_qty;
	}

	public void setMbp_bid1_qty(float mbp_bid1_qty) {
		this.mbp_bid1_qty = mbp_bid1_qty;
	}

	public float getMbp_ask1() {
		return mbp_ask1;
	}

	public void setMbp_ask1(float mbp_ask1) {
		this.mbp_ask1 = mbp_ask1;
	}

	public float getMbp_ask1_qty() {
		return mbp_ask1_qty;
	}

	public void setMbp_ask1_qty(float mbp_ask1_qty) {
		this.mbp_ask1_qty = mbp_ask1_qty;
	}

	public float getNoOfTrades() {
		return noOfTrades;
	}

	public void setNoOfTrades(float noOfTrades) {
		this.noOfTrades = noOfTrades;
	}

	public float getVolume() {
		return volume;
	}

	public void setVolume(float volume) {
		this.volume = volume;
	}

	public float getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(float turnOver) {
		this.turnOver = turnOver;
	}

	public float getVwap() {
		return vwap;
	}

	public void setVwap(float vwap) {
		this.vwap = vwap;
	}

	public float getHigh() {
		return high;
	}

	public void setHigh(float high) {
		this.high = high;
	}

	public float getLow() {
		return low;
	}

	public void setLow(float low) {
		this.low = low;
	}

	public String getLastTradeTime() {
		return lastTradeTime;
	}

	public void setLastTradeTime(String lastTradeTime) {
		this.lastTradeTime = lastTradeTime;
	}

	public String getShortDescriptionEn() {
		return shortDescriptionEn;
	}

	public void setShortDescriptionEn(String shortDescriptionEn) {
		this.shortDescriptionEn = shortDescriptionEn;
	}

	public String getShortDescriptionAr() {
		return shortDescriptionAr;
	}

	public void setShortDescriptionAr(String shortDescriptionAr) {
		this.shortDescriptionAr = shortDescriptionAr;
	}

	public String getDescriptionEn() {
		return descriptionEn;
	}

	public void setDescriptionEn(String descriptionEn) {
		this.descriptionEn = descriptionEn;
	}

	public String getDescriptionAr() {
		return descriptionAr;
	}

	public void setDescriptionAr(String descriptionAr) {
		this.descriptionAr = descriptionAr;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (!(o instanceof Symbol))
			return false;
		return ((Symbol) o).getId() != null && ((Symbol) o).getId().equals(this.getId());
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Integer.parseInt(this.getId());
	}
}
