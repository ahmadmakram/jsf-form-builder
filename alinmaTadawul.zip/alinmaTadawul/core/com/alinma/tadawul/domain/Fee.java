package com.alinma.tadawul.domain;

import com.alinma.tadawul.domain.lov.FeeCategory;
import com.alinma.tadawul.domain.lov.FeeCode;
import com.ejada.commons.domain.BusinessObject;

/**
 * 
 * @author mahamoda
 * 
 */
public class Fee extends BusinessObject {

	private static final int FEE_DIMEN_LENGTH = 3;
	private String[] feeDimen = new String[FEE_DIMEN_LENGTH];
	private FeeCategory category;
	private FeeCode code;
	private String type;
	private Amount feeAmount;

	public FeeCategory getCategory() {
		return category;
	}

	public void setCategory(FeeCategory category) {
		this.category = category;
	}

	public FeeCode getCode() {
		return code;
	}

	public void setCode(FeeCode code) {
		this.code = code;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Amount getFeeAmount() {
		if (feeAmount == null) {
			feeAmount = new Amount();
		}
		return feeAmount;
	}

	public void setFeeAmount(Amount feeAmount) {
		this.feeAmount = feeAmount;
	}

	public String[] getFeeDimen() {
		return feeDimen;
	}

	public void setFeeDimen(String[] feeDimen) {
		this.feeDimen = feeDimen;
	}
}
