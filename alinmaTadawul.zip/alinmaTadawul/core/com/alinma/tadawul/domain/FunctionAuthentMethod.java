package com.alinma.tadawul.domain;

import com.alinma.tadawul.domain.lov.AuthenticationDisabledReason;
import com.alinma.tadawul.domain.lov.AuthenticationStatus;
import com.alinma.tadawul.domain.lov.NotificationMethodType;
import com.ejada.commons.domain.lov.SecurityInfoType;

/**
 * 
 * @author Hani Younis
 * 
 */
public class FunctionAuthentMethod {

	public static final int DIMENSOIONSSIZE = 3;
	private String[] functioDimensions = new String[DIMENSOIONSSIZE];
	private AuthenticationStatus authenticationStatus;
	private SecurityInfoType securityInfoType;
	private AuthenticationDisabledReason authenticationDisabledReason;
	private String authenticationGroupNumber;
	private String returnedNotificationsMethodsNumber;
	private NotificationMethodType notificationMethodType;

	public String[] getFunctioDimensions() {
		return functioDimensions;
	}

	public AuthenticationDisabledReason getAuthenticationDisabledReason() {
		return authenticationDisabledReason;
	}

	public String getAuthenticationGroupNumber() {
		return authenticationGroupNumber;
	}

	public String getReturnedNotificationsMethodsNumber() {
		return returnedNotificationsMethodsNumber;
	}

	public NotificationMethodType getNotificationMethodType() {
		return notificationMethodType;
	}

	public void setFunctioDimensions(String[] functioDimensions) {
		this.functioDimensions = functioDimensions;
	}

	public void setAuthenticationDisabledReason(AuthenticationDisabledReason authenticationDisabledReason) {
		this.authenticationDisabledReason = authenticationDisabledReason;
	}

	public void setAuthenticationGroupNumber(String authenticationGroupNumber) {
		this.authenticationGroupNumber = authenticationGroupNumber;
	}

	public void setReturnedNotificationsMethodsNumber(String returnedNotificationsMethodsNumber) {
		this.returnedNotificationsMethodsNumber = returnedNotificationsMethodsNumber;
	}

	public void setNotificationMethodType(NotificationMethodType notificationMethodType) {
		this.notificationMethodType = notificationMethodType;
	}

	public void setAuthenticationStatus(AuthenticationStatus authenticationStatus) {
		this.authenticationStatus = authenticationStatus;
	}

	public AuthenticationStatus getAuthenticationStatus() {
		return authenticationStatus;
	}

	public SecurityInfoType getSecurityInfoType() {
		return securityInfoType;
	}

	public void setSecurityInfoType(SecurityInfoType securityInfoType) {
		this.securityInfoType = securityInfoType;
	}
}
