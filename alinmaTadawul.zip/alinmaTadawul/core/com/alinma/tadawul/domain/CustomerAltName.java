/**
 * 
 */
package com.alinma.tadawul.domain;

import org.hibernate.validator.NotEmpty;
import org.hibernate.validator.NotNull;

import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.Language;

/**
 * Holds the Alternative name of the customer.
 * 
 * @author Waleed Tayea
 */
public class CustomerAltName extends BusinessObject {

	private SurrogateKey surrogateKey; // surrogate key for the alternative name
	private EntityKey nameType;
	private EntityKey nameLang;
	private String fullName;
	// TODO add to domain
	private CombinedDate effectiveDate;
	// TODO add to domain
	private CombinedDate expiryDate;

	@NotNull(message = "{customerAlternativeName.nameType.required}")
	public EntityKey getNameType() {
		return nameType;
	}

	public void setNameType(EntityKey nameType) {
		this.nameType = nameType;
	}

	public EntityKey getNameLang() {
		return nameLang;
	}

	public void setNameLang(Language nameLang) {
		this.nameLang = nameLang;
	}

	@NotEmpty(message = "{customerAlternativeName.fullName.required}")
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public CombinedDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(CombinedDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public CombinedDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(CombinedDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	/**
	 * @param nameLang
	 *            the nameLang to set
	 */
	public void setNameLang(EntityKey nameLang) {
		this.nameLang = nameLang;
	}
}
