package com.alinma.tadawul.domain;

import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

public class CustomerDependency extends DateAwareEntityImpl {

	private SurrogateKey dpndntId;
	private String partyId;
	private EntityKey relType;
	private EntityKey gender;
	private CombinedDate dateOfBirth;
	private String arFirstName;
	private String arSecondName;
	private String arThirdName;
	private String arFamilyName;
	private String enFirstName;
	private String enSecondName;
	private String enThirdName;
	private String enFamilyName;
	private EntityKey nationality;
	private boolean updatable;
	private EntityKey partyType;
	private CustomerIdDoc customerIdDoc;
	private boolean reverse;

	public CustomerIdDoc getCustomerIdDoc() {
		if (customerIdDoc == null) {
			this.customerIdDoc = createDependencyCustomerIdDoc();
		}
		return customerIdDoc;
	}

	public String getIdNumber() {
		return this.getCustomerIdDoc().getIdDocKey().getIdNumber();
	}

	public EntityKey getIdType() {
		return this.getCustomerIdDoc().getIdDocKey().getIdDocType();
	}

	private CustomerIdDoc createDependencyCustomerIdDoc() {
		return new CustomerIdDoc();
	}

	public void setCustomerIdDoc(CustomerIdDoc customerIdDoc) {
		this.customerIdDoc = customerIdDoc;
	}

	public EntityKey getGender() {
		return gender;
	}

	public void setGender(EntityKey gender) {
		this.gender = gender;
	}

	public CombinedDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(CombinedDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public SurrogateKey getDpndntId() {
		if (dpndntId == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			dpndntId = new SurrogateKey(key);
		}
		return dpndntId;
	}

	public void setDpndntId(SurrogateKey dpndntId) {
		this.dpndntId = dpndntId;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getArFirstName() {
		return arFirstName;
	}

	public void setArFirstName(String arFirstName) {
		this.arFirstName = arFirstName;
	}

	public String getArSecondName() {
		return arSecondName;
	}

	public void setArSecondName(String arSecondName) {
		this.arSecondName = arSecondName;
	}

	public String getArThirdName() {
		return arThirdName;
	}

	public void setArThirdName(String arThirdName) {
		this.arThirdName = arThirdName;
	}

	public String getArFamilyName() {
		return arFamilyName;
	}

	public void setArFamilyName(String arFamilyName) {
		this.arFamilyName = arFamilyName;
	}

	public String getEnFirstName() {
		return enFirstName;
	}

	public void setEnFirstName(String enFirstName) {
		this.enFirstName = enFirstName;
	}

	public String getEnSecondName() {
		return enSecondName;
	}

	public void setEnSecondName(String enSecondName) {
		this.enSecondName = enSecondName;
	}

	public String getEnThirdName() {
		return enThirdName;
	}

	public void setEnThirdName(String enThirdName) {
		this.enThirdName = enThirdName;
	}

	public String getEnFamilyName() {
		return enFamilyName;
	}

	public void setEnFamilyName(String enFamilyName) {
		this.enFamilyName = enFamilyName;
	}

	public EntityKey getRelType() {
		return relType;
	}

	public void setRelType(EntityKey relType) {
		this.relType = relType;
	}

	public EntityKey getNationality() {
		return nationality;
	}

	public void setNationality(EntityKey nationality) {
		this.nationality = nationality;
	}

	public EntityKey getPartyType() {
		return partyType;
	}

	public void setPartyType(EntityKey partyType) {
		this.partyType = partyType;
	}

	public boolean isUpdatable() {
		return updatable;
	}

	public void setUpdatable(boolean updatable) {
		this.updatable = updatable;
	}

	public boolean isReverse() {
		return reverse;
	}

	public void setReverse(boolean reverse) {
		this.reverse = reverse;
	}
}
