package com.alinma.tadawul.domain;

import com.ejada.commons.domain.CombinedDate;

/**
 * A marker interface represents all the business objects that have a period in which they are valid.
 * 
 * @author Administrator
 * 
 */
public interface DateAwareEntity {

	CombinedDate getStartEffectiveDate();

	void setStartEffectiveDate(CombinedDate startEffectiveDate);

	CombinedDate getEndEffectiveDate();

	void setEndEffectiveDate(CombinedDate endEffectiveDate);

	boolean isValid();
}
