package com.alinma.tadawul.domain;

import com.ejada.commons.domain.lov.ChannelId;

public class TadawulLogData {

	private String id;
	private String server;
	private String fileName;
	private String channelId;
	private String application;
	private String messageId;
	private String requestId;
	private String statusCode;
	private String cif;
	private String userId;
	private String serviceName;
	private String functionId;
	private String amount;
	private String requestTime;
	private String responseTime;
	private String waitTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

	public String getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}

	public String getWaitTime() {
		return waitTime;
	}

	public void setWaitTime(String waitTime) {
		this.waitTime = waitTime;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("ServerIP : " + getServer() + " - ");
		buffer.append("FileName : " + getFileName() + " - ");
		buffer.append("ChannelId : " + getChannelId() + " - ");
		buffer.append("Application : " + getApplication() + " - ");
		buffer.append("MessageId : " + getMessageId() + " - ");
		buffer.append("MessageId : " + getMessageId() + " - ");
		buffer.append("RequestId : " + getRequestId() + " - ");
		buffer.append("StatusCode : " + getStatusCode() + " - ");
		buffer.append("Cif : " + getCif() + " - ");
		buffer.append("UserId : " + getUserId() + " - ");
		buffer.append("ServiceName : " + getServiceName() + " - ");
		buffer.append("FunctionId : " + getFunctionId() + " - ");
		buffer.append("Amount : " + getAmount() + " - ");
		buffer.append("RequestTime : " + getRequestTime() + " - ");
		buffer.append("ResponseTime : " + getResponseTime() + " - ");
		buffer.append("WaitTime : " + getWaitTime() + " - ");
		return buffer.toString();
	}
}
