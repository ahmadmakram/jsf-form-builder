package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.lov.CustomerId;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class DefaultIdDoc extends BusinessObject {

	private CustomerId customerId;
	private Boolean registerETrade;
	private String eTradeLoginName;
	private CustomerIdDoc idDoc;
	private EntityKey legalEntity;
	private EntityKey sublegalEntity;
	private EntityKey investmentClassification;

	public Boolean getRegisterETrade() {
		return registerETrade;
	}

	public void setRegisterETrade(Boolean registerETrade) {
		this.registerETrade = registerETrade;
	}

	public String getETradeLoginName() {
		return eTradeLoginName;
	}

	public void setETradeLoginName(String tradeLoginName) {
		eTradeLoginName = tradeLoginName;
	}

	public CustomerId getCustomerId() {
		if (this.customerId == null) {
			this.customerId = createCustomerId();
		}
		return customerId;
	}

	public CustomerId createCustomerId() {
		return (CustomerId) ApplicationContextFactory.getApplicationContext().getBean("customerId");
	}

	public void setCustomerId(CustomerId customerId) {
		this.customerId = customerId;
	}

	public CustomerIdDoc getIdDoc() {
		if (this.idDoc == null) {
			this.idDoc = createIdDoc();
		}
		return idDoc;
	}

	public CustomerIdDoc createIdDoc() {
		return (CustomerIdDoc) ApplicationContextFactory.getApplicationContext().getBean("customerIdDoc");
	}

	public void setIdDoc(CustomerIdDoc idDoc) {
		this.idDoc = idDoc;
	}

	// /@author hani go to refactor
	public EntityKey getLegalEntity() {
		return legalEntity;
	}

	public void setLegalEntity(EntityKey legalEntity) {
		this.legalEntity = legalEntity;
	}

	public EntityKey getSublegalEntity() {
		return sublegalEntity;
	}

	public void setSublegalEntity(EntityKey sublegalEntity) {
		this.sublegalEntity = sublegalEntity;
	}

	public EntityKey getInvestmentClassification() {
		return investmentClassification;
	}

	public void setInvestmentClassification(EntityKey investmentClassification) {
		this.investmentClassification = investmentClassification;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	public void CommitUpdates() {
		super.CommitUpdates();
		if (customerId != null) {
			customerId.CommitUpdates();
		}
		if (idDoc != null) {
			idDoc.CommitUpdates();
		}
	}
}
