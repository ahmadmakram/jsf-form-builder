package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.validators.annotations.SkipValidation;

public class CustomerStartingInfo extends BusinessObject {

	private DefaultIdDoc defaultIdDoc;
	private CustomerPersonalInfo personalInfo;
	private CustomerBankInfo bankInfo;

	public DefaultIdDoc getDefaultIdDoc() {
		if (this.defaultIdDoc == null) {
			this.defaultIdDoc = createDefaultIdDoc();
		}
		return defaultIdDoc;
	}

	public DefaultIdDoc createDefaultIdDoc() {
		return (DefaultIdDoc) ApplicationContextFactory.getApplicationContext().getBean("defaultIdDoc");
	}

	public void setDefaultIdDoc(DefaultIdDoc defaultIdDoc) {
		this.defaultIdDoc = defaultIdDoc;
	}

	public CustomerPersonalInfo getPersonalInfo() {
		if (personalInfo == null) {
			this.personalInfo = createPersonalInfo();
		}
		return personalInfo;
	}

	public CustomerPersonalInfo createPersonalInfo() {
		return (CustomerPersonalInfo) ApplicationContextFactory.getApplicationContext().getBean("customerPersonalInfo");
	}

	public void setPersonalInfo(CustomerPersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}

	@SkipValidation(context = "internet_user")
	public CustomerBankInfo getBankInfo() {
		if (bankInfo == null) {
			this.bankInfo = createBankInfo();
		}
		return bankInfo;
	}

	public CustomerBankInfo createBankInfo() {
		return (CustomerBankInfo) ApplicationContextFactory.getApplicationContext().getBean("customerBankInfo");
	}

	public void setBankInfo(CustomerBankInfo bankInfo) {
		this.bankInfo = bankInfo;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (defaultIdDoc != null) {
			defaultIdDoc.CommitUpdates();
		}
		if (personalInfo != null) {
			personalInfo.CommitUpdates();
		}
		if (bankInfo != null) {
			bankInfo.CommitUpdates();
		}
	}
}
