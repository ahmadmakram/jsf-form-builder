/**
 * 
 */
package com.alinma.tadawul.domain;

import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public class CustomerProduct extends BusinessObject {

	private EntityKey productId;
	private SurrogateKey surrogateKey;

	/**
	 * @return the productId
	 */
	public EntityKey getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(EntityKey productId) {
		this.productId = productId;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}
}
