package com.alinma.tadawul.domain;

import com.alinma.tadawul.domain.lov.BeneficiaryStatus;
import com.alinma.tadawul.domain.lov.DetailsOfCharge;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.IdDocKey;
import com.ejada.commons.domain.Name;

/**
 * @author Khalid AlQahtani
 * 
 */
public class Beneficiary extends BusinessObject implements EntityKey {

	private String code;
	private EntityKey beneficiaryType;
	private EntityKey country;
	private EntityKey currency;
	private BeneficiaryStatus status;
	private String nickName;
	private Name name;
	private Account account;
	private Bank bank;
	private boolean iban;
	private String rejectReason;
	private EntityKey scID;
	private Boolean subUserEnable;
	private EntityKey fundTransferPurpose;
	private EntityKey fundTransferCompany;
	private EntityKey fundTransferSubCateogry;
	private String defualtAmount;
	private DetailsOfCharge detailsOfCharge;
	private String address;
	private String phoneNum;
	private IdDocKey idDocKey;
	private String paymentDesc;
	private String corresponding;
	private String IntermediateCode;
	private String receiverBankCode;
	private EntityKey charityInstitution;
	private EntityKey CharityInstitutionSubCategory;
	private EntityKey CharityInstitutionCategory;

	public EntityKey getCharityInstitutionCategory() {
		return CharityInstitutionCategory;
	}

	public void setCharityInstitutionCategory(EntityKey charityInstitutionCategory) {
		CharityInstitutionCategory = charityInstitutionCategory;
	}

	public EntityKey getCharityInstitution() {
		return charityInstitution;
	}

	public void setCharityInstitution(EntityKey charityInstitution) {
		this.charityInstitution = charityInstitution;
	}

	public EntityKey getCharityInstitutionSubCategory() {
		return CharityInstitutionSubCategory;
	}

	public void setCharityInstitutionSubCategory(EntityKey charityInstitutionSubCategory) {
		CharityInstitutionSubCategory = charityInstitutionSubCategory;
	}

	public String getReceiverBankCode() {
		return receiverBankCode;
	}

	public void setReceiverBankCode(String receiverBankCode) {
		this.receiverBankCode = receiverBankCode;
	}

	public EntityKey getCountry() {
		return country;
	}

	public void setCountry(EntityKey country) {
		this.country = country;
	}

	public EntityKey getCurrency() {
		return currency;
	}

	public void setCurrency(EntityKey currency) {
		this.currency = currency;
	}

	public BeneficiaryStatus getStatus() {
		return status;
	}

	public void setStatus(BeneficiaryStatus status) {
		this.status = status;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Name getName() {
		if (this.name == null) {
			this.name = createName();
		}
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Account getAccount() {
		if (this.account == null) {
			this.account = createAccount();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Bank getBank() {
		if (this.bank == null) {
			this.bank = createBank();
		}
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public boolean isIban() {
		return iban;
	}

	public void setIban(boolean iban) {
		this.iban = iban;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public EntityKey getScID() {
		return scID;
	}

	public void setScID(EntityKey scID) {
		this.scID = scID;
	}

	public Boolean getSubUserEnable() {
		return subUserEnable;
	}

	public void setSubUserEnable(Boolean subUserEnable) {
		this.subUserEnable = subUserEnable;
	}

	public EntityKey getFundTransferCompany() {
		return fundTransferCompany;
	}

	public void setFundTransferCompany(EntityKey fundTransferCompany) {
		this.fundTransferCompany = fundTransferCompany;
	}

	public EntityKey getFundTransferSubCateogry() {
		return fundTransferSubCateogry;
	}

	public void setFundTransferSubCateogry(EntityKey fundTransferSubCateogry) {
		this.fundTransferSubCateogry = fundTransferSubCateogry;
	}

	public void setDefualtAmount(String defualtAmount) {
		this.defualtAmount = defualtAmount;
	}

	public String getDefualtAmount() {
		return defualtAmount;
	}

	public void setDetailsOfCharge(DetailsOfCharge detailsOfCharge) {
		this.detailsOfCharge = detailsOfCharge;
	}

	public DetailsOfCharge getDetailsOfCharge() {
		return detailsOfCharge;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public IdDocKey getIdDocKey() {
		if (idDocKey == null) {
			idDocKey = createidDocKey();
		}
		return idDocKey;
	}

	public void setIdDocKey(IdDocKey idDocKey) {
		this.idDocKey = idDocKey;
	}

	public String getPaymentDesc() {
		return paymentDesc;
	}

	public void setPaymentDesc(String paymentDesc) {
		this.paymentDesc = paymentDesc;
	}

	public String getCorresponding() {
		return corresponding;
	}

	public void setCorresponding(String corresponding) {
		this.corresponding = corresponding;
	}

	public String getIntermediateCode() {
		return IntermediateCode;
	}

	public void setIntermediateCode(String intermediateCode) {
		IntermediateCode = intermediateCode;
	}

	public EntityKey getFundTransferPurpose() {
		return fundTransferPurpose;
	}

	public void setFundTransferPurpose(EntityKey fundTransferPurpose) {
		this.fundTransferPurpose = fundTransferPurpose;
	}

	public Name createName() {
		return this.name = new Name();
	}

	public Account createAccount() {
		return this.account = new Account();
	}

	public Bank createBank() {
		return this.bank = new Bank();
	}

	public IdDocKey createidDocKey() {
		return this.idDocKey = new IdDocKey();
	}

	public EntityKey getBeneficiaryType() {
		return beneficiaryType;
	}

	public void setBeneficiaryType(EntityKey beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}
}
