package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.validators.annotations.SkipValidation;
import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.lov.DefaultAddressContactType;

public class CustomerEssentialInfo extends BusinessObject {

	private CustomerEssentialCoreInfo customerEssentialCoreInfo;
	private CustomerEssentialAdditionalInfo customerEssentialAdditionalInfo;

	public CustomerEssentialCoreInfo getCustomerEssentialCoreInfo() {
		if (customerEssentialCoreInfo == null) {
			customerEssentialCoreInfo = createCustomerEssentialCoreInfo();
		}
		return customerEssentialCoreInfo;
	}

	public CustomerEssentialCoreInfo createCustomerEssentialCoreInfo() {
		return (CustomerEssentialCoreInfo) ApplicationContextFactory.getApplicationContext().getBean("customerEssentialCoreInfo");
	}

	public void setCustomerEssentialCoreInfo(CustomerEssentialCoreInfo customerEssentialCoreInfo) {
		this.customerEssentialCoreInfo = customerEssentialCoreInfo;
	}

	public CustomerEssentialAdditionalInfo getCustomerEssentialAdditionalInfo() {
		if (customerEssentialAdditionalInfo == null) {
			customerEssentialAdditionalInfo = createCustomerEssentialAdditionalInfo();
		}
		return customerEssentialAdditionalInfo;
	}

	public CustomerEssentialAdditionalInfo createCustomerEssentialAdditionalInfo() {
		return (CustomerEssentialAdditionalInfo) ApplicationContextFactory.getApplicationContext().getBean("customerEssentialAdditionalInfo");
	}

	public void setCustomerEssentialAdditionalInfo(CustomerEssentialAdditionalInfo customerEssentialAdditionalInfo) {
		this.customerEssentialAdditionalInfo = customerEssentialAdditionalInfo;
	}

	@SkipValidation
	public CustomerContact getDefaultContactInfo() {
		if (this.getCustomerEssentialAdditionalInfo().getDefaultAddressContacts().getDefaultContact() == null) {
			return null;
		}
		if (this.getCustomerEssentialAdditionalInfo().getDefaultAddressContacts().getDefaultContact().equals(DefaultAddressContactType.WORK)) {
			return this.getCustomerEssentialAdditionalInfo().getWorkContacts();
		} else {
			return this.getCustomerEssentialCoreInfo().getHomeContacts();
		}
	}

	@SkipValidation
	public CustomerAddress getDefaultAddressInfo() {
		if (customerEssentialAdditionalInfo.getDefaultAddressContacts().getDefaultAddress() == null) {
			return null;
		}
		if (customerEssentialAdditionalInfo.getDefaultAddressContacts().getDefaultAddress().equals(DefaultAddressContactType.WORK)) {
			return customerEssentialAdditionalInfo.getWorkAddress();
		} else {
			return customerEssentialCoreInfo.getHomeAdrress();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (customerEssentialCoreInfo != null) {
			customerEssentialCoreInfo.CommitUpdates();
		}
		if (customerEssentialAdditionalInfo != null) {
			customerEssentialAdditionalInfo.CommitUpdates();
		}
	}
}
