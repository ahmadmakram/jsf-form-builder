package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

public enum Status implements EntityKey {
	ACTIVE("A"), INACTIVE("I"), PENDING("P");

	private String code;

	Status(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}
}
