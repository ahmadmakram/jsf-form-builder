package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

/**
 * @author mgahmed
 * 
 */
public enum ServiceFunctionsEnum {
	cardPayment("16500000"), getAccountTransactions("52020000"), getAccountWithBalance("26010000"), requestCheckBook("19500000"), getMOIFee("14031000"), MOIFeePayment("14530000"), getAccountsWithBalance(
			"26021000"), payBill("14520000"), payAdhocBill("14520500"), createIpoApplication("34500000"), createComplaint("56000000"), getStandingOrders("50000000"), createOwnTransferSO("51000000"), createInternalTransferSO(
			"51000010"), createKSATransferSO("51000020"), createInternationalTransferSO("51000030"), updateOwnInternalTransferSO("51001010"), updateKSATransferSO("51001020"), updateInternationalTransferSO(
			"51001030"), stopOwnInternalTransferSO("51002010"), stopKSATransferSO("51002020"), stopInternationalTransferSO("51002030"), updateAccountNames("27005000"), updateAccountStatementSetting(
			"27002000"), primaryCardIssuanceRequest("17010010"), supplementaryCardIssuanceRequest("17010020"), cardReissuanceRequest("17010030"), cardReplaceRequest("17010035"), cardLimitChangeRequest(
			"17010040"), cancelCardRequest("17010050"), addBeneficiary("12020010"), transferBetweenCustomerAccounts("38501000"), transferToBeneficiaryInsideBank("38502000"), transferToBeneficiaryInsideKsaViaSarie(
			"38503000"), applyMOIRefundRequest("15502000"), currentAccountStatementRequest("52501000"), creditCardStatementRequest("52502000"), authenticateUser("10020100"), cardStatuseNormalOpenCard(
			"17000040"), cardStatusUnrestrictedOpenCard("17000041"), cardStatusInactiveCard("17000042"), cardStatusLostCard("17000043"), cardStatusStolenCard("17000044"), cardStatusClosedCard(
			"17000045"), cardStatusPickupCard("17000046"), cardStatusRestrictedCard("17000047"), personalFinanceInstallmentScheduleRequest("44510000"), ussdRegistration("10500000"), ussdReRegistration(
			"10502000"), calculateFees("32040000"), createOrder("33000000"), updateOrder("33001000"), cancelOrder("33002000"), getAccountsWithoutBalance("26020000");

	ServiceFunctionsEnum(String code) {
		this.code = code;
	}

	private String code;

	public String getCode() {
		return code;
	}

	private static Map<String, ServiceFunctionsEnum> map;
	static {
		map = new HashMap<String, ServiceFunctionsEnum>();
		for (ServiceFunctionsEnum value : ServiceFunctionsEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static ServiceFunctionsEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
