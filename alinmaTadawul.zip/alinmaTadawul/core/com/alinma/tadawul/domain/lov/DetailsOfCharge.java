package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum DetailsOfCharge implements EntityKey {
	BENEFICIARY("BEN"), OUR("OUR"), SHARED("SHA");

	private String code;
	private static Map<String, DetailsOfCharge> map;
	static {
		map = new Hashtable<String, DetailsOfCharge>();
		for (DetailsOfCharge value : DetailsOfCharge.values()) {
			map.put(value.getCode(), value);
		}
	}

	DetailsOfCharge(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static DetailsOfCharge getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
