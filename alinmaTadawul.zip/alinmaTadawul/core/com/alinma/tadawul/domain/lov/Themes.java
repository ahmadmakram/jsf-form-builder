/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum Themes implements EntityKey {
	BASIC("0"), THEME_ONE("1"), THEME_TWO("2"), THEME_THREE("3");

	private String code;
	private static Map<String, Themes> map;
	static {
		map = new HashMap<String, Themes>();
		for (Themes value : Themes.values()) {
			map.put(value.getCode(), value);
		}
	}

	Themes(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static Themes getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
