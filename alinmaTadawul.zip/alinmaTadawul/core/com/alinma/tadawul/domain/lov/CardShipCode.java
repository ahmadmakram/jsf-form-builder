/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum CardShipCode implements EntityKey {
	DISALLOWED("0"), ALLOWED("1"), REQUIRED("2");

	private String code;
	private static Map<String, CardShipCode> map;
	static {
		map = new Hashtable<String, CardShipCode>();
		for (CardShipCode value : CardShipCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	CardShipCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static CardShipCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
