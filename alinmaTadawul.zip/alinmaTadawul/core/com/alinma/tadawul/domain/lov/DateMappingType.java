/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Hammam Comp
 * 
 */
public enum DateMappingType implements EntityKey {
	HijriFromGregorian("1"), GregorianFromHijri("2");

	private String code;

	DateMappingType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
