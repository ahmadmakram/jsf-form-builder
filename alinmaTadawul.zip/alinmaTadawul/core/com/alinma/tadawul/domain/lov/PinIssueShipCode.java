package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum PinIssueShipCode implements EntityKey {
	DISALLOWED("0"), ALLOWED("1"), REQUIRED("2");

	private String code;
	private static Map<String, PinIssueShipCode> map;
	static {
		map = new Hashtable<String, PinIssueShipCode>();
		for (PinIssueShipCode value : PinIssueShipCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	PinIssueShipCode(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static PinIssueShipCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
