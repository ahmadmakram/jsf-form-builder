package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum SAMAStatus implements EntityKey {
	NORMAL("0"), WARNING("1"), BLOCKED("2");

	private String code;

	SAMAStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	private static Map<String, SAMAStatus> map;
	static {
		map = new Hashtable<String, SAMAStatus>();
		for (SAMAStatus value : SAMAStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static SAMAStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
