/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author ASQA
 * 
 */
public enum IdDocType implements EntityKey {
	IQAMA("2"), NATIONAL_ID("1"), FAMILY_REGISTERATION_BOOK("7"), SAUDI_PASSPORT("3"), GENERAL_AGREEMENT("77");

	private String code;
	private static Map<String, IdDocType> map;
	static {
		map = new Hashtable<String, IdDocType>();
		for (IdDocType value : IdDocType.values()) {
			map.put(value.getCode(), value);
		}
	}

	IdDocType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static IdDocType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
