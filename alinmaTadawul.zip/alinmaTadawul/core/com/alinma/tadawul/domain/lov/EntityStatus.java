package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

public enum EntityStatus implements EntityKey {
	ACTIVE("A"), INACTIVE("I");

	private String code;

	EntityStatus(String code) {
		this.code = code;
	}

	/**
	 * Returns status code
	 */
	public String getCode() {
		return code;
	}
}
