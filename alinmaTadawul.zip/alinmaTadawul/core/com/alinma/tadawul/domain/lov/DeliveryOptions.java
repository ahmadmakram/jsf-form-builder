package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum DeliveryOptions implements EntityKey {
	ALERT_BOX("A", false), BRANCH("B", true), EMAIL("E", false), FAX("F", false), MAIL_BOX("M", true), ONLINE("O", false), INTERNET_BANKING_INBOX("IB", false); // means disable

	// DISABLE_DELIVERY("I",false);//this is wrong value should be removed
	private String code;
	private boolean physical;
	private static Map<String, DeliveryOptions> map;
	static {
		map = new Hashtable<String, DeliveryOptions>();
		for (DeliveryOptions value : DeliveryOptions.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static DeliveryOptions getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}

	DeliveryOptions(String code, boolean physical) {
		this.code = code;
		this.physical = physical;
	}

	public String getCode() {
		return code;
	}

	public boolean isPhysical() {
		return physical;
	}
}
