/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.EnumMap;
import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public enum AddressIndicator implements EntityKey {
	WASEL("W"), POBOX("POF"), DESCRIPTIVE("D");

	private static Map<String, AddressIndicator> map;
	private String code;
	static {
		map = new Hashtable<String, AddressIndicator>();
		for (AddressIndicator value : AddressIndicator.values()) {
			map.put(value.getCode(), value);
		}
	}

	// Default constructor
	AddressIndicator(String code) {
		this.code = code;
	}

	/**
	 * Get the code of the Address Indicator
	 * 
	 * @return
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Returns the Address Indicator for the specified code.
	 * 
	 * @param code
	 * @return
	 */
	public static AddressIndicator getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
