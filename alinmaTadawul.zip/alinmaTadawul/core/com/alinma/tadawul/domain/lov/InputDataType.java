package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum InputDataType implements EntityKey {
	Number("N"), LOV("L"), Text("T"), Date("D"), Boolean("B");

	private String code;
	private static Map<String, InputDataType> map;
	static {
		map = new Hashtable<String, InputDataType>();
		for (InputDataType value : InputDataType.values()) {
			map.put(value.getCode(), value);
		}
	}

	InputDataType(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static InputDataType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
