package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum DefaultAddressContactType implements EntityKey {
	HOME("3"), WORK("4");

	private String code;
	private static Map<String, DefaultAddressContactType> map;
	static {
		map = new Hashtable<String, DefaultAddressContactType>();
		for (DefaultAddressContactType value : DefaultAddressContactType.values()) {
			map.put(value.getCode(), value);
		}
	}

	DefaultAddressContactType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static DefaultAddressContactType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
