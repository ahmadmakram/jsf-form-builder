package com.alinma.tadawul.domain.lov;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotEmpty;
import org.hibernate.validator.NotNull;
import org.hibernate.validator.Pattern;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class AccountId extends BusinessObject implements EntityKey {

	private EntityKey accountType;
	private String accountNumber;
	private String accountIbanNumber;

	public String getCode() {
		if (accountIbanNumber != null)
			return accountIbanNumber;
		return accountNumber;
	}

	/**
	 * @return the accountType
	 */
	@NotNull(message = "{account.accountType.required}")
	public EntityKey getAccountType() {
		return accountType;
	}

	/**
	 * @param accountType
	 *            the accountType to set
	 */
	public void setAccountType(EntityKey accountType) {
		this.accountType = accountType;
	}

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber
	 *            the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	@NotEmpty(message = "{account.accountNo.required}")
	@Length(min = 24, max = 24, message = "{account.invalidIbanFormat}")
	@Pattern(regex = "\\D\\D(\\d)*", message = "{account.invalidIbanFormat}")
	public String getAccountIbanNumber() {
		return accountIbanNumber;
	}

	public void setAccountIbanNumber(String accountIbanNumber) {
		this.accountIbanNumber = accountIbanNumber;
	}
}
