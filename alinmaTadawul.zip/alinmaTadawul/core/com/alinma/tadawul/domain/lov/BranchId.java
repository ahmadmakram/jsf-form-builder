package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum BranchId implements EntityKey {
	INV_BRANCH("SA0010002");

	private String code;
	private static Map<String, BranchId> map;
	static {
		map = new HashMap<String, BranchId>();
		for (BranchId value : BranchId.values()) {
			map.put(value.getCode(), value);
		}
	}

	BranchId(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static BranchId getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
