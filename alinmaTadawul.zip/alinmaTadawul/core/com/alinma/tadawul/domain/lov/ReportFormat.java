package com.alinma.tadawul.domain.lov;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum ReportFormat {
	// HTML("HTML", "text/html; charset=UTF-8", "html"),
	PDF("PDF", "application/pdf", "pdf"), WORD("RTF", "application/rtf", "rtf"), EXCEL("XLS", "application/xls", "xls"), CSV("CSV", "application/vnd.ms-excel", "csv"), HTML("HTML", "text/html",
			"html");

	private String code;
	private String responseContentType;
	private String fileExtension;

	ReportFormat(String format, String responseContentType, String fileExtension) {
		this.code = format;
		this.responseContentType = responseContentType;
		this.fileExtension = fileExtension;
	}

	public String getCode() {
		return this.code;
	}

	public String getResponseContentType() {
		return this.responseContentType;
	}

	public String getFileExtension() {
		return this.fileExtension;
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	public List getValues() {
		return Arrays.asList(this.values());
	}

	public void setCode(String format) {
		this.code = format;
	}

	private static Map<String, ReportFormat> map;
	static {
		map = new HashMap<String, ReportFormat>();
		for (ReportFormat value : ReportFormat.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static ReportFormat getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
