package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum Country implements EntityKey {
	SAUDIARABIA("SA"), RESIDENT("RD");

	private String code;
	private static Map<String, Country> map;
	static {
		map = new Hashtable<String, Country>();
		for (Country value : Country.values()) {
			map.put(value.getCode(), value);
		}
	}

	Country(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static Country getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
