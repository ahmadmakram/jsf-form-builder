/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author mbrins
 * 
 */
public enum AccountType implements EntityKey {
	CURRENT_ACCOUNT("CA"), CHARGE_CARD("CC"), SAVING_ACCOUNT("SA"), INVESTMENT_ACCOUNT("IN"), DEPOSIT_ACCOUNT("DA"), PERSONAL_FINANCE("PF"), MUTUAL_FUND("MF");

	private String code;
	private static Map<String, AccountType> map;
	static {
		map = new HashMap<String, AccountType>();
		for (AccountType value : AccountType.values()) {
			map.put(value.getCode(), value);
		}
	}

	AccountType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static AccountType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
