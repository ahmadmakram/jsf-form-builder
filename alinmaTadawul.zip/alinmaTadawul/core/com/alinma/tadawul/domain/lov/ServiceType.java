package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum ServiceType implements EntityKey {
	CUSTOMER_INITIATED_PAYMENT("CIP"), ELECTRICITY("ELCT"), PHONE("PHON"), MOBILE_PHONE("GSM"), LAND_LINE("LLIN"), INSURANCE("INSR"), BANK_SERVICE("BKSV"), GOVERNMENT_SERVICE("GOVT"), MEDICAL("MED"), CREDIT_CARD(
			"CCRD"), UTILITY("UTIL"), PERSONAL_COMPUTER_PAYMENT_INSTALLMENT("PCIN"), UNIVERSITY_EXAM_FEES("EXAM");

	private String code;
	private static Map<String, ServiceType> map;
	static {
		map = new Hashtable<String, ServiceType>();
		for (ServiceType value : ServiceType.values()) {
			map.put(value.getCode(), value);
		}
	}

	ServiceType(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static ServiceType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
