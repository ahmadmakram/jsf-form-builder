/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author M. Ali Hammam
 * 
 */
public enum LoginType implements EntityKey {
	USER_ID("1"), CIF("2"), ALINMA_ID("3"), LOGIN_NAME("4");

	LoginType(String code) {
		this.code = code;
	}

	private String code;

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
}
