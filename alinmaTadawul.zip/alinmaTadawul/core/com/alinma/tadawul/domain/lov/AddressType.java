package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum AddressType implements EntityKey {
	HOME("3"), WORK("4");

	private String code;
	private static Map<String, AddressType> map;
	static {
		map = new Hashtable<String, AddressType>();
		for (AddressType value : AddressType.values()) {
			map.put(value.getCode(), value);
		}
	}

	AddressType(String code) {
		this.code = code;
	}

	/**
	 * Returns the address type code;
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Returns the Address Type for the specified code.
	 * 
	 * @param code
	 * @return
	 */
	public static AddressType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
