/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum AuthenticationStatus implements EntityKey {
	DISABLED("0"), ENABLED("1");

	private String code;
	private static Map<String, AuthenticationStatus> map;
	static {
		map = new HashMap<String, AuthenticationStatus>();
		for (AuthenticationStatus value : AuthenticationStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	AuthenticationStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static AuthenticationStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
