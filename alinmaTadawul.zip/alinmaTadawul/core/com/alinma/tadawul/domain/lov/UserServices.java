package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum UserServices implements EntityKey {
	NET_PLUS_LIGHT("17"), NET_PLUS_WITH_MD("9"), PRO_V9("10"), TTATHEER("6"), TECHNICAL_ANALYSIS_REPORTS("8");

	private String code;
	private static Map<String, UserServices> map;
	static {
		map = new HashMap<String, UserServices>();
		for (UserServices value : UserServices.values()) {
			map.put(value.getCode(), value);
		}
	}

	UserServices(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static UserServices getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
