package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum FundTypes implements EntityKey {
	My_ACCOUNTS("MyAccounts"), BENEFICIARY("Beneficiaries");

	private String code;
	private static Map<String, FundTypes> map;
	static {
		map = new Hashtable<String, FundTypes>();
		for (FundTypes value : FundTypes.values()) {
			map.put(value.getCode(), value);
		}
	}

	FundTypes(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static FundTypes getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
