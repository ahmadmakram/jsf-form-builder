/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum RequestMailingCode implements EntityKey {
	USE_CARD_ADDRESS("0"), USE_ADDRESS("1"), USE_CUSTODIAL_BU("2");

	private String code;
	private static Map<String, RequestMailingCode> map;
	static {
		map = new Hashtable<String, RequestMailingCode>();
		for (RequestMailingCode value : RequestMailingCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	RequestMailingCode(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static RequestMailingCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
