package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum RegistrationErrorCode implements EntityKey {
	NO_MAIN_USER("E001113"), LOGIN_NAME_DOESNT_EXIST("E001129"), NOT_REGISTERED_CHANNEL_USER("E001105");

	private String code;
	private static Map<String, RegistrationErrorCode> map;
	static {
		map = new Hashtable<String, RegistrationErrorCode>();
		for (RegistrationErrorCode value : RegistrationErrorCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	RegistrationErrorCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static RegistrationErrorCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
