package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum BeneficiaryStatus implements EntityKey {
	ACTIVE("A"), INACTIVE("I"), PENDING("P"), DISABLED("D"), UNDER_PROCESSING("U"), REJECTED("R");

	private String code;
	private static Map<String, BeneficiaryStatus> map;
	static {
		map = new Hashtable<String, BeneficiaryStatus>();
		for (BeneficiaryStatus value : BeneficiaryStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	BeneficiaryStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static BeneficiaryStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
