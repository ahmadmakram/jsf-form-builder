package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum FundTransferPurpose implements EntityKey {
	PERSONAL_SAVING("2");

	private String code;
	private static Map<String, FundTransferPurpose> map;
	static {
		map = new Hashtable<String, FundTransferPurpose>();
		for (FundTransferPurpose value : FundTransferPurpose.values()) {
			map.put(value.getCode(), value);
		}
	}

	FundTransferPurpose(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static FundTransferPurpose getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
