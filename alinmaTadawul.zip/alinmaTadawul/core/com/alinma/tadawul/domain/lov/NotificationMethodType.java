package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum NotificationMethodType implements EntityKey {
	SMS("SMS","1"), EMAIL("EMAIL","2"),SMS_AND_EMAIL("SMS_AND_EMAIL", "3"), FAX("FAX","4"), ALERT("ALERT","5"), MARKETING("MARKETING","6");

	private String code;
	private String label;
	private static Map<String, NotificationMethodType> map;
	private static Map<String, NotificationMethodType> labelMap;
	static {
		map = new Hashtable<String, NotificationMethodType>();
		for (NotificationMethodType value : NotificationMethodType.values()) {
			map.put(value.getCode(), value);
		}
		
		labelMap = new Hashtable<String, NotificationMethodType>();
		for (NotificationMethodType value : NotificationMethodType.values()) {
			labelMap.put(value.getLabel(), value);
		}
	}

	NotificationMethodType(String label,String code) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return this.code;
	}
	public String getLabel() {
		return this.label;
	}

	public static NotificationMethodType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
	
	public static NotificationMethodType getByLabel(String label) {
		if (labelMap == null) {
			return null;
		}
		return labelMap.get(label);
	}
}
