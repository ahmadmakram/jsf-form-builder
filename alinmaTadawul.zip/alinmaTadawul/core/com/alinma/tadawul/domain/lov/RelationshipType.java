/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the possible relationships that could exist with the customer and other parties.
 * 
 * @author Waleed Tayea
 * 
 */
public enum RelationshipType implements EntityKey {
	VEILED_WOMAN_WITNESS("41"), COURT_APPOINTED_GUARDIAN("42"), GUARDIAN_OF_MINOR("43"), ILLITERATE_AND_BLIND_WITNESS("44"), EMPLOYER("23"), BANK("68"), COMPANY("67"), INESTMENT_BANK_INFO("87"), BENEFICIAL_OWNER(
			"90"), CUSTODIAN_DETAILS("91");

	private String code;

	RelationshipType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
