/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Hani Younis
 * 
 */
public enum BankSystem implements EntityKey {
	T24("T24"), PYM("PYM");

	String code;

	BankSystem(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
