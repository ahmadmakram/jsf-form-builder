/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum SessionTimes implements EntityKey {
	FIVE_MINUTES("5"), TEN_MINUTES("10"), FIFTEEN_MINUTES("15"), TWENTY_MINUTES("20");

	private String code;
	private static Map<String, SessionTimes> map;
	static {
		map = new HashMap<String, SessionTimes>();
		for (SessionTimes value : SessionTimes.values()) {
			map.put(value.getCode(), value);
		}
	}

	SessionTimes(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static SessionTimes getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
