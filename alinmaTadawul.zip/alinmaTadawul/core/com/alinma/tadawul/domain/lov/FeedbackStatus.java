package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;


public enum FeedbackStatus implements EntityKey {
	FAILED("0"), SUCCESS("1");

	private String code;
	private static Map<String, FeedbackStatus> map;

	@Override
	public String getCode() {
		return code;
	}

	static {
		map = new HashMap<String, FeedbackStatus>();
		for (FeedbackStatus value : FeedbackStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	FeedbackStatus(String code) {
		this.code = code;
	}

	public static FeedbackStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
