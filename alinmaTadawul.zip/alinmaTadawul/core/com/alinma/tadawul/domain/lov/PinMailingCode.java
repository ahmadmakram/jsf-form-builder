package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum PinMailingCode implements EntityKey {
	DISALLOWED("0"), ALLOWED("1"), REQUIRED("2");

	private String code;
	private static Map<String, PinMailingCode> map;
	static {
		map = new Hashtable<String, PinMailingCode>();
		for (PinMailingCode value : PinMailingCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	PinMailingCode(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static PinMailingCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
