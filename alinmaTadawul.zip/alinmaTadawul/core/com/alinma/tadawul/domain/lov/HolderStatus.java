package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum HolderStatus implements EntityKey {
	NORMAL("0"), BLOCKED("1"), CLOSED("2");

	private String code;
	private static Map<String, HolderStatus> map;
	static {
		map = new Hashtable<String, HolderStatus>();
		for (HolderStatus value : HolderStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	HolderStatus(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static HolderStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
