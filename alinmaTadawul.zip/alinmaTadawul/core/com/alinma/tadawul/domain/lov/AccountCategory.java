package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum AccountCategory implements EntityKey {
	MF_ACCT("1003");

	private String code;
	private static Map<String, AccountCategory> map;
	static {
		map = new HashMap<String, AccountCategory>();
		for (AccountCategory value : AccountCategory.values()) {
			map.put(value.getCode(), value);
		}
	}

	AccountCategory(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static AccountCategory getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
