/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed tayea
 * 
 */
public enum ContextKeys implements EntityKey {
	BACKEND_GROUPS("BEGroups");

	String code;

	ContextKeys(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
