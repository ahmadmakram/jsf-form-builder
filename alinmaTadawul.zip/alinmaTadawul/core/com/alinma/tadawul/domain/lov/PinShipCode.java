package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum PinShipCode implements EntityKey {
	DO_NOT_MAIL("0"), MAIL_TO_CUSTOMER("1");

	private String code;
	private static Map<String, PinShipCode> map;
	static {
		map = new Hashtable<String, PinShipCode>();
		for (PinShipCode value : PinShipCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	PinShipCode(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static PinShipCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
