/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public enum ServiceStatus implements EntityKey {
	SUCCESS("I000000"), TIME_OUT("EXPTIMEOUT"), SERVICE_UNAVALIABLE("EC000001"), OVERRIDE_DATA_RESUBMISSION("W001534"), OVERRIDE_NO_DATA_RESUBMISSION("W001535"), NOT_SYNCHRONIZED_T24("W001540"), IDENTITY_DOCUMENT_RESERVED(
			"E700275"), LOV_NAME_INVALID("EC000002"), RELATION_NOT_FOUND("EC000003"), ALINMA_ID_EXIST("E001534"), INVALID_ARGS("EC000004"), PASSWORD_EXPIRY_DATE_WARNING("W001194"), DATABASE_ERROR(
			"DATABASEERROR"), KYC_INFORMATION_EXPIRED_WARNING("W002924"), MIN_HOLDING_ERR("E710059"), NIN_ALREADY_REGISTERED("10");

	protected String code;

	ServiceStatus(String code) {
		this.code = code;
	}

	/**
	 * Returns the status code
	 */
	public String getCode() {
		return code;
	}
}
