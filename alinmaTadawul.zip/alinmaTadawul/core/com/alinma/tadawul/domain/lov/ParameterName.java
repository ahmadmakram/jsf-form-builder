/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public enum ParameterName implements EntityKey {
	SUB_STATUS("SUBSTS");

	String code;

	ParameterName(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
