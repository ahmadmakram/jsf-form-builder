/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public enum ServiceMsgParametersNames {
	EXCEPTION_DETAILS("ExceptionDetails");

	public String name;

	ServiceMsgParametersNames(String name) {
		this.name = name;
	}

	/**
	 * Get the name of the parameter.
	 */
	public String getName() {
		return name;
	}
}
