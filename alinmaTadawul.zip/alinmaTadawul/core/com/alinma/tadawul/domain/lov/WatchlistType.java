package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum WatchlistType implements EntityKey {
	CUSTOM("0"), SECTOR("1"), SHARES("2"), TOP_TEN("3"), DOWN_TEN("4");

	private String code;
	private static Map<String, WatchlistType> map;

	@Override
	public String getCode() {
		return code;
	}

	static {
		map = new HashMap<String, WatchlistType>();
		for (WatchlistType value : WatchlistType.values()) {
			map.put(value.getCode(), value);
		}
	}

	WatchlistType(String code) {
		this.code = code;
	}

	public static WatchlistType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
