package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author mahamoda
 * 
 */
public enum FeeCategory implements EntityKey {
	CHARGE("1"), COMMISSION("2");

	private String code;
	private static Map<String, FeeCategory> map;
	static {
		map = new HashMap<String, FeeCategory>();
		for (FeeCategory value : FeeCategory.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static FeeCategory getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}

	FeeCategory(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
