package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum CustomerType implements EntityKey {
	INDIVIDUAL("I"), CORPORATE("C"), ORGANIZATION("O");

	private String code;
	private static Map<String, CustomerType> map;
	static {
		map = new HashMap<String, CustomerType>();
		for (CustomerType value : CustomerType.values()) {
			map.put(value.getCode(), value);
		}
	}

	CustomerType(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static CustomerType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
