/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author mbrins
 * 
 */
public enum FunctionMode implements EntityKey {
	CREDIT("C"), DEBIT("D"), VIEW("V");

	private String code;
	private static Map<String, FunctionMode> map;
	static {
		map = new HashMap<String, FunctionMode>();
		for (FunctionMode value : FunctionMode.values()) {
			map.put(value.getCode(), value);
		}
	}

	FunctionMode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static FunctionMode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
