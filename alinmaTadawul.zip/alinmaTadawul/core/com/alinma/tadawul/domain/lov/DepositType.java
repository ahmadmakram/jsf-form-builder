package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum DepositType implements EntityKey {
	USESTANDARD("0"), USECOMMERCIAL("1");

	private String code;
	private static Map<String, DepositType> map;
	static {
		map = new Hashtable<String, DepositType>();
		for (DepositType value : DepositType.values()) {
			map.put(value.getCode(), value);
		}
	}

	DepositType(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static DepositType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
