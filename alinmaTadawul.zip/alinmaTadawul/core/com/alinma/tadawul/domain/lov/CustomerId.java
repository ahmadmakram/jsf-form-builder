package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class CustomerId extends BusinessObject implements EntityKey {

	private String CIF;
	private EntityKey systemId; // The system id in which CIF number is applicable;
	private String alinmaId;
	private String partyId;
	private EntityKey customerType; // Individual (I), Organization (O)
	private EntityKey partyType; // Prospect, Partner, other...

	/**
	 * @return the cIF
	 */
	public String getCIF() {
		return CIF;
	}

	/**
	 * @param cif
	 *            the cIF to set
	 */
	public void setCIF(String cif) {
		CIF = cif;
	}

	/**
	 * @return the systemId
	 */
	public EntityKey getSystemId() {
		return systemId;
	}

	/**
	 * @param systemId
	 *            the systemId to set
	 */
	public void setSystemId(EntityKey systemId) {
		this.systemId = systemId;
	}

	public String getCode() {
		return alinmaId;
	}

	public String getAlinmaId() {
		return alinmaId;
	}

	public void setAlinmaId(String alinmaId) {
		this.alinmaId = alinmaId;
	}

	/**
	 * @return the partyId
	 */
	public String getPartyId() {
		return partyId;
	}

	/**
	 * @param partyId
	 *            the partyId to set
	 */
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	/**
	 * @return the customerType
	 */
	public EntityKey getCustomerType() {
		return customerType;
	}

	/**
	 * @param customerType
	 *            the customerType to set
	 */
	public void setCustomerType(EntityKey customerType) {
		this.customerType = customerType;
	}

	/**
	 * @return the partyType
	 */
	public EntityKey getPartyType() {
		return partyType;
	}

	/**
	 * @param partyType
	 *            the partyType to set
	 */
	public void setPartyType(EntityKey partyType) {
		this.partyType = partyType;
	}
}
