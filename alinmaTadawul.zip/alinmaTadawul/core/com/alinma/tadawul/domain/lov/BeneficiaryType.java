package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum BeneficiaryType implements EntityKey {
	ALINMA_BANK("1", "38502000"), EXTERNAL_BANK_INSIDE_KSA("2", "38503000"), INTERNATIONAL("3", "38504000"), COMPANY_BENEFICIARY("4", "38505000");

	private String code;
	private String tranfereFunctionId;
	private static Map<String, BeneficiaryType> map;
	static {
		map = new Hashtable<String, BeneficiaryType>();
		for (BeneficiaryType value : BeneficiaryType.values()) {
			map.put(value.getCode(), value);
		}
	}

	BeneficiaryType(String code, String tranfereFunctionId) {
		this.code = code;
		this.tranfereFunctionId = tranfereFunctionId;
	}

	public String getCode() {
		return this.code;
	}

	public static BeneficiaryType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}

	public String getTranfereFunctionId() {
		return tranfereFunctionId;
	}
}
