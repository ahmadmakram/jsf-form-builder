/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public enum UserRole implements EntityKey {
	ADMIN("0");

	private String code;
	private static Map<String, UserRole> map;
	static {
		map = new Hashtable<String, UserRole>();
		for (UserRole value : UserRole.values()) {
			map.put(value.getCode(), value);
		}
	}

	UserRole(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static UserRole getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
