package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum MutualFundFinancialStatementPeriod {
	SEMI_ANNUAL("6"), ANNUAL("12");

	private String code;
	private static Map<String, MutualFundFinancialStatementPeriod> map;
	static {
		map = new HashMap<String, MutualFundFinancialStatementPeriod>();
		for (MutualFundFinancialStatementPeriod value : MutualFundFinancialStatementPeriod.values()) {
			map.put(value.getCode(), value);
		}
	}

	MutualFundFinancialStatementPeriod(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MutualFundFinancialStatementPeriod getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
