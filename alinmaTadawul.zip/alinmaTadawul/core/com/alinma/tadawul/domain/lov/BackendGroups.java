/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public enum BackendGroups {
	PARTY_BASIC, PARTY_DETAILS, PARTY_ALT_NAMES, PARTY_RM_NOTES, IDENTIFICATIONS_DOCS, PARTY_POSTAL_ADDRESSES, PARTY_ELECTRONIC_ADDRESSES, PARTY_RELATIONS, CROSS_REFS, SELECTED_PRODUCTS, PARTY_SEGMENT, PARTY_EMRGS, PARTY_INVESTMENT, PARTY_DPNDNTS;
}
