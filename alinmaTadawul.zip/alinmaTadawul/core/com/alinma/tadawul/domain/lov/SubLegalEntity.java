/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import com.ejada.commons.domain.EntityKey;

/**
 * Sub legal entity enumeration
 * 
 * @author Waleed Tayea
 * 
 */
public enum SubLegalEntity implements EntityKey {
	AGE_LESS_THAN_18("3"), FEMALE_OLDER_THAN_18("4"), MENTALLY_DISABLED("7"), LEGALLY_INCOMPETENT("8"), SPECIAL_CIRCUMSTANCES("9"), BLIND_AND_ILLITERATES("11");

	private String code;

	SubLegalEntity(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
