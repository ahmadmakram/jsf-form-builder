/**
 * 
 */
package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum AuthenticationDisabledReason implements EntityKey {
	NORMAL("00"), TOKEN_NOT_AVAILABLE("01"), MOBILE_TOKEN_DISABLED("02"), MOBILE_STATUS_INVALID("03");

	private String code;
	private static Map<String, AuthenticationDisabledReason> map;
	static {
		map = new HashMap<String, AuthenticationDisabledReason>();
		for (AuthenticationDisabledReason value : AuthenticationDisabledReason.values()) {
			map.put(value.getCode(), value);
		}
	}

	AuthenticationDisabledReason(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static AuthenticationDisabledReason getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
