package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author mahamoda
 * 
 */
public enum FeeCode implements EntityKey {
	WAIVE("W"), CREDIT_LESS_FEES("C"), DEBIT_PLUS_FEES("D");

	private String code;
	private static Map<String, FeeCode> map;
	static {
		map = new HashMap<String, FeeCode>();
		for (FeeCode value : FeeCode.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static FeeCode getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}

	FeeCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
