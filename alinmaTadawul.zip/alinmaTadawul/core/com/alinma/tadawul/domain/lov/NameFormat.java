package com.alinma.tadawul.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum NameFormat implements EntityKey {
	NONAME("0"), NAME_SUFFIX("1"), TITLE_NAME_SUFFIX("2"), FIRST_OTH_FAMILY_SUFFIX("3"), First_Family_Oth_Suffix("4"), TITLE_FIRST_OTH_FAMILY_SUFFIX("5"), TITLE_FIRST_FAMILY_OTH_SUFFIX("6"), OTHER_NAME(
			"7"), COMPANY_NAME("8"), PROVIDED("9");

	private String code;
	private static Map<String, NameFormat> map;
	static {
		map = new Hashtable<String, NameFormat>();
		for (NameFormat value : NameFormat.values()) {
			map.put(value.getCode(), value);
		}
	}

	NameFormat(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static NameFormat getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
