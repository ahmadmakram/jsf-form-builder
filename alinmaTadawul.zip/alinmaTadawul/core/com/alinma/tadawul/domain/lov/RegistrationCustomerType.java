package com.alinma.tadawul.domain.lov;

import java.util.HashMap;
import java.util.Map;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum RegistrationCustomerType implements EntityKey {
	SELECET_OPTION_CUSTOMER_TYPE_INDIVIDUAL("I"), SELECET_OPTION_CUSTOMER_TYPE_ORGANIZATION("O");

	private String code;
	private static Map<String, RegistrationCustomerType> map;
	static {
		map = new HashMap<String, RegistrationCustomerType>();
		for (RegistrationCustomerType value : RegistrationCustomerType.values()) {
			map.put(value.getCode(), value);
		}
	}

	RegistrationCustomerType(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static RegistrationCustomerType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
