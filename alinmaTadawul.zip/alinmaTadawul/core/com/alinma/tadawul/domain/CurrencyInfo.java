package com.alinma.tadawul.domain;

import com.ejada.commons.domain.EntityKey;

public class CurrencyInfo {

	private EntityKey currencySource;
	private String amountSource;
	private String buyRateSource;
	private String amountSourceLocal;
	private EntityKey currencyTarget;
	private String amountTarget;
	private String sellRateTarget;
	private String amountTargetLocal;

	public String getAmountSource() {
		return amountSource;
	}

	public String getBuyRateSource() {
		return buyRateSource;
	}

	public String getAmountSourceLocal() {
		return amountSourceLocal;
	}

	public String getAmountTarget() {
		return amountTarget;
	}

	public String getSellRateTarget() {
		return sellRateTarget;
	}

	public String getAmountTargetLocal() {
		return amountTargetLocal;
	}

	public void setAmountSource(String amountSource) {
		this.amountSource = amountSource;
	}

	public void setBuyRateSource(String buyRateSource) {
		this.buyRateSource = buyRateSource;
	}

	public void setAmountSourceLocal(String amountSourceLocal) {
		this.amountSourceLocal = amountSourceLocal;
	}

	public void setAmountTarget(String amountTarget) {
		this.amountTarget = amountTarget;
	}

	public void setSellRateTarget(String sellRateTarget) {
		this.sellRateTarget = sellRateTarget;
	}

	public void setAmountTargetLocal(String amountTargetLocal) {
		this.amountTargetLocal = amountTargetLocal;
	}

	public static CurrencyInfo createCurrencyInfo() {
		return new CurrencyInfo();
	}

	public void setCurrencySource(EntityKey currencySource) {
		this.currencySource = currencySource;
	}

	public EntityKey getCurrencySource() {
		return currencySource;
	}

	public void setCurrencyTarget(EntityKey currencyTarget) {
		this.currencyTarget = currencyTarget;
	}

	public EntityKey getCurrencyTarget() {
		return currencyTarget;
	}
}
