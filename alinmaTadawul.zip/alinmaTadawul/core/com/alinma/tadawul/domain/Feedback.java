package com.alinma.tadawul.domain;

import java.io.Serializable;

import com.alinma.tadawul.domain.lov.FeedbackStatus;

public class Feedback implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String userId;
	private String FeedBackText;
	private FeedbackStatus feedBackStatus;
	private String requestId;
	private String userEnglishName;
	private String userArabicName;
	private String userMobileNumber;
	private String userEmail;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFeedBackText() {
		return FeedBackText;
	}

	public void setFeedBackText(String feedBackText) {
		FeedBackText = feedBackText;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getUserEnglishName() {
		return userEnglishName;
	}

	public void setUserEnglishName(String userEnglishName) {
		this.userEnglishName = userEnglishName;
	}

	public String getUserArabicName() {
		return userArabicName;
	}

	public void setUserArabicName(String userArabicName) {
		this.userArabicName = userArabicName;
	}

	public String getUserMobileNumber() {
		return userMobileNumber;
	}

	public void setUserMobileNumber(String userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public FeedbackStatus getFeedBackStatus() {
		return feedBackStatus;
	}

	public void setFeedBackStatus(FeedbackStatus feedBackStatus) {
		this.feedBackStatus = feedBackStatus;
	}
}
