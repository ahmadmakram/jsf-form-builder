/**
 * 
 */
package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.IdDocKey;

/**
 * @author Hani Younis
 * 
 */
public class CustomerIdDoc extends DateAwareEntityImpl {

	private SurrogateKey surrogateKey; // surrogate key for the document.
	private IdDocKey idDocKey;
	private EntityKey issueCountry;
	private String issuePlace;
	private String ECMReference;
	private String hexContent;
	private Boolean regularIqama = false;
	private Boolean uploaded = false;

	public void setIdDocKey(IdDocKey idDocKey) {
		this.idDocKey = idDocKey;
	}

	public IdDocKey getIdDocKey() {
		if (idDocKey == null) {
			this.idDocKey = createIdDocKey();
		}
		return idDocKey;
	}

	public IdDocKey createIdDocKey() {
		return (IdDocKey) ApplicationContextFactory.getApplicationContext().getBean("idDocKey");
	}

	public EntityKey getIssueCountry() {
		return issueCountry;
	}

	public void setIssueCountry(EntityKey issueCountry) {
		this.issueCountry = issueCountry;
	}

	public String getIssuePlace() {
		return issuePlace;
	}

	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}

	public Boolean getRegularIqama() {
		return regularIqama;
	}

	public void setRegularIqama(Boolean regularIqama) {
		this.regularIqama = regularIqama;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	/**
	 * @return the eCMReference
	 */
	public String getECMReference() {
		return ECMReference;
	}

	/**
	 * @param reference
	 *            the eCMReference to set
	 */
	public void setECMReference(String reference) {
		ECMReference = reference;
	}

	public void setHexContent(String hexContent) {
		this.hexContent = hexContent;
	}

	public String getHexContent() {
		return hexContent;
	}

	public void setUploaded(Boolean uploaded) {
		this.uploaded = uploaded;
	}

	public Boolean getUploaded() {
		return uploaded;
	}
}
