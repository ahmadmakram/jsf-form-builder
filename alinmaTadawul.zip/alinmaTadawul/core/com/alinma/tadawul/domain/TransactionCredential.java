/**
 * 
 */
package com.alinma.tadawul.domain;

import com.ejada.commons.domain.SecurityInfo;
import com.ejada.commons.domain.lov.SecurityInfoType;

/**
 * 
 * @author Hani Younis
 * 
 */
public class TransactionCredential extends SecurityInfo {

	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public SecurityInfoType getType() {
		return getSecInfoType();
	}

	public void setType(SecurityInfoType type) {
		setSecInfoType(type);
	}
}
