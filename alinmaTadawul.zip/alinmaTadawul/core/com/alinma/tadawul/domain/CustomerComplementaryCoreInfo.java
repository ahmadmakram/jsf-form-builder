package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;

public class CustomerComplementaryCoreInfo extends BusinessObject {

	private CustomerAdditionalInfo additionalInfo;
	private CustomerFinancialInfo financialInfo;
	private IncomeSourceDetails incomeSourceDetails;

	public CustomerAdditionalInfo getAdditionalInfo() {
		if (this.additionalInfo == null) {
			this.additionalInfo = createAdditionalInfo();
		}
		return additionalInfo;
	}

	public CustomerAdditionalInfo createAdditionalInfo() {
		return (CustomerAdditionalInfo) ApplicationContextFactory.getApplicationContext().getBean("customerAdditionalInfo");
	}

	public void setAdditionalInfo(CustomerAdditionalInfo additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public CustomerFinancialInfo getFinancialInfo() {
		if (this.financialInfo == null) {
			this.financialInfo = createFinancialInfo();
		}
		return financialInfo;
	}

	public CustomerFinancialInfo createFinancialInfo() {
		return (CustomerFinancialInfo) ApplicationContextFactory.getApplicationContext().getBean("customerFinancialInfo");
	}

	public void setFinancialInfo(CustomerFinancialInfo financialInfo) {
		this.financialInfo = financialInfo;
	}

	public IncomeSourceDetails getIncomeSourceDetails() {
		if (this.incomeSourceDetails == null) {
			this.incomeSourceDetails = createIncomeSourceDetails();
		}
		return incomeSourceDetails;
	}

	public IncomeSourceDetails createIncomeSourceDetails() {
		return (IncomeSourceDetails) ApplicationContextFactory.getApplicationContext().getBean("incomeSourceDetails");
	}

	public void setIncomeSourceDetails(IncomeSourceDetails incomeSourceDetails) {
		this.incomeSourceDetails = incomeSourceDetails;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (additionalInfo != null) {
			additionalInfo.CommitUpdates();
		}
		if (financialInfo != null) {
			financialInfo.CommitUpdates();
		}
		if (incomeSourceDetails != null) {
			incomeSourceDetails.CommitUpdates();
		}
	}
}
