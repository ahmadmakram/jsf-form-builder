package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;

public class CustomerEssentialAdditionalInfo extends BusinessObject {

	private CustomerProfessionalInfo professionalInfo;
	private CustomerAddress workAddress;
	private CustomerContact workContacts;
	private DefaultAddressContacts defaultAddressContacts;
	private PartyRelation representativePersonalInfo;

	public CustomerProfessionalInfo getProfessionalInfo() {
		if (professionalInfo == null) {
			professionalInfo = createCustomerProfessionalInfo();
		}
		return professionalInfo;
	}

	public CustomerProfessionalInfo createCustomerProfessionalInfo() {
		return (CustomerProfessionalInfo) ApplicationContextFactory.getApplicationContext().getBean("customerProfessionalInfo");
	}

	public void setProfessionalInfo(CustomerProfessionalInfo professionalInfo) {
		this.professionalInfo = professionalInfo;
	}

	public CustomerAddress getWorkAddress() {
		if (workAddress == null) {
			workAddress = createWorkAddress();
		}
		return workAddress;
	}

	public CustomerAddress createWorkAddress() {
		return (CustomerAddress) ApplicationContextFactory.getApplicationContext().getBean("customerAddress");
	}

	public void setWorkAddress(CustomerAddress workAddress) {
		this.workAddress = workAddress;
	}

	public CustomerContact getWorkContacts() {
		if (workContacts == null) {
			workContacts = createWorkContact();
		}
		return workContacts;
	}

	public CustomerContact createWorkContact() {
		return (CustomerContact) ApplicationContextFactory.getApplicationContext().getBean("customerContact");
	}

	public void setWorkContacts(CustomerContact workContacts) {
		this.workContacts = workContacts;
	}

	public DefaultAddressContacts getDefaultAddressContacts() {
		if (defaultAddressContacts == null) {
			defaultAddressContacts = createDefaultAddressContacts();
		}
		return defaultAddressContacts;
	}

	public DefaultAddressContacts createDefaultAddressContacts() {
		return (DefaultAddressContacts) ApplicationContextFactory.getApplicationContext().getBean("defaultAddressContacts");
	}

	public void setDefaultAddressContacts(DefaultAddressContacts defaultAddressContacts) {
		this.defaultAddressContacts = defaultAddressContacts;
	}

	public PartyRelation getRepresentativePersonalInfo() {
		if (representativePersonalInfo == null) {
			representativePersonalInfo = createRepresentativePartyRelation();
		}
		return representativePersonalInfo;
	}

	public PartyRelation createRepresentativePartyRelation() {
		return (PartyRelation) ApplicationContextFactory.getApplicationContext().getBean("partyRelation");
	}

	public void setRepresentativePersonalInfo(PartyRelation representativePersonalInfo) {
		this.representativePersonalInfo = representativePersonalInfo;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (professionalInfo != null) {
			professionalInfo.CommitUpdates();
		}
		if (workAddress != null) {
			workAddress.CommitUpdates();
		}
		if (workContacts != null) {
			workContacts.CommitUpdates();
		}
		if (defaultAddressContacts != null) {
			defaultAddressContacts.CommitUpdates();
		}
		if (representativePersonalInfo != null) {
			representativePersonalInfo.CommitUpdates();
		}
	}
}
