package com.alinma.tadawul.domain;

import java.util.Locale;

import com.ejada.commons.domain.EntityKey;

public class Amount {

	private EntityKey currencyCode;
	private String currencyRate;
	private String amount;
	private String formatedAmount;
	private String localAmount;

	public Amount() {
	}

	public Amount(String amount) {
		this.amount = amount;
	}

	public EntityKey getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(EntityKey currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getLocalAmount() {
		return localAmount;
	}

	public void setLocalAmount(String localAmount) {
		this.localAmount = localAmount;
	}

	public void setCurrencyRate(String currencyRate) {
		this.currencyRate = currencyRate;
	}

	public String getCurrencyRate() {
		return currencyRate;
	}

	public void setFormatedAmount(String formatedAmount) {
		this.formatedAmount = formatedAmount;
	}

	public String getFormatedAmount() {
		formatedAmount = String.format(Locale.ENGLISH, "%1$,.2f", Double.valueOf(getAmount()));
		return formatedAmount;
	}
}
