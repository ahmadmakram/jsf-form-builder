package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementCycle extends BusinessObject {

	private String frequency;
	private StatementCycleType type;
	private CombinedDate startDate;
	private CombinedDate endDate;

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public StatementCycleType getType() {
		return type;
	}

	public void setType(StatementCycleType type) {
		this.type = type;
	}

	public CombinedDate getStartDate() {
		return startDate;
	}

	public void setStartDate(CombinedDate startDate) {
		this.startDate = startDate;
	}

	public CombinedDate getEndDate() {
		return endDate;
	}

	public void setEndDate(CombinedDate endDate) {
		this.endDate = endDate;
	}
}
