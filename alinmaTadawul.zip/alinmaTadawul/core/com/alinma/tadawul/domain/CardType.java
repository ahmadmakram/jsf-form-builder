/**
 * 
 */
package com.alinma.tadawul.domain;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the channel Ids
 * 
 * @author Mohammad Suliman
 * 
 */
public enum CardType implements EntityKey {
	DEBIT_CARD("DR"), CHARGE_CARD("CC"), PREPAID_CARD("PR");

	private String code;
	private static Map<String, CardType> map;
	static {
		map = new Hashtable<String, CardType>();
		for (CardType value : CardType.values()) {
			map.put(value.getCode(), value);
		}
	}

	CardType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static CardType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
