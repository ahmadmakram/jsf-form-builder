package com.alinma.tadawul.domain;

import java.util.List;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.investment.CustodianDetails;
import com.alinma.tadawul.domain.investment.InvestmentBankInfo;
import com.alinma.tadawul.domain.investment.InvestmentInfo;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.ReserveDeletedList;

/**
 * this class hold the Capital Market Authority(CMA) customer related information.
 **/
public class CustomerCapitalMarketAuthorityInfo extends BusinessObject {

	private static final long serialVersionUID = 1L;
	private InvestmentBankInfo investmentBankInfo;
	private CustodianDetails custodianDetails;
	private InvestmentInfo investmentInfo;
	private List<PartyRelation> beneficialOwners;

	public InvestmentBankInfo getInvestmentBankInfo() {
		if (investmentBankInfo == null) {
			this.investmentBankInfo = createInvestmentBankInfo();
		}
		return investmentBankInfo;
	}

	private InvestmentBankInfo createInvestmentBankInfo() {
		return (InvestmentBankInfo) ApplicationContextFactory.getApplicationContext().getBean("investmentBankInfo");
	}

	public void setInvestmentBankInfo(InvestmentBankInfo investmentBankInfo) {
		this.investmentBankInfo = investmentBankInfo;
	}

	public CustodianDetails getCustodianDetails() {
		if (custodianDetails == null) {
			this.custodianDetails = createCustodianDetails();
		}
		return custodianDetails;
	}

	private CustodianDetails createCustodianDetails() {
		return (CustodianDetails) ApplicationContextFactory.getApplicationContext().getBean("custodianDetails");
	}

	public void setCustodianDetails(CustodianDetails custodianDetails) {
		this.custodianDetails = custodianDetails;
	}

	public InvestmentInfo getInvestmentInfo() {
		if (investmentInfo == null) {
			this.investmentInfo = createInvestmentInfo();
		}
		return investmentInfo;
	}

	private InvestmentInfo createInvestmentInfo() {
		return (InvestmentInfo) ApplicationContextFactory.getApplicationContext().getBean("investmentInfo");
	}

	public void setInvestmentInfo(InvestmentInfo investmentInfo) {
		this.investmentInfo = investmentInfo;
	}

	public List<PartyRelation> getBeneficialOwners() {
		if (this.beneficialOwners == null) {
			this.beneficialOwners = new ReserveDeletedList<PartyRelation>();
		}
		return beneficialOwners;
	}

	public void setBeneficialOwners(List<PartyRelation> beneficialOwners) {
		this.beneficialOwners = beneficialOwners;
	}

	public void addBeneficialOwner() {
		if (this.beneficialOwners == null) {
			this.beneficialOwners = new ReserveDeletedList<PartyRelation>();
		}
		this.beneficialOwners.add(createBeneficialOwnerPartyRelation());
	}

	public PartyRelation createBeneficialOwnerPartyRelation() {
		return (PartyRelation) ApplicationContextFactory.getApplicationContext().getBean("partyRelation");
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (investmentBankInfo != null) {
			investmentBankInfo.CommitUpdates();
		}
		if (custodianDetails != null) {
			custodianDetails.CommitUpdates();
		}
		if (investmentInfo != null) {
			investmentInfo.CommitUpdates();
		}
		if (investmentBankInfo != null) {
			investmentBankInfo.CommitUpdates();
		}
		if (beneficialOwners != null) {
			((ReserveDeletedList<PartyRelation>) beneficialOwners).CommitUpdates();
		}
	}
}
