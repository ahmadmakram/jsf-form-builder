/**
 * 
 */
package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.validations.annotations.RegularExpression;

/**
 * @author Waleed Tayea
 * 
 */
public class CustomerContact extends DateAwareEntityImpl {

	private SurrogateKey surrogateKey;
	private MobileInfo mobile;
	private PhoneInfo phone;
	private FaxInfo fax;
	private String homePageURL;
	private String email;
	private String preferredContactTime; // free text to indicate the preferred time
	private Boolean badAddress;
	private Integer rank;

	public MobileInfo getMobile() {
		if (mobile == null) {
			mobile = createMobile();
		}
		return mobile;
	}

	public MobileInfo createMobile() {
		return (MobileInfo) ApplicationContextFactory.getApplicationContext().getBean("mobileInfo");
	}

	public void setMobile(MobileInfo mobile) {
		this.mobile = mobile;
	}

	public PhoneInfo getPhone() {
		if (phone == null) {
			phone = createPhone();
		}
		return phone;
	}

	public PhoneInfo createPhone() {
		return (PhoneInfo) ApplicationContextFactory.getApplicationContext().getBean("phoneInfo");
	}

	public void setPhone(PhoneInfo phone) {
		this.phone = phone;
	}

	public FaxInfo getFax() {
		if (fax == null) {
			fax = createFax();
		}
		return fax;
	}

	public FaxInfo createFax() {
		return (FaxInfo) ApplicationContextFactory.getApplicationContext().getBean("faxInfo");
	}

	public void setFax(FaxInfo fax) {
		this.fax = fax;
	}

	public String getHomePageURL() {
		return homePageURL;
	}

	public void setHomePageURL(String homePageURL) {
		this.homePageURL = homePageURL;
	}

	@RegularExpression(regexIndex = "email", message = "{contact.invalidEmail}")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPreferredContactTime() {
		return preferredContactTime;
	}

	public void setPreferredContactTime(String preferredContactTime) {
		this.preferredContactTime = preferredContactTime;
	}

	public Boolean getBadAddress() {
		return badAddress;
	}

	public void setBadAddress(Boolean badAddress) {
		this.badAddress = badAddress;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (mobile != null) {
			mobile.CommitUpdates();
		}
		if (phone != null) {
			phone.CommitUpdates();
		}
		if (fax != null) {
			fax.CommitUpdates();
		}
	}

	/**
	 * @return the rank
	 */
	public Integer getRank() {
		return rank;
	}

	/**
	 * @param rank
	 *            the rank to set
	 */
	public void setRank(Integer rank) {
		this.rank = rank;
	}
}
