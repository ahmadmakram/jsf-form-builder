package com.alinma.tadawul.domain;

import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.Language;
import com.ejada.commons.validations.annotations.RegularExpression;

import com.alinma.tadawul.domain.lov.Country;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;

public class CustomerAddress extends DateAwareEntityImpl {

	private SurrogateKey surrogateKey;
	private EntityKey addressType;
	private EntityKey informationLang;
	private EntityKey country;
	private String city;
	private String pobox;
	private String postalCode;
	private String street;
	private String district;
	private String basicNumber;
	private String unitNumber;
	private String additionalNumber;
	private String internalMail;
	private Boolean badAddress;
	private String locationDirection;
	private String state;
	private String AddressLine1;
	private String AddressLine2;
	private Integer rank;

	// private AddressIndicator addressIndicator; //e.g. Wasel, P.O.Box and
	// Descriptive
	// private EntityStatus addressStatus; //e.g. Active and Inactive
	// private String AddressLine3;
	// private String AddressLine4;
	// private String AddressLine5;
	public EntityKey getAddressType() {
		return addressType;
	}

	public void setAddressType(EntityKey addressType) {
		if (addressType == null) {
			return;
		}
		this.addressType = addressType;
	}

	public EntityKey getInformationLang() {
		return informationLang;
	}

	public void setInformationLang(EntityKey informationLang) {
		if (informationLang != null && informationLang.getCode().equals(Language.ARABIC.getCode())
				&& (this.informationLang == null || this.informationLang.getCode().equals(Language.ENGLISH.getCode()))) {
			informationLang = new EntityDefaultKey(Language.ENGLISH.getCode());
			this.addPropertyUpdate("InformationLang");
			this.changeUpdateStatus(true);
		}
		this.informationLang = informationLang;
	}

	public EntityKey getCountry() {
		return country;
	}

	public void setCountry(EntityKey country) {
		this.country = country;
	}

	public boolean getSaudiCountry() {
		if (country != null)
			return country.equals(Country.SAUDIARABIA);
		return false;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@RegularExpression(regexIndex = "poBox", message = "{address.invalidPOBox}")
	public String getPobox() {
		return pobox;
	}

	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	@RegularExpression(regexIndex = "digits", message = "{address.invalidPostalCode}")
	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getBasicNumber() {
		return basicNumber;
	}

	public void setBasicNumber(String basicNumber) {
		this.basicNumber = basicNumber;
	}

	public String getUnitNumber() {
		return unitNumber;
	}

	public void setUnitNumber(String unitNumber) {
		this.unitNumber = unitNumber;
	}

	public String getAdditionalNumber() {
		return additionalNumber;
	}

	public void setAdditionalNumber(String additionalNumber) {
		this.additionalNumber = additionalNumber;
	}

	public String getInternalMail() {
		return internalMail;
	}

	public void setInternalMail(String internalMail) {
		this.internalMail = internalMail;
	}

	public Boolean getBadAddress() {
		return badAddress;
	}

	public void setBadAddress(Boolean badAddress) {
		this.badAddress = badAddress;
	}

	public String getLocationDirection() {
		return locationDirection;
	}

	public void setLocationDirection(String locationDirection) {
		this.locationDirection = locationDirection;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddressLine1() {
		return AddressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return AddressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	/**
	 * @return the rank
	 */
	public Integer getRank() {
		return rank;
	}

	/**
	 * @param rank
	 *            the rank to set
	 */
	public void setRank(Integer rank) {
		this.rank = rank;
	}
}
