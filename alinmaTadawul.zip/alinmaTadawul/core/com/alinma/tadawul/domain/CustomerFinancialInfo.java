package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class CustomerFinancialInfo extends BusinessObject {

	private String annualIncome;
	private EntityKey investmentExperience;
	private Float subsidizedMonthlyPercentage;

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public EntityKey getInvestmentExperience() {
		return investmentExperience;
	}

	public void setInvestmentExperience(EntityKey investmentExperience) {
		this.investmentExperience = investmentExperience;
	}

	public Float getSubsidizedMonthlyPercentage() {
		return subsidizedMonthlyPercentage;
	}

	public void setSubsidizedMonthlyPercentage(Float subsidizedMonthlyPercentage) {
		this.subsidizedMonthlyPercentage = subsidizedMonthlyPercentage;
	}
}
