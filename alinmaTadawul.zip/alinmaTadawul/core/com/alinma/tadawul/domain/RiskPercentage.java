package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;

public class RiskPercentage extends BusinessObject {

	private Float low;
	private Float medium;
	private Float high;

	public Float getLow() {
		return low;
	}

	public void setLow(Float low) {
		this.low = low;
	}

	public Float getMedium() {
		return medium;
	}

	public void setMedium(Float medium) {
		this.medium = medium;
	}

	public Float getHigh() {
		return high;
	}

	public void setHigh(Float high) {
		this.high = high;
	}

	public Float getTotal() {
		Float total = 0F;
		if (this.getLow() != null) {
			total += this.getLow();
		}
		if (this.getMedium() != null) {
			total += this.getMedium();
		}
		if (this.getHigh() != null) {
			total += this.getHigh();
		}
		return total;
	}
}
