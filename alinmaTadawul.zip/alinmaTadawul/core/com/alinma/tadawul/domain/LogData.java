package com.alinma.tadawul.domain;

import com.alinma.tadawul.domain.lov.MessageType;

public class LogData {

	public static final String RESPONSE = MessageType.RESPONSE.getCode();
	public static final String REQUEST = MessageType.REQUEST.getCode();
	public static final String EXCEPTION = MessageType.EXCEPTION.getCode();
	private String transactionNumber;
	private String messageType;
	private String creationTypeStamp;
	private String toTimeStamp;
	private String channelId;
	private String alinmaId;
	private String functionId;
	private String branchId;
	private String requestId;
	private String messageId;
	private String statusCode;
	private String exceptionMessage;
	private String comment;
	private String takeTime;
	private String countTakeTime;
	private String avgTakeTime;
	private String conccuentLoginedUser;
	private String conccurentTo;
	private String sessionRef;

	public String getComment() {
		if (comment == null) {
			comment = "";
		}
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getTransactionNumber() {
		if (transactionNumber == null) {
			transactionNumber = "";
		}
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getMessageType() {
		if (messageType == null) {
			messageType = "";
		}
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getCreationTypeStamp() {
		if (creationTypeStamp == null) {
			creationTypeStamp = "";
		}
		return creationTypeStamp;
	}

	public void setCreationTypeStamp(String creationTypeStamp) {
		this.creationTypeStamp = creationTypeStamp;
	}

	public String getChannelId() {
		if (channelId == null) {
			channelId = "";
		}
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getAlinmaId() {
		if (alinmaId == null) {
			alinmaId = "";
		}
		return alinmaId;
	}

	public void setAlinmaId(String alinmaId) {
		this.alinmaId = alinmaId;
	}

	public String getFunctionId() {
		if (functionId == null) {
			functionId = "";
		}
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getBranchId() {
		if (branchId == null) {
			branchId = "";
		}
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getRequestId() {
		if (requestId == null) {
			requestId = "";
		}
		return requestId;
	}

	public String getRequestIdSmall() {
		if (requestId == null) {
			requestId = "";
		} else {
			requestId = requestId.substring(0, 10);
		}
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getMessageId() {
		if (messageId == null) {
			messageId = "";
		}
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getStatusCode() {
		if (statusCode == null) {
			statusCode = "";
		}
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getExceptionMessage() {
		if (exceptionMessage == null) {
			exceptionMessage = "";
		}
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String getToTimeStamp() {
		if (toTimeStamp == null) {
			toTimeStamp = "";
		}
		return toTimeStamp;
	}

	public void setToTimeStamp(String toTimeStamp) {
		this.toTimeStamp = toTimeStamp;
	}

	public String getTakeTime() {
		return takeTime;
	}

	public void setTakeTime(String takeTime) {
		this.takeTime = takeTime;
	}

	public String getCountTakeTime() {
		return countTakeTime;
	}

	public void setCountTakeTime(String countTakeTime) {
		this.countTakeTime = countTakeTime;
	}

	public String getAvgTakeTime() {
		return avgTakeTime;
	}

	public void setAvgTakeTime(String avgTakeTime) {
		this.avgTakeTime = avgTakeTime;
	}

	public String getConccuentLoginedUser() {
		if (conccuentLoginedUser == null) {
			conccuentLoginedUser = "";
		}
		return conccuentLoginedUser;
	}

	public void setConccuentLoginedUser(String conccuentLoginedUser) {
		this.conccuentLoginedUser = conccuentLoginedUser;
	}

	public String toString() {
		return "  transactionNumber  " + transactionNumber + "\n" + "  messageType " + messageType + "\n" + " creationTypeStamp " + creationTypeStamp + "\n" + " toTimeStamp " + toTimeStamp + "\n"
				+ " channelId " + channelId + "\n" + " alinmaId " + alinmaId + "\n" + " functionId " + functionId + "\n" + " branchId " + branchId + "\n" + " requestId " + requestId + "\n"
				+ " statusCode " + statusCode + "\n" + " exceptionMessage " + exceptionMessage + "\n" + " comment " + comment + "\n";
	}

	public String getConccurentTo() {
		return conccurentTo;
	}

	public void setConccurentTo(String conccurentTo) {
		this.conccurentTo = conccurentTo;
	}

	public String getSessionRef() {
		return sessionRef;
	}

	public void setSessionRef(String sessionRef) {
		this.sessionRef = sessionRef;
	}
}
