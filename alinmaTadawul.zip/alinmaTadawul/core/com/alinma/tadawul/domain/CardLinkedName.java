package com.alinma.tadawul.domain;

import java.util.ArrayList;
import java.util.List;

import com.alinma.tadawul.domain.lov.HolderStatus;
import com.alinma.tadawul.domain.lov.NameFormat;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author ASaqqa
 * 
 */
public class CardLinkedName extends BusinessObject {

	private String title;
	private String embossingName;
	private String firstName;
	private String middleName;
	private String lastName;
	private String otherName;
	private HolderStatus holderStatusCode;
	private String suffix;
	private NameFormat nameFormatSourceCode;
	private String memberNumber;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmbossingName() {
		return embossingName;
	}

	public void setEmbossingName(String embossingName) {
		this.embossingName = embossingName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOtherName() {
		return otherName;
	}

	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}

	public HolderStatus getHolderStatusCode() {
		return holderStatusCode;
	}

	public void setHolderStatusCode(HolderStatus holderStatusCode) {
		this.holderStatusCode = holderStatusCode;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public NameFormat getNameFormatSourceCode() {
		return nameFormatSourceCode;
	}

	public void setNameFormatSourceCode(NameFormat nameFormatSourceCode) {
		this.nameFormatSourceCode = nameFormatSourceCode;
	}

	public String getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}
}
