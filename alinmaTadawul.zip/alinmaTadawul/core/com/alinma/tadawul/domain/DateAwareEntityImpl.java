package com.alinma.tadawul.domain;

import java.util.Date;

import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.BusinessObject;

/**
 * The class represents all the business objects that have a period in which they are valid.
 * 
 * @author Waleed Tayea
 * 
 */
public abstract class DateAwareEntityImpl extends BusinessObject implements DateAwareEntity {

	private CombinedDate startEffectiveDate;
	private CombinedDate endEffectiveDate;
	private CombinedDate oldEndEffectiveDate;

	public CombinedDate getStartEffectiveDate() {
		return startEffectiveDate;
	}

	public void setStartEffectiveDate(CombinedDate startEffectiveDate) {
		this.startEffectiveDate = startEffectiveDate;
	}

	public CombinedDate getEndEffectiveDate() {
		return endEffectiveDate;
	}

	public void setEndEffectiveDate(CombinedDate endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}

	public void setOldEndEffectiveDate(CombinedDate oldEndEffectiveDate) {
		this.oldEndEffectiveDate = oldEndEffectiveDate;
	}

	public CombinedDate getOldEndEffectiveDate() {
		return oldEndEffectiveDate;
	}

	public boolean isValid() {
		return true;
	}
}
