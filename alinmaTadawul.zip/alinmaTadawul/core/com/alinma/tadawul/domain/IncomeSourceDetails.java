package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;

public class IncomeSourceDetails extends BusinessObject {

	private Income payrollIncome;
	private Income investmentIncome;
	private Income rentIncome;
	private Income savingIncome;
	private Income stockDividendsIncome;
	private Income tradeIncome;
	private Income commissOrBonusIncome;
	private Income allowanceIncome;
	private Income additionalWorkIncome;
	private Income endServiceIncome;
	private Income otherIncome;
	private Income inheritanceIncome;
	private Float realPropertyAssets;

	public Income getPayrollIncome() {
		if (this.payrollIncome == null) {
			this.payrollIncome = createIncome();
		}
		return payrollIncome;
	}

	public void setPayrollIncome(Income payrollIncome) {
		this.payrollIncome = payrollIncome;
	}

	public Income getInvestmentIncome() {
		if (this.investmentIncome == null) {
			this.investmentIncome = createIncome();
		}
		return investmentIncome;
	}

	public void setInvestmentIncome(Income investmentIncome) {
		this.investmentIncome = investmentIncome;
	}

	public Income getRentIncome() {
		if (this.rentIncome == null) {
			this.rentIncome = createIncome();
		}
		return rentIncome;
	}

	public void setRentIncome(Income rentIncome) {
		this.rentIncome = rentIncome;
	}

	public Income getSavingIncome() {
		if (this.savingIncome == null) {
			this.savingIncome = createIncome();
		}
		return savingIncome;
	}

	public void setSavingIncome(Income savingIncome) {
		this.savingIncome = savingIncome;
	}

	public Income getStockDividendsIncome() {
		if (this.stockDividendsIncome == null) {
			this.stockDividendsIncome = createIncome();
		}
		return stockDividendsIncome;
	}

	public void setStockDividendsIncome(Income stockDividendsIncome) {
		this.stockDividendsIncome = stockDividendsIncome;
	}

	public Income getTradeIncome() {
		if (this.tradeIncome == null) {
			this.tradeIncome = createIncome();
		}
		return tradeIncome;
	}

	public void setTradeIncome(Income tradeIncome) {
		this.tradeIncome = tradeIncome;
	}

	public Income getCommissOrBonusIncome() {
		if (this.commissOrBonusIncome == null) {
			this.commissOrBonusIncome = createIncome();
		}
		return commissOrBonusIncome;
	}

	public void setCommissOrBonusIncome(Income commissOrBonusIncome) {
		this.commissOrBonusIncome = commissOrBonusIncome;
	}

	public Income getAllowanceIncome() {
		if (this.allowanceIncome == null) {
			this.allowanceIncome = createIncome();
		}
		return allowanceIncome;
	}

	public void setAllowanceIncome(Income allowanceIncome) {
		this.allowanceIncome = allowanceIncome;
	}

	public Income getAdditionalWorkIncome() {
		if (this.additionalWorkIncome == null) {
			this.additionalWorkIncome = createIncome();
		}
		return additionalWorkIncome;
	}

	public void setAdditionalWorkIncome(Income additionalWorkIncome) {
		this.additionalWorkIncome = additionalWorkIncome;
	}

	public Income getEndServiceIncome() {
		if (this.endServiceIncome == null) {
			this.endServiceIncome = createIncome();
		}
		return endServiceIncome;
	}

	public void setEndServiceIncome(Income endServiceIncome) {
		this.endServiceIncome = endServiceIncome;
	}

	public Income getOtherIncome() {
		if (this.otherIncome == null) {
			this.otherIncome = new Income();
		}
		return otherIncome;
	}

	public void setOtherIncome(Income otherIncome) {
		this.otherIncome = otherIncome;
	}

	public Income getInheritanceIncome() {
		if (this.inheritanceIncome == null) {
			this.inheritanceIncome = createIncome();
		}
		return inheritanceIncome;
	}

	public Income createIncome() {
		return (Income) ApplicationContextFactory.getApplicationContext().getBean("income");
	}

	public void setInheritanceIncome(Income inheritanceIncome) {
		this.inheritanceIncome = inheritanceIncome;
	}

	/**
	 * @return the realPropertyAssets
	 */
	public Float getRealPropertyAssets() {
		return realPropertyAssets;
	}

	/**
	 * @param realPropertyAssets
	 *            the realPropertyAssets to set
	 */
	public void setRealPropertyAssets(Float realPropertyAssets) {
		this.realPropertyAssets = realPropertyAssets;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (payrollIncome != null) {
			payrollIncome.CommitUpdates();
		}
		if (investmentIncome != null) {
			investmentIncome.CommitUpdates();
		}
		if (rentIncome != null) {
			rentIncome.CommitUpdates();
		}
		if (savingIncome != null) {
			savingIncome.CommitUpdates();
		}
		if (stockDividendsIncome != null) {
			stockDividendsIncome.CommitUpdates();
		}
		if (tradeIncome != null) {
			tradeIncome.CommitUpdates();
		}
		if (commissOrBonusIncome != null) {
			commissOrBonusIncome.CommitUpdates();
		}
		if (allowanceIncome != null) {
			allowanceIncome.CommitUpdates();
		}
		if (additionalWorkIncome != null) {
			additionalWorkIncome.CommitUpdates();
		}
		if (endServiceIncome != null) {
			endServiceIncome.CommitUpdates();
		}
		if (otherIncome != null) {
			otherIncome.CommitUpdates();
		}
		if (inheritanceIncome != null) {
			inheritanceIncome.CommitUpdates();
		}
	}
}
