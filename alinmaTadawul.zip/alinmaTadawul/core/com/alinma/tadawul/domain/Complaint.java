package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author mahamoda
 * 
 */
public class Complaint extends BusinessObject {

	private String complaintId;
	private String cif;
	private MobileInfo mobileInfo;
	private PhoneInfo phoneInfo;
	private Account account;
	// private Card card;
	private EntityKey type;
	private EntityKey subType;
	private EntityKey status;
	private String subject;
	private String description;
	private CombinedDate creationDateTime;
	private CombinedDate responseDateTime;
	private ChannelInfo channelInfo;
	private String complaintBankResponse;

	public String getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(String complaintId) {
		this.complaintId = complaintId;
	}

	public MobileInfo getMobileInfo() {
		if (mobileInfo == null) {
			mobileInfo = new MobileInfo();
		}
		return mobileInfo;
	}

	public void setMobileInfo(MobileInfo mobileInfo) {
		this.mobileInfo = mobileInfo;
	}

	public Account getAccount() {
		if (account == null) {
			account = new Account();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	// public Card getCard() {
	// if (card == null) {
	// card = new Card();
	// }
	// return card;
	// }
	//
	// public void setCard(Card card) {
	// this.card = card;
	// }
	public EntityKey getType() {
		return type;
	}

	public void setType(EntityKey type) {
		this.type = type;
	}

	public EntityKey getSubType() {
		return subType;
	}

	public void setSubType(EntityKey subType) {
		this.subType = subType;
	}

	public EntityKey getStatus() {
		return status;
	}

	public void setStatus(EntityKey status) {
		this.status = status;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CombinedDate getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(CombinedDate creationTime) {
		this.creationDateTime = creationTime;
	}

	public PhoneInfo getPhoneInfo() {
		return phoneInfo;
	}

	public void setPhoneInfo(PhoneInfo phoneInfo) {
		this.phoneInfo = phoneInfo;
	}

	public static Complaint createComplaint() {
		return new Complaint();
	}

	public CombinedDate getResponseDateTime() {
		return responseDateTime;
	}

	public void setResponseDateTime(CombinedDate responseDateTime) {
		this.responseDateTime = responseDateTime;
	}

	public ChannelInfo getChannelInfo() {
		if (channelInfo == null) {
			channelInfo = createChannelInfo();
		}
		return channelInfo;
	}

	private ChannelInfo createChannelInfo() {
		return new ChannelInfo();
	}

	public void setChannelInfo(ChannelInfo channelInfo) {
		this.channelInfo = channelInfo;
	}

	public String getComplaintBankResponse() {
		return complaintBankResponse;
	}

	public void setComplaintBankResponse(String complaintBankResponse) {
		this.complaintBankResponse = complaintBankResponse;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}
}
