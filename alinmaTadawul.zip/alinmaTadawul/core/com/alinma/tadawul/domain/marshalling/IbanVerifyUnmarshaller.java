package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.IbanVerifyResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class IbanVerifyUnmarshaller extends MsgUnmarshaller {

	@Override
	@SuppressWarnings("unchecked")
	protected ResponseMessage createResponseMessage() {
		return new IbanVerifyResMsg();
	}

	@Override
	public String getElementString() {
		return "IBANVerifyRs";
	}
}
