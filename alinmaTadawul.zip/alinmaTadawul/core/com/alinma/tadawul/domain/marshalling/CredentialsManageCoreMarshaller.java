/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.CredentialsManageReqMsgCore;
import com.alinma.tadawul.services.dao.impl.CredentialsManageDAOImpl;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class CredentialsManageCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		CredentialsManageReqMsgCore credentialsManageReqMsgCore = (CredentialsManageReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		String functionName = "";
		if (context != null && context.getAssociatedBOs() != null) {
			functionName = (String) context.getAssociatedBOs().get("FunctionName");
		}
		try {
			if (credentialsManageReqMsgCore == null) {
				return;
			}
			marshallingHelper.createNode(xmlWriter, "UsrId", credentialsManageReqMsgCore.getUserId(), false, false);
			marshallingHelper.createNode(xmlWriter, "InfoType", credentialsManageReqMsgCore.getSecurityInformationType().getCode(), false, false);
			if (CredentialsManageDAOImpl.CHANGE_PASSWORD.equals(functionName)) {
				marshallingHelper.createNode(xmlWriter, "OldSecInfo", credentialsManageReqMsgCore.getOldPassword(), false, false);
			}
			if (CredentialsManageDAOImpl.GENERATE_ONE_TIME_TOKEN.equals(functionName)) {
				if (credentialsManageReqMsgCore.getFunctionId() != null)
					marshallingHelper.createNode(xmlWriter, "FuncId", credentialsManageReqMsgCore.getFunctionId(), false, false);
				if (credentialsManageReqMsgCore.getUserDef() != null) {
					for (String userDef : credentialsManageReqMsgCore.getUserDef()) {
						if (userDef != null) {
							marshallingHelper.createNode(xmlWriter, "UsrDef1", userDef, false, false);
						}
						break;
					}
				}
			}
			if (!CredentialsManageDAOImpl.GENERATE_ONE_TIME_TOKEN.equals(functionName)) {
				if (credentialsManageReqMsgCore.getLoginName() != null)
					marshallingHelper.createNode(xmlWriter, "LoginName", credentialsManageReqMsgCore.getLoginName(), false, false);
				if (credentialsManageReqMsgCore.getNewSecurityPassword() != null)
					marshallingHelper.createNode(xmlWriter, "NewSecInfo", credentialsManageReqMsgCore.getNewSecurityPassword(), false, false);
				marshallingHelper.createNode(xmlWriter, "ChanId", credentialsManageReqMsgCore.getChannelId().getCode(), false, false);
			}
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}
}
