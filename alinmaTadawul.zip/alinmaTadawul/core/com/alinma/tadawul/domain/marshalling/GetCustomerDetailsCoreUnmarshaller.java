package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.BankAccount;
import com.alinma.tadawul.domain.CustomerAdditionalInfo;
import com.alinma.tadawul.domain.CustomerAddress;
import com.alinma.tadawul.domain.CustomerAltName;
import com.alinma.tadawul.domain.CustomerBankInfo;
import com.alinma.tadawul.domain.CustomerCapitalMarketAuthorityInfo;
import com.alinma.tadawul.domain.CustomerFinancialInfo;
import com.alinma.tadawul.domain.CustomerIdDoc;
import com.alinma.tadawul.domain.CustomerNote;
import com.alinma.tadawul.domain.CustomerPersonalInfo;
import com.alinma.tadawul.domain.CustomerProduct;
import com.alinma.tadawul.domain.CustomerProfessionalInfo;
import com.alinma.tadawul.domain.DefaultAddressContacts;
import com.alinma.tadawul.domain.DefaultIdDoc;
import com.alinma.tadawul.domain.FaxInfo;
import com.alinma.tadawul.domain.Income;
import com.alinma.tadawul.domain.IncomeSourceDetails;
import com.alinma.tadawul.domain.InstallmentCompanies;
import com.alinma.tadawul.domain.MobileInfo;
import com.alinma.tadawul.domain.PartyRelation;
import com.alinma.tadawul.domain.PartySegment;
import com.alinma.tadawul.domain.PhoneInfo;
import com.alinma.tadawul.domain.RiskPercentage;
import com.alinma.tadawul.domain.SurrogateKey;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.investment.CustodianDetails;
import com.alinma.tadawul.domain.investment.InvestmentBankInfo;
import com.alinma.tadawul.domain.investment.InvestmentInfo;
import com.alinma.tadawul.domain.keys.EmployeeId;
import com.alinma.tadawul.domain.lov.AddressType;
import com.alinma.tadawul.domain.lov.BackendGroups;
import com.alinma.tadawul.domain.lov.BankSystem;
import com.alinma.tadawul.domain.lov.ContextKeys;
import com.alinma.tadawul.domain.lov.CustomerId;
import com.alinma.tadawul.domain.lov.EntityStatus;
import com.alinma.tadawul.domain.lov.IdDocType;
import com.alinma.tadawul.domain.lov.RelationshipType;
import com.alinma.tadawul.domain.messages.response.GetCustomerDetailsResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.IdDocKey;
import com.ejada.commons.domain.Name;
import com.ejada.commons.domain.lov.RecordStatus;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class GetCustomerDetailsCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			TadawulUser customer = null;
			if (context != null && context.getAssociatedBOs() != null) {
				customer = (TadawulUser) context.getAssociatedBOs().get(TadawulUser.class.getName());
			}
			if (customer == null) {
				customer = (TadawulUser) ApplicationContextFactory.getApplicationContext().getBean("customer");
			}
			List<BackendGroups> backendGroups = (List<BackendGroups>) context.getAssociatedBOs().get(ContextKeys.BACKEND_GROUPS.getCode());
			// read the tag of Body
			xmlReader.next();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			if (msgParsed.size() <= 0) {
				return null;
			}
			unmarshalPartyKeys(customer, msgParsed);
			if (backendGroups.contains(BackendGroups.PARTY_BASIC)) {
				unmarshalPartyCommon(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_ALT_NAMES)) {
				unmarshalPartyAltNames(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_RM_NOTES)) {
				unmarshalPartyRMNotes(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.IDENTIFICATIONS_DOCS)) {
				unmarshalPartyIdents(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_POSTAL_ADDRESSES)) {
				unmarshalPostalAddrs(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_RELATIONS)) {
				unmarshalPartyRels(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_DETAILS)) {
				unmarshalPartyDetail(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.CROSS_REFS)) {
				unmarshalT24CIF(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.SELECTED_PRODUCTS)) {
				unmarshalSelectedProducts(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_SEGMENT)) {
				unmarshalCustomerSegment(customer, msgParsed);
			}
			if (backendGroups.contains(BackendGroups.PARTY_INVESTMENT)) {
				unmarshalPartyInvestment(customer, msgParsed);
			}
			GetCustomerDetailsResMsgCore msgCore = new GetCustomerDetailsResMsgCore();
			msgCore.setUser(customer);
			ResponseMessageBody<GetCustomerDetailsResMsgCore> msgResBody = new ResponseMessageBody<GetCustomerDetailsResMsgCore>();
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException("Error at unmarshalling");
		}
	}

	private void unmarshalPartyAltNames(TadawulUser customer, Hashtable<String, String> hash) {
		List<CustomerAltName> customerAltNames = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().getAlternativeNames();
		if (customerAltNames == null) {
			customerAltNames = new ArrayList<CustomerAltName>(0);
		}
		String repetition = "PartyAltNames/PartyAltName/";
		for (int i = 1;; i++) {
			if (hash.get(repetition + "EffDt") != null || hash.get(repetition + "EffDtHjr") != null || hash.get(repetition + "TerminationDt") != null
					|| hash.get(repetition + "TerminationDtHjr") != null || hash.get(repetition + "AltFullName") != null || hash.get(repetition + "LangCode") != null
					|| hash.get(repetition + "AltNameTypeCode") != null) {
				if (hash.get(repetition + "RecStatusCode") != null && hash.get(repetition + "RecStatusCode").equals(EntityStatus.INACTIVE.getCode())) {
					repetition = "PartyAltNames/PartyAltName[" + i + "]/";
					continue;
				}
				CustomerAltName customerAltName = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().createAlternativeName();
				if (hash.get(repetition + "EffDt") != null || hash.get(repetition + "EffDtHjr") != null) {
					CombinedDate effDt = new CombinedDate();
					effDt.setDate(hash.get(repetition + "EffDt"));
					effDt.setHijriDate(hash.get(repetition + "EffDtHjr"));
					customerAltName.setEffectiveDate(effDt);
				}
				if (hash.get(repetition + "TerminationDt") != null || hash.get(repetition + "TerminationDtHjr") != null) {
					CombinedDate termDt = new CombinedDate();
					termDt.setDate(hash.get(repetition + "TerminationDt"));
					termDt.setHijriDate(hash.get(repetition + "TerminationDtHjr"));
					customerAltName.setExpiryDate(termDt);
				}
				customerAltName.setFullName(hash.get(repetition + "AltFullName"));
				if (hash.get(repetition + "LangCode") != null) {
					customerAltName.setNameLang(new EntityDefaultKey(hash.get(repetition + "LangCode")));
				}
				if (hash.get(repetition + "AltNameTypeCode") != null) {
					customerAltName.setNameType(new EntityDefaultKey(hash.get(repetition + "AltNameTypeCode")));
				}
				customerAltName.setSurrogateKey(new SurrogateKey(hash.get(repetition + "AltNameId")));// TODO this is
				// surrogate
				// TODO RecStatusCode not used
				// TODO RecCreateUsr not used
				// TODO RecCreateDt not used
				// TODO RecUpdateUsr not used
				// TODO RecUpdateDt not used
				customerAltName.setRecordStatus(RecordStatus.NO_CHANGE);
				customerAltNames.add(customerAltName);
				repetition = "PartyAltNames/PartyAltName[" + i + "]/";
			} else {
				break;
			}
		}
	}

	private void unmarshalPartyCommon(TadawulUser customer, Hashtable<String, String> hash) {
		CustomerBankInfo cBI = customer.getCustomerStartingInfo().getBankInfo();
		CustomerAdditionalInfo cAI = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getAdditionalInfo();
		CustomerId cI = customer.getCustomerStartingInfo().getDefaultIdDoc().getCustomerId();
		CustomerPersonalInfo cPI = customer.getCustomerStartingInfo().getPersonalInfo();
		DefaultIdDoc dI = customer.getCustomerStartingInfo().getDefaultIdDoc();
		if (hash.get("PartyCommon/ApprovalDt") != null || hash.get("PartyCommon/ApprovalDtHjr") != null) {
			CombinedDate approvalDate = new CombinedDate();
			approvalDate.setDate(hash.get("PartyCommon/ApprovalDt"));
			approvalDate.setHijriDate(hash.get("PartyCommon/ApprovalDtHjr"));
			cBI.setSAMAApprovalDate(approvalDate);
		}
		if (hash.get("PartyCommon/BackupRM") != null) {
			cAI.setBackupRM(new EntityDefaultKey(hash.get("PartyCommon/BackupRM")));
		}
		if (hash.get("PartyCommon/IsBlackList") != null) {
			cBI.setBlackListed(hash.get("PartyCommon/IsBlackList").equalsIgnoreCase("y"));
		}
		// TODO BecomeCustDt not used
		// TODO BecomeCustDtHjr not used
		if (hash.get("PartyCommon/LOBCode") != null) {
			cAI.setLineOfBusiness(new EntityDefaultKey(hash.get("PartyCommon/LOBCode")));
		}
		if (hash.get("PartyCommon/ResidenceCountryCode") != null) {
			cAI.setCountryOfResidence(new EntityDefaultKey(hash.get("PartyCommon/ResidenceCountryCode")));
		}
		if (hash.get("PartyCommon/CombinedStmtRequired") != null) {
			cAI.setStatmentCombined(hash.get("PartyCommon/CombinedStmtRequired").equalsIgnoreCase("y"));
		}
		if (hash.get("PartyCommon/CrrspndAcceptCode") != null) {
			cAI.setAcceptedCorrespondance(new EntityDefaultKey(hash.get("PartyCommon/CrrspndAcceptCode")));
		}
		if (hash.get("PartyCommon/RgstrBranchId") != null) {
			cBI.setCreationBranch(new EntityDefaultKey(hash.get("PartyCommon/RgstrBranchId")));
		}
		cAI.setJoinReason(hash.get("PartyCommon/JoinReason"));
		if (hash.get("PartyCommon/LeaveReasonCode") != null) {
			cBI.setStatusChangeReason(new EntityDefaultKey(hash.get("PartyCommon/LeaveReasonCode")));
		}
		if (hash.get("PartyCommon/RecVersion") != null) {
			cBI.setRecordVersion(new Integer(hash.get("PartyCommon/RecVersion")));
		}
		cI.setAlinmaId(hash.get("PartyCommon/AlinmaId"));// TODO this
		// PTY/AlInmaId
		// used as
		// surrogate
		// TODO FullName not used
		EmployeeId employeeId = new EmployeeId(hash.get("PartyCommon/IntroducerCode"));
		cAI.setIntroducerEmployee(employeeId);
		if (hash.get("PartyCommon/IntroducerBranchId") != null) {
			cAI.setIntroducerBranch(new EntityDefaultKey(hash.get("PartyCommon/IntroducerBranchId")));
		}
		if (hash.get("PartyCommon/LangCode") != null) {
			cPI.setNameLanguage(new EntityDefaultKey(hash.get("PartyCommon/LangCode")));
		}
		// TODO KYC no used
		// TODO KYC no used
		if (hash.get("PartyCommon/LegalEntityCode") != null) {
			dI.setLegalEntity(new EntityDefaultKey(hash.get("PartyCommon/LegalEntityCode")));
		}
		if (hash.get("PartyCommon/MainBranchId") != null) {
			cAI.setMainBranch(new EntityDefaultKey(hash.get("PartyCommon/MainBranchId")));
		}
		if (hash.get("PartyCommon/NationalityCode") != null) {
			cPI.setNationality(new EntityDefaultKey(hash.get("PartyCommon/NationalityCode")));
		}
		// TODO NextKYCReviewDt not used
		// TODO NextKYCReviewDt not used
		cI.setPartyId(hash.get("PartyCommon/PartyId"));// TODO this is a
		// surrogate
		// TODO joinDt not used
		// TODO joinDt not used
		if (hash.get("PartyCommon/SAMAStatus") != null) {
			cBI.setSAMAStatus(new EntityDefaultKey(hash.get("PartyCommon/SAMAStatus")));
		}
		if (hash.get("PartyCommon/PartyStatusCode") != null) {
			cBI.setCustomerStatus(new EntityDefaultKey(hash.get("PartyCommon/PartyStatusCode")));
		}
		if (hash.get("PartyCommon/PartyStatusDt") != null || hash.get("PartyCommon/PartyStatusDtHjr") != null) {
			CombinedDate customerStatusDate = new CombinedDate();
			customerStatusDate.setDate(hash.get("PartyCommon/PartyStatusDt"));
			customerStatusDate.setHijriDate(hash.get("PartyCommon/PartyStatusDtHjr"));
			cBI.setStatusChangeDate(customerStatusDate);
		}
		if (hash.get("PartyCommon/CustType") != null) {
			cI.setCustomerType(new EntityDefaultKey(hash.get("PartyCommon/CustType")));// TODO this is a
																					   // surrogate
		}
		if (hash.get("PartyCommon/PartyTypeCode") != null) {
			cI.setPartyType(new EntityDefaultKey(hash.get("PartyCommon/PartyTypeCode")));// TODO this is a
		}
		// surrogate
		// TODO PFANIBD not used
		// TODO PFATD not used
		// TODO photoID not used
		if (hash.get("PartyCommon/LangPref") != null) {
			cAI.setPreferredLang(new EntityDefaultKey(hash.get("PartyCommon/LangPref")));
		}
		if (hash.get("PartyCommon/PreferChan") != null) {
			cAI.setPreferredChannel(new EntityDefaultKey(hash.get("PartyCommon/PreferChan")));
		}
		if (hash.get("PartyCommon/PrimaryRM") != null) {
			cAI.setPrimeRM(new EntityDefaultKey(hash.get("PartyCommon/PrimaryRM")));
		}
		if (hash.get("PartyCommon/ResidenceDt") != null || hash.get("PartyCommon/ResidenceDtHjr") != null) {
			CombinedDate residenceDate = new CombinedDate();
			residenceDate.setDate(hash.get("PartyCommon/ResidenceDt"));
			residenceDate.setHijriDate(hash.get("PartyCommon/ResidenceDtHjr"));
			cAI.setResidenceDate(residenceDate);
		}
		cBI.setSAMAApprovalNum(hash.get("PartyCommon/SAMAApprovalNum"));
		if (hash.get("PartyCommon/SAMARskCategory") != null) {
			cBI.setSAMARiskCategory(new EntityDefaultKey(hash.get("PartyCommon/SAMARskCategory")));
		}
		if (hash.get("PartyCommon/SubLegalEntityCode") != null) {
			dI.setSublegalEntity(new EntityDefaultKey(hash.get("PartyCommon/SubLegalEntityCode")));
		}
		// TODO unknown IsVirtualParty
		cBI.setStatusReasonExplanation(hash.get("PartyCommon/StatusReasonExplanation"));
		// TODO unknown WaitingBlackList
		// TODO unknown needSync
		// TODO unknown cocode
		// TODO RecVersion not used
		// TODO RecStatusCode not used
		cBI.setLastAmendmentUser(hash.get("PartyCommon/RecCreateUsr"));
		CombinedDate date = new CombinedDate();
		if (hash.get("PartyCommon/RecCreateDt") != null) {
			date.setDate(hash.get("PartyCommon/RecCreateDt"));
			cBI.setLastAmendmentDate(date);
		}
		if (hash.get("PartyCommon/RecLastUpdateUsr") != null) {
			cBI.setLastAmendmentUser(hash.get("PartyCommon/RecLastUpdateUsr"));
			date.setDate(hash.get("PartyCommon/RecLastUpdateDt"));
			cBI.setLastAmendmentDate(date);
		}
		// TODO: add the new Fields For the Common Here
		if (hash.get("PartyCommon/InvCustClassification") != null) {
			dI.setInvestmentClassification(new EntityDefaultKey(hash.get("PartyCommon/InvCustClassification")));
		}
		if (hash.get("PartyCommon/SelfActvty") != null) {
			cPI.setSelfActivity(hash.get("PartyCommon/SelfActvty").equalsIgnoreCase("y"));
		}
	}

	private void unmarshalPartyDetail(TadawulUser customer, Hashtable<String, String> hash) {
		CustomerFinancialInfo cFI = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getFinancialInfo();
		CustomerProfessionalInfo cPrI = customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getProfessionalInfo();
		CustomerPersonalInfo cPI = customer.getCustomerStartingInfo().getPersonalInfo();
		DefaultAddressContacts dAC = customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getDefaultAddressContacts();
		CustomerAdditionalInfo cAI = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getAdditionalInfo();
		IncomeSourceDetails iSD = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getIncomeSourceDetails();
		CustomerBankInfo cBI = customer.getCustomerStartingInfo().getBankInfo();
		cFI.setAnnualIncome(hash.get("Person/AnnualIncome") != null ? (hash.get("Person/AnnualIncome")) : null);
		// TODO AvgMonthlyDepAmt not used
		if (hash.get("Person/IsBankEmployee") != null) {
			cPrI.setBankEmployee(hash.get("Person/IsBankEmployee").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/IsBlindWitness") != null) {
			cPI.setBlindWitness(hash.get("Person/IsBlindWitness").equalsIgnoreCase("y"));
		}
		// TODO BloodType not used
		if (hash.get("Person/ContactPrefType") != null) {
			dAC.setPreferredContactMethod(new EntityDefaultKey(hash.get("Person/ContactPrefType")));
		}
		if (hash.get("Person/BirthDt") != null || hash.get("Person/BirthDtHjr") != null) {
			CombinedDate dateOfBirth = new CombinedDate();
			dateOfBirth.setDate(hash.get("Person/BirthDt"));
			dateOfBirth.setHijriDate(hash.get("Person/BirthDtHjr"));
			cPI.setDateOfBirth(dateOfBirth);
		}
		// TODO DtOfDeath not used
		if (hash.get("Person/IsDesignatedPerson") != null) {
			cAI.setDesignatedPerson(hash.get("Person/IsDesignatedPerson").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/EduCode") != null) {
			cPrI.setEducationLevel(new EntityDefaultKey(hash.get("Person/EduCode")));
		}
		// TODO EmpRptngDevisionCd not used
		// TODO EmployeeComputerNum not used
		// TODO EmployeeFinMgnrContact not used
		cPrI.setEmployerName(hash.get("Person/EmployerName"));
		if (hash.get("Person/EmploymentDt") != null || hash.get("Person/EmploymentDtHjr") != null) {
			CombinedDate employmentDate = new CombinedDate();
			employmentDate.setDate(hash.get("Person/EmploymentDt"));
			employmentDate.setHijriDate(hash.get("Person/EmploymentDtHjr"));
			cPrI.setEmploymentDate(employmentDate);
		}
		if (hash.get("Person/EmploymentIndCode") != null) {
			cPrI.setEmploymentIndicator(new EntityDefaultKey(hash.get("Person/EmploymentIndCode")));
		}
		if (hash.get("Person/EmploymentTypeCode") != null) {
			cPrI.setEmploymentIndustry(new EntityDefaultKey(hash.get("Person/EmploymentTypeCode")));
		}
		if (hash.get("Person/EmploymentSubTypeCode") != null) {
			cPrI.setEmploymentSubIndustry(new EntityDefaultKey(hash.get("Person/EmploymentSubTypeCode")));
		}
		Name personNameAr = cPI.getCustomerNameAr();
		Name personNameEn = cPI.getCustomerNameEn();
		personNameEn.setFamilyName(hash.get("Person/PersonFamilyNameEn"));
		personNameEn.setFifthName(hash.get("Person/PersonFifthNameEn"));
		personNameAr.setFamilyName(hash.get("Person/PersonFamilyNameAr"));
		personNameAr.setFifthName(hash.get("Person/PersonFifthNameAr"));
		// TODO FinalExitVisaDt not used
		// TODO FinalExitVisaFlg not used
		personNameEn.setFirstName(hash.get("Person/PersonFirstNameEn"));
		personNameEn.setFourthName(hash.get("Person/PersonFourthNameEn"));
		personNameAr.setFirstName(hash.get("Person/PersonFirstNameAr"));
		personNameAr.setFourthName(hash.get("Person/PersonFourthNameAr"));
		if (hash.get("Person/FinalExitVisaDt") != null || hash.get("Person/FinalExitVisaDtHjr") != null) {
			CombinedDate visa = new CombinedDate();
			visa.setDate(hash.get("Person/FinalExitVisaDt"));
			visa.setHijriDate(hash.get("Person/FinalExitVisaDtHjr"));
			cBI.setFinalExitVisaDate(visa);
		}
		if (hash.get("Person/HasFinalExitVisa") != null) {
			cBI.setFinalExitVisaFlag(hash.get("Person/HasFinalExitVisa").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/Gender") != null) {
			cPI.setGender(new EntityDefaultKey(hash.get("Person/Gender")));
		}
		if (hash.get("Person/IsIlliterate") != null) {
			cPI.setIlliterate(hash.get("Person/IsIlliterate").equalsIgnoreCase("y"));
		}
		iSD.setRealPropertyAssets(hash.get("Person/PropertyAssests") != null ? new Float(hash.get("Person/PropertyAssests")) : null);
		// TODO IndLiabilities not used
		// TODO IndLiquidNetWorth not used
		if (hash.get("Person/InvstmntExperienceCode") != null) {
			cFI.setInvestmentExperience(new EntityDefaultKey(hash.get("Person/InvstmntExperienceCode")));
		}
		cPrI.setJobTitle(hash.get("Person/JobTitle"));
		personNameEn.setThirdName(hash.get("Person/PersonGrandFatherNameEn"));
		personNameAr.setThirdName(hash.get("Person/PersonGrandFatherNameAr"));
		// TODO MaritalEffDt not used
		if (hash.get("Person/MaritalStatus") != null) {
			cPI.setMaritalStatus(new EntityDefaultKey(hash.get("Person/MaritalStatus")));
		}
		personNameEn.setSecondName(hash.get("Person/PersonFatherNameEn"));
		personNameAr.setSecondName(hash.get("Person/PersonFatherNameAr"));
		cPI.setCustomerNameAr(personNameAr);
		cPI.setCustomerNameEn(personNameEn);
		if (hash.get("Person/IsMinor") != null) {
			cPI.setMinor(hash.get("Person/IsMinor").equalsIgnoreCase("y"));
		}
		cAI.setNumberOfDependents(hash.get("Person/NumOfDpndnts") != null ? new Integer(hash.get("Person/NumOfDpndnts")) : null);
		cAI.setNumberOfSpouse(hash.get("Person/NumOfSpouses") != null ? new Integer(hash.get("Person/NumOfSpouses")) : null);
		if (hash.get("Person/OccpncyCode") != null) {
			cAI.setOccupancy(new EntityDefaultKey(hash.get("Person/OccpncyCode")));
		}
		if (hash.get("Person/OccupationCode") != null) {
			cPrI.setOccupation(new EntityDefaultKey(hash.get("Person/OccupationCode")));
		}
		cPI.setPlaceOfBirth(hash.get("Person/BirthPlace"));
		if (hash.get("Person/IsPoliticallyExposed") != null) {
			cPI.setPoliticallyExposed(hash.get("Person/IsPoliticallyExposed").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/MentallyDisabled") != null) {
			cPI.setMentalyDisabled(hash.get("Person/MentallyDisabled").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/LegallyIncmptntSaudi") != null) {
			cPI.setIncompetentSaudi(hash.get("Person/LegallyIncmptntSaudi").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/ChildWithSpecCrcmstnc") != null) {
			cPI.setSpecialChild(hash.get("Person/ChildWithSpecCrcmstnc").equalsIgnoreCase("y"));
		}
		Income additionalWorkIncome = iSD.getAdditionalWorkIncome();
		additionalWorkIncome.setAmount(hash.get("Person/AdditionalIncome/IncomeAmt") != null ? new Float(hash.get("Person/AdditionalIncome/IncomeAmt")) : null);
		if (hash.get("Person/AdditionalIncome/IsApplcble") != null) {
			additionalWorkIncome.setApplicability(hash.get("Person/AdditionalIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/AdditionalIncome/FreqIncome") != null) {
			additionalWorkIncome.setFrequence(new EntityDefaultKey(hash.get("Person/AdditionalIncome/FreqIncome")));
		}
		if (hash.get("Person/AdditionalIncome/RcvMethod") != null) {
			additionalWorkIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/AdditionalIncome/RcvMethod")));
		}
		iSD.setAdditionalWorkIncome(additionalWorkIncome);
		Income allowanceIncome = iSD.getAllowanceIncome();
		allowanceIncome.setAmount(hash.get("Person/AllwnceIncome/IncomeAmt") != null ? new Float(hash.get("Person/AllwnceIncome/IncomeAmt")) : null);
		if (hash.get("Person/AllwnceIncome/IsApplcble") != null) {
			allowanceIncome.setApplicability(hash.get("Person/AllwnceIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/AllwnceIncome/FreqIncome") != null) {
			allowanceIncome.setFrequence(new EntityDefaultKey(hash.get("Person/AllwnceIncome/FreqIncome")));
		}
		if (hash.get("Person/AllwnceIncome/RcvMethodCode") != null) {
			allowanceIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/AllwnceIncome/RcvMethodCode")));
		}
		iSD.setAllowanceIncome(allowanceIncome);
		Income commissOrBonusIncome = iSD.getCommissOrBonusIncome();
		commissOrBonusIncome.setAmount(hash.get("Person/BonusIncome/IncomeAmt") != null ? new Float(hash.get("Person/BonusIncome/IncomeAmt")) : null);
		if (hash.get("Person/BonusIncome/IsApplcble") != null) {
			commissOrBonusIncome.setApplicability(hash.get("Person/BonusIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/BonusIncome/FreqIncome") != null) {
			commissOrBonusIncome.setFrequence(new EntityDefaultKey(hash.get("Person/BonusIncome/FreqIncome")));
		}
		if (hash.get("Person/BonusIncome/RcvMethodCode") != null) {
			commissOrBonusIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/BonusIncome/RcvMethodCode")));
		}
		iSD.setCommissOrBonusIncome(commissOrBonusIncome);
		Income endServiceIncome = iSD.getEndServiceIncome();
		endServiceIncome.setAmount(hash.get("Person/EndSvcIncome/IncomeAmt") != null ? new Float(hash.get("Person/EndSvcIncome/IncomeAmt")) : null);
		if (hash.get("Person/EndSvcIncome/IsApplcble") != null) {
			endServiceIncome.setApplicability(hash.get("Person/EndSvcIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		iSD.setEndServiceIncome(endServiceIncome);
		Income inheritanceIncome = iSD.getInheritanceIncome();
		inheritanceIncome.setAmount(hash.get("Person/InhrtanceIncome/IncomeAmt") != null ? new Float(hash.get("Person/InhrtanceIncome/IncomeAmt")) : null);
		if (hash.get("Person/InhrtanceIncome/IsApplcble") != null) {
			inheritanceIncome.setApplicability(hash.get("Person/InhrtanceIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		iSD.setInheritanceIncome(inheritanceIncome);
		Income investmentIncome = iSD.getInvestmentIncome();
		investmentIncome.setAmount(hash.get("Person/InvstmntIncome/IncomeAmt") != null ? new Float(hash.get("Person/InvstmntIncome/IncomeAmt")) : null);
		if (hash.get("Person/InvstmntIncome/IsApplcble") != null) {
			investmentIncome.setApplicability(hash.get("Person/InvstmntIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/InvstmntIncome/FreqIncome") != null) {
			investmentIncome.setFrequence(new EntityDefaultKey(hash.get("Person/InvstmntIncome/FreqIncome")));
		}
		if (hash.get("Person/InvstmntIncome/RcvMethodCode") != null) {
			investmentIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/InvstmntIncome/RcvMethodCode")));
		}
		iSD.setInvestmentIncome(investmentIncome);
		Income otherIncome = iSD.getOtherIncome();
		otherIncome.setAmount(hash.get("Person/OtherIncome/IncomeAmt") != null ? new Float(hash.get("Person/OtherIncome/IncomeAmt")) : null);
		otherIncome.setDescription(hash.get("Person/OtherIncome/IncomeDesc"));
		if (hash.get("Person/OtherIncome/IsApplcble") != null) {
			otherIncome.setApplicability(hash.get("Person/OtherIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/OtherIncome/RcvMethodCode") != null) {
			otherIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/OtherIncome/RcvMethodCode")));
		}
		iSD.setOtherIncome(otherIncome);
		Income payrollIncome = iSD.getPayrollIncome();
		payrollIncome.setAmount(hash.get("Person/PayrollIncome/IncomeAmt") != null ? new Float(hash.get("Person/PayrollIncome/IncomeAmt")) : null);
		if (hash.get("Person/PayrollIncome/IsApplcble") != null) {
			payrollIncome.setApplicability(hash.get("Person/PayrollIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/PayrollIncome/FreqIncome") != null) {
			payrollIncome.setFrequence(new EntityDefaultKey(hash.get("Person/PayrollIncome/FreqIncome")));
		}
		if (hash.get("Person/PayrollIncome/RcvMethodCode") != null) {
			payrollIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/PayrollIncome/RcvMethodCode")));
		}
		iSD.setPayrollIncome(payrollIncome);
		Income rentIncome = iSD.getRentIncome();
		rentIncome.setAmount(hash.get("Person/RentIncome/IncomeAmt") != null ? new Float(hash.get("Person/RentIncome/IncomeAmt")) : null);
		if (hash.get("Person/RentIncome/IsApplcble") != null) {
			rentIncome.setApplicability(hash.get("Person/RentIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/RentIncome/FreqIncome") != null) {
			rentIncome.setFrequence(new EntityDefaultKey(hash.get("Person/RentIncome/FreqIncome")));
		}
		if (hash.get("Person/RentIncome/RcvMethodCode") != null) {
			rentIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/RentIncome/RcvMethodCode")));
		}
		iSD.setRentIncome(rentIncome);
		Income savingIncome = iSD.getSavingIncome();
		savingIncome.setAmount(hash.get("Person/SavingIncome/IncomeAmt") != null ? new Float(hash.get("Person/SavingIncome/IncomeAmt")) : null);
		if (hash.get("Person/SavingIncome/IsApplcble") != null) {
			savingIncome.setApplicability(hash.get("Person/SavingIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/SavingIncome/FreqIncome") != null) {
			savingIncome.setFrequence(new EntityDefaultKey(hash.get("Person/SavingIncome/FreqIncome")));
		}
		if (hash.get("Person/SavingIncome/RcvMethodCode") != null) {
			savingIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/SavingIncome/RcvMethodCode")));
		}
		iSD.setSavingIncome(savingIncome);
		Income stockDividendsIncome = iSD.getStockDividendsIncome();
		stockDividendsIncome.setAmount(hash.get("Person/StockIncome/IncomeAmt") != null ? new Float(hash.get("Person/StockIncome/IncomeAmt")) : null);
		if (hash.get("Person/StockIncome/IsApplcble") != null) {
			stockDividendsIncome.setApplicability(hash.get("Person/StockIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/StockIncome/FreqIncome") != null) {
			stockDividendsIncome.setFrequence(new EntityDefaultKey(hash.get("Person/StockIncome/FreqIncome")));
		}
		if (hash.get("Person/StockIncome/RcvMethodCode") != null) {
			stockDividendsIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/StockIncome/RcvMethodCode")));
		}
		iSD.setStockDividendsIncome(stockDividendsIncome);
		Income tradeIncome = iSD.getTradeIncome();
		tradeIncome.setAmount(hash.get("Person/TradeIncome/IncomeAmt") != null ? new Float(hash.get("Person/TradeIncome/IncomeAmt")) : null);
		if (hash.get("Person/TradeIncome/IsApplcble") != null) {
			tradeIncome.setApplicability(hash.get("Person/TradeIncome/IsApplcble").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/TradeIncome/FreqIncome") != null) {
			tradeIncome.setFrequence(new EntityDefaultKey(hash.get("Person/TradeIncome/FreqIncome")));
		}
		if (hash.get("Person/TradeIncome/RcvMethodCode") != null) {
			tradeIncome.setReceivingMethod(new EntityDefaultKey(hash.get("Person/TradeIncome/RcvMethodCode")));
		}
		iSD.setTradeIncome(tradeIncome);
		if (hash.get("Person/ReligionCode") != null) {
			cAI.setReligion(new EntityDefaultKey(hash.get("Person/ReligionCode")));
		}
		// TODO SalaryFreqDtl not used
		if (hash.get("Person/SpokenLangCode") != null) {
			cAI.setSpokenLanguage(new EntityDefaultKey(hash.get("Person/SpokenLangCode")));
		}
		cFI.setSubsidizedMonthlyPercentage(hash.get("Person/SubsdzdMonthlyPercen") != null ? new Float(hash.get("Person/SubsdzdMonthlyPercen")) : null);
		if (hash.get("Person/PersonTitleCode") != null) {
			cPI.setTitle(new EntityDefaultKey(hash.get("Person/PersonTitleCode")));
		}
		// TODO TrustLvlCd not used
		if (hash.get("Person/IsVeiledWomen") != null) {
			cPI.setVeiledWoman(hash.get("Person/IsVeiledWomen").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/TransportTypeCode") != null) {
			cAI.setTransportationType(new EntityDefaultKey(hash.get("Person/TransportTypeCode")));
		}
		cAI.setNumberOfCars(hash.get("Person/NumCars") != null ? new Integer(hash.get("Person/NumCars")) : null);
		cBI.setLastAmendmentUser(hash.get("Person/RecCreateUsr"));
		if (hash.get("Person/RecCreateDt") != null) {
			CombinedDate crDt = new CombinedDate();
			crDt.setDate(hash.get("Person/RecCreateDt"));
			cBI.setLastAmendmentDate(crDt);
		}
		if (hash.get("Person/RecLastUpdateUsr") != null) {
			cBI.setLastAmendmentUser(hash.get("Person/RecLastUpdateUsr"));
			CombinedDate upDt = new CombinedDate();
			upDt.setDate(hash.get("Person/RecLastUpdateDt"));
			cBI.setLastAmendmentDate(upDt);
		}
		if (hash.get("Person/DirectorOfficer") != null) {
			cPI.setDirectorOfficer(hash.get("Person/DirectorOfficer").equalsIgnoreCase("y"));
		}
		if (hash.get("Person/TotalAnnualIncome") != null) {
			cPI.setTotalAnnualIncome(new EntityDefaultKey(hash.get("Person/TotalAnnualIncome")));
		}
		if (hash.get("Person/NetWorth") != null) {
			cPI.setNetWorth(new EntityDefaultKey(hash.get("Person/NetWorth")));
		}
	}

	private void unmarshalPartyIdents(TadawulUser customer, Hashtable<String, String> hash) {
		List<CustomerIdDoc> customerIdDocs = customer.getCustomerEssentialInfo().getCustomerEssentialCoreInfo().getIdDocs();
		if (customerIdDocs == null) {
			customerIdDocs = new ArrayList<CustomerIdDoc>(0);
		}
		String repetition = "PartyIdents/PartyIdent/";
		for (int i = 1;; i++) {
			if (hash.get(repetition + "IdExpDt") != null || hash.get(repetition + "IdExpDtHjr") != null || hash.get(repetition + "IdIssueDt") != null || hash.get(repetition + "IdIssueDtHjr") != null
					|| hash.get(repetition + "IdentDoc") != null || hash.get(repetition + "IdIssuePlace") != null || hash.get(repetition + "IdentDocType") != null
					|| hash.get(repetition + "IssueCountryCode") != null) {
				if (hash.get(repetition + "RecStatusCode") != null && hash.get(repetition + "RecStatusCode").equals(EntityStatus.INACTIVE.getCode())) {
					repetition = "PartyIdents/PartyIdent[" + i + "]/";
					continue;
				}
				CustomerIdDoc customerIdDoc = customer.getCustomerEssentialInfo().getCustomerEssentialCoreInfo().createIdDoc();
				// TODO ECMRef not used
				if (hash.get(repetition + "IdExpDt") != null || hash.get(repetition + "IdExpDtHjr") != null) {
					CombinedDate expiryDt = new CombinedDate();
					expiryDt.setDate(hash.get(repetition + "IdExpDt"));
					expiryDt.setHijriDate(hash.get(repetition + "IdExpDtHjr"));
					customerIdDoc.setEndEffectiveDate(expiryDt);
				}
				if (hash.get(repetition + "IdIssueDt") != null || hash.get(repetition + "IdIssueDtHjr") != null) {
					CombinedDate issueDt = new CombinedDate();
					issueDt.setDate(hash.get(repetition + "IdIssueDt"));
					issueDt.setHijriDate(hash.get(repetition + "IdIssueDtHjr"));
					customerIdDoc.setStartEffectiveDate(issueDt);
				}
				customerIdDoc.setIssuePlace(hash.get(repetition + "IdIssuePlace"));
				IdDocKey idDocKey = customerIdDoc.getIdDocKey();
				idDocKey.setIdNumber(hash.get(repetition + "IdentDoc"));
				customerIdDoc.setECMReference(hash.get(repetition + "ECMRef"));
				idDocKey.setIdDocType(new EntityDefaultKey(hash.get(repetition + "IdentDocType")));
				customerIdDoc.setIdDocKey(idDocKey);
				if (hash.get(repetition + "IssueCountryCode") != null) {
					customerIdDoc.setIssueCountry(new EntityDefaultKey(hash.get(repetition + "IssueCountryCode")));
				}
				customerIdDoc.setSurrogateKey(new SurrogateKey(hash.get(repetition + "IdentId")));// TODO this is surrogate
				// TODO EnPrintedFullName not used
				// TODO ArPrintedFullName not used
				String rank = hash.get(repetition + "Rank");
				// TODO RecStatusCode not used
				if (hash.get(repetition + "IsRegIqama") != null) {
					customerIdDoc.setRegularIqama(hash.get(repetition + "IsRegIqama").equalsIgnoreCase("y"));
				}
				// TODO PrintedAddr not used
				// TODO RecCreateUsr not used
				// TODO RecCreateDt not used
				// TODO RecUpdateUsr not used
				// TODO RecUpdateDt not used
				customerIdDoc.setRecordStatus(RecordStatus.NO_CHANGE);
				if (rank != null && rank.equals("0")) {
					customer.getCustomerStartingInfo().getDefaultIdDoc().setIdDoc(customerIdDoc);
				} else {
					if (customerIdDoc.getIdDocKey().getIdDocType().getCode().equals(IdDocType.GENERAL_AGREEMENT.getCode())) {
						// customer.setGeneralAgreement(customerIdDoc);
					} else {
						customerIdDocs.add(customerIdDoc);
					}
				}
				repetition = "PartyIdents/PartyIdent[" + i + "]/";
			} else {
				break;
			}
		}
		customer.getCustomerEssentialInfo().getCustomerEssentialCoreInfo().setIdDocs(customerIdDocs);
	}

	private void unmarshalPartyKeys(TadawulUser customer, Hashtable<String, String> hash) {
		CustomerId customerId = customer.getCustomerStartingInfo().getDefaultIdDoc().getCustomerId();
		CustomerBankInfo cBI = customer.getCustomerStartingInfo().getBankInfo();
		customerId.setPartyId(hash.get("PartyKeys/PartyId"));
		if (customerId.getAlinmaId() == null || customerId.getAlinmaId().equals("")) {
			customerId.setAlinmaId(hash.get("PartyKeys/AlinmaId"));
		}
		if (hash.get("PartyKeys/PartyTypeCode") != null) {
			customerId.setPartyType(new EntityDefaultKey(hash.get("PartyKeys/PartyTypeCode")));
		}
		if (hash.get("PartyKeys/PartyStatusCode") != null) {
			cBI.setCustomerStatus((new EntityDefaultKey(hash.get("PartyKeys/PartyStatusCode"))));
		}
		if (hash.get("PartyKeys/RecVersion") != null) {
			customer.getCustomerStartingInfo().getBankInfo().setRecordVersion(new Integer(hash.get("PartyKeys/RecVersion")));
			// customerId.setRecordStatus(RecordStatus.NO_CHANGE);
		}
	}

	private void unmarshalPartyRels(TadawulUser customer, Hashtable<String, String> hash) {
		List<PartyRelation> partyRelations = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().getOtherPartiesRelations();
		if (partyRelations == null) {
			partyRelations = new ArrayList<PartyRelation>(0);
		}
		List<BankAccount> bankAccounts = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().getOtherBanksAccounts();
		InvestmentBankInfo investmentBankInfo = customer.getCustomerCapitalMarketAuthorityInfo().getInvestmentBankInfo();
		CustodianDetails custodianDetails = customer.getCustomerCapitalMarketAuthorityInfo().getCustodianDetails();
		List<PartyRelation> beneficialOwners = customer.getCustomerCapitalMarketAuthorityInfo().getBeneficialOwners();
		if (bankAccounts == null) {
			bankAccounts = new ArrayList<BankAccount>(0);
		}
		List<InstallmentCompanies> installmentCompanies = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().getInstallmentCompanies();
		if (installmentCompanies == null) {
			installmentCompanies = new ArrayList<InstallmentCompanies>(0);
		}
		// Change the fetched status of customer representative to fetched
		customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getRepresentativePersonalInfo().changeFetchStatus(true);
		String repetition = "PartyRels/PartyRel/";
		for (int i = 1;; i++) {
			if (hash.get(repetition + "PartyRelate/FullName") != null || hash.get(repetition + "PartyRelate/AlinmaId") != null || hash.get(repetition + "PartyRelate/SysId") != null
					|| hash.get(repetition + "PartyRelate/SysCIF") != null || hash.get(repetition + "PartyRelate/NationalityCode") != null
					|| hash.get(repetition + "PartyRelate/LegalEntityCode") != null || hash.get(repetition + "PartyRelate/Gender") != null || hash.get(repetition + "PartyRelate/BirthDt") != null
					|| hash.get(repetition + "PartyRelate/BirthDtHjr") != null || hash.get(repetition + "PartyRelate/PersonFirstName") != null || hash.get(repetition + "PartyRelate/PartyId") != null
					|| hash.get(repetition + "PartyRelate/IdExpDt") != null) {
				if (hash.get(repetition + "RecStatusCode") != null && hash.get(repetition + "RecStatusCode").equals(EntityStatus.INACTIVE.getCode())) {
					repetition = "PartyRels/PartyRel[" + i + "]/";
					continue;
				}
				String relation = hash.get(repetition + "RelTypeCode");
				if (relation != null && relation.equals(RelationshipType.BANK.getCode())) {
					BankAccount account = new BankAccount();
					account.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PartyRelId")));
					account.getAccountId().setAccountType(new EntityDefaultKey(hash.get(repetition + "PartyRelate/OtherBankAcctTypeCode")));
					account.getAccountId().setAccountNumber(hash.get(repetition + "PartyRelate/OtherBankAcctNum"));
					account.getAccountId().setAccountIbanNumber(hash.get(repetition + "PartyRelate/OtherBankIBAN"));
					account.setBankId(new EntityDefaultKey(hash.get(repetition + "PartyRelate/PartyId")));
					account.setRecordStatus(RecordStatus.NO_CHANGE);
					bankAccounts.add(account);
				} else if (relation != null && relation.equals(RelationshipType.COMPANY.getCode())) {
					InstallmentCompanies company = new InstallmentCompanies();
					company.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PartyRelId")));
					company.setCompanyName(hash.get(repetition + "PartyRelate/FullName"));
					if (hash.get(repetition + "CreditAmt") != null)
						company.setCreditAmount(new Float(hash.get(repetition + "CreditAmt")));
					if (hash.get(repetition + "CreditMonthlyPmt") != null)
						company.setCreditMonthlyPayment(new Float(hash.get(repetition + "CreditMonthlyPmt")));
					if (hash.get(repetition + "CreditOutstand") != null)
						company.setCreditOutstanding(new Float(hash.get(repetition + "CreditOutstand")));
					company.setCreditPeriod(hash.get(repetition + "CreditPeriod"));
					company.setRecordStatus(RecordStatus.NO_CHANGE);
					installmentCompanies.add(company);
				} else if (relation != null && relation.equals(RelationshipType.INESTMENT_BANK_INFO.getCode())) {
					investmentBankInfo.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PartyRelId")));
					investmentBankInfo.setBranchName(hash.get(repetition + "BranchName"));
					investmentBankInfo.setBankId(new EntityDefaultKey(hash.get(repetition + "PartyRelate/PartyId")));
					investmentBankInfo.setMainAccountNumber(hash.get(repetition + "PartyRelate/OtherBankAcctNum"));
					investmentBankInfo.setMainAccountIban(hash.get(repetition + "PartyRelate/OtherBankIBAN"));
					investmentBankInfo.setRecordStatus(RecordStatus.NO_CHANGE);
				} else if (relation != null && relation.equals(RelationshipType.CUSTODIAN_DETAILS.getCode())) {
					custodianDetails.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PartyRelId")));
					custodianDetails.setAccountName(hash.get(repetition + "AcctName"));
					custodianDetails.setAccountNumber(hash.get(repetition + "PartyRelate/OtherBankAcctNum"));
					custodianDetails.setAccountIBAN(hash.get(repetition + "PartyRelate/OtherBankIBAN"));
					custodianDetails.setCustodianName(hash.get(repetition + "CustodianName"));
					custodianDetails.setCustodianId(new EntityDefaultKey(hash.get(repetition + "PartyRelate/PartyId")));
					custodianDetails.setRecordStatus(RecordStatus.NO_CHANGE);
					/* Contacts */
					FaxInfo fax = custodianDetails.getFax();
					if (hash.get(repetition + "PartyRelate/Fax/PhoneCountryCode") != null) {
						fax.setFaxCountryCode(new EntityDefaultKey(hash.get(repetition + "PartyRelate/Fax/PhoneCountryCode")));
						fax.setRecordStatus(RecordStatus.NO_CHANGE);
					}
					fax.setFaxCityCode(hash.get(repetition + "PartyRelate/Fax/PhoneAreaCode"));
					fax.setFaxNumber(hash.get(repetition + "PartyRelate/Fax/PhoneNum"));
					fax.setFaxExtension(hash.get(repetition + "PartyRelate/Fax/PhoneExtension"));
					custodianDetails.setFax(fax);
					PhoneInfo phone = custodianDetails.getPhone();
					if (hash.get(repetition + "PartyRelate/Phone/PhoneCountryCode") != null) {
						phone.setPhoneCountryCode(new EntityDefaultKey(hash.get(repetition + "PartyRelate/Phone/PhoneCountryCode")));
						phone.setRecordStatus(RecordStatus.NO_CHANGE);
					}
					phone.setPhoneCityCode(hash.get(repetition + "PartyRelate/Phone/PhoneAreaCode"));
					phone.setPhoneNumber(hash.get(repetition + "PartyRelate/Phone/PhoneNum"));
					phone.setPhoneExtension(hash.get(repetition + "PartyRelate/Phone/PhoneExtension"));
					custodianDetails.setPhone(phone);
					/* Address */
					CustomerAddress workAddress = custodianDetails.getWorkAddress();
					workAddress.setCity(hash.get(repetition + "PartyRelate/City"));
					workAddress.setDistrict(hash.get(repetition + "PartyRelate/Dist"));
					workAddress.setPobox(hash.get(repetition + "PartyRelate/POBox"));
					workAddress.setPostalCode(hash.get(repetition + "PartyRelate/PostalCode"));
					workAddress.setStreet(hash.get(repetition + "PartyRelate/Street"));
					custodianDetails.setWorkAddress(workAddress);
				} else {
					PartyRelation partyRelation = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().createOtherPartyRelation();
					partyRelation.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PartyRelId")));
					partyRelation.setRelationContactSurrogateKey(new SurrogateKey(hash.get(repetition + "ContactId")));
					// TODO PartyRelationId not used
					// TODO RelatedContactTypeCd not used
					// TODO RelatedEmail not used
					// TODO RelatedFax1CityCd not used
					// TODO RelatedFax1CountryCd not used
					// TODO RelatedFax1Extn not used
					// TODO RelatedFaxNum1 not used
					Name name = partyRelation.getName();
					name.setFullName(hash.get(repetition + "PartyRelate/FullName"));
					// TODO RelatedMobileNum1 not used
					// TODO RelatedMobile1CountryCd not used
					// TODO RelatedPhone1CityCd not used
					// TODO RelatedPhone1CountryCd not used
					// TODO RelatedPhone1Extn not used
					// TODO RelatedPhoneNum1 not used
					// TODO EmploymentNum not used
					// TODO EndDt not used
					// TODO JobTitle not used
					// TODO RelatedAdditionalNum not used
					// TODO RelatedAddr1 not used
					// TODO RelatedAddr2 not used
					// TODO RelatedAddrInd not used
					// TODO RelatedBasicNum not used
					// TODO ... till the node RelatedUnitNum not used
					CustomerId customerId = partyRelation.getCustomerId();
					customerId.setAlinmaId(hash.get(repetition + "PartyRelate/AlinmaId"));
					customerId.setSystemId(new EntityDefaultKey(hash.get(repetition + "PartyRelate/SysId")));
					customerId.setCIF(hash.get(repetition + "PartyRelate/SysCIF"));
					if (hash.get(repetition + "PartyRelate/CustType") != null) {
						customerId.setCustomerType(new EntityDefaultKey(hash.get(repetition + "PartyRelate/CustType")));
					}
					if (hash.get(repetition + "PartyRelate/NationalityCode") != null) {
						partyRelation.setNationality(new EntityDefaultKey(hash.get(repetition + "PartyRelate/NationalityCode")));
					}
					// TODO RelatedPartySubTypeCd not used
					if (hash.get(repetition + "PartyRelate/LegalEntityCode") != null) {
						partyRelation.setLegalEntity(new EntityDefaultKey(hash.get(repetition + "PartyRelate/LegalEntityCode")));
					}
					if (hash.get(repetition + "PartyRelate/SubLegalEntityCode") != null) {
						partyRelation.setSublegalEntity(new EntityDefaultKey(hash.get(repetition + "PartyRelate/SubLegalEntityCode")));
					}
					if (hash.get(repetition + "PartyRelate/Gender") != null) {
						partyRelation.setGender(new EntityDefaultKey(hash.get(repetition + "PartyRelate/Gender")));
					}
					/* Contacts */
					FaxInfo fax = partyRelation.getFax();
					if (hash.get(repetition + "PartyRelate/Fax/PhoneCountryCode") != null) {
						fax.setFaxCountryCode(new EntityDefaultKey(hash.get(repetition + "PartyRelate/Fax/PhoneCountryCode")));
						fax.setRecordStatus(RecordStatus.NO_CHANGE);
					}
					fax.setFaxCityCode(hash.get(repetition + "PartyRelate/Fax/PhoneAreaCode"));
					fax.setFaxNumber(hash.get(repetition + "PartyRelate/Fax/PhoneNum"));
					fax.setFaxExtension(hash.get(repetition + "PartyRelate/Fax/PhoneExtension"));
					partyRelation.setFax(fax);
					MobileInfo mobile = partyRelation.getMobile();
					if (hash.get(repetition + "PartyRelate/Mobile/PhoneCountryCode") != null) {
						mobile.setMobileCountryCode(new EntityDefaultKey(hash.get(repetition + "PartyRelate/Mobile/PhoneCountryCode")));
						mobile.setRecordStatus(RecordStatus.NO_CHANGE);
					}
					mobile.setMobileNumber(hash.get(repetition + "PartyRelate/Mobile/PhoneNum"));
					partyRelation.setMobile(mobile);
					// TODO pagr not used
					PhoneInfo phone = partyRelation.getPhone();
					if (hash.get(repetition + "PartyRelate/Phone/PhoneCountryCode") != null) {
						phone.setPhoneCountryCode(new EntityDefaultKey(hash.get(repetition + "PartyRelate/Phone/PhoneCountryCode")));
						phone.setRecordStatus(RecordStatus.NO_CHANGE);
					}
					phone.setPhoneCityCode(hash.get(repetition + "PartyRelate/Phone/PhoneAreaCode"));
					phone.setPhoneNumber(hash.get(repetition + "PartyRelate/Phone/PhoneNum"));
					phone.setPhoneExtension(hash.get(repetition + "PartyRelate/Phone/PhoneExtension"));
					partyRelation.setPhone(phone);
					/**/
					if (hash.get(repetition + "PartyRelate/BirthDt") != null || hash.get(repetition + "PartyRelate/BirthDtHjr") != null) {
						CombinedDate dateOfBirth = new CombinedDate();
						dateOfBirth.setDate(hash.get(repetition + "PartyRelate/BirthDt"));
						dateOfBirth.setHijriDate(hash.get(repetition + "PartyRelate/BirthDtHjr"));
						partyRelation.setDateOfBirth(dateOfBirth);
					}
					name.setFirstName(hash.get(repetition + "PartyRelate/PersonFirstName"));
					name.setSecondName(hash.get(repetition + "PartyRelate/PersonFatherName"));
					name.setThirdName(hash.get(repetition + "PartyRelate/PersonGrandFatherName"));
					name.setFamilyName(hash.get(repetition + "PartyRelate/PersonFamilyName"));
					partyRelation.setName(name);
					// TODO RelatedOrgRegName not used
					customerId.setPartyId(hash.get(repetition + "PartyRelate/PartyId"));
					partyRelation.setCustomerId(customerId);
					// TODO RelatedECMRef not used
					if (hash.get(repetition + "PartyRelate/IdExpDt") != null || hash.get(repetition + "PartyRelate/IdExpDtHjr") != null) {
						CombinedDate expiry = new CombinedDate();
						if (hash.get(repetition + "PartyRelate/IdExpDt") != null) {
							expiry.setDate(hash.get(repetition + "PartyRelate/IdExpDt"));
						}
						expiry.setHijriDate(hash.get(repetition + "PartyRelate/IdExpDtHjr"));
						partyRelation.setIdDocExpiryDate(expiry);
					}
					if (hash.get(repetition + "PartyRelate/IdIssueDt") != null || hash.get(repetition + "PartyRelate/IdIssueDtHjr") != null) {
						CombinedDate issueDate = new CombinedDate();
						if (hash.get(repetition + "PartyRelate/IdIssueDt") != null) {
							issueDate.setDate(hash.get(repetition + "PartyRelate/IdIssueDt"));
						}
						issueDate.setHijriDate(hash.get(repetition + "PartyRelate/IdIssueDtHjr"));
						partyRelation.setIdDocIssueDate(issueDate);
					}
					partyRelation.setIssuePlace(hash.get(repetition + "PartyRelate/IdIssuePlace"));
					IdDocKey idDocKey = partyRelation.getIdDocKey();
					idDocKey.setIdNumber(hash.get(repetition + "PartyRelate/IdentDoc"));
					idDocKey.setIdDocType(new EntityDefaultKey(hash.get(repetition + "PartyRelate/IdentDocType")));
					partyRelation.setIdDocKey(idDocKey);
					if (hash.get(repetition + "PartyRelate/IssueCountryCode") != null) {
						partyRelation.setIssueCountry(new EntityDefaultKey(hash.get(repetition + "PartyRelate/IssueCountryCode")));
					}
					// TODO RelatedEnPrintedFullName not used
					// TODO RelatedArPrintedFullName not used
					if (hash.get(repetition + "PartyRelate/IsRegIqama") != null) {
						partyRelation.setRegularIqama(hash.get(repetition + "PartyRelate/IsRegIqama").equalsIgnoreCase("y"));
					}
					// TODO RelatedPrintedAddr not used
					// TODO EndDt not used
					// TODO JobTitle not used
					partyRelation.setNote(hash.get(repetition + "RelCmmnts"));
					// TODO Percen not used
					if (hash.get(repetition + "RelTypeCode") != null) {
						partyRelation.setRelationType(new EntityDefaultKey(hash.get(repetition + "RelTypeCode")));
					}
					partyRelation.setRole(new EntityDefaultKey(hash.get(repetition + "RelRoleCode")));
					if (hash.get(repetition + "StartDt") != null || hash.get(repetition + "StartDtHjr") != null) {
						CombinedDate startDate = new CombinedDate();
						startDate.setDate(hash.get(repetition + "StartDt"));
						startDate.setHijriDate(hash.get(repetition + "StartDtHjr"));
						partyRelation.setStartDate(startDate);
					}
					if (hash.get(repetition + "RecStatusCode") != null) {
						partyRelation.setStatus(new EntityDefaultKey(hash.get(repetition + "RecStatusCode")));
					}
					if (hash.get(repetition + "TrstLvlCode") != null) {
						partyRelation.setTrustLevel(new EntityDefaultKey(hash.get(repetition + "TrstLvlCode")));
					}
					// TODO LocIdRelated not used
					// TODO IdsIdRelated not used
					// TODO ContactIdRelated not used
					// TODO CreateUsr not used
					// TODO CreateDt not used
					// TODO LastMaintUsr not used
					// TODO LastMaintDt not used
					partyRelation.setRecordStatus(RecordStatus.NO_CHANGE);
					if (relation != null
							&& (relation.equals(RelationshipType.VEILED_WOMAN_WITNESS.getCode()) || relation.equals(RelationshipType.ILLITERATE_AND_BLIND_WITNESS.getCode())
									|| relation.equals(RelationshipType.GUARDIAN_OF_MINOR.getCode()) || relation.equals(RelationshipType.COURT_APPOINTED_GUARDIAN.getCode()))) {// is
						// "Vailed Woman Witness",
						// "Court Appointed Guardian","Guardian of a minor",
						// "Illetrate and Blind Witness"
						customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().setRepresentativePersonalInfo(partyRelation);
					} else if (relation != null && relation.equals(RelationshipType.EMPLOYER.getCode())) {
						customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getProfessionalInfo().setEmployerId(partyRelation);
					} else if (relation != null && relation.equals(RelationshipType.BENEFICIAL_OWNER.getCode())) {
						beneficialOwners.add(partyRelation);
					} else {
						partyRelations.add(partyRelation);
					}
				}
				repetition = "PartyRels/PartyRel[" + i + "]/";
			} else {
				break;
			}
		}
		customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().setOtherPartiesRelations(partyRelations);
	}

	private void unmarshalPartyRMNotes(TadawulUser customer, Hashtable<String, String> hash) {
		List<CustomerNote> customerNotes = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().getCustomerNotes();
		if (customerNotes == null) {
			customerNotes = new ArrayList<CustomerNote>(0);
		}
		String repetition = "PartyRMNotes/PartyRMNote/";
		for (int i = 1;; i++) {
			if (hash.get(repetition + "Cmmnts") != null || hash.get(repetition + "ExpDt") != null || hash.get(repetition + "ExpDtHjr") != null || hash.get(repetition + "EffDt") != null
					|| hash.get(repetition + "EffDtHjr") != null || hash.get(repetition + "RMId") != null || hash.get(repetition + "TrstLvlCode") != null) {
				if (hash.get(repetition + "RecStatusCode") != null && hash.get(repetition + "RecStatusCode").equals(EntityStatus.INACTIVE.getCode())) {
					repetition = "PartyRMNotes/PartyRMNote[" + i + "]/";
					continue;
				}
				CustomerNote customerNote = customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().createCustomerNote();
				// TODO Id should be kept
				customerNote.setComments(hash.get(repetition + "Cmmnts"));
				if (hash.get(repetition + "ExpDt") != null || hash.get(repetition + "ExpDtHjr") != null) {
					CombinedDate expiry = new CombinedDate();
					expiry.setDate(hash.get(repetition + "ExpDt"));
					expiry.setHijriDate(hash.get(repetition + "ExpDtHjr"));
					customerNote.setExpiryDate(expiry);
				}
				if (hash.get(repetition + "EffDt") != null || hash.get(repetition + "EffDtHjr") != null) {
					CombinedDate effDt = new CombinedDate();
					effDt.setDate(hash.get(repetition + "EffDt"));
					effDt.setHijriDate(hash.get(repetition + "EffDtHjr"));
					customerNote.setStartEffectiveDate(effDt);
				}
				if (hash.get(repetition + "RMId") != null) {
					customerNote.setRelationManagerId(new EntityDefaultKey(hash.get(repetition + "RMId")));
				}
				customerNote.setSurrogateKey(new SurrogateKey(hash.get(repetition + "RMNoteId")));// TODO this is
				// surrogate
				// TODO RecStatusCode not used
				if (hash.get(repetition + "TrstLvlCode") != null) {
					customerNote.setTrustLevel(new EntityDefaultKey(hash.get(repetition + "TrstLvlCode")));
				}
				customerNote.setRecordStatus(RecordStatus.NO_CHANGE);
				customerNotes.add(customerNote);
				repetition = "PartyRMNotes/PartyRMNote[" + i + "]/";
			} else {
				break;
			}
		}
		customer.getCustomerComplementaryInfo().getCustomerComplementaryAdditionalInfo().setCustomerNotes(customerNotes);
	}

	private void unmarshalPostalAddrs(TadawulUser customer, Hashtable<String, String> hash) {
		String rank = "";
		String repetition = "PostalAddrs/PostalAddr/";
		for (int i = 1;; i++) {
			if (hash.get(repetition + "AddrLine1") != null || hash.get(repetition + "AddrLine2") != null || hash.get(repetition + "EffDt") != null || hash.get(repetition + "EffDtHjr") != null
					|| hash.get(repetition + "ExpDt") != null || hash.get(repetition + "ExpDtHjr") != null || hash.get(repetition + "AddrInd") != null || hash.get(repetition + "StreetNum") != null
					|| hash.get(repetition + "City") != null || hash.get(repetition + "CountryCode") != null || hash.get(repetition + "IsBadAddr") != null || hash.get(repetition + "Dist") != null
					|| hash.get(repetition + "WASELInternalMail") != null || hash.get(repetition + "LangCode") != null || hash.get(repetition + "LocDirctns") != null
					|| hash.get(repetition + "AddrType") != null || hash.get(repetition + "POBox") != null || hash.get(repetition + "PostalCode") != null || hash.get(repetition + "State") != null
					|| hash.get(repetition + "Street") != null || hash.get(repetition + "UnitNum") != null) {
				if (hash.get(repetition + "RecStatusCode") != null && hash.get(repetition + "RecStatusCode").equals(EntityStatus.INACTIVE.getCode())) {
					repetition = "PostalAddrs/PostalAddr[" + i + "]/";
					continue;
				}
				String homeWork = hash.get(repetition + "AddrType");
				CustomerAddress customerAddress;
				if (homeWork.equals(AddressType.HOME.getCode())) {
					customerAddress = customer.getCustomerEssentialInfo().getCustomerEssentialCoreInfo().getHomeAdrress();
				} else {
					// work
					customerAddress = customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getWorkAddress();
				}
				customerAddress.setRecordStatus(RecordStatus.NO_CHANGE);
				// TODO ArrngmntAcctId not used
				// TODO ArrngmntAcctNum not used
				customerAddress.setAdditionalNumber(hash.get(repetition + "WASELNum"));
				customerAddress.setAddressLine1(hash.get(repetition + "AddrLine1"));
				customerAddress.setAddressLine2(hash.get(repetition + "AddrLine2"));
				// TODO AddrLine3 not used
				// TODO AddrLine4 not used
				// TODO AddrLine5 not used
				if (hash.get(repetition + "EffDt") != null || hash.get(repetition + "EffDtHjr") != null) {
					CombinedDate effDt = new CombinedDate();
					effDt.setDate(hash.get(repetition + "EffDt"));
					effDt.setHijriDate(hash.get(repetition + "EffDtHjr"));
					customerAddress.setStartEffectiveDate(effDt);
				}
				if (hash.get(repetition + "ExpDt") != null || hash.get(repetition + "ExpDtHjr") != null) {
					CombinedDate expiryDt = new CombinedDate();
					expiryDt.setDate(hash.get(repetition + "ExpDt"));
					expiryDt.setHijriDate(hash.get(repetition + "ExpDtHjr"));
					customerAddress.setEndEffectiveDate(expiryDt);
				}
				if (hash.get(repetition + "AddrInd") != null) {
					customerAddress.setAddressType(new EntityDefaultKey(hash.get(repetition + "AddrInd")));// is AddressInd in
																										   // the
				}
				// schema
				customerAddress.setBasicNumber(hash.get(repetition + "StreetNum"));
				customerAddress.setCity(hash.get(repetition + "City"));
				if (hash.get(repetition + "CountryCode") != null) {
					customerAddress.setCountry(new EntityDefaultKey(hash.get(repetition + "CountryCode")));
				}
				if (hash.get(repetition + "IsBadAddr") != null) {
					customerAddress.setBadAddress(hash.get(repetition + "IsBadAddr").equalsIgnoreCase("y"));
				}
				customerAddress.setDistrict(hash.get(repetition + "Dist"));
				customerAddress.setInternalMail(hash.get(repetition + "WASELInternalMail"));
				if (hash.get(repetition + "LangCode") != null) {
					customerAddress.setInformationLang(new EntityDefaultKey(hash.get(repetition + "LangCode")));
				}
				customerAddress.setLocationDirection(hash.get(repetition + "LocDirctns"));
				customerAddress.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PostalAddrId")));// TODO this is
				// surrogate
				customerAddress.setPobox(hash.get(repetition + "POBox"));
				customerAddress.setPostalCode(hash.get(repetition + "PostalCode"));
				if (hash.get(repetition + "Rank") != null) {
					if (hash.get(repetition + "Rank").equals("0")) {
						rank = homeWork;
					}
					customerAddress.setRank(new Integer(hash.get(repetition + "Rank")));
				}
				customerAddress.setState(hash.get(repetition + "State"));
				// TODO RecStatusCode not used
				customerAddress.setStreet(hash.get(repetition + "Street"));
				customerAddress.setUnitNumber(hash.get(repetition + "UnitNum"));
				// TODO TerminationDt not used
				// TODO TerminationDtHjr not used
				// TODO RecCreateUsr not used
				// TODO RecCreateDt not used
				// TODO RecUpdateUsr not used
				// TODO RecUpdateDt not used
				repetition = "PostalAddrs/PostalAddr[" + i + "]/";
			} else {
				break;
			}
		}
		customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getDefaultAddressContacts().setDefaultAddress(new EntityDefaultKey(rank));
	}

	/**
	 * Marshal T24 CIF from the cross references section of the reply.
	 * 
	 * @param customer
	 * @param hash
	 */
	private void unmarshalT24CIF(TadawulUser customer, Hashtable<String, String> hash) {
		CustomerId customerId = customer.getCustomerStartingInfo().getDefaultIdDoc().getCustomerId();
		if (customerId == null) {
			customerId = new CustomerId();
			customer.getCustomerStartingInfo().getDefaultIdDoc().setCustomerId(customerId);
		}
		String repetition = "PartyCrossRefs/PartyCrossRef/";
		/**
		 * The following loop will iterate over the cross reference relations to find the relation with T24 and then extracts the System CIF from it.
		 */
		int i = 1;
		while (hash.get(repetition + "CrossRefId") != null) {
			if (hash.get(repetition + "RecStatusCode") != null && hash.get(repetition + "RecStatusCode").equals(EntityStatus.ACTIVE.getCode())) {
				String bankSystem = hash.get(repetition + "SysId");
				if (bankSystem != null) {
					if (bankSystem.equals(BankSystem.T24.getCode())) {
						// T24 entry is found.
						String cif = hash.get(repetition + "SysCIF");
						if (cif != null && !cif.equals("")) {
							customerId.setCIF(cif);
						}
						break;
					}
				}
			}
			repetition = "PartyCrossRefs/PartyCrossRef[" + i + "]/";
			i++;
		}
	}

	/**
	 * Unmarshall Party selected products.
	 * 
	 * @param customer
	 * @param hash
	 */
	private void unmarshalSelectedProducts(TadawulUser customer, Hashtable<String, String> hash) {
		List<CustomerProduct> customerProducts = customer.getSelectedCustomerProducts();
		if (customerProducts == null) {
			customerProducts = new ArrayList<CustomerProduct>();
		}
		String repetition = "ProductsSelList/ProductSel/";
		int i = 0;
		CustomerProduct product;
		while (hash.get(repetition + "PreRegProductId") != null) {
			product = new CustomerProduct();
			product.setSurrogateKey(new SurrogateKey(hash.get(repetition + "PreRegProductId")));
			product.setRecordStatus(RecordStatus.NO_CHANGE);
			if (hash.get(repetition + "ProductCode") != null) {
				product.setProductId(new EntityDefaultKey(hash.get(repetition + "ProductCode")));
			}
			customerProducts.add(product);
			i++;
			repetition = "ProductsSelList/ProductSel[" + i + "]/";
		}
		customer.setSelectedCustomerProducts(customerProducts);
	}

	/**
	 * Unmarshall Party segment.
	 * 
	 * @param customer
	 * @param hash
	 */
	private void unmarshalCustomerSegment(TadawulUser customer, Hashtable<String, String> hash) {
		PartySegment customerSegment = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getAdditionalInfo().getCustomerSegment();
		String partySegmentXPath = "PartySegments/PartySegment/";
		String tmp = hash.get(partySegmentXPath + "Segment");
		if (tmp != null) {
			customerSegment.setSegmentEntity(new EntityDefaultKey(tmp));
			customerSegment.setRecordStatus(RecordStatus.NO_CHANGE);
		}
		tmp = hash.get(partySegmentXPath + "PartySegmentId");
		if (tmp != null) {
			customerSegment.setSurrogateKey(new SurrogateKey(tmp));
		}
	}

	public void unmarshalPartyInvestment(TadawulUser customer, Hashtable<String, String> hash) {
		CustomerCapitalMarketAuthorityInfo customerCMAInfo = customer.getCustomerCapitalMarketAuthorityInfo();
		InvestmentInfo investInfo = customerCMAInfo.getInvestmentInfo();
		CustodianDetails custodianDetails = customerCMAInfo.getCustodianDetails();
		String tmpVal;
		tmpVal = hash.get("PartyInvstmnt/CommdtsAmt");
		if (tmpVal != null) {
			investInfo.setCommoditiesAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/ContractDifOptionsAmt");
		if (tmpVal != null) {
			investInfo.setContractDiffAndOptAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/DebitInstAmt");
		if (tmpVal != null) {
			investInfo.setDebitInstAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/DepsAmt");
		if (tmpVal != null) {
			investInfo.setDepositsAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/ForeignExAmt");
		if (tmpVal != null) {
			investInfo.setForeignExchangeAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/InvstmntFundsAmt");
		if (tmpVal != null) {
			investInfo.setInvestmentFundsAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/RealEstateAmt");
		if (tmpVal != null) {
			investInfo.setRealEstateAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/SharesAmt");
		if (tmpVal != null) {
			investInfo.setSharesAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/TradeFinanceAmt");
		if (tmpVal != null) {
			investInfo.setTradeFinanceAmount((tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LclAsset");
		if (tmpVal != null) {
			investInfo.getPreferredInvestmentAssets().setSARInvestmentAsset(tmpVal.equalsIgnoreCase("y"));
		}
		tmpVal = hash.get("PartyInvstmnt/USDAsset");
		if (tmpVal != null) {
			investInfo.getPreferredInvestmentAssets().setUSDInvestmentAsset(tmpVal.equalsIgnoreCase("y"));
		}
		tmpVal = hash.get("PartyInvstmnt/EURAsset");
		if (tmpVal != null) {
			investInfo.getPreferredInvestmentAssets().setEUROInvestmentAsset(tmpVal.equalsIgnoreCase("y"));
		}
		tmpVal = hash.get("PartyInvstmnt/OtherAsset");
		if (tmpVal != null) {
			investInfo.getPreferredInvestmentAssets().setOtherInvestmentAsset(tmpVal.equalsIgnoreCase("y"));
		}
		tmpVal = hash.get("PartyInvstmnt/OtherAssetDesc");
		if (tmpVal != null) {
			investInfo.getPreferredInvestmentAssets().setOtherInvestmentAssetDesc(tmpVal);
		}
		tmpVal = hash.get("PartyInvstmnt/ForwardCertifType");
		if (tmpVal != null) {
			custodianDetails.setForwardCertifcate(new EntityDefaultKey(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/ForwardCertifOtherDesc");
		if (tmpVal != null) {
			custodianDetails.setForwardCertifcateOtherDesc(tmpVal);
		}
		tmpVal = hash.get("PartyInvstmnt/ForwardDivIncomeOtherDesc");
		if (tmpVal != null) {
			custodianDetails.setForwardDivindandsOtherDesc(tmpVal);
		}
		tmpVal = hash.get("PartyInvstmnt/ForwardDivIncomeType");
		if (tmpVal != null) {
			custodianDetails.setForwardDivindands(new EntityDefaultKey(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/ForwardSaleProceedsOtherDesc");
		if (tmpVal != null) {
			custodianDetails.setForwardSaleProceedsOtherDesc(tmpVal);
		}
		tmpVal = hash.get("PartyInvstmnt/ForwardSaleProceedsType");
		if (tmpVal != null) {
			custodianDetails.setForwardSaleProceeds(new EntityDefaultKey(tmpVal));
		}
		// risk percentages
		RiskPercentage commoditiesRisk = investInfo.getCommoditiesRisk();
		tmpVal = hash.get("PartyInvstmnt/HighRiskCommdtsPercen");
		if (tmpVal != null) {
			commoditiesRisk.setHigh(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/MedRiskCommdtsPercen");
		if (tmpVal != null) {
			commoditiesRisk.setMedium(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LowRiskCommdtsPercen");
		if (tmpVal != null) {
			commoditiesRisk.setLow(new Float(tmpVal));
		}
		RiskPercentage debitInstRisk = investInfo.getDebitInstRisk();
		tmpVal = hash.get("PartyInvstmnt/HighRiskDebitPercen");
		if (tmpVal != null) {
			debitInstRisk.setHigh(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/MedRiskDebitPercen");
		if (tmpVal != null) {
			debitInstRisk.setMedium(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LowRiskDebitPercen");
		if (tmpVal != null) {
			debitInstRisk.setLow(new Float(tmpVal));
		}
		RiskPercentage investmentFundsRisk = investInfo.getInvestmentFundsRisk();
		tmpVal = hash.get("PartyInvstmnt/HighRiskInvstmntPercen");
		if (tmpVal != null) {
			investmentFundsRisk.setHigh(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/MedRiskInvstmntPercen");
		if (tmpVal != null) {
			investmentFundsRisk.setMedium(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LowRiskInvstmntPercen");
		if (tmpVal != null) {
			investmentFundsRisk.setLow(new Float(tmpVal));
		}
		RiskPercentage optionsRisk = investInfo.getOptionsRisk();
		tmpVal = hash.get("PartyInvstmnt/HighRiskOptionsPercen");
		if (tmpVal != null) {
			optionsRisk.setHigh(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/MedRiskOptionsPercen");
		if (tmpVal != null) {
			optionsRisk.setMedium(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LowRiskOptionsPercen");
		if (tmpVal != null) {
			optionsRisk.setLow(new Float(tmpVal));
		}
		RiskPercentage sharesRisk = investInfo.getSharesRisk();
		tmpVal = hash.get("PartyInvstmnt/HighRiskSharesPercen");
		if (tmpVal != null) {
			sharesRisk.setHigh(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/MedRiskSharesPercen");
		if (tmpVal != null) {
			sharesRisk.setMedium(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LowRiskSharesPercen");
		if (tmpVal != null) {
			sharesRisk.setLow(new Float(tmpVal));
		}
		RiskPercentage tradeFinanceRisk = investInfo.getTradeFinanceRisk();
		tmpVal = hash.get("PartyInvstmnt/HighRiskTradePercen");
		if (tmpVal != null) {
			tradeFinanceRisk.setHigh(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/MedRiskTradePercen");
		if (tmpVal != null) {
			tradeFinanceRisk.setMedium(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/LowRiskTradePercen");
		if (tmpVal != null) {
			tradeFinanceRisk.setLow(new Float(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/InvstmntObjctv");
		if (tmpVal != null) {
			investInfo.setInvestmentObjective(new EntityDefaultKey(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/InvstmntRiskPref");
		if (tmpVal != null) {
			investInfo.setInvestmentRisk(new EntityDefaultKey(tmpVal));
		}
		tmpVal = hash.get("PartyInvstmnt/OtherFinancialInfo");
		if (tmpVal != null) {
			investInfo.setOtherFinancialInfo(tmpVal);
		}
		tmpVal = hash.get("PartyInvstmnt/AlinmaCustodian");
		if (tmpVal != null) {
			custodianDetails.setAlinmaCustodian(tmpVal.equalsIgnoreCase("y"));
		}
		tmpVal = hash.get("PartyInvstmnt/InvstmntExperienceCode");
		if (tmpVal != null) {
			investInfo.setInvestmentExperience(new EntityDefaultKey(tmpVal));
		}
	}
}
