package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.alinma.tadawul.domain.messages.request.GetBeneficiariesReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiariesCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetBeneficiariesReqMsgCore request = (GetBeneficiariesReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (request.getFunctionId() != null) {
				marshallingHelper.createNode(xmlWriter, "FuncId", request.getFunctionId());
			}
			if (request.getBeneficiaryType() != null) {
				marshallingHelper.createNode(xmlWriter, "BenType", request.getBeneficiaryType().getCode());
			}
			if (request.getBank() != null) {
				if (request.getBank().getCode() != null) {
					marshallingHelper.createNode(xmlWriter, "BankCode", request.getBank().getCode().getCode());
				}
			}
			if (request.getCountry() != null) {
				marshallingHelper.createNode(xmlWriter, "CountryCode", request.getCountry().getCode());
			}
			if (request.getCurrency() != null) {
				marshallingHelper.createNode(xmlWriter, "CurCode", request.getCurrency().getCode());
			}
			if (request.getBeneficiaryStatus() != null) {
				if (request.getBeneficiaryStatus().getCode() != null) {
					marshallingHelper.createNode(xmlWriter, "BenStatus", request.getBeneficiaryStatus().getCode());
				}
			}
			if (request.getUserId() != null) {
				marshallingHelper.createNode(xmlWriter, "UsrId", request.getUserId());
			}
			if (request.getPaginationInRec() != null) {
				xmlWriter.writeStartElement("RecCtrlIn");
				marshallingHelper.createNode(xmlWriter, "MaxRecs", request.getPaginationInRec().getPageSize().toString());
				marshallingHelper.createNode(xmlWriter, "Offset", request.getPaginationInRec().getPageOffset().toString());
				xmlWriter.writeEndElement();
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
