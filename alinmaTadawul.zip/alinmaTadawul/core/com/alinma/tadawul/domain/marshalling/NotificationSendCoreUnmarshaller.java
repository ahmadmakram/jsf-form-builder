package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.market.domain.messages.response.NotificationSendResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;

public class NotificationSendCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		NotificationSendResMsgCore msgCore = new NotificationSendResMsgCore();
		ResponseMessageBody<NotificationSendResMsgCore> msgResBody = new ResponseMessageBody<NotificationSendResMsgCore>();
		msgResBody.setBodyCore(msgCore);
		return msgResBody;
	}
}
