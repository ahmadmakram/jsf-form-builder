/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;
import com.alinma.tadawul.domain.messages.response.GetLOVResMsg;

/**
 * @author Administrator
 * 
 */
public class GetLOVUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected GetLOVResMsg createResponseMessage() {
		return new GetLOVResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		// TODO Auto-generated method stub
		return "LOVInqRs";
	}
}
