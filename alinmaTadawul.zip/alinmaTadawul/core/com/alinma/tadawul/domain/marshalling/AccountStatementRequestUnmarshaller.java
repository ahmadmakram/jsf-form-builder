package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.AccountStatementRequestResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Mohammad Suliman
 * 
 */
public class AccountStatementRequestUnmarshaller extends MsgUnmarshaller {

	@Override
	protected AccountStatementRequestResMsg createResponseMessage() {
		return new AccountStatementRequestResMsg();
	}

	@Override
	public String getElementString() {
		return "AcctStmtRqRs";
	}
}
