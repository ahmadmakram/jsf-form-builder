package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.StatementCycle;
import com.alinma.tadawul.domain.StatementCycleType;
import com.alinma.tadawul.domain.messages.response.StatementCycleInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementCycleInquiryCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		StatementCycleInquiryResMsgCore msgCore = new StatementCycleInquiryResMsgCore();
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			String repetition = "StmtCyclesList/StmtCycleInfo/";
			int i = 1;
			StatementCycle statementCycle;
			PaginationOutRec pagination = null;
			if (msgParsed.get("SentRecs") != null) {
				pagination = new PaginationOutRec(new Integer(msgParsed.get("SentRecs")), new Integer(msgParsed.get("SentRecs")));
			}
			List<StatementCycle> statementCycleList = new ArrayList<StatementCycle>();
			while (msgParsed.get(repetition + "StartDtHjr") != null) {
				statementCycle = new StatementCycle();
				if (msgParsed.get(repetition + "StartDtHjr") != null) {
					CombinedDate combinedDate = new CombinedDate();
					combinedDate.setHijriDate(msgParsed.get(repetition + "StartDtHjr"));
					statementCycle.setStartDate(combinedDate);
				}
				if (msgParsed.get(repetition + "EndDtHjr") != null) {
					CombinedDate combinedDate = new CombinedDate();
					combinedDate.setHijriDate(msgParsed.get(repetition + "EndDtHjr"));
					statementCycle.setEndDate(combinedDate);
				}
				if (msgParsed.get(repetition + "StartDt") != null) {
					CombinedDate combinedDate = new CombinedDate();
					combinedDate.setDate(msgParsed.get(repetition + "StartDt"));
					statementCycle.setStartDate(combinedDate);
				}
				if (msgParsed.get(repetition + "EndDt") != null) {
					CombinedDate combinedDate = new CombinedDate();
					combinedDate.setDate(msgParsed.get(repetition + "EndDt"));
					statementCycle.setEndDate(combinedDate);
				}
				if (msgParsed.get(repetition + "StmtFreq") != null) {
					statementCycle.setFrequency(msgParsed.get(repetition + "StmtFreq"));
				}
				if (msgParsed.get(repetition + "StmtCycleType") != null) {
					statementCycle.setType(StatementCycleType.getByCode(msgParsed.get(repetition + "StmtCycleType")));
				}
				statementCycleList.add(statementCycle);
				repetition = "StmtCyclesList/StmtCycleInfo[" + i + "]/";
				i++;
			}
			ResponseMessageBody<StatementCycleInquiryResMsgCore> msgResBody = new ResponseMessageBody<StatementCycleInquiryResMsgCore>();
			msgCore.setStatementCycleList(statementCycleList);
			msgCore.setPaginationOutRec(pagination);
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
	}
}
