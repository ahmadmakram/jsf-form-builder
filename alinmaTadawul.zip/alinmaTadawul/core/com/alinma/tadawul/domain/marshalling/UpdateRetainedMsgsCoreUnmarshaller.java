package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * 
 * @author mahamoda
 * 
 */
public class UpdateRetainedMsgsCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		// This Service does not returns response body
		return null;
	}

	public String getElementString() {
		return null;
	}
}
