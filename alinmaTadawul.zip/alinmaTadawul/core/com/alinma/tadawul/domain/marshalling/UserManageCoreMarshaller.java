package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.alinma.tadawul.domain.ChannelInfo;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.UserContact;
import com.alinma.tadawul.domain.messages.request.UserManageReqMsgCore;
import com.alinma.tadawul.services.dao.impl.UserManageDAOImpl;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.Name;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class UserManageCoreMarshaller implements Marshaller {

	public static final String ACTIVATE_USER_FUNCTION = "activateUser";
	public static final String DEACTIVATE_USER_FUNCTION = "deActivateUser";

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		UserManageReqMsgCore userManageReqMsgCore = (UserManageReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			String functionName = "";
			if (context != null && context.getAssociatedBOs() != null) {
				functionName = (String) context.getAssociatedBOs().get("FunctionName");
			}
			marshallingManageUserInfo(xmlWriter, userManageReqMsgCore, marshallingHelper, functionName);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingManageUserInfo(XMLStreamWriter xmlWriter, UserManageReqMsgCore userManageReqMsgCore, MarshallingHelper marshallingHelper, String functionName) throws XMLStreamException {
		TadawulUser tadawulUser = userManageReqMsgCore.getTadawulUser();
		if (tadawulUser == null) {
			return;
		}
		if (tadawulUser.getUserId() != null) {
			marshallingHelper.createNode(xmlWriter, "UsrId", tadawulUser.getUserId(), false, false);
		}
		if (tadawulUser.getBaseUserProfile() != null)
			if (tadawulUser.isUpdated("BaseUserProfile"))
				marshallingHelper.createNode(xmlWriter, "BaseUsrProf", tadawulUser.getBaseUserProfile(), false, false);
		xmlWriter.writeStartElement("UsrInfo");
		marshallingNames("UsrNameAr", xmlWriter, tadawulUser, marshallingHelper);
		marshallingNames("UsrNameEn", xmlWriter, tadawulUser, marshallingHelper);
		if (tadawulUser.getGender() != null)
			if (tadawulUser.isUpdated("Gender"))
				marshallingHelper.createNode(xmlWriter, "Gender", tadawulUser.getGender().getCode(), false, false);
		if (tadawulUser.getTitle() != null)
			if (tadawulUser.isUpdated("Title"))
				marshallingHelper.createNode(xmlWriter, "TitlePrefix", tadawulUser.getTitle().getCode(), false, false);
		marshallingContacts(xmlWriter, tadawulUser, marshallingHelper);
		xmlWriter.writeEndElement();
		// if (UserActivationManageDAOImpl.ACTIVATE_USER_FUNCTION.equals(functionName) || UserActivationManageDAOImpl.DEACTIVATE_USER_FUNCTION.equals(functionName)){
		if (ACTIVATE_USER_FUNCTION.equals(functionName) || DEACTIVATE_USER_FUNCTION.equals(functionName)) {
			marshallingChannelInfo(xmlWriter, tadawulUser.getChannelInfo(userManageReqMsgCore.getTargetChannelId()), marshallingHelper);
		} else {
			marshallingChannelInfo(xmlWriter, tadawulUser.getInternetChannelInfo(), marshallingHelper);
		}
	}

	private void marshallingNames(String englishOrArabicName, XMLStreamWriter xmlWriter, TadawulUser tadawulUser, MarshallingHelper marshallingHelper) throws XMLStreamException {
		Name name = null;
		if ("UsrNameAr".equals(englishOrArabicName)) {
			name = tadawulUser.getArabicName();
		} else {
			name = tadawulUser.getEnglishName();
		}
		if (!BusinessObject.isBusinessObjectReallyUpdated(name)) {
			return;
		}
		if (name != null) {
			xmlWriter.writeStartElement(englishOrArabicName);
			if (name.isUpdated("FirstName"))
				marshallingHelper.createNode(xmlWriter, "FirstName", name.getFirstName(), false, false);
			if (name.isUpdated("SecondName"))
				marshallingHelper.createNode(xmlWriter, "FatherName", name.getSecondName(), false, false);
			if (name.isUpdated("FamilyName"))
				marshallingHelper.createNode(xmlWriter, "FamilyName", name.getFamilyName(), false, false);
			xmlWriter.writeEndElement();
		}
	}

	private void marshallingContacts(XMLStreamWriter xmlWriter, TadawulUser tadawulUser, MarshallingHelper marshallingHelper) throws XMLStreamException {
		UserContact userContact = tadawulUser.getUserContact();
		if (!BusinessObject.isBusinessObjectReallyUpdated(userContact)) {
			return;
		}
		if (userContact != null) {
			xmlWriter.writeStartElement("UsrContacts");
			if (userContact.isUpdated("Address"))
				marshallingHelper.createNode(xmlWriter, "Addr", userContact.getAddress(), false, false);
			if (userContact.isUpdated("PoBox"))
				marshallingHelper.createNode(xmlWriter, "POBox", userContact.getPoBox(), false, false);
			if (userContact.isUpdated("PostalCode"))
				marshallingHelper.createNode(xmlWriter, "PostalCode", userContact.getPostalCode(), false, false);
			if (userContact.isUpdated("City"))
				marshallingHelper.createNode(xmlWriter, "City", userContact.getCity().getCode(), false, false);
			if (userContact.getCountry() != null)
				if (userContact.isUpdated("Country"))
					marshallingHelper.createNode(xmlWriter, "TownConutry", userContact.getCountry().getCode(), false, false);
			if (userContact.getMobile() != null)
				if (userContact.getMobile().isUpdated("MobileNumber"))
					marshallingHelper.createNode(xmlWriter, "MobileNum", userContact.getMobile().getMobileNumber(), false, false);
			if (userContact.getPhone() != null) {
				if (userContact.getPhone().isUpdated("PhoneNumber"))
					marshallingHelper.createNode(xmlWriter, "PhoneNum", userContact.getPhone().getPhoneNumber(), false, false);
				if (userContact.getPhone().isUpdated("PhoneExtension"))
					marshallingHelper.createNode(xmlWriter, "PhoneExtension", userContact.getPhone().getPhoneExtension(), false, false);
			}
			if (userContact.getFax() != null)
				if (userContact.getFax().isUpdated("FaxNumber"))
					marshallingHelper.createNode(xmlWriter, "FaxNum", userContact.getFax().getFaxNumber(), false, false);
			if (userContact.isUpdated("Email"))
				marshallingHelper.createNode(xmlWriter, "Email", userContact.getEmail(), false, false);
			xmlWriter.writeEndElement();
		}
	}

	private void marshallingChannelInfo(XMLStreamWriter xmlWriter, ChannelInfo channelInfo, MarshallingHelper marshallingHelper) throws XMLStreamException {
		if (!BusinessObject.isBusinessObjectReallyUpdated(channelInfo)) {
			return;
		}
		xmlWriter.writeStartElement("UsrChanInfo");
		if (channelInfo.getChannelId() != null) {
			marshallingHelper.createNode(xmlWriter, "ChanId", channelInfo.getChannelId().getCode(), false, false);
		}
		if (channelInfo.getUserCredential() != null) {
			if (channelInfo.getUserCredential().isUpdated("LoginName"))
				marshallingHelper.createNode(xmlWriter, "LoginName", channelInfo.getUserCredential().getLoginName(), false, false);
			if (channelInfo.getUserCredential().isUpdated("Password"))
				marshallingHelper.createNode(xmlWriter, "ChanPswd", channelInfo.getUserCredential().getPassword(), false, false);
		}
		if (channelInfo.getPreferredLang() != null)
			if (channelInfo.isUpdated("PreferredLang"))
				marshallingHelper.createNode(xmlWriter, "LangPref", channelInfo.getPreferredLang().getCode(), false, false);
		if (channelInfo.isUpdated("DefaultUserAccountNumber"))
			marshallingHelper.createNode(xmlWriter, "DfltChanUsrAcctNum", channelInfo.getDefaultUserAccountNumber(), false, false);
		if (channelInfo.isUpdated("SecurityHint"))
			marshallingHelper.createNode(xmlWriter, "SecHint", channelInfo.getSecurityHint(), false, false);
		if (channelInfo.isUpdated("VacationFromDate"))
			marshallingHelper.createNode(xmlWriter, "VacationFromDt", channelInfo.getVacationFromDate(), false, false);
		if (channelInfo.isUpdated("VacationToDate"))
			marshallingHelper.createNode(xmlWriter, "VacationToDt", channelInfo.getVacationToDate(), false, false);
		if (channelInfo.isUpdated("WelcomeMessage"))
			marshallingHelper.createNode(xmlWriter, "WelcomeMsg", channelInfo.getWelcomeMessage(), false, false);
		if (channelInfo.isUpdated("DisplayMessage"))
			marshallingHelper.createNode(xmlWriter, "DispMrktngMsg", channelInfo.getDisplayMessage(), false, false);
		if (channelInfo.isUpdated("ThemeId")) {
			marshallingHelper.createNode(xmlWriter, "ThemeId", channelInfo.getThemeId(), false, false);
		}
		if (channelInfo.isUpdated("SessionTimeout")) {
			marshallingHelper.createNode(xmlWriter, "SessTimeout", String.valueOf(channelInfo.getSessionTimeout()));
		}
		if (channelInfo.isUpdated("ShowSessionHistory")) {
			if (channelInfo.getShowSessionHistory().toString().equalsIgnoreCase("true")) {
				marshallingHelper.createNode(xmlWriter, "ShowSessHist", "Y", false, false);
			} else {
				marshallingHelper.createNode(xmlWriter, "ShowSessHist", "N", false, false);
			}
		}
		xmlWriter.writeEndElement();
	}
}
