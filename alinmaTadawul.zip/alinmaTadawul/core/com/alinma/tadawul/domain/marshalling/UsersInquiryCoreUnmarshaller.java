package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.response.UsersInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.Name;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class UsersInquiryCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		UsersInquiryResMsgCore msgCore = new UsersInquiryResMsgCore();
		List<TadawulUser> ibrUserList = new ArrayList<TadawulUser>();
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			PaginationOutRec paginationOutRec = new PaginationOutRec();
			String repetition = "UsrsList/UsrInfo/";
			TadawulUser tadawulUser;
			int i = 1;
			while (msgParsed.get(repetition + "UsrId") != null) {
				tadawulUser = new TadawulUser();
				if (msgParsed.get("SentRecs") != null) {
					paginationOutRec.setWholeResultSetSize(new Integer(msgParsed.get("SentRecs")));
				}
				if (msgParsed.get(repetition + "UsrId") != null) {
					tadawulUser.setUserId(msgParsed.get(repetition + "UsrId"));
				}
				if (msgParsed.get(repetition + "usrStatus") != null) {
					tadawulUser.setUserStatus(msgParsed.get(repetition + "usrStatus"));
				}
				if (msgParsed.get(repetition + "LoginName") != null) {
					tadawulUser.getInternetChannelInfo().getUserCredential().setLoginName(msgParsed.get(repetition + "LoginName"));
				}
				if (msgParsed.get(repetition + "UsrNameAr/FirstName") != null) {
					tadawulUser.getArabicName().setFirstName(msgParsed.get(repetition + "UsrNameAr/FirstName"));
				}
				if (msgParsed.get(repetition + "UsrNameAr/FatherName") != null) {
					tadawulUser.getArabicName().setSecondName(msgParsed.get(repetition + "UsrNameAr/FatherName"));
				}
				if (msgParsed.get(repetition + "UsrNameAr/FamilyName") != null) {
					tadawulUser.getArabicName().setFamilyName(msgParsed.get(repetition + "UsrNameAr/FamilyName"));
				}
				if (msgParsed.get(repetition + "UsrNameEn/FirstName") != null) {
					tadawulUser.getEnglishName().setFirstName(msgParsed.get(repetition + "UsrNameEn/FirstName"));
				}
				if (msgParsed.get(repetition + "UsrNameEn/FatherName") != null) {
					tadawulUser.getEnglishName().setSecondName(msgParsed.get(repetition + "UsrNameEn/FatherName"));
				}
				if (msgParsed.get(repetition + "UsrNameEn/FamilyName") != null) {
					tadawulUser.getEnglishName().setFamilyName(msgParsed.get(repetition + "UsrNameEn/FamilyName"));
				}
				tadawulUser.setArabicName(tadawulUser.getArabicName());
				tadawulUser.setEnglishName(tadawulUser.getEnglishName());
				ibrUserList.add(tadawulUser);
				repetition = "UsrsList/UsrInfo[" + i + "]/";
				i++;
			}
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		ResponseMessageBody<UsersInquiryResMsgCore> resMsgBody = new ResponseMessageBody<UsersInquiryResMsgCore>();
		msgCore.setTadawulUser(ibrUserList);
		resMsgBody.setBodyCore(msgCore);
		return resMsgBody;
	}

	public String getElementString() {
		return null;
	}
}
