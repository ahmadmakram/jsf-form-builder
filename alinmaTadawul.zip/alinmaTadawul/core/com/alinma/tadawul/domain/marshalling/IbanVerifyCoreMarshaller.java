package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.messages.request.IbanVerifyReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class IbanVerifyCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		IbanVerifyReqMsgCore ibanVerifyReqMsgCore = (IbanVerifyReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshalCardNum(marshallingHelper, xmlWriter, ibanVerifyReqMsgCore.getAccount());
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}

	private void marshalCardNum(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, Account account) throws XMLStreamException {
		if (account.getIban() != null) {
			marshallingHelper.createNode(xmlWriter, "IBAN", account.getIban());
		}
		if (account.getCountryCode() != null) {
			marshallingHelper.createNode(xmlWriter, "CountryCode", account.getCountryCode().getCode());
		}
		if (account.getAccountCurrency() != null) {
			marshallingHelper.createNode(xmlWriter, "CurCode", account.getAccountCurrency().getCode());
		}
		if (account.getBankCode() != null) {
			marshallingHelper.createNode(xmlWriter, "BankCode", account.getBankCode().getCode());
		}
	}
}
