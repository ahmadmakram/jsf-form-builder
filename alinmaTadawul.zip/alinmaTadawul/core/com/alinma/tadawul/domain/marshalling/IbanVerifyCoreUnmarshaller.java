package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamReader;
import com.alinma.tadawul.domain.messages.response.IbanVerifyResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class IbanVerifyCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		IbanVerifyResMsgCore msgCore = new IbanVerifyResMsgCore();
		ResponseMessageBody<IbanVerifyResMsgCore> resMsgBody = new ResponseMessageBody<IbanVerifyResMsgCore>();
		resMsgBody.setBodyCore(msgCore);
		return resMsgBody;
	}

	public String getElementString() {
		return null;
	}
}
