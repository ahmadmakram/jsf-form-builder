/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;
import com.alinma.tadawul.domain.messages.response.DateMappingResMsg;

/**
 * @author M. Ali Hammam
 * 
 */
public class MapDateUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected ResponseMessage createResponseMessage() {
		return new DateMappingResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		return "DataMapngInqRs";
	}
}
