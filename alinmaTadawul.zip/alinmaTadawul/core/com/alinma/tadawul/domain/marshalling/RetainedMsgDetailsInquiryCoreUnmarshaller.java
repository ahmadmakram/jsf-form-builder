package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.RetainedMsg;
import com.alinma.tadawul.domain.messages.response.GetRetainedMsgDetailsInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.exceptions.UnmarshallingException;

public class RetainedMsgDetailsInquiryCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		GetRetainedMsgDetailsInquiryResMsgCore msgCore = new GetRetainedMsgDetailsInquiryResMsgCore();
		ResponseMessageBody<GetRetainedMsgDetailsInquiryResMsgCore> msgResBody = new ResponseMessageBody<GetRetainedMsgDetailsInquiryResMsgCore>();
		msgResBody.setBodyCore(msgCore);
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			RetainedMsg retainedMsg = null;
			if (context != null && context.getAssociatedBOs() != null) {
				retainedMsg = (RetainedMsg) context.getAssociatedBOs().get(RetainedMsg.class.getName());
			}
			if (retainedMsg == null) {
				retainedMsg = new RetainedMsg();
			}
			if (msgParsed.get("MsgId") != null) {
				retainedMsg.setMsgId(new EntityDefaultKey(msgParsed.get("MsgId")));
			}
			if (msgParsed.get("MsgBody") != null) {
				retainedMsg.setMsgBody(msgParsed.get("MsgBody"));
			}
			if (msgParsed.get("MsgId") != null) {
				retainedMsg.setMsgId(new EntityDefaultKey(msgParsed.get("MsgId")));
			}
			if (msgParsed.get("MsgHdr") != null) {
				retainedMsg.setMsgHeader(msgParsed.get("MsgHdr"));
			}
			if (msgParsed.get("MsgRead") != null && msgParsed.get("MsgRead").equalsIgnoreCase("Y")) {
				retainedMsg.setReadMsg(true);
			} else if (msgParsed.get("MsgRead") != null && msgParsed.get("MsgRead").equalsIgnoreCase("N")) {
				retainedMsg.setReadMsg(false);
			}
			if (msgParsed.get("MsgDeleted") != null && msgParsed.get("MsgDeleted").equalsIgnoreCase("Y")) {
				retainedMsg.setDeletedMsg(true);
			} else if (msgParsed.get("MsgDeleted") != null && msgParsed.get("MsgDeleted").equalsIgnoreCase("N")) {
				retainedMsg.setDeletedMsg(false);
			}
			if (msgParsed.get("ReceivedDt") != null) {
				String dateTimeString = msgParsed.get("ReceivedDt");
				CombinedDate receivedDate = new CombinedDate();
				receivedDate.setDateTime(dateTimeString);
				retainedMsg.setReceivedDate(receivedDate);
			}
			msgCore.setRetainedMsg(retainedMsg);
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		return msgResBody;
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
