package com.alinma.tadawul.domain.marshalling;

/**
 * 
 * @author Mahmoud Al Selwadi
 *
 */
import com.alinma.tadawul.domain.messages.response.SessionTerminationResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class SessionTerminationUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new SessionTerminationResMsg();
	}

	@Override
	public String getElementString() {
		return "UsrSessTerminationRs";
	}
}
