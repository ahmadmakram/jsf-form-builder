package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.response.UserManageResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;

public class UserManageCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		UserManageResMsgCore msgCore = new UserManageResMsgCore();
		ResponseMessageBody<UserManageResMsgCore> msgResBody = new ResponseMessageBody<UserManageResMsgCore>();
		msgResBody.setBodyCore(msgCore);
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			TadawulUser tadawulUser = null;
			if (context != null && context.getAssociatedBOs() != null) {
				tadawulUser = (TadawulUser) context.getAssociatedBOs().get(TadawulUser.class.getName());
			}
			if (tadawulUser == null) {
				tadawulUser = new TadawulUser();
			}
			if (msgParsed.get("UsrId") != null) {
				tadawulUser.setUserId(msgParsed.get("UsrId"));
			}
			msgCore.setTadawulUser(tadawulUser);
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		return msgResBody;
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
