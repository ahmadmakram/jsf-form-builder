package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.Beneficiary;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.response.AccountDetailsInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.Language;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class AccountDetailsInquiryCoreUnMarshaller implements Unmarshaller {

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		AccountDetailsInquiryResMsgCore msgCore = new AccountDetailsInquiryResMsgCore();
		ResponseMessageBody<AccountDetailsInquiryResMsgCore> msgResBody = new ResponseMessageBody<AccountDetailsInquiryResMsgCore>();
		Account account = null;
		try {
			if (context != null && context.getAssociatedBOs() != null) {
				account = (Account) context.getAssociatedBOs().get(Account.class.getName());
			}
			if (account == null) {
				account = new Account();
			}
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			if (msgParsed.get("AcctId/AcctNum") != null) {
				account.setAccountNumber(msgParsed.get("AcctId/AcctNum"));
			}
			if (msgParsed.get("AcctId/AcctType") != null) {
				account.setAccountType(new EntityDefaultKey(msgParsed.get("AcctId/AcctType")));
			}
			if (msgParsed.get("IBAN") != null) {
				account.setIban(msgParsed.get("IBAN"));
			}
			if (msgParsed.get("AcctName") != null) {
				account.setAccountName((msgParsed.get("AcctName")));
			}
			if (msgParsed.get("ShortDesc") != null) {
				account.setShortDesc(msgParsed.get("ShortDesc"));
			}
			if (msgParsed.get("AcctNickname") != null) {
				account.setAccountNickName(msgParsed.get("AcctNickname"));
			}
			if (msgParsed.get("AcctStatus") != null) {
				account.setAccountStatus(new EntityDefaultKey(msgParsed.get("AcctStatus")));
			}
			if (msgParsed.get("AcctCur") != null) {
				account.setAccountCurrency(new EntityDefaultKey(msgParsed.get("AcctCur")));
			}
			if (msgParsed.get("StmtDeliveryOpt") != null) {
				account.setDeliveryOption(new EntityDefaultKey(msgParsed.get("StmtDeliveryOpt")));
			}
			if (msgParsed.get("StmtLangPref") != null) {
				account.setStmtPreferredLang(Language.getByCode(msgParsed.get("StmtLangPref")));
			}
			if (msgParsed.get("BranchId") != null) {
				account.setBranchId(msgParsed.get("BranchId"));
			}
			if (msgParsed.get("AvailBal") != null) {
				account.setAvailableBalance(new Double(msgParsed.get("AvailBal").replace(",", "")));
			}
			if (msgParsed.get("LedgerBal") != null) {
				account.setLedgerBalance(new Double(msgParsed.get("LedgerBal").replace(",", "")));
			}
			if (msgParsed.get("CurrBal") != null) {
				account.setCurrentBalance(new Double(msgParsed.get("CurrBal").replace(",", "")));
			}
			if (msgParsed.get("ATMCardExist") != null) {
				account.setATMCardExist(new Boolean(msgParsed.get("ATMCardExist")));
			}
			if (msgParsed.get("SignId") != null) {
				account.setSignId(msgParsed.get("SignId"));
			}
			msgCore.setAccount(account);
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		msgResBody.setBodyCore(msgCore);
		return msgResBody;
	}
}
