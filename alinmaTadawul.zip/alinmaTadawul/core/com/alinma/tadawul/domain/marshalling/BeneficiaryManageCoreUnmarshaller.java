package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Beneficiary;
import com.alinma.tadawul.domain.lov.BeneficiaryStatus;
import com.alinma.tadawul.domain.messages.response.BeneficiaryManageResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * 
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			BeneficiaryManageResMsgCore msgCore = new BeneficiaryManageResMsgCore();
			Beneficiary beneficiary = null;
			if (context != null && context.getAssociatedBOs() != null) {
				beneficiary = (Beneficiary) context.getAssociatedBOs().get(Beneficiary.class.getName());
			}
			if (beneficiary == null) {
				beneficiary = new Beneficiary();
			}
			if (msgParsed.get("BenCode") != null) {
				beneficiary.setCode(msgParsed.get("BenCode"));
			}
			if (msgParsed.get("BenStatus") != null) {
				beneficiary.setStatus(BeneficiaryStatus.getByCode(msgParsed.get("BenStatus")));
			}
			msgCore.setBeneficiary(beneficiary);
			ResponseMessageBody<BeneficiaryManageResMsgCore> resMsgBody = new ResponseMessageBody<BeneficiaryManageResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
