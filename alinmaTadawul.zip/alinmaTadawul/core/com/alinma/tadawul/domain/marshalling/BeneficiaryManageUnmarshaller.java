package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.BeneficiaryManageResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new BeneficiaryManageResMsg();
	}

	@Override
	public String getElementString() {
		return "BenMngRs";
	}
}
