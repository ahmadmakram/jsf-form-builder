package com.alinma.tadawul.domain.marshalling;

/**
 * 
 * @author Mahmoud Al Selwadi
 *
 */
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.LogoutType;
import com.alinma.tadawul.domain.messages.request.SessionTerminationReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

public class SessionTerminationCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		SessionTerminationReqMsgCore sessionTerminationReqMsgCore = (SessionTerminationReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "LogoutType", sessionTerminationReqMsgCore.getLogoutType().getCode());
			if (sessionTerminationReqMsgCore.getLogoutType().equals(LogoutType.SEESION_TERMINATED_UNEXPECTEDLY)) {
				marshallingHelper.createNode(xmlWriter, "LogoutReason", sessionTerminationReqMsgCore.getLogoutReason());
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
