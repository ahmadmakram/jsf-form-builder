/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

//import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

//import com.alinma.tadawul.domain.messages.request.ExchangeRatesReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
//import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRatesCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		// No body to marshal
	}
}
