package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.StatementDetailsInquiryResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new StatementDetailsInquiryResMsg();
	}

	@Override
	public String getElementString() {
		return "StmtDtlsInqRs";
	}
}
