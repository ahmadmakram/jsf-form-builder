package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.lov.ServiceFunctionsEnum;
import com.alinma.tadawul.domain.messages.request.AccountStatementRequestReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Mohammad Suliman
 * 
 */
public class AccountStatementRequestCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		AccountStatementRequestReqMsgCore accountStmtInqReqMsgCore = (AccountStatementRequestReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			String functionName = "";
			if (context != null && context.getAssociatedBOs() != null) {
				functionName = (String) context.getAssociatedBOs().get("FunctionName");
			}
			if (ServiceFunctionsEnum.currentAccountStatementRequest.name().equals(functionName) || ServiceFunctionsEnum.personalFinanceInstallmentScheduleRequest.name().equals(functionName))
				if (accountStmtInqReqMsgCore.getAccount() != null) {
					xmlWriter.writeStartElement("AcctId");
					marshallingHelper.createNode(xmlWriter, "AcctNum", accountStmtInqReqMsgCore.getAccount().getAccountNumber(), false, false);
					if (accountStmtInqReqMsgCore.getAccount().getAccountType() != null) {
						marshallingHelper.createNode(xmlWriter, "AcctType", accountStmtInqReqMsgCore.getAccount().getAccountType().getCode(), false, false);
					}
					xmlWriter.writeEndElement();
				}
			if (ServiceFunctionsEnum.creditCardStatementRequest.name().equals(functionName))
				if (accountStmtInqReqMsgCore.getCard() != null) {
					xmlWriter.writeStartElement("CardId");
					marshallingHelper.createNode(xmlWriter, "CardNum", accountStmtInqReqMsgCore.getCard().getCardNumber(), false, false);
					if (accountStmtInqReqMsgCore.getCard().getCardType() != null) {
						marshallingHelper.createNode(xmlWriter, "AcctType", accountStmtInqReqMsgCore.getCard().getCardType().getCode(), false, false);
					}
					xmlWriter.writeEndElement();
				}
			if (ServiceFunctionsEnum.currentAccountStatementRequest.name().equals(functionName) || ServiceFunctionsEnum.creditCardStatementRequest.name().equals(functionName)) {
				if (accountStmtInqReqMsgCore.getStartDate() != null) {
					xmlWriter.writeStartElement("DtRange");
					marshallingHelper.createNode(xmlWriter, "StartDt", accountStmtInqReqMsgCore.getStartDate().getDate(), false, false);
					marshallingHelper.createNode(xmlWriter, "EndDt", accountStmtInqReqMsgCore.getEndDate().getDate(), false, false);
					xmlWriter.writeEndElement();
				} else if (accountStmtInqReqMsgCore.getStatementPeriod() != null) {
					marshallingHelper.createNode(xmlWriter, "StmtPeriod", accountStmtInqReqMsgCore.getStatementPeriod(), false, false);
				}
			}
			marshallingHelper.createNode(xmlWriter, "StmtDeliveryOpt", accountStmtInqReqMsgCore.getStatementDelivery().getCode(), false, false);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}
}
