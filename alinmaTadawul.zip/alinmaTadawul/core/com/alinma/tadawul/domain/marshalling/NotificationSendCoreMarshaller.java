package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.market.domain.NotificationSendRecipInfo;
import com.alinma.tadawul.market.domain.messages.request.NotificationSendReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

public class NotificationSendCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		NotificationSendReqMsgCore reqMsgCore = (NotificationSendReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "MsgContent", reqMsgCore.getMsgContent(), false, false);
			xmlWriter.writeStartElement("RecipsList");
			for (NotificationSendRecipInfo recipInfo : reqMsgCore.getRecipInfo()) {
				xmlWriter.writeStartElement("RecipInfo");
				xmlWriter.writeStartElement("NotificationMethodInfo");
				marshallingHelper.createNode(xmlWriter, "NotificationMethod", recipInfo.getNotificationMethodInfo().getNotificationMethod(), false, false);
				marshallingHelper.createNode(xmlWriter, "Contact", recipInfo.getNotificationMethodInfo().getContact(), false, false);
				marshallingHelper.createNode(xmlWriter, "EmailFrom", recipInfo.getNotificationMethodInfo().getEmailFrom(), false, false);
				marshallingHelper.createNode(xmlWriter, "EmailSubject", recipInfo.getNotificationMethodInfo().getEmailSubject(), false, false);
				xmlWriter.writeEndElement();
				xmlWriter.writeEndElement();
			}
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
