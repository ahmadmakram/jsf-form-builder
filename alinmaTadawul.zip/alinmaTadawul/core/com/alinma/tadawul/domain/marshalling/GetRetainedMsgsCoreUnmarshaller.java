package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.RetainedMsg;
import com.alinma.tadawul.domain.lov.NotificationMethodType;
import com.alinma.tadawul.domain.messages.response.GetRetainedMsgsResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * 
 * @author mahamoda
 * 
 */
public class GetRetainedMsgsCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			GetRetainedMsgsResMsgCore msgCore = new GetRetainedMsgsResMsgCore();
			List<RetainedMsg> retainedMsgs = new ArrayList<RetainedMsg>(0);
			if (validateRequiredFields(msgParsed)) {
				PaginationOutRec paginationOutRec = new PaginationOutRec(new Integer(msgParsed.get("RecCtrlOut/MatchedRecs")), new Integer(msgParsed.get("RecCtrlOut/SentRecs")));
				msgCore.setPaginationOut(paginationOutRec);
				String repetition = "RetainedMsgsList/RetainedMsgInfo/";
				int i = 0;
				while (msgParsed.get(repetition + "MsgId") != null) {
					RetainedMsg retainedMsg = new RetainedMsg();
					if (msgParsed.get(repetition + "MsgId") != null) {
						retainedMsg.setMsgId(new EntityDefaultKey(msgParsed.get(repetition + "MsgId")));
					}
					if (msgParsed.get(repetition + "NotificationMethod") != null) {
						retainedMsg.setNotificationMethod(NotificationMethodType.getByLabel(msgParsed.get(repetition + "NotificationMethod")));
					}
					if (msgParsed.get(repetition + "MsgHdr") != null) {
						retainedMsg.setMsgHeader(msgParsed.get(repetition + "MsgHdr"));
					}
					if (msgParsed.get(repetition + "MsgRead") != null && msgParsed.get(repetition + "MsgRead").equalsIgnoreCase("Y")) {
						retainedMsg.setReadMsg(true);
					} else if (msgParsed.get(repetition + "MsgRead") != null && msgParsed.get(repetition + "MsgRead").equalsIgnoreCase("N")) {
						retainedMsg.setReadMsg(false);
					}
					if (msgParsed.get(repetition + "MsgDeleted") != null && msgParsed.get(repetition + "MsgDeleted").equalsIgnoreCase("Y")) {
						retainedMsg.setDeletedMsg(true);
					} else if (msgParsed.get(repetition + "MsgDeleted") != null && msgParsed.get(repetition + "MsgDeleted").equalsIgnoreCase("N")) {
						retainedMsg.setDeletedMsg(false);
					}
					if (msgParsed.get(repetition + "MsgBody") != null) {
						retainedMsg.setMsgHeader(msgParsed.get(repetition + "MsgBody"));
					}
					if (msgParsed.get(repetition + "ReceivedDt") != null) {
						String dateTimeString = msgParsed.get(repetition + "ReceivedDt");
						CombinedDate receivedDate = new CombinedDate();
						receivedDate.setDateTime(dateTimeString);
						retainedMsg.setReceivedDate(receivedDate);
					}
					retainedMsgs.add(retainedMsg);
					i++;
					repetition = "RetainedMsgsList/RetainedMsgInfo[" + i + "]/";
				}
			}
			msgCore.setRetainedMsgs(retainedMsgs);
			ResponseMessageBody<GetRetainedMsgsResMsgCore> resMsgBody = new ResponseMessageBody<GetRetainedMsgsResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}

	private boolean validateRequiredFields(Hashtable<String, String> msgParsed) {
		if (msgParsed.get("RecCtrlOut/MatchedRecs") == null || msgParsed.get("RecCtrlOut/SentRecs") == null) {
			return false;
		}
		return true;
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
