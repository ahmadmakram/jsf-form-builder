package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.market.domain.messages.response.NotificationSendResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class NotificationSendUnmarshaller extends MsgUnmarshaller {

	@Override
	protected NotificationSendResMsg createResponseMessage() {
		// TODO Auto-generated method stub
		return new NotificationSendResMsg();
	}

	@Override
	public String getElementString() {
		// TODO Auto-generated method stub
		return "NotificationSendRs";
	}
}
