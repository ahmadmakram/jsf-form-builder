package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.GetCustomerDetailsResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Hani Younis
 * 
 */
public class GetCustomerDetailsUnmarshaller extends MsgUnmarshaller {

	@Override
	protected GetCustomerDetailsResMsg createResponseMessage() {
		return new GetCustomerDetailsResMsg();
	}

	@Override
	public String getElementString() {
		return "PartyDtlsInqRs";
	}
}
