/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.UserLimit;
import com.alinma.tadawul.domain.messages.response.GetUserLimitsResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class GetUserLimitsCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString ()
	 */
	public String getElementString() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax .xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		GetUserLimitsResMsgCore msgCore = new GetUserLimitsResMsgCore();
		// read the tag of Body
		PaginationOutRec pagination = null;
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			if (msgParsed.get("RecCtrlOut/SentRecs") != null) {
				pagination = new PaginationOutRec(new Integer(msgParsed.get("RecCtrlOut/MatchedRecs")), new Integer(msgParsed.get("RecCtrlOut/SentRecs")));
			}
			String repetition = "UsrLimitsList/UsrLimits/";
			int i = 1;
			UserLimit userLimit;
			List<UserLimit> userLimits = msgCore.getUserLimits();
			while (msgParsed.get(repetition + "FuncGrpId") != null) {
				userLimit = new UserLimit();
				if (msgParsed.get(repetition + "ChanId") != null) {
					userLimit.setChannelId(new EntityDefaultKey(msgParsed.get(repetition + "ChanId")));
				}
				if (msgParsed.get(repetition + "FuncGrpId") != null) {
					userLimit.setFunctionID(new EntityDefaultKey(msgParsed.get(repetition + "FuncGrpId")));
				}
				if (msgParsed.get(repetition + "CurGrpId") != null) {
					userLimit.setCurrencyGroup(new EntityDefaultKey(msgParsed.get(repetition + "CurGrpId")));
				}
				// TODO :get 3 dimens
				if (msgParsed.get(repetition + "Dimen") != null) {
					userLimit.getLimitsDimensions()[0] = msgParsed.get(repetition + "Dimen");
				}
				if (msgParsed.get(repetition + "Dimen[1]") != null) {
					userLimit.getLimitsDimensions()[1] = msgParsed.get(repetition + "Dimen[1]");
				}
				if (msgParsed.get(repetition + "Dimen[2]") != null) {
					userLimit.getLimitsDimensions()[2] = msgParsed.get(repetition + "Dimen[2]");
				}
				if (msgParsed.get(repetition + "TrnAmt") != null) {
					userLimit.setAmountLimit(new Double(msgParsed.get(repetition + "TrnAmt")));
				}
				if (msgParsed.get(repetition + "TotalAmt") != null) {
					userLimit.setDailyAmountLimit(new Double(msgParsed.get(repetition + "TotalAmt")));
				}
				if (msgParsed.get(repetition + "TrnCount") != null) {
					userLimit.setLimitOnNumberOftransactionsPerDay(new Double(msgParsed.get(repetition + "TrnCount")));
				}
				if (msgParsed.get(repetition + "TrnAmtPercen") != null) {
					userLimit.setPercentageAmountLimit(new Double(msgParsed.get(repetition + "TrnAmtPercen")));
				}
				if (msgParsed.get(repetition + "TotalAmtPercen") != null) {
					userLimit.setPercentageDailyAmountLimit(new Double(msgParsed.get(repetition + "TotalAmtPercen")));
				}
				if (msgParsed.get(repetition + "TrnCountPercen") != null) {
					userLimit.setPercentageLimitPerDay(new Double(msgParsed.get(repetition + "TrnCountPercen")));
				}
				if (msgParsed.get(repetition + "NonSTPTrnAmt") != null) {
					userLimit.setNonSTPAmountLimit(new Double(msgParsed.get(repetition + "NonSTPTrnAmt")));
				}
				if (msgParsed.get(repetition + "NonSTPTotalAmt") != null) {
					userLimit.setNonSTPAmountLimit(new Double(msgParsed.get(repetition + "NonSTPTotalAmt")));
				}
				if (msgParsed.get(repetition + "AvailTotalAmt") != null) {
					userLimit.setAvailableDailyAmountLimit(new Double(msgParsed.get(repetition + "AvailTotalAmt")));
				}
				if (msgParsed.get(repetition + "AvailTrnCount") != null) {
					userLimit.setAvailableLimitPerDay(new Double(msgParsed.get(repetition + "AvailTrnCount")));
				}
				userLimits.add(userLimit);
				repetition = "UsrLimitsList/UsrLimits[" + i + "]/";
				i++;
			}
			ResponseMessageBody<GetUserLimitsResMsgCore> msgResBody = new ResponseMessageBody<GetUserLimitsResMsgCore>();
			msgResBody.setBodyCore(msgCore);
			msgCore.setUserLimits(userLimits);
			msgCore.setPaginationOutRec(pagination);
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
	}
}
