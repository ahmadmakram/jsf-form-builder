package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.RetainedMsg;
import com.alinma.tadawul.domain.messages.request.GetRetainedMsgDetailsInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class RetainedMsgDetailsInquiryCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetRetainedMsgDetailsInquiryReqMsgCore userDetailsInquiryReqMsgCore = (GetRetainedMsgDetailsInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingRetainedMsgDetailsInquiry(xmlWriter, userDetailsInquiryReqMsgCore, marshallingHelper);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	private void marshallingRetainedMsgDetailsInquiry(XMLStreamWriter xmlWriter, GetRetainedMsgDetailsInquiryReqMsgCore getRetainedMsgDetailsInquiryReqMsgCore, MarshallingHelper marshallingHelper)
			throws XMLStreamException {
		RetainedMsg retainedMsg = getRetainedMsgDetailsInquiryReqMsgCore.getRetainedMsg();
		if (retainedMsg == null) {
			return;
		}
		if (retainedMsg.getMsgId() != null)
			marshallingHelper.createNode(xmlWriter, "MsgId", retainedMsg.getMsgId().getCode());
	}
}
