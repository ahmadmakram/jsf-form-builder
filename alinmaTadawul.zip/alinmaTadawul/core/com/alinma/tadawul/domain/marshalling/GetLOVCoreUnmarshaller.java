/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.Language;
import com.ejada.commons.domain.lov.LOVDescription;
import com.ejada.commons.domain.lov.LOVItem;
import com.ejada.commons.domain.lov.LOVList;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.alinma.tadawul.domain.lov.LOVTypeImpl;
import com.alinma.tadawul.domain.messages.response.GetLOVResMsgCore;

/**
 * @author Administrator
 * 
 */
public class GetLOVCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString()
	 */
	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax.xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader reader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			// read the tag of Body
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(reader);
			int sentRecs = msgParsed.get("SentRecs") != null ? Integer.parseInt(msgParsed.get("SentRecs")) : 0;
			String repetition = "LOVList/LOVInfo/";
			String id, label, desc;
			EntityKey lang = null;
			Language opsLang = null;
			String attribute1;
			List<Object> attributes;
			if (context != null && context.getAssociatedBOs() != null) {
				lang = (EntityKey) context.getAssociatedBOs().get(EntityDefaultKey.class.getName());
			}
			if (lang == null) {
				lang = Language.ENGLISH; // to be the default
			} else {
				if (lang.getCode().equals(Language.ENGLISH.getCode())) {
					lang = Language.ENGLISH;
					opsLang = Language.ARABIC;
				} else {
					lang = Language.ARABIC;
					opsLang = Language.ENGLISH;
				}
			}
			LOVItem lovItem;
			LOVList<LOVTypeImpl> lovList = new LOVList<LOVTypeImpl>();
			for (int i = 1; i <= sentRecs; i++) {
				id = msgParsed.get(repetition + "RecTypeCode");
				label = msgParsed.get(repetition + "RecShortDesc");
				desc = msgParsed.get(repetition + "RecDesc");
				attribute1 = msgParsed.get(repetition + "Attribute1");
				if (desc == null || desc.equals("")) {
					if (attribute1 != null && !attribute1.equals("")) {
						// The main description is not exist; set it as attribute1
						desc = attribute1;
					} else {
						desc = "Missing Description";
					}
				}
				lovItem = new LOVItem(id, (Language) lang, label, desc);
				if (attribute1 != null) {
					lovItem.addDescription(new LOVDescription(opsLang, label, attribute1));
				} else {
					lovItem.addDescription(new LOVDescription(opsLang, label, desc));
				}
				attributes = new ArrayList<Object>(0);
				for (int j = 1; j < 10; j++) {
					attributes.add(msgParsed.get(repetition + "Attribute" + j));
				}
				lovItem.setAttributes(attributes);
				lovList.add(lovItem);
				repetition = "LOVList/LOVInfo[" + i + "]/";
			}
			GetLOVResMsgCore msgCore = new GetLOVResMsgCore();
			msgCore.setLovList(lovList);
			ResponseMessageBody<GetLOVResMsgCore> resMsgBody = new ResponseMessageBody<GetLOVResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException("Error at unmarshalling");
		}
	}
}
