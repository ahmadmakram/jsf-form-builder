package com.alinma.tadawul.domain.marshalling;

/**
 * 
 * @author Mahmoud Al Selwadi
 *
 */
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.MsgMarshaller;

public class SessionTerminationMarshaller extends MsgMarshaller {

	@Override
	public void appendMsgStart(XMLStreamWriter xmlWriter) throws XMLStreamException {
		xmlWriter.writeStartElement("UsrSessTerminationRq");
	}
}
