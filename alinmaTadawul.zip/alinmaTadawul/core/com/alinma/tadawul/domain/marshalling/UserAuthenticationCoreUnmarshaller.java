package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.TadawulUser;
//import com.alinma.tadawul.domain.lov.CustomerType;
//import com.alinma.tadawul.domain.lov.SAMAStatus;
import com.alinma.tadawul.domain.lov.Status;
import com.alinma.tadawul.domain.messages.response.UserAuthenticationResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.Name;
import com.ejada.commons.domain.User;
import com.ejada.commons.exceptions.UnmarshallingException;

public class UserAuthenticationCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			// // read the tag of Body
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			UserAuthenticationResMsgCore msgCore = new UserAuthenticationResMsgCore();
			TadawulUser user = null;
			if (validateRequiredFields(msgParsed)) {
				if (context != null && context.getAssociatedBOs() != null) {
					user = (TadawulUser) context.getAssociatedBOs().get(User.class.getName());
				}
				if (user == null) {
					user = new TadawulUser();
				}
				unmarshalUserChannelInfo(msgParsed, user, msgCore);
				unmarshalUserInfo(msgParsed, user, msgCore);
				unmarshalCustomerInfo(msgParsed, user, msgCore);
				if (msgParsed.get("OneTmPswdFlg").equalsIgnoreCase("Y")) {
					user.setOneTimePassword(new Boolean(true));
				} else if (msgParsed.get("OneTmPswdFlg").equalsIgnoreCase("N")) {
					user.setOneTimePassword(new Boolean(false));
				}
				if (msgParsed.get("ScndPswdFlg").equalsIgnoreCase("Y")) {
					user.setSecondPassword(new Boolean(true));
				} else if (msgParsed.get("ScndPswdFlg").equalsIgnoreCase("N")) {
					user.setSecondPassword(new Boolean(false));
				}
			}
			msgCore.setUser(user);
			ResponseMessageBody<UserAuthenticationResMsgCore> resMsgBody = new ResponseMessageBody<UserAuthenticationResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}

	private boolean validateRequiredFields(Hashtable<String, String> msgParsed) {
		if (msgParsed.get("UsrChanInfo/ChanId") == null || msgParsed.get("UsrChanInfo/ChanStatus") == null || msgParsed.get("UsrInfo/UsrId") == null || msgParsed.get("CustInfo/CIF") == null
				|| msgParsed.get("CustInfo/AlinmaId") == null || msgParsed.get("CustInfo/CustStatus") == null || msgParsed.get("CustInfo/Segment") == null
				|| msgParsed.get("CustInfo/SAMAStatus") == null || msgParsed.get("OneTmPswdFlg") == null || msgParsed.get("ScndPswdFlg") == null) {
			return false;
		}
		return true;
	}

	private void unmarshalUserChannelInfo(Hashtable<String, String> msgParsed, TadawulUser user, UserAuthenticationResMsgCore msgCore) {
		user.getInternetChannelInfo().setChannelId(new EntityDefaultKey(msgParsed.get("UsrChanInfo/ChanId")));
		String channelStatus = msgParsed.get("UsrChanInfo/ChanStatus");
		if (channelStatus.equalsIgnoreCase("A")) {
			user.getInternetChannelInfo().setChannelStatus(new EntityDefaultKey(Status.ACTIVE.getCode()));
		} else if (channelStatus.equalsIgnoreCase("I")) {
			user.getInternetChannelInfo().setChannelStatus(new EntityDefaultKey(Status.INACTIVE.getCode()));
		}
		if (msgParsed.get("UsrChanInfo/LangPref") != null) {
			user.getInternetChannelInfo().setPreferredLang(new EntityDefaultKey(msgParsed.get("UsrChanInfo/LangPref")));
		}
		if (msgParsed.get("UsrChanInfo/DfltChanUsrAcctNum") != null) {
			user.getInternetChannelInfo().setDefaultUserAccountNumber(msgParsed.get("UsrChanInfo/DfltChanUsrAcctNum"));
		}
		if (msgParsed.get("UsrChanInfo/VacationStatus") != null) {
			if (msgParsed.get("UsrChanInfo/VacationStatus").equalsIgnoreCase("A")) {
				user.getInternetChannelInfo().setVacationStatus(new EntityDefaultKey(Status.ACTIVE.getCode()));
			} else if (msgParsed.get("UsrChanInfo/VacationStatus").equalsIgnoreCase("I")) {
				user.getInternetChannelInfo().setVacationStatus(new EntityDefaultKey(Status.INACTIVE.getCode()));
			} else if (msgParsed.get("UsrChanInfo/VacationStatus").equalsIgnoreCase("P")) {
				user.getInternetChannelInfo().setVacationStatus(new EntityDefaultKey(Status.PENDING.getCode()));
			}
		}
		if (msgParsed.get("UsrChanInfo/VacationFromDt") != null) {
			user.getInternetChannelInfo().setVacationFromDate(msgParsed.get("UsrChanInfo/VacationFromDt"));
		}
		if (msgParsed.get("UsrChanInfo/VacationToDt") != null) {
			user.getInternetChannelInfo().setVacationToDate(msgParsed.get("UsrChanInfo/VacationToDt"));
		}
		if (msgParsed.get("UsrChanInfo/NumOfFailedLogins") != null) {
			user.getInternetChannelInfo().setNumberOfFailedLogins(new Integer(msgParsed.get("UsrChanInfo/NumOfFailedLogins")));
		}
		if (msgParsed.get("UsrChanInfo/LastFailedLoginTmstmp") != null) {
			CombinedDate lastFailedLogin = new CombinedDate();
			lastFailedLogin.setDateTime((msgParsed.get("UsrChanInfo/LastFailedLoginTmstmp")));
			user.getInternetChannelInfo().setLastFailedLoginDateTime(lastFailedLogin);
		}
		if (msgParsed.get("UsrChanInfo/LastSuccLoginTmstmp") != null) {
			CombinedDate lastSuccessLogin = new CombinedDate();
			lastSuccessLogin.setDateTime(msgParsed.get("UsrChanInfo/LastSuccLoginTmstmp"));
			user.getInternetChannelInfo().setLastSuccessLoginDateTime(lastSuccessLogin);
		}
		if (msgParsed.get("UsrChanInfo/WelcomeMsg") != null) {
			user.getInternetChannelInfo().setWelcomeMessage(msgParsed.get("UsrChanInfo/WelcomeMsg"));
		}
		if (msgParsed.get("UsrChanInfo/DispMrktngMsg") != null) {
			if (msgParsed.get("UsrChanInfo/DispMrktngMsg").equalsIgnoreCase("Y")) {
				user.getInternetChannelInfo().setDispalyMarketingMsg(new Boolean(true));
			} else if (msgParsed.get("UsrChanInfo/DispMrktngMsg").equalsIgnoreCase("N")) {
				user.getInternetChannelInfo().setDispalyMarketingMsg(new Boolean(false));
			}
		}
	} // End of unmarshalUserChannelInfo

	private void unmarshalUserInfo(Hashtable<String, String> msgParsed, TadawulUser user, UserAuthenticationResMsgCore msgCore) {
		user.setUserId(msgParsed.get("UsrInfo/UsrId"));
		Name arabicName = new Name();
		if (msgParsed.get("UsrInfo/UsrNameAr/FirstName") != null) {
			arabicName.setFirstName(msgParsed.get("UsrInfo/UsrNameAr/FirstName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameAr/FatherName") != null) {
			arabicName.setSecondName(msgParsed.get("UsrInfo/UsrNameAr/FatherName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameAr/FamilyName") != null) {
			arabicName.setFamilyName(msgParsed.get("UsrInfo/UsrNameAr/FamilyName"));
		}
		user.setArabicName(arabicName);
		Name englishName = new Name();
		if (msgParsed.get("UsrInfo/UsrNameEn/FirstName") != null) {
			englishName.setFirstName(msgParsed.get("UsrInfo/UsrNameEn/FirstName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameEn/FatherName") != null) {
			englishName.setSecondName(msgParsed.get("UsrInfo/UsrNameEn/FatherName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameEn/FamilyName") != null) {
			englishName.setFamilyName(msgParsed.get("UsrInfo/UsrNameEn/FamilyName"));
		}
		user.setEnglishName(englishName);
	} // End of unmarshalUserInfo

	private void unmarshalCustomerInfo(Hashtable<String, String> msgParsed, TadawulUser user, UserAuthenticationResMsgCore msgCore) {
		user.setCif(msgParsed.get("CustInfo/CIF"));
		user.setAlinmaId(msgParsed.get("CustInfo/AlinmaId"));
		if (msgParsed.get("CustInfo/CustType") != null) {
			// if (msgParsed.get("CustInfo/CustType").equalsIgnoreCase("I")) {
			// user.setCustomerType(new EntityDefaultKey(CustomerType.INDIVIDUAL.getCode()));
			// } else if (msgParsed.get("CustInfo/CustType").equalsIgnoreCase("C")) {
			// user.setCustomerType(new EntityDefaultKey(CustomerType.CORPORATE.getCode()));
			// }
		}
		user.setCustomerStatus(new EntityDefaultKey(msgParsed.get("CustInfo/CustStatus")));
		user.setSegment(new EntityDefaultKey(msgParsed.get("CustInfo/Segment")));
		// if (msgParsed.get("CustInfo/SAMAStatus").equalsIgnoreCase("0")) {
		// user.setCustomerType(new EntityDefaultKey(SAMAStatus.NORMAL.getCode()));
		// } else if (msgParsed.get("CustInfo/SAMAStatus").equalsIgnoreCase("1")) {
		// user.setCustomerType(new EntityDefaultKey(SAMAStatus.WARNING.getCode()));
		// } else if (msgParsed.get("CustInfo/SAMAStatus").equalsIgnoreCase("2")) {
		// user.setCustomerType(new EntityDefaultKey(SAMAStatus.BLOCKED.getCode()));
		// }
	} // End of unmarshalCustomerInfo

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
