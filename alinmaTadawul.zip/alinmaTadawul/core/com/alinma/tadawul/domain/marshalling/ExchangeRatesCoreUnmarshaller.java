/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.CurrencyInfo;
import com.alinma.tadawul.domain.messages.response.ExchangeRatesResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRatesCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		ExchangeRatesResMsgCore msgCore = new ExchangeRatesResMsgCore();
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			List<CurrencyInfo> exchangeRatesList = msgCore.getExchangeRatesInquiry();
			String repetition = "ExRateList/ExRateInfo/";
			int i = 1;
			while (msgParsed.get(repetition + "CurCode") != null) {
				CurrencyInfo exchangeRate = new CurrencyInfo();
				exchangeRate.setCurrencySource(new EntityDefaultKey(msgParsed.get(repetition + "CurCode")));
				if (msgParsed.get(repetition + "BuyRate") != null) {
					exchangeRate.setBuyRateSource(msgParsed.get(repetition + "BuyRate"));
				}
				if (msgParsed.get(repetition + "SellRate") != null) {
					exchangeRate.setSellRateTarget(msgParsed.get(repetition + "SellRate"));
				}
				exchangeRatesList.add(exchangeRate);
				repetition = "ExRateList/ExRateInfo[" + i + "]/";
				i++;
			}
			ResponseMessageBody<ExchangeRatesResMsgCore> msgResBody = new ResponseMessageBody<ExchangeRatesResMsgCore>();
			msgResBody.setBodyCore(msgCore);
			msgCore.setExchangeRates(exchangeRatesList);
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
	}
}
