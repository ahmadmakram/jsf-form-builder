package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.StatementCycleInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementCycleInquiryCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		StatementCycleInquiryReqMsgCore statementCycleInquiryReqMsgCore = (StatementCycleInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		String function = (String) context.getAssociatedBOs().get(String.class.getName());
		try {
			if (statementCycleInquiryReqMsgCore.getAccountNum() != null) {
				xmlWriter.writeStartElement("AcctId");
				marshallingHelper.createNode(xmlWriter, "AcctNum", statementCycleInquiryReqMsgCore.getAccountNum());
				if (statementCycleInquiryReqMsgCore.getAccountType() != null) {
					marshallingHelper.createNode(xmlWriter, "AcctType", statementCycleInquiryReqMsgCore.getAccountType());
				}
				xmlWriter.writeEndElement();
			}
			if (statementCycleInquiryReqMsgCore.getCardNum() != null) {
				xmlWriter.writeStartElement("CardId");
				marshallingHelper.createNode(xmlWriter, "CardNum", statementCycleInquiryReqMsgCore.getCardNum());
				if (statementCycleInquiryReqMsgCore.getCardType() != null) {
					marshallingHelper.createNode(xmlWriter, "CardType", statementCycleInquiryReqMsgCore.getCardType());
				}
				xmlWriter.writeEndElement();
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
