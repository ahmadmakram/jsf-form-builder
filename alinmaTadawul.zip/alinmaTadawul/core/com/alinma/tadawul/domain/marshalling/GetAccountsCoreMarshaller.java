package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.GetAccountsReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.PaginationInRec;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author mbrins
 * 
 */
public class GetAccountsCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetAccountsReqMsgCore filter = (GetAccountsReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "CIF", filter.getCif(), false, false);
			marshallingHelper.createNode(xmlWriter, "FuncId", filter.getFunctionId(), false, false);
			if (filter.getFunctionMode() != null && filter.getFunctionMode().getCode() != null) {
				marshallingHelper.createNode(xmlWriter, "FuncMode", filter.getFunctionMode().getCode(), false, false);
			}
			if (filter.getAccountStatus() != null && filter.getAccountStatus().getCode() != null) {
				marshallingHelper.createNode(xmlWriter, "AcctStatus", filter.getAccountStatus().getCode(), false, false);
			}
			marshallingHelper.createNode(xmlWriter, "AcctType", (filter.getAccountType() != null) ? filter.getAccountType().getCode() : "");
			if (filter.getAccountCurrency() != null && filter.getAccountCurrency().getCode() != null) {
				marshallingHelper.createNode(xmlWriter, "AcctCur", filter.getAccountCurrency().getCode(), false, false);
			}
			marshallingHelper.createNode(xmlWriter, "UsrId", filter.getUsrId(), false, false);
			marshalPagination(marshallingHelper, xmlWriter, filter.getRecordControlInput());
		} catch (XMLStreamException e) {
			throw new MarshallingException(e.getMessage());
		}
	}

	private void marshalPagination(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, PaginationInRec pagination) throws XMLStreamException {
		if (pagination == null) {
			return;
		}
		xmlWriter.writeStartElement("RecCtrlIn");
		marshallingHelper.createNode(xmlWriter, "MaxRecs", pagination.getPageSize().toString());
		marshallingHelper.createNode(xmlWriter, "Offset", pagination.getPageOffset().toString(), false, false);
		xmlWriter.writeEndElement();
	}
}
