package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import com.alinma.tadawul.domain.Beneficiary;
import com.alinma.tadawul.domain.lov.BeneficiaryStatus;
import com.alinma.tadawul.domain.lov.BeneficiaryType;
import com.alinma.tadawul.domain.lov.DetailsOfCharge;
import com.alinma.tadawul.domain.messages.response.GetBeneficiariesResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * 
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiariesCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			GetBeneficiariesResMsgCore msgCore = new GetBeneficiariesResMsgCore();
			List<Beneficiary> benfsList = new ArrayList<Beneficiary>(0);
			PaginationOutRec paginationOutRec = null;
			if (msgParsed.get("RecCtrlOut/SentRecs") != null) {
				paginationOutRec = new PaginationOutRec(new Integer(msgParsed.get("RecCtrlOut/MatchedRecs")), new Integer(msgParsed.get("RecCtrlOut/SentRecs")));
				msgCore.setPaginationOut(paginationOutRec);
			} else {
				throw new UnmarshallingException("RecCtrlOut/SentRecs has not been sent");
			}
			String repetition = "BensList/BenInfo/";
			for (int i = 1; i <= paginationOutRec.getCurrentResultSetSize(); i++) {
				Beneficiary beneficiary = new Beneficiary();
				if (msgParsed.get(repetition + "BenDtls/BenCode") != null) {
					beneficiary.setCode(msgParsed.get(repetition + "BenDtls/BenCode"));
				}
				if (msgParsed.get(repetition + "BenDtls/BenType") != null) {
					beneficiary.setBeneficiaryType(BeneficiaryType.getByCode(msgParsed.get(repetition + "BenDtls/BenType")));
				}
				if (msgParsed.get(repetition + "BenDtls/Nickname") != null) {
					beneficiary.setNickName(msgParsed.get(repetition + "BenDtls/Nickname"));
				}
				if (msgParsed.get(repetition + "BenDtls/FullName") != null) {
					beneficiary.getName().setFullName(msgParsed.get(repetition + "BenDtls/FullName"));
				}
				if (msgParsed.get(repetition + "BenDtls/CountryCode") != null) {
					beneficiary.setCountry(new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/CountryCode")));
				}
				if (msgParsed.get(repetition + "BenDtls/CurCode") != null) {
					beneficiary.setCurrency(new EntityDefaultKey((msgParsed.get(repetition + "BenDtls/CurCode"))));
				}
				if (msgParsed.get(repetition + "BenDtls/DfltAmt") != null) {
					beneficiary.setDefualtAmount((msgParsed.get(repetition + "BenDtls/DfltAmt")));
				}
				if (msgParsed.get(repetition + "BenDtls/BenType") != null && msgParsed.get(repetition + "BenDtls/BenType").equalsIgnoreCase("1")) {
					if (msgParsed.get(repetition + "BenDtls/AcctId/AcctNum") != null) {
						beneficiary.getAccount().setAccountNumber(msgParsed.get(repetition + "BenDtls/AcctId/AcctNum"));
					}
					if (msgParsed.get(repetition + "BenDtls/AcctId/AcctType") != null) {
						beneficiary.getAccount().setAccountType(new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/AcctId/AcctType")));
					}
				} else {
					if (msgParsed.get(repetition + "BenDtls/BenAcctNum") != null) {
						beneficiary.getAccount().setAccountNumber(msgParsed.get(repetition + "BenDtls/BenAcctNum"));
					}
				}
				if (msgParsed.get(repetition + "BenDtls/IsIBAN") != null && msgParsed.get(repetition + "BenDtls/IsIBAN").equalsIgnoreCase("Y")) {
					beneficiary.setIban(true);
				} else if (msgParsed.get(repetition + "BenDtls/IsIBAN") != null && msgParsed.get(repetition + "BenDtls/IsIBAN").equalsIgnoreCase("N")) {
					beneficiary.setIban(false);
				}
				if (msgParsed.get(repetition + "BenDtls/FundXferCoCode") != null) {
					beneficiary.setFundTransferCompany(new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/FundXferCoCode")));
				}
				if (msgParsed.get(repetition + "BenDtls/FundXferCoSubCategoryCode") != null) {
					beneficiary.setFundTransferSubCateogry(new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/FundXferCoSubCategoryCode")));
				}
				if (msgParsed.get(repetition + "BenDtls/BenBankDtl/BankCode") != null) {
					beneficiary.getBank().setCode(new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/BenBankDtl/BankCode")));
				}
				if (msgParsed.get(repetition + "BenDtls/BenBankDtl/BankName") != null) {
					beneficiary.getBank().setBankName(msgParsed.get(repetition + "BenDtls/BenBankDtl/BankName"));
				}
				if (msgParsed.get(repetition + "BenDtls/FundXferPurpose") != null) {
					beneficiary.setFundTransferPurpose((new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/FundXferPurpose"))));
				}
				if (msgParsed.get(repetition + "BenDtls/DtlOfCharge") != null) {
					beneficiary.setDetailsOfCharge(DetailsOfCharge.getByCode(msgParsed.get(repetition + "BenDtls/DtlOfCharge")));
				}
				if (msgParsed.get(repetition + "BenDtls/BenStatus") != null) {
					beneficiary.setStatus(BeneficiaryStatus.getByCode(msgParsed.get(repetition + "BenDtls/BenStatus")));
				}
				if (msgParsed.get(repetition + "BenDtls/RejectionReason") != null) {
					beneficiary.setRejectReason(msgParsed.get(repetition + "BenDtls/RejectionReason"));
				}
				if (msgParsed.get(repetition + "BenDtls/SCId") != null) {
					beneficiary.setScID(new EntityDefaultKey(msgParsed.get(repetition + "BenDtls/SCId")));
				}
				if (msgParsed.get(repetition + "IsSubUsrEnabled") != null && msgParsed.get(repetition + "IsSubUsrEnabled").equalsIgnoreCase("Y")) {
					beneficiary.setSubUserEnable(true);
				} else if (msgParsed.get(repetition + "IsSubUsrEnabled") != null && msgParsed.get(repetition + "IsSubUsrEnabled").equalsIgnoreCase("N"))
					beneficiary.setSubUserEnable(false);
				benfsList.add(beneficiary);
				repetition = "BensList/BenInfo[" + i + "]/";
			}
			msgCore.setBeneficiaries(benfsList);
			ResponseMessageBody<GetBeneficiariesResMsgCore> resMsgBody = new ResponseMessageBody<GetBeneficiariesResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}

	private boolean validateRequiredFields(Hashtable<String, String> msgParsed) {
		if (msgParsed.get("RecCtrlOut/MatchedRecs") == null || msgParsed.get("RecCtrlOut/SentRecs") == null) {
			return false;
		}
		return true;
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
