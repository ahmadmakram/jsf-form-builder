/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.FundTransferResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class FundTransferUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected FundTransferResMsg createResponseMessage() {
		return new FundTransferResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		return "FundXferRs";
	}
}
