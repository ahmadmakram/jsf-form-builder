/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;
import com.alinma.tadawul.domain.messages.request.GetLOVReqMsgCore;

/**
 * @author Waleed Tayea
 * 
 */
public class GetLOVCoreMarshaller implements Marshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Marshaller#marshal(javax.xml.stream.XMLStreamWriter, java.lang.Object, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetLOVReqMsgCore requestMsgCore = (GetLOVReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (requestMsgCore.getLovTypeCode() != null && !"".equals(requestMsgCore.getLovTypeCode())) {
				marshallingHelper.createNode(xmlWriter, "LOVType", requestMsgCore.getLovTypeCode());
			} else if (requestMsgCore.getLovType().getCode() != null) {
				marshallingHelper.createNode(xmlWriter, "LOVType", requestMsgCore.getLovType().getCode());
			}
			marshallingHelper.createNode(xmlWriter, "LOVCode1", requestMsgCore.getLovCode1());
			marshallingHelper.createNode(xmlWriter, "LOVCode2", requestMsgCore.getLovCode2());
			marshallingHelper.createNode(xmlWriter, "LOVCode3", requestMsgCore.getLovCode3());
			marshallingHelper.createNode(xmlWriter, "LOVCode4", requestMsgCore.getLovCode4());
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			throw new MarshallingException(e.getMessage());
		}
	}
}
