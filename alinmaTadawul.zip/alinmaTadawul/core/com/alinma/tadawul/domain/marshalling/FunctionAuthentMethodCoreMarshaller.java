/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;
import com.alinma.tadawul.domain.messages.request.FunctionAuthentMethodReqMsgCore;

/**
 * @author Hani Younis
 * 
 */
public class FunctionAuthentMethodCoreMarshaller implements Marshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Marshaller#marshal(javax. xml.stream.XMLStreamWriter, java.lang.Object, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		FunctionAuthentMethodReqMsgCore functionAuthentMethodReqMsgCore = (FunctionAuthentMethodReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingUserLimitsInfo(xmlWriter, functionAuthentMethodReqMsgCore, marshallingHelper);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingUserLimitsInfo(XMLStreamWriter xmlWriter, FunctionAuthentMethodReqMsgCore functionAuthentMethodReqMsgCore, MarshallingHelper marshallingHelper) throws XMLStreamException {
		marshallingHelper.createNode(xmlWriter, "FuncId", functionAuthentMethodReqMsgCore.getFuncId(), false, false);
		if (functionAuthentMethodReqMsgCore.getFunctionAuthentDimensions()[0] != null)
			marshallingHelper.createNode(xmlWriter, "Dimen", functionAuthentMethodReqMsgCore.getFunctionAuthentDimensions()[0], false, false);
		if (functionAuthentMethodReqMsgCore.getFunctionAuthentDimensions()[1] != null)
			marshallingHelper.createNode(xmlWriter, "Dimen", functionAuthentMethodReqMsgCore.getFunctionAuthentDimensions()[1], false, false);
		if (functionAuthentMethodReqMsgCore.getFunctionAuthentDimensions()[2] != null)
			marshallingHelper.createNode(xmlWriter, "Dimen", functionAuthentMethodReqMsgCore.getFunctionAuthentDimensions()[2], false, false);
		if (functionAuthentMethodReqMsgCore.getSourceCurrencyAmount() != null || functionAuthentMethodReqMsgCore.getCurrency() != null
				|| functionAuthentMethodReqMsgCore.getLocalCurrencyAmount() != null) {
			xmlWriter.writeStartElement("SrcCurAmt");
			marshallingHelper.createNode(xmlWriter, "Amt", functionAuthentMethodReqMsgCore.getSourceCurrencyAmount(), false, false);
			marshallingHelper.createNode(xmlWriter, "CurCode", functionAuthentMethodReqMsgCore.getCurrency().getCode(), false, false);
			marshallingHelper.createNode(xmlWriter, "AmtLcl", functionAuthentMethodReqMsgCore.getLocalCurrencyAmount(), false, false);
			xmlWriter.writeEndElement();
		}
	}
}
