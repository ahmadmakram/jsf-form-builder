/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.CustomerAdditionalInfo;
import com.alinma.tadawul.domain.CustomerAddress;
import com.alinma.tadawul.domain.CustomerBankInfo;
import com.alinma.tadawul.domain.CustomerPersonalInfo;
import com.alinma.tadawul.domain.CustomerProfessionalInfo;
import com.alinma.tadawul.domain.DefaultIdDoc;
import com.alinma.tadawul.domain.IncomeSourceDetails;
import com.alinma.tadawul.domain.RiskPercentage;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.investment.InvestmentAssets;
import com.alinma.tadawul.domain.investment.InvestmentInfo;
import com.alinma.tadawul.domain.lov.AddressType;
import com.alinma.tadawul.domain.lov.CustomerId;
import com.alinma.tadawul.market.domain.messages.request.ManageCustomerReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author M. Ali Hammam
 * 
 */
public class ManageCustomerCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		ManageCustomerReqMsgCore manageCustomerReqMsgCore = (ManageCustomerReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		TadawulUser customer = manageCustomerReqMsgCore.getCustomer();
		if (customer == null) {
			;// TODO raise an exception
		}
		try {
			xmlWriter.writeStartElement("Party");
			marshallingPartyCommon(marshallingHelper, customer, xmlWriter, context);
			marshallingPostalAddrs(marshallingHelper, customer, xmlWriter);
			marshallingPartyDetail(marshallingHelper, customer, xmlWriter);
			marshallingPartyInvestment(marshallingHelper, customer, xmlWriter);
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			throw new MarshallingException(e.getMessage());
		}
	}

	private void marshallingPartyCommon(MarshallingHelper marshallingHelper, TadawulUser customer, XMLStreamWriter xmlWriter, Context context) throws XMLStreamException {
		CustomerBankInfo cBI = customer.getCustomerStartingInfo().getBankInfo();
		CustomerAdditionalInfo cAI = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getAdditionalInfo();
		CustomerId cI = customer.getCustomerStartingInfo().getDefaultIdDoc().getCustomerId();
		CustomerPersonalInfo cPI = customer.getCustomerStartingInfo().getPersonalInfo();
		CustomerProfessionalInfo professionalInfo = customer.getCustomerEssentialInfo().getCustomerEssentialAdditionalInfo().getProfessionalInfo();
		DefaultIdDoc dI = customer.getCustomerStartingInfo().getDefaultIdDoc();
		EntityKey userBranch = null;
		try {
			xmlWriter.writeStartElement("PartyCommon");
			marshallingHelper.createNode(xmlWriter, "LangCode", cPI.getNameLanguage() != null ? cPI.getNameLanguage().getCode() : null);
			if (userBranch != null && cAI.getMainBranch() == null) {
				marshallingHelper.createNode(xmlWriter, "MainBranchId", userBranch.getCode(), false, false);
			} else {
				marshallingHelper.createNode(xmlWriter, "MainBranchId", cAI.getMainBranch() != null ? cAI.getMainBranch().getCode() : null, false, false);
			}
			marshallingHelper.createNode(xmlWriter, "PartyId", cI.getPartyId(), false, false);
			marshallingHelper.createNode(xmlWriter, "CustType", cI.getCustomerType() != null ? cI.getCustomerType().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "PartyTypeCode", cI.getPartyType() != null ? cI.getPartyType().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "RecVersion", cBI.getRecordVersion() != null ? cBI.getRecordVersion() + "" : null, false, false);
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			throw e;
		}
	}

	private void marshallingPartyDetail(MarshallingHelper marshallingHelper, TadawulUser customer, XMLStreamWriter xmlWriter) throws XMLStreamException {
		IncomeSourceDetails iSD = customer.getCustomerComplementaryInfo().getCustomerComplementaryCoreInfo().getIncomeSourceDetails();
		marshallingHelper.createNode(xmlWriter, "PropertyAssests", iSD.getRealPropertyAssets() != null ? iSD.getRealPropertyAssets().floatValue() + "" : null, false, false);
		try {
			xmlWriter.writeStartElement("Person");
			if (iSD.getAdditionalWorkIncome() != null) {
				xmlWriter.writeStartElement("AdditionalIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getAdditionalWorkIncome().getAmount() != null ? iSD.getAdditionalWorkIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getAdditionalWorkIncome().getApplicability() != null ? iSD.getAdditionalWorkIncome().getApplicability() ? "Y" : "N" : null,
						false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getAdditionalWorkIncome().getFrequence() != null ? iSD.getAdditionalWorkIncome().getFrequence().getCode() : null, false,
						false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getAdditionalWorkIncome().getReceivingMethod() != null ? iSD.getAdditionalWorkIncome().getReceivingMethod().getCode()
						: null, false, false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getAllowanceIncome() != null) {
				xmlWriter.writeStartElement("AllwnceIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getAllowanceIncome().getAmount() != null ? iSD.getAllowanceIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getAllowanceIncome().getApplicability() != null ? iSD.getAllowanceIncome().getApplicability() ? "Y" : "N" : null, false,
						false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getAllowanceIncome().getFrequence() != null ? iSD.getAllowanceIncome().getFrequence().getCode() : null, false, false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getAllowanceIncome().getReceivingMethod() != null ? iSD.getAllowanceIncome().getReceivingMethod().getCode() : null, false,
						false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getCommissOrBonusIncome() != null) {
				xmlWriter.writeStartElement("BonusIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getCommissOrBonusIncome().getAmount() != null ? iSD.getCommissOrBonusIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getCommissOrBonusIncome().getApplicability() != null ? iSD.getCommissOrBonusIncome().getApplicability() ? "Y" : "N" : null,
						false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getCommissOrBonusIncome().getFrequence() != null ? iSD.getCommissOrBonusIncome().getFrequence().getCode() : null, false,
						false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getCommissOrBonusIncome().getReceivingMethod() != null ? iSD.getCommissOrBonusIncome().getReceivingMethod().getCode()
						: null, false, false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getEndServiceIncome() != null) {
				xmlWriter.writeStartElement("EndSvcIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getEndServiceIncome().getAmount() != null ? iSD.getEndServiceIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getEndServiceIncome().getApplicability() != null ? iSD.getEndServiceIncome().getApplicability() ? "Y" : "N" : null, false,
						false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getInheritanceIncome() != null) {
				xmlWriter.writeStartElement("InhrtanceIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getInheritanceIncome().getAmount() != null ? iSD.getInheritanceIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getInheritanceIncome().getApplicability() != null ? iSD.getInheritanceIncome().getApplicability() ? "Y" : "N" : null, false,
						false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getInvestmentIncome() != null) {
				xmlWriter.writeStartElement("InvstmntIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getInvestmentIncome().getAmount() != null ? iSD.getInvestmentIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getInvestmentIncome().getApplicability() != null ? iSD.getInvestmentIncome().getApplicability() ? "Y" : "N" : null, false,
						false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getInvestmentIncome().getFrequence() != null ? iSD.getInvestmentIncome().getFrequence().getCode() : null, false, false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getInvestmentIncome().getReceivingMethod() != null ? iSD.getInvestmentIncome().getReceivingMethod().getCode() : null,
						false, false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getOtherIncome() != null) {
				xmlWriter.writeStartElement("OtherIncome");
				marshallingHelper.createNode(xmlWriter, "Amt", iSD.getOtherIncome().getAmount() != null ? iSD.getOtherIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getOtherIncome().getApplicability() != null ? iSD.getOtherIncome().getApplicability() ? "Y" : "N" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getOtherIncome().getReceivingMethod() != null ? iSD.getOtherIncome().getReceivingMethod().getCode() : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IncomeDesc", iSD.getOtherIncome().getDescription());
				xmlWriter.writeEndElement();
			}
			if (iSD.getPayrollIncome() != null) {
				xmlWriter.writeStartElement("PayrollIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getPayrollIncome().getAmount() != null ? iSD.getPayrollIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getPayrollIncome().getApplicability() != null ? iSD.getPayrollIncome().getApplicability() ? "Y" : "N" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getPayrollIncome().getFrequence() != null ? iSD.getPayrollIncome().getFrequence().getCode() : null, false, false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getPayrollIncome().getReceivingMethod() != null ? iSD.getPayrollIncome().getReceivingMethod().getCode() : null, false,
						false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getRentIncome() != null) {
				xmlWriter.writeStartElement("RentIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getRentIncome().getAmount() != null ? iSD.getRentIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getRentIncome().getApplicability() != null ? iSD.getRentIncome().getApplicability() ? "Y" : "N" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getRentIncome().getFrequence() != null ? iSD.getRentIncome().getFrequence().getCode() : null, false, false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getRentIncome().getReceivingMethod() != null ? iSD.getRentIncome().getReceivingMethod().getCode() : null, false, false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getSavingIncome() != null) {
				xmlWriter.writeStartElement("SavingIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getSavingIncome().getAmount() != null ? iSD.getSavingIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getSavingIncome().getApplicability() != null ? iSD.getSavingIncome().getApplicability() ? "Y" : "N" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getSavingIncome().getFrequence() != null ? iSD.getSavingIncome().getFrequence().getCode() : null, false, false);
				marshallingHelper
						.createNode(xmlWriter, "RcvMethodCode", iSD.getSavingIncome().getReceivingMethod() != null ? iSD.getSavingIncome().getReceivingMethod().getCode() : null, false, false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getStockDividendsIncome() != null) {
				xmlWriter.writeStartElement("StockIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getStockDividendsIncome().getAmount() != null ? iSD.getStockDividendsIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getStockDividendsIncome().getApplicability() != null ? iSD.getStockDividendsIncome().getApplicability() ? "Y" : "N" : null,
						false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getStockDividendsIncome().getFrequence() != null ? iSD.getStockDividendsIncome().getFrequence().getCode() : null, false,
						false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getStockDividendsIncome().getReceivingMethod() != null ? iSD.getStockDividendsIncome().getReceivingMethod().getCode()
						: null, false, false);
				xmlWriter.writeEndElement();
			}
			if (iSD.getTradeIncome() != null) {
				xmlWriter.writeStartElement("TradeIncome");
				marshallingHelper.createNode(xmlWriter, "IncomeAmt", iSD.getTradeIncome().getAmount() != null ? iSD.getTradeIncome().getAmount() + "" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "IsApplcble", iSD.getTradeIncome().getApplicability() != null ? iSD.getTradeIncome().getApplicability() ? "Y" : "N" : null, false, false);
				marshallingHelper.createNode(xmlWriter, "FreqIncome", iSD.getTradeIncome().getFrequence() != null ? iSD.getTradeIncome().getFrequence().getCode() : null, false, false);
				marshallingHelper.createNode(xmlWriter, "RcvMethodCode", iSD.getTradeIncome().getReceivingMethod() != null ? iSD.getTradeIncome().getReceivingMethod().getCode() : null, false, false);
				xmlWriter.writeEndElement();
			}
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			throw e;
		}
	}

	private void marshallingPostalAddrs(MarshallingHelper marshallingHelper, TadawulUser customer, XMLStreamWriter xmlWriter) throws XMLStreamException, MarshallingException {
		CustomerAddress homeAddress = null;
		homeAddress = customer.getCustomerEssentialInfo().getCustomerEssentialCoreInfo().getHomeAdrress();
		try {
			xmlWriter.writeStartElement("PostalAddrs");
			xmlWriter.writeStartElement("PostalAddr");
			marshallingHelper.createNode(xmlWriter, "Operation", "U", false, false);
			marshallingHelper.createNode(xmlWriter, "WASELNum", homeAddress.getAdditionalNumber() != null ? homeAddress.getAdditionalNumber() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "AddrLine1", homeAddress.getAddressLine1() != null ? homeAddress.getAddressLine1() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "AddrLine2", homeAddress.getAddressLine2() != null ? homeAddress.getAddressLine2() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "EffDt", homeAddress.getStartEffectiveDate() != null ? homeAddress.getStartEffectiveDate().getGregorianString() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "EffDtHjr", homeAddress.getStartEffectiveDate() != null ? homeAddress.getStartEffectiveDate().getHijriDate() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "ExpDt", homeAddress.getEndEffectiveDate() != null ? homeAddress.getEndEffectiveDate().getGregorianString() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "ExpDtHjr", homeAddress.getEndEffectiveDate() != null ? homeAddress.getEndEffectiveDate().getHijriDate() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "AddrInd", homeAddress.getAddressType() != null ? homeAddress.getAddressType().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "StreetNum", homeAddress.getBasicNumber() != null ? homeAddress.getBasicNumber() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "City", homeAddress.getCity() != null ? homeAddress.getCity() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "CountryCode", homeAddress.getCountry() != null ? homeAddress.getCountry().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "IsBadAddr", homeAddress.getBadAddress() != null ? homeAddress.getBadAddress() ? "Y" : "N" : null, false, false);
			marshallingHelper.createNode(xmlWriter, "Dist", homeAddress.getDistrict() != null ? homeAddress.getDistrict() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "WASELInternalMail", homeAddress.getInternalMail() != null ? homeAddress.getInternalMail() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "LangCode", homeAddress.getInformationLang() != null ? homeAddress.getInformationLang().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "LocDirctns", homeAddress.getLocationDirection() != null ? homeAddress.getLocationDirection() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "PostalAddrId", homeAddress.getSurrogateKey() != null ? homeAddress.getSurrogateKey().getKey() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "AddrType", AddressType.HOME.getCode() != null ? AddressType.HOME.getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "POBox", homeAddress.getPobox() != null ? homeAddress.getPobox() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "PostalCode", homeAddress.getPostalCode() != null ? homeAddress.getPostalCode() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "Rank", homeAddress.getRank() != null ? homeAddress.getRank().toString() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "State", homeAddress.getState() != null ? homeAddress.getState() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "Street", homeAddress.getStreet() != null ? homeAddress.getStreet() : null, false, true);
			marshallingHelper.createNode(xmlWriter, "UnitNum", homeAddress.getUnitNumber() != null ? homeAddress.getUnitNumber() : null, false, true);
			xmlWriter.writeEndElement();
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			throw e;
		}
	}

	/**
	 * Marshal the specified contact, with the specified address type.
	 * 
	 * @param contact
	 * @param addressType
	 */
	private void marshallingPartyInvestment(MarshallingHelper marshallingHelper, TadawulUser customer, XMLStreamWriter xmlWriter) throws XMLStreamException {
		InvestmentInfo investInfo = customer.getCustomerCapitalMarketAuthorityInfo().getInvestmentInfo();
		try {
			xmlWriter.writeStartElement("PartyInvstmnt");
			// if (investInfo.isUpdated("CommoditiesAmount"))
			marshallingHelper.createNode(xmlWriter, "CommdtsAmt", (investInfo.getCommoditiesAmount()) + "");
			// if (investInfo.isUpdated("ContractDiffAndOptAmount"))
			marshallingHelper.createNode(xmlWriter, "ContractDifOptionsAmt", investInfo.getContractDiffAndOptAmount() + "");
			// if (investInfo.isUpdated("DebitInstAmount"))
			marshallingHelper.createNode(xmlWriter, "DebitInstAmt", (investInfo.getDebitInstAmount()) + "");
			// if (investInfo.isUpdated("DepositsAmount"))
			marshallingHelper.createNode(xmlWriter, "DepsAmt", (investInfo.getDepositsAmount()) + "");
			// if (investInfo.isUpdated("ForeignExchangeAmount"))
			marshallingHelper.createNode(xmlWriter, "ForeignExAmt", (investInfo.getForeignExchangeAmount()) + "");
			// if (investInfo.isUpdated("InvestmentFundsAmount"))
			marshallingHelper.createNode(xmlWriter, "InvstmntFundsAmt", (investInfo.getInvestmentFundsAmount()) + "");
			// if (investInfo.isUpdated("RealEstateAmount"))
			marshallingHelper.createNode(xmlWriter, "RealEstateAmt", (investInfo.getRealEstateAmount()) + "");
			// if (investInfo.isUpdated("SharesAmount"))
			marshallingHelper.createNode(xmlWriter, "SharesAmt", (investInfo.getSharesAmount()) + "");
			// if (investInfo.isUpdated("TradeFinanceAmount"))
			marshallingHelper.createNode(xmlWriter, "TradeFinanceAmt", (investInfo.getTradeFinanceAmount()) + "");
			InvestmentAssets preferredInvestmentAssets = investInfo.getPreferredInvestmentAssets();
			if (preferredInvestmentAssets != null) {
				marshallingHelper.createNode(xmlWriter, "LclAsset", preferredInvestmentAssets.getSARInvestmentAsset() ? "Y" : "N");
				marshallingHelper.createNode(xmlWriter, "USDAsset", preferredInvestmentAssets.getUSDInvestmentAsset() ? "Y" : "N");
				marshallingHelper.createNode(xmlWriter, "EURAsset", preferredInvestmentAssets.getEUROInvestmentAsset() ? "Y" : "N");
				marshallingHelper.createNode(xmlWriter, "OtherAsset", preferredInvestmentAssets.getOtherInvestmentAsset() ? "Y" : "N");
				marshallingHelper.createNode(xmlWriter, "OtherAssetDesc", preferredInvestmentAssets.getOtherInvestmentAssetDesc());
			}
			RiskPercentage commoditiesRisk = investInfo.getCommoditiesRisk();
			if (commoditiesRisk != null) {
				marshallingHelper.createNode(xmlWriter, "HighRiskCommdtsPercen", (commoditiesRisk.getHigh() == null ? 0.0 : commoditiesRisk.getHigh()) + "");
				marshallingHelper.createNode(xmlWriter, "MedRiskCommdtsPercen", (commoditiesRisk.getMedium() == null ? 0.0 : commoditiesRisk.getMedium()) + "");
				marshallingHelper.createNode(xmlWriter, "LowRiskCommdtsPercen", (commoditiesRisk.getLow() == null ? 0.0 : commoditiesRisk.getLow()) + "");
			}
			RiskPercentage debitInstRisk = investInfo.getDebitInstRisk();
			if (debitInstRisk != null) {
				marshallingHelper.createNode(xmlWriter, "HighRiskDebitPercen", (debitInstRisk.getHigh() == null ? 0.0 : debitInstRisk.getHigh()) + "");
				marshallingHelper.createNode(xmlWriter, "MedRiskDebitPercen", (debitInstRisk.getMedium() == null ? 0.0 : debitInstRisk.getMedium()) + "");
				marshallingHelper.createNode(xmlWriter, "LowRiskDebitPercen", (debitInstRisk.getLow() == null ? 0.0 : debitInstRisk.getLow()) + "");
			}
			RiskPercentage investmentFundsRisk = investInfo.getInvestmentFundsRisk();
			if (investmentFundsRisk != null) {
				marshallingHelper.createNode(xmlWriter, "HighRiskInvstmntPercen", (investmentFundsRisk.getHigh() == null ? 0.0 : investmentFundsRisk.getHigh()) + "");
				marshallingHelper.createNode(xmlWriter, "MedRiskInvstmntPercen", (investmentFundsRisk.getMedium() == null ? 0.0 : investmentFundsRisk.getMedium()) + "");
				marshallingHelper.createNode(xmlWriter, "LowRiskInvstmntPercen", (investmentFundsRisk.getLow() == null ? 0.0 : investmentFundsRisk.getLow()) + "");
			}
			RiskPercentage optionsRisk = investInfo.getOptionsRisk();
			if (optionsRisk != null) {
				marshallingHelper.createNode(xmlWriter, "HighRiskOptionsPercen", (optionsRisk.getHigh() == null ? 0.0 : optionsRisk.getHigh()) + "");
				marshallingHelper.createNode(xmlWriter, "MedRiskOptionsPercen", (optionsRisk.getMedium() == null ? 0.0 : optionsRisk.getMedium()) + "");
				marshallingHelper.createNode(xmlWriter, "LowRiskOptionsPercen", (optionsRisk.getLow() == null ? 0.0 : optionsRisk.getLow()) + "");
			}
			RiskPercentage sharesRisk = investInfo.getSharesRisk();
			if (sharesRisk != null) {
				marshallingHelper.createNode(xmlWriter, "HighRiskSharesPercen", (sharesRisk.getHigh() == null ? 0.0 : sharesRisk.getHigh()) + "");
				marshallingHelper.createNode(xmlWriter, "MedRiskSharesPercen", (sharesRisk.getMedium() == null ? 0.0 : sharesRisk.getMedium()) + "");
				marshallingHelper.createNode(xmlWriter, "LowRiskSharesPercen", (sharesRisk.getLow() == null ? 0.0 : sharesRisk.getLow()) + "");
			}
			RiskPercentage tradeFinanceRisk = investInfo.getTradeFinanceRisk();
			if (tradeFinanceRisk != null) {
				marshallingHelper.createNode(xmlWriter, "HighRiskTradePercen", (tradeFinanceRisk.getHigh() == null ? 0.0 : tradeFinanceRisk.getHigh()) + "");
				marshallingHelper.createNode(xmlWriter, "MedRiskTradePercen", (tradeFinanceRisk.getMedium() == null ? 0.0 : tradeFinanceRisk.getMedium()) + "");
				marshallingHelper.createNode(xmlWriter, "LowRiskTradePercen", (tradeFinanceRisk.getLow() == null ? 0.0 : tradeFinanceRisk.getLow()) + "");
			}
			marshallingHelper.createNode(xmlWriter, "InvstmntObjctv", investInfo.getInvestmentObjective() != null ? investInfo.getInvestmentObjective().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "InvstmntRiskPref", investInfo.getInvestmentRisk() != null ? investInfo.getInvestmentRisk().getCode() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "OtherFinancialInfo", investInfo.getOtherFinancialInfo() != null ? investInfo.getOtherFinancialInfo() : null, false, false);
			marshallingHelper.createNode(xmlWriter, "InvstmntExperienceCode", investInfo.getInvestmentExperience() != null ? investInfo.getInvestmentExperience().getCode() : null, false, false);
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			throw e;
		}
	}
}
