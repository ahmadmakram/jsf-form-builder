package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.UserAuthenticationResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class UserAuthenticationUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new UserAuthenticationResMsg();
	}

	@Override
	public String getElementString() {
		return "UsrAuthentRs";
	}
}
