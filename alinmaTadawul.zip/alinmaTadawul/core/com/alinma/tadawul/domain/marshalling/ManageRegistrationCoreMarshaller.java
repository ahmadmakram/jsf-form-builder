package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.RegistrationInfo;
import com.alinma.tadawul.domain.messages.request.ManageRegistrationReqMsgCore;
import com.alinma.tadawul.services.dao.impl.RegistrationManageDAOImpl;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.lov.ChannelId;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class ManageRegistrationCoreMarshaller implements Marshaller {

	private static final String DEFAULT_ONLINE_ACTIVATION_METHOD = "O";

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		ManageRegistrationReqMsgCore manageRegistrationReqMsgCore = (ManageRegistrationReqMsgCore) obj;
		RegistrationInfo registrationInfo = manageRegistrationReqMsgCore.getRegistrationInfo();
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			String functionName = "";
			if (context != null && context.getAssociatedBOs() != null) {
				functionName = (String) context.getAssociatedBOs().get("FunctionName");
			}
			// if (!RegistrationManageDAOImpl.REGISTER_SUB_USER_FUNCTION
			// .equals(functionName)) {
			// marshallingHelper.createNode(xmlWriter, "ActvtnMethod",
			// DEFAULT_ONLINE_ACTIVATION_METHOD, false, false);
			// }
			if (!RegistrationManageDAOImpl.USER_ACTIVATION_FUNCTION.equals(functionName)) {
				marshallingCustIdentInfo(xmlWriter, registrationInfo, marshallingHelper, functionName);
			}
			marshallingUserInfo(xmlWriter, registrationInfo, marshallingHelper);
			marshallingChanRgstrtnInfo(xmlWriter, manageRegistrationReqMsgCore, marshallingHelper, functionName);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	private void marshallingChanRgstrtnInfo(XMLStreamWriter xmlWriter, ManageRegistrationReqMsgCore manageRegistrationReqMsgCore, MarshallingHelper marshallingHelper, String functionName)
			throws XMLStreamException {
		RegistrationInfo registrationInfo = manageRegistrationReqMsgCore.getRegistrationInfo();
		xmlWriter.writeStartElement("ChanRgstrtnInfo");
		marshallingHelper.createNode(xmlWriter, "ChanId", manageRegistrationReqMsgCore.getChannelId().getCode(), false, false);
		String chanelCode = registrationInfo.getTargetChannel().getCode();
		String loginName = manageRegistrationReqMsgCore.getRegistrationInfo().getUser().getChannelInfo(ChannelId.getByCode(chanelCode)).getUserCredential().getLoginName();
		if (RegistrationManageDAOImpl.USER_ACTIVATION_FUNCTION.equals(functionName)) {
			marshallingHelper.createNode(xmlWriter, "ActivationCode", manageRegistrationReqMsgCore.getRegistrationInfo().getActivationCode(), false, false);
			if (loginName != null) {
				marshallingHelper.createNode(xmlWriter, "LoginName",
						manageRegistrationReqMsgCore.getRegistrationInfo().getUser().getChannelInfo(ChannelId.getByCode(registrationInfo.getTargetChannel().getCode())).getUserCredential()
								.getLoginName(), false, false);
			}
			String password = manageRegistrationReqMsgCore.getRegistrationInfo().getUser().getChannelInfo(ChannelId.getByCode(chanelCode)).getUserCredential().getPassword();
			if (password != null) {
				marshallingHelper.createNode(xmlWriter, "ChanPswd",
						manageRegistrationReqMsgCore.getRegistrationInfo().getUser().getChannelInfo(ChannelId.getByCode(registrationInfo.getTargetChannel().getCode())).getUserCredential()
								.getPassword(), false, false);
			}
			marshallingHelper.createNode(xmlWriter, "ActivationCode", manageRegistrationReqMsgCore.getRegistrationInfo().getActivationCode(), false, false);
		}
		xmlWriter.writeEndElement();
	}

	private void marshallingCustIdentInfo(XMLStreamWriter xmlWriter, RegistrationInfo registrationInfo, MarshallingHelper marshallingHelper, String functionName) throws XMLStreamException {
		if (RegistrationManageDAOImpl.REGISTER_CUSTOMER_FUNCTION.equals(functionName)) {
			marshallingHelper.createNode(xmlWriter, "CustType", registrationInfo.getUser().getCustomerType().getCode(), false, false);
		}
		xmlWriter.writeStartElement("CustIdentInfo");
		marshallingHelper.createNode(xmlWriter, "AcctNum", registrationInfo.getAccount().getAccountNumber(), false, false);
		if (registrationInfo.getUser().getIdDocKey() != null && registrationInfo.getUser().getIdDocKey().getIdNumber() != null) {
			xmlWriter.writeStartElement("POI");
			marshallingHelper.createNode(xmlWriter, "POINum", registrationInfo.getUser().getIdDocKey().getIdNumber(), false, false);
			xmlWriter.writeEndElement();
		}
		xmlWriter.writeEndElement();
	}

	private void marshallingUserInfo(XMLStreamWriter xmlWriter, RegistrationInfo registrationInfo, MarshallingHelper marshallingHelper) throws XMLStreamException {
		String email = registrationInfo.getUser().getUserContact().getEmail();
		if (email != null && !(email.equals(""))) {
			xmlWriter.writeStartElement("UsrInfo");
			xmlWriter.writeStartElement("UsrContacts");
			marshallingHelper.createNode(xmlWriter, "Email", email, false, false);
			xmlWriter.writeEndElement();
			xmlWriter.writeEndElement();
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingArabicName(XMLStreamWriter xmlWriter, RegistrationInfo registrationInfo, MarshallingHelper marshallingHelper) throws XMLStreamException {
		xmlWriter.writeStartElement("UsrNameEn");
		marshallingHelper.createNode(xmlWriter, "FirstName", registrationInfo.getUser().getEnglishName().getFirstName(), false, false);
		marshallingHelper.createNode(xmlWriter, "FatherName", registrationInfo.getUser().getEnglishName().getSecondName(), false, false);
		marshallingHelper.createNode(xmlWriter, "FamilyName", registrationInfo.getUser().getEnglishName().getFamilyName(), false, false);
		xmlWriter.writeEndElement();
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingEnglishName(XMLStreamWriter xmlWriter, RegistrationInfo registrationInfo, MarshallingHelper marshallingHelper) throws XMLStreamException {
		xmlWriter.writeStartElement("UsrNameAr");
		marshallingHelper.createNode(xmlWriter, "FirstName", registrationInfo.getUser().getArabicName().getFirstName(), false, false);
		marshallingHelper.createNode(xmlWriter, "FatherName", registrationInfo.getUser().getArabicName().getSecondName(), false, false);
		marshallingHelper.createNode(xmlWriter, "FamilyName", registrationInfo.getUser().getArabicName().getFamilyName(), false, false);
		xmlWriter.writeEndElement();
	}
}
