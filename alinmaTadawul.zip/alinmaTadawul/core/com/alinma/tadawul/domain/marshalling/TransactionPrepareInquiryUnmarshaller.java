/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.TransactionPrepareInquiryResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class TransactionPrepareInquiryUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected TransactionPrepareInquiryResMsg createResponseMessage() {
		return new TransactionPrepareInquiryResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		return "TrnPrepRs";
	}
}
