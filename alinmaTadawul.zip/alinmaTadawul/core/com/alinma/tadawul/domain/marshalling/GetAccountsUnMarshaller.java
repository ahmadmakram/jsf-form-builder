/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.GetAccountsResMsg;
import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author mbrins
 * 
 */
public class GetAccountsUnMarshaller extends MsgUnmarshaller {

	@Override
	protected GetAccountsResMsg createResponseMessage() {
		return new GetAccountsResMsg();
	}

	@Override
	public String getElementString() {
		return "CustAcctsInqRs";
	}
}
