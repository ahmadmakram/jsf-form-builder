/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.ExchangeRateResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRateUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ExchangeRateResMsg createResponseMessage() {
		return new ExchangeRateResMsg();
	}

	@Override
	public String getElementString() {
		return "ExRateInqRs";
	}
}
