package com.alinma.tadawul.domain.marshalling;

import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.TransactionCredential;
import com.alinma.tadawul.domain.UserCredential;
import com.alinma.tadawul.domain.lov.LoginType;
import com.alinma.tadawul.domain.messages.request.UserAuthenticationReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.lov.SecurityInfoType;
import com.ejada.commons.exceptions.MarshallingException;

public class UserAuthenticationCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		UserAuthenticationReqMsgCore userAuthenticateReqMsgCore = (UserAuthenticationReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (context != null && context.getAssociatedBOs() != null && context.getAssociatedBOs().size() > 0) {
				String function = (String) context.getAssociatedBOs().get(String.class.getName());
				if (function != null && function.equals("transactionAuthenticate")) {
					List<TransactionCredential> credentialInfoList = userAuthenticateReqMsgCore.getCredentialInfoList();
					xmlWriter.writeStartElement("LoginId");
					marshallingHelper.createNode(xmlWriter, "LoginAttribVal", credentialInfoList.get(0).getUserId());
					marshallingHelper.createNode(xmlWriter, "LoginAttribType", LoginType.USER_ID.getCode());
					xmlWriter.writeEndElement();
					for (TransactionCredential transactionCredential : credentialInfoList) {
						xmlWriter.writeStartElement("Sec");
						marshallingHelper.createNode(xmlWriter, "Info", transactionCredential.getValue());
						marshallingHelper.createNode(xmlWriter, "InfoType", transactionCredential.getType().getCode());
						xmlWriter.writeEndElement();
					}
				} else if (function != null && function.equals("authenticateUser")) {
					marshalLoginId(marshallingHelper, xmlWriter, userAuthenticateReqMsgCore.getUserCredential());
					marshalSec(marshallingHelper, xmlWriter, userAuthenticateReqMsgCore.getUserCredential());
				}
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}

	private void marshalLoginId(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, UserCredential userCredential) throws XMLStreamException {
		xmlWriter.writeStartElement("LoginId");
		marshallingHelper.createNode(xmlWriter, "LoginAttribVal", userCredential.getLoginName());// TODO should be mail
		marshallingHelper.createNode(xmlWriter, "LoginAttribType", LoginType.LOGIN_NAME.getCode());
		xmlWriter.writeEndElement();
	}

	private void marshalSec(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, UserCredential userCredential) throws XMLStreamException {
		xmlWriter.writeStartElement("Sec");
		marshallingHelper.createNode(xmlWriter, "Info", userCredential.getPassword());
		marshallingHelper.createNode(xmlWriter, "InfoType", SecurityInfoType.PASSWORD.getCode());
		xmlWriter.writeEndElement();
	}
}
