/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;
import com.alinma.tadawul.domain.RegistrationInfo;
import com.alinma.tadawul.domain.messages.request.GetUserLimitsReqMsgCore;

/**
 * @author Hani Younis
 * 
 */
public class GetUserLimitsCoreMarshaller implements Marshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Marshaller#marshal(javax. xml.stream.XMLStreamWriter, java.lang.Object, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetUserLimitsReqMsgCore userLimitsReqMsgCore = (GetUserLimitsReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingUserLimitsInfo(xmlWriter, userLimitsReqMsgCore, marshallingHelper);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingUserLimitsInfo(XMLStreamWriter xmlWriter, GetUserLimitsReqMsgCore userLimitsReqMsgCore, MarshallingHelper marshallingHelper) throws XMLStreamException {
		marshallingHelper.createNode(xmlWriter, "UsrId", userLimitsReqMsgCore.getSubUserId(), false, false);
		marshallingHelper.createNode(xmlWriter, "ChanId", userLimitsReqMsgCore.getChannelId().getCode(), false, false);
		marshallingHelper.createNode(xmlWriter, "FuncGrpId", userLimitsReqMsgCore.getFunctionGroup() != null ? userLimitsReqMsgCore.getFunctionGroup().getCode() : null, false, false);
		marshallingHelper.createNode(xmlWriter, "CurGrpId", userLimitsReqMsgCore.getCurrencyGroup().getCode(), false, false);
		// TODO send 3 dimen
		marshallingHelper.createNode(xmlWriter, "Dimen", userLimitsReqMsgCore.getLimitsDimensions()[0], false, false);
		marshallingHelper.createNode(xmlWriter, "Dimen", userLimitsReqMsgCore.getLimitsDimensions()[1], false, false);
		if (userLimitsReqMsgCore.getPaginationIn() != null) {
			marshallingHelper.createNode(xmlWriter, "Dimen", userLimitsReqMsgCore.getLimitsDimensions()[2], false, false);
			xmlWriter.writeStartElement("RecCtrlIn");
			marshallingHelper.createNode(xmlWriter, "MaxRecs", userLimitsReqMsgCore.getPaginationIn().getPageSize().toString(), false, false);
			marshallingHelper.createNode(xmlWriter, "Offset", userLimitsReqMsgCore.getPaginationIn().getPageOffset().toString(), false, false);
			xmlWriter.writeEndElement();
		}
	}
}
