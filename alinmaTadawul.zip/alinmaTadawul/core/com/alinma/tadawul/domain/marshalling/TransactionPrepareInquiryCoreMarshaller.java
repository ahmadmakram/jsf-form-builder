/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.TransactionPrepareInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Mahmoud AL Selwadi
 * 
 */
public class TransactionPrepareInquiryCoreMarshaller implements Marshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Marshaller#marshal(javax. xml.stream.XMLStreamWriter, java.lang.Object, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		TransactionPrepareInquiryReqMsgCore transactionPrepareInquiryReqMsgCore = (TransactionPrepareInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingTransactionPrepareInquiry(xmlWriter, transactionPrepareInquiryReqMsgCore, marshallingHelper);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingTransactionPrepareInquiry(XMLStreamWriter xmlWriter, TransactionPrepareInquiryReqMsgCore transactionPrepareInquiryReqMsgCore, MarshallingHelper marshallingHelper)
			throws XMLStreamException {
		marshallingHelper.createNode(xmlWriter, "FuncId", transactionPrepareInquiryReqMsgCore.getFuncId(), false, false);
		for (String exRateDimen : transactionPrepareInquiryReqMsgCore.getExRateDimen()) {
			if (exRateDimen != null) {
				marshallingHelper.createNode(xmlWriter, "ExRateDimen", exRateDimen, false, false);
			}
		}
		for (String feeDimen : transactionPrepareInquiryReqMsgCore.getFeeDimen()) {
			if (feeDimen != null) {
				marshallingHelper.createNode(xmlWriter, "FeeDimen", feeDimen, false, false);
			}
		}
		for (String authentMethodDimen : transactionPrepareInquiryReqMsgCore.getAuthentMethodDimen()) {
			if (authentMethodDimen != null) {
				marshallingHelper.createNode(xmlWriter, "AuthentMethodDimen", authentMethodDimen, false, false);
			}
		}
		xmlWriter.writeStartElement("SrcCurAmt");
		marshallingHelper.createNode(xmlWriter, "Amt", transactionPrepareInquiryReqMsgCore.getSourceCurrencyAmount().getAmount(), false, false);
		marshallingHelper.createNode(xmlWriter, "CurCode", transactionPrepareInquiryReqMsgCore.getSourceCurrencyAmount().getCurrencyCode().getCode(), false, false);
		xmlWriter.writeEndElement();
		xmlWriter.writeStartElement("TargCurAmt");
		if (transactionPrepareInquiryReqMsgCore.getTargetCurrencyAmount() != null && transactionPrepareInquiryReqMsgCore.getTargetCurrencyAmount().getAmount() != null)
			marshallingHelper.createNode(xmlWriter, "Amt", transactionPrepareInquiryReqMsgCore.getTargetCurrencyAmount().getAmount(), false, false);
		if (transactionPrepareInquiryReqMsgCore.getTargetCurrencyAmount() != null && transactionPrepareInquiryReqMsgCore.getTargetCurrencyAmount().getCurrencyCode() != null)
			marshallingHelper.createNode(xmlWriter, "CurCode", transactionPrepareInquiryReqMsgCore.getTargetCurrencyAmount().getCurrencyCode().getCode(), false, false);
		xmlWriter.writeEndElement();
	}
}
