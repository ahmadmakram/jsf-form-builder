/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Fee;
import com.alinma.tadawul.domain.FunctionAuthentMethod;
import com.alinma.tadawul.domain.lov.AuthenticationDisabledReason;
import com.alinma.tadawul.domain.lov.AuthenticationStatus;
import com.alinma.tadawul.domain.lov.FeeCategory;
import com.alinma.tadawul.domain.lov.FeeCode;
import com.alinma.tadawul.domain.lov.NotificationMethodType;
import com.alinma.tadawul.domain.messages.response.TransactionPrepareInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.lov.SecurityInfoType;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Mahmoud AL SElwadi
 * 
 */
public class TransactionPrepareInquiryCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString ()
	 */
	public String getElementString() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax .xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		TransactionPrepareInquiryResMsgCore msgCore = new TransactionPrepareInquiryResMsgCore();
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			msgCore.getSourceAmount().setAmount(msgParsed.get("SrcCurAmt/Amt"));
			msgCore.getSourceAmount().setCurrencyCode(new EntityDefaultKey(msgParsed.get("SrcCurAmt/CurCode")));
			msgCore.getSourceAmount().setCurrencyRate(msgParsed.get("SrcCurAmt/CurRate"));
			if (msgParsed.get("SrcCurAmt/AmtLcl") != null) {
				msgCore.getSourceAmount().setLocalAmount(msgParsed.get("SrcCurAmt/AmtLcl"));
			}
			msgCore.getTargetAmount().setAmount(msgParsed.get("TargCurAmt/Amt"));
			msgCore.getTargetAmount().setCurrencyCode(new EntityDefaultKey(msgParsed.get("TargCurAmt/CurCode")));
			msgCore.getTargetAmount().setCurrencyRate(msgParsed.get("TargCurAmt/CurRate"));
			if (msgParsed.get("TargCurAmt/AmtLcl") != null) {
				msgCore.getTargetAmount().setLocalAmount(msgParsed.get("TargCurAmt/AmtLcl"));
			}
			String repetition = "FeesList/FeeInfo/";
			int i = 1;
			Fee fee;
			List<Fee> feeList = msgCore.getFees();
			while (msgParsed.get(repetition + "FeeCategory") != null) {
				fee = new Fee();
				fee.getFeeDimen()[0] = msgParsed.get(repetition + "Dimen");
				fee.getFeeDimen()[1] = msgParsed.get(repetition + "Dimen[1]");
				fee.getFeeDimen()[2] = msgParsed.get(repetition + "Dimen[2]");
				fee.setCategory(FeeCategory.getByCode(msgParsed.get(repetition + "FeeCategory")));
				if (msgParsed.get(repetition + "FeeCode") != null) {
					fee.setCode(FeeCode.getByCode(msgParsed.get(repetition + "FeeCode")));
				}
				if (msgParsed.get(repetition + "FeeType") != null) {
					fee.setType(msgParsed.get(repetition + "FeeType"));
				}
				fee.getFeeAmount().setAmount(msgParsed.get(repetition + "CurAmt/Amt"));
				if (msgParsed.get(repetition + "CurAmt/CurCode") != null) {
					fee.getFeeAmount().setCurrencyCode(new EntityDefaultKey(msgParsed.get(repetition + "CurAmt/CurCode")));
				}
				fee.getFeeAmount().setLocalAmount(msgParsed.get(repetition + "CurAmt/AmtLcl"));
				feeList.add(fee);
				repetition = "FeesList/FeeInfo[" + i + "]/";
				i++;
			}
			repetition = "AuthentMethodsList/AuthentMethodInfo/";
			i = 1;
			FunctionAuthentMethod functionAuthentMethod;
			List<FunctionAuthentMethod> functionAuthentMethodList = msgCore.getFunctionAuthentMethods();
			while (msgParsed.get(repetition + "AuthentType") != null) {
				functionAuthentMethod = new FunctionAuthentMethod();
				if (msgParsed.get(repetition + "AuthentType") != null) {
					functionAuthentMethod.setSecurityInfoType(SecurityInfoType.getByCode(msgParsed.get(repetition + "AuthentType")));
				}
				if (msgParsed.get(repetition + "AuthentStatus") != null) {
					functionAuthentMethod.setAuthenticationStatus(AuthenticationStatus.getByCode(msgParsed.get(repetition + "AuthentStatus")));
				}
				if (msgParsed.get(repetition + "AuthentDisabledReason") != null) {
					functionAuthentMethod.setAuthenticationDisabledReason(AuthenticationDisabledReason.getByCode(msgParsed.get(repetition + "AuthentDisabledReason")));
				}
				if (msgParsed.get(repetition + "AuthenrGrpNum") != null) {
					functionAuthentMethod.setAuthenticationGroupNumber(msgParsed.get(repetition + "AuthenrGrpNum"));
				}
				if (msgParsed.get(repetition + "NotificationMethod") != null) {
					functionAuthentMethod.setNotificationMethodType(NotificationMethodType.getByLabel(msgParsed.get(repetition + "NotificationMethod")));
				}
				functionAuthentMethodList.add(functionAuthentMethod);
				repetition = "AuthentMethodsList/AuthentMethodInfo[" + i + "]/";
				i++;
			}
			ResponseMessageBody<TransactionPrepareInquiryResMsgCore> msgResBody = new ResponseMessageBody<TransactionPrepareInquiryResMsgCore>();
			msgResBody.setBodyCore(msgCore);
			msgCore.setFunctionAuthentMethods(functionAuthentMethodList);
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
	}
}
