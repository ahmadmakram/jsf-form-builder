/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Fee;
import com.alinma.tadawul.domain.messages.response.FundTransferResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Mahmoud AL SElwadi
 * 
 */
public class FundTransferCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString ()
	 */
	public String getElementString() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax .xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		FundTransferResMsgCore msgCore = new FundTransferResMsgCore();
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			if (msgParsed.get("CurrBal") != null) {
				msgCore.getCurrentBalance().setAmount(msgParsed.get("CurrBal"));
			}
			if (msgParsed.get("CustLimit/MinLimit") != null) {
				msgCore.getCustomerlimit().getMinimumLimit().setAmount(msgParsed.get("CustLimit/MinLimit"));
				msgCore.getCustomerlimit().getUsageAmount().setAmount(msgParsed.get("CustLimit/UsageAmt"));
				msgCore.getCustomerlimit().getAvailableLimit().setAmount(msgParsed.get("CustLimit/AvailLimit"));
				msgCore.getCustomerlimit().setNumOftrans(msgParsed.get("CustLimit/NumOfRecs"));
			}
			if (msgParsed.get("CustLimit/STPMinLimit") != null) {
				msgCore.getCustomerlimit().getStpMinimumLimit().setAmount(msgParsed.get("CustLimit/STPMinLimit"));
			}
			if (msgParsed.get("CustLimit/STPAvailLimit") != null) {
				msgCore.getCustomerlimit().getStpAvailableLimit().setAmount(msgParsed.get("CustLimit/STPAvailLimit"));
			}
			if (msgParsed.get("AmtDebited/Amt") != null) {
				msgCore.getAmountDebited().setAmount(msgParsed.get("AmtDebited/Amt"));
				msgCore.getAmountDebited().setLocalAmount(msgParsed.get("AmtDebited/AmtLcl"));
			}
			if (msgParsed.get("AmtCredited/Amt") != null) {
				msgCore.getAmountCredited().setAmount(msgParsed.get("AmtCredited/Amt"));
				msgCore.getAmountCredited().setLocalAmount(msgParsed.get("AmtCredited/AmtLcl"));
			}
			if (msgParsed.get("ExRate") != null) {
				msgCore.setExchangeRate(msgParsed.get("ExRate"));
			}
			if (msgParsed.get("StmtEntryId") != null) {
				msgCore.setStatementEntryId(msgParsed.get("StmtEntryId"));
			}
			String repetition = "FeesList/FeeInfo/";
			int i = 1;
			Fee fee;
			List<Fee> feeList = msgCore.getFeeList();
			while (msgParsed.get(repetition + "FeeCategory") != null) {
				fee = new Fee();
				fee.getFeeAmount().setAmount(msgParsed.get(repetition + "CurAmt/Amt"));
				if (msgParsed.get(repetition + "CurAmt/CurCode") != null) {
					fee.getFeeAmount().setCurrencyCode(new EntityDefaultKey(msgParsed.get(repetition + "CurAmt/CurCode")));
				}
				if (msgParsed.get(repetition + "CurAmt/AmtLcl") != null) {
					fee.getFeeAmount().setLocalAmount(msgParsed.get(repetition + "CurAmt/AmtLcl"));
				}
				feeList.add(fee);
				repetition = "FeesList/FeeInfo[" + i + "]/";
				i++;
			}
			ResponseMessageBody<FundTransferResMsgCore> msgResBody = new ResponseMessageBody<FundTransferResMsgCore>();
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
	}
}
