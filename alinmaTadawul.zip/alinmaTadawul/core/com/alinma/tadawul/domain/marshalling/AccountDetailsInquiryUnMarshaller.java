package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.AccountDetailsInquiryResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class AccountDetailsInquiryUnMarshaller extends MsgUnmarshaller {

	@Override
	protected AccountDetailsInquiryResMsg createResponseMessage() {
		return new AccountDetailsInquiryResMsg();
	}

	@Override
	public String getElementString() {
		return "CustAcctDtlsInqRs";
	}
}
