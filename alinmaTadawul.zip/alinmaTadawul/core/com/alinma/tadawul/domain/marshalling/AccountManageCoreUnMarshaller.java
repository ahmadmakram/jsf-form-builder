package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.messages.response.AccountManageResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class AccountManageCoreUnMarshaller implements Unmarshaller {

	@Override
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		AccountManageResMsgCore msgCore = new AccountManageResMsgCore();
		ResponseMessageBody<AccountManageResMsgCore> msgResBody = null;
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			Account account = new Account();
			account.setAccountNumber((msgParsed.get("AcctId/AcctNum")));
			msgResBody = new ResponseMessageBody<AccountManageResMsgCore>();
			msgCore.setAccount(account);
			msgResBody.setBodyCore(msgCore);
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		return msgResBody;
	}

	@Override
	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
