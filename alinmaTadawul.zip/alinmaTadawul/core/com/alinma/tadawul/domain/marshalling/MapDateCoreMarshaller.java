/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;
import com.alinma.tadawul.domain.lov.DateMappingType;
import com.alinma.tadawul.domain.messages.request.DateMappingReqMsgCore;

/**
 * @author M. Ali Hammam
 * 
 */
public class MapDateCoreMarshaller implements Marshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Marshaller#marshal(javax.xml.stream.XMLStreamWriter, java.lang.Object, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		DateMappingReqMsgCore dateMappingReqMsgCore = (DateMappingReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			xmlWriter.writeStartElement("DataMapngsList");
			marshalDates(marshallingHelper, xmlWriter, dateMappingReqMsgCore.getDateMapping(), dateMappingReqMsgCore.getDateMappingType());
			xmlWriter.writeEndElement();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			throw new MarshallingException(e.getMessage());
		}
	}

	private void marshalDates(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, List<String> dates, DateMappingType dateMappingType) throws XMLStreamException {
		if (dates == null || dates.isEmpty()) {
			;// TODO throw some kind of exception
		}
		for (int i = 0; i < dates.size(); i++) {
			xmlWriter.writeStartElement("DataMapngInfo");
			marshallingHelper.createNode(xmlWriter, "MapngId", dateMappingType.getCode());
			if (dates.get(i) != null) {
				marshallingHelper.createNode(xmlWriter, "MapngVal", dates.get(i).replace("-", ""));
			}
			xmlWriter.writeEndElement();
		}
	}
}
