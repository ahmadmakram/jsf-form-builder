package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.GetRetainedMsgDetailsInquiryResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class RetainedMsgDetailsInquiryUnmarshaller extends MsgUnmarshaller {

	@Override
	protected GetRetainedMsgDetailsInquiryResMsg createResponseMessage() {
		return new GetRetainedMsgDetailsInquiryResMsg();
	}

	@Override
	public String getElementString() {
		return "RetainedMsgDtlsInqRs";
	}
}
