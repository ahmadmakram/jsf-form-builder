package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.AccountManageReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class AccountManageCoreMarshaller implements Marshaller {

	@Override
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		if (obj == null) {
			return;
		}
		AccountManageReqMsgCore accountManageReqMsgCore = (AccountManageReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "AcctCategory", accountManageReqMsgCore.getAccountCategory().getCode());
			marshallingHelper.createNode(xmlWriter, "AcctCur", accountManageReqMsgCore.getAccountCurrency());
			marshallingHelper.createNode(xmlWriter, "AcctName", accountManageReqMsgCore.getAccountName());
			marshallingHelper.createNode(xmlWriter, "BranchId", accountManageReqMsgCore.getBranchId().getCode());
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}
}
