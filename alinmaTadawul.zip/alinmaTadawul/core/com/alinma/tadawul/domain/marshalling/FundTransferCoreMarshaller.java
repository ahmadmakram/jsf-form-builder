/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.Fee;
import com.alinma.tadawul.domain.lov.ServiceFunctionsEnum;
import com.alinma.tadawul.domain.messages.request.FundTransferReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Mahmoud AL Selwadi
 * 
 */
public class FundTransferCoreMarshaller implements Marshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Marshaller#marshal(javax. xml.stream.XMLStreamWriter, java.lang.Object, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		FundTransferReqMsgCore fundTransferReqMsgCore = (FundTransferReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			String functionName = "";
			if (context != null && context.getAssociatedBOs() != null) {
				functionName = (String) context.getAssociatedBOs().get("FunctionName");
			}
			marshallingFundTransferSource(xmlWriter, fundTransferReqMsgCore, marshallingHelper);
			marshallingFundTransferTarget(xmlWriter, fundTransferReqMsgCore, marshallingHelper, functionName);
			marshallingFundTransferFeeInfo(xmlWriter, fundTransferReqMsgCore, marshallingHelper, functionName);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingFundTransferSource(XMLStreamWriter xmlWriter, FundTransferReqMsgCore fundTransferReqMsgCore, MarshallingHelper marshallingHelper) throws XMLStreamException {
		xmlWriter.writeStartElement("Src");
		xmlWriter.writeStartElement("AcctId");
		marshallingHelper.createNode(xmlWriter, "AcctNum", fundTransferReqMsgCore.getSourceAccount().getAccountNumber(), false, false);
		if (fundTransferReqMsgCore.getSourceAccount().getAccountType() != null) {
			marshallingHelper.createNode(xmlWriter, "AcctType", fundTransferReqMsgCore.getSourceAccount().getAccountType().getCode(), false, false);
		}
		xmlWriter.writeEndElement();
		if (fundTransferReqMsgCore.getSourceAmount().getCurrencyCode().getCode().equalsIgnoreCase(fundTransferReqMsgCore.getCurCode())) {
			if (fundTransferReqMsgCore.getSourceAmount() != null) {
				xmlWriter.writeStartElement("CurAmt");
				marshallingHelper.createNode(xmlWriter, "Amt", fundTransferReqMsgCore.getSourceAmount().getAmount(), false, false);
				if (fundTransferReqMsgCore.getSourceAmount().getCurrencyCode() != null) {
					marshallingHelper.createNode(xmlWriter, "CurCode", fundTransferReqMsgCore.getSourceAmount().getCurrencyCode().getCode(), false, false);
				}
				if (fundTransferReqMsgCore.getSourceAmount().getCurrencyRate() != null) {
					marshallingHelper.createNode(xmlWriter, "CurRate", fundTransferReqMsgCore.getSourceAmount().getCurrencyRate(), false, false);
				}
				if (fundTransferReqMsgCore.getSourceAmount().getLocalAmount() != null) {
					marshallingHelper.createNode(xmlWriter, "AmtLcl", fundTransferReqMsgCore.getSourceAmount().getLocalAmount(), false, false);
				}
				xmlWriter.writeEndElement();
			}
		}
		if (fundTransferReqMsgCore.getSourceTrnDesc() != null) {
			marshallingHelper.createNode(xmlWriter, "TrnDesc", fundTransferReqMsgCore.getSourceTrnDesc(), false, false);
		}
		xmlWriter.writeEndElement();
	}

	private void marshallingFundTransferTarget(XMLStreamWriter xmlWriter, FundTransferReqMsgCore fundTransferReqMsgCore, MarshallingHelper marshallingHelper, String functionName)
			throws XMLStreamException {
		xmlWriter.writeStartElement("Targ");
		if (ServiceFunctionsEnum.transferToBeneficiaryInsideBank.name().equals(functionName) || ServiceFunctionsEnum.transferToBeneficiaryInsideKsaViaSarie.name().equals(functionName)) {
			marshallingHelper.createNode(xmlWriter, "BenCode", fundTransferReqMsgCore.getBeneficiary().getCode(), false, false);
		}
		if (ServiceFunctionsEnum.transferBetweenCustomerAccounts.name().equals(functionName)) {
			xmlWriter.writeStartElement("AcctId");
			marshallingHelper.createNode(xmlWriter, "AcctNum", fundTransferReqMsgCore.getTargetAccount().getAccountNumber(), false, false);
			if (fundTransferReqMsgCore.getTargetAccount().getAccountType() != null) {
				marshallingHelper.createNode(xmlWriter, "AcctType", fundTransferReqMsgCore.getTargetAccount().getAccountType().getCode(), false, false);
			}
			xmlWriter.writeEndElement();
		}
		xmlWriter.writeEndElement();
	}

	private void marshallingFundTransferFeeInfo(XMLStreamWriter xmlWriter, FundTransferReqMsgCore fundTransferReqMsgCore, MarshallingHelper marshallingHelper, String functionName)
			throws XMLStreamException {
		if (fundTransferReqMsgCore.getFundTransferPurpose() != null) {
			marshallingHelper.createNode(xmlWriter, "FundXferPurpose", fundTransferReqMsgCore.getFundTransferPurpose().getCode(), false, false);
		}
		for (String pmtDesc : fundTransferReqMsgCore.getPaymentDesc()) {
			if (pmtDesc != null) {
				marshallingHelper.createNode(xmlWriter, "PmtDesc", pmtDesc, false, false);
			}
		}
		if (fundTransferReqMsgCore.getMemo() != null) {
			marshallingHelper.createNode(xmlWriter, "Memo", fundTransferReqMsgCore.getMemo(), false, false);
		}
		if (ServiceFunctionsEnum.transferToBeneficiaryInsideKsaViaSarie.name().equals(functionName)) {
			xmlWriter.writeStartElement("FeeInfo");
			for (Fee fee : fundTransferReqMsgCore.getFeeList()) {
				for (String dimen : fee.getFeeDimen()) {
					if (dimen != null) {
						marshallingHelper.createNode(xmlWriter, "Dimen", dimen, false, false);
					}
				}
				marshallingHelper.createNode(xmlWriter, "FeeCategory", fee.getCategory().getCode(), false, false);
				if (fee.getCode() != null) {
					marshallingHelper.createNode(xmlWriter, "FeeCode", fee.getCode().getCode(), false, false);
				}
				if (fee.getType() != null) {
					marshallingHelper.createNode(xmlWriter, "FeeType", fee.getType(), false, false);
				}
				if (fee.getFeeAmount() != null) {
					xmlWriter.writeStartElement("CurAmt");
					if (fee.getFeeAmount().getAmount() != null) {
						marshallingHelper.createNode(xmlWriter, "Amt", fee.getFeeAmount().getAmount(), false, false);
					}
					if (fee.getFeeAmount().getCurrencyCode() != null) {
						marshallingHelper.createNode(xmlWriter, "CurCode", fee.getFeeAmount().getCurrencyCode().getCode(), false, false);
					}
					xmlWriter.writeEndElement();
				}
			}
			xmlWriter.writeEndElement();
		}
	}
}
