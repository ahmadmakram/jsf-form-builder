package com.alinma.tadawul.domain.marshalling;

import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.Card;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.lov.BackendGroups;
import com.alinma.tadawul.domain.messages.request.GetCustomerDetailsReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.IdDocKey;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class GetCustomerDetailsCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetCustomerDetailsReqMsgCore getCustomerDetailsReqMsgCore = (GetCustomerDetailsReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshalBackedGroups(marshallingHelper, xmlWriter, getCustomerDetailsReqMsgCore.getRequiredBackendGroups());
			marshalCustomerId(marshallingHelper, xmlWriter, getCustomerDetailsReqMsgCore.getUser());
			marshalAccountId(marshallingHelper, xmlWriter, getCustomerDetailsReqMsgCore.getUser().getDefaultAccount());
			marshalIdDockey(marshallingHelper, xmlWriter, getCustomerDetailsReqMsgCore.getUser().getIdDocKey());
			marshalCard(marshallingHelper, xmlWriter, getCustomerDetailsReqMsgCore.getCard());
		} catch (XMLStreamException e) {
			throw new MarshallingException(e.getMessage());
		}
	}

	private void marshalAccountId(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, Account account) throws XMLStreamException, MarshallingException {
		if (account != null && account.getAccountNumber() != null) {
			xmlWriter.writeStartElement("AcctId");
			marshallingHelper.createNode(xmlWriter, "AcctNum", account.getAccountNumber());
			if (account.getAccountType() != null) {
				marshallingHelper.createNode(xmlWriter, "AcctType", account.getAccountType().getCode(), false, false);
			}
			xmlWriter.writeEndElement();
		}
	}

	private void marshalBackedGroups(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, List<BackendGroups> groups) throws XMLStreamException {
		if (groups == null || groups.size() == 0) {
			return;
		}
		xmlWriter.writeStartElement("Ctrl");
		if (groups.contains(BackendGroups.PARTY_BASIC)) {
			marshallingHelper.createNode(xmlWriter, "ReturnPartyBasic", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_DETAILS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnPartyDtls", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_ALT_NAMES)) {
			marshallingHelper.createNode(xmlWriter, "ReturnAltNames", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_RM_NOTES)) {
			marshallingHelper.createNode(xmlWriter, "ReturnRMNotes", "Y");
		}
		if (groups.contains(BackendGroups.IDENTIFICATIONS_DOCS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnIdents", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_POSTAL_ADDRESSES)) {
			marshallingHelper.createNode(xmlWriter, "ReturnPostalAddrs", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_ELECTRONIC_ADDRESSES)) {
			marshallingHelper.createNode(xmlWriter, "ReturnElecAddrs", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_RELATIONS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnPartyRels", "Y");
		}
		if (groups.contains(BackendGroups.CROSS_REFS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnCrossRefs", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_SEGMENT)) {
			marshallingHelper.createNode(xmlWriter, "ReturnSegments", "Y");
		}
		if (groups.contains(BackendGroups.SELECTED_PRODUCTS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnProductsSel", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_EMRGS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnPartyEmrgs", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_DPNDNTS)) {
			marshallingHelper.createNode(xmlWriter, "ReturnPartyDpndnts", "Y");
		}
		if (groups.contains(BackendGroups.PARTY_INVESTMENT)) {
			marshallingHelper.createNode(xmlWriter, "ReturnInvestment", "Y");
		}
		xmlWriter.writeEndElement();
	}

	private void marshalCustomerId(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, TadawulUser user) throws XMLStreamException, MarshallingException {
		if (user == null) {
			return;
		}
		if (user != null && user.getAlinmaId() != null) {
			marshallingHelper.createNode(xmlWriter, "AlinmaId", user.getAlinmaId());
		}
		// marshallingHelper.createNode(xmlWriter, "PartyId", user.getPartyId());
		// if (user.getCif() != null) {
		// xmlWriter.writeStartElement("CrossRef");
		// if(user.getSystemId() != null) {
		// marshallingHelper.createNode(xmlWriter, "SysId", user.getSystemId().getCode());
		// }
		// marshallingHelper.createNode(xmlWriter, "SysCIF", user.getCif());
		// xmlWriter.writeEndElement();
		// }
	}

	private void marshalIdDockey(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, IdDocKey idDocKey) throws XMLStreamException, MarshallingException {
		if (idDocKey != null && idDocKey.getIdNumber() != null) {
			xmlWriter.writeStartElement("Ident");
			marshallingHelper.createNode(xmlWriter, "IdentDoc", idDocKey.getIdNumber());
			if (idDocKey.getIdDocType() != null) {
				marshallingHelper.createNode(xmlWriter, "IdentDocType", idDocKey.getIdDocType().getCode(), false, false);
			}
			xmlWriter.writeEndElement();
		}
	}

	private void marshalCard(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, Card card) throws XMLStreamException, MarshallingException {
		if (card != null && card.getCardNumber() != null) {
			xmlWriter.writeStartElement("AcctId");
			marshallingHelper.createNode(xmlWriter, "AcctNum", card.getCardNumber());
			xmlWriter.writeEndElement();
		}
	}
}
