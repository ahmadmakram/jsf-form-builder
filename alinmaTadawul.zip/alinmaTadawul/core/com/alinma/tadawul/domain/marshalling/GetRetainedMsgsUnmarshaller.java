package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.GetRetainedMsgsResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class GetRetainedMsgsUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new GetRetainedMsgsResMsg();
	}

	@Override
	public String getElementString() {
		return "RetainedMsgsInqRs";
	}
}
