package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.MobileInfo;
import com.alinma.tadawul.domain.RegistrationInfo;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.UserContact;
import com.alinma.tadawul.domain.messages.response.CustomerIdentificationResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.Name;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class CustomerIdentificationCoreUnMarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		ResponseMessageBody<CustomerIdentificationResMsgCore> msgResBody = new ResponseMessageBody<CustomerIdentificationResMsgCore>();
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			TadawulUser iBRUser = new TadawulUser();
			Name name = new Name();
			MobileInfo mobileInfo = new MobileInfo();
			UserContact userContact = new UserContact();
			if (msgParsed.get("CIF") != null) {
				iBRUser.setCif(msgParsed.get("CIF"));
			}
			if (msgParsed.get("AlinmaId") != null) {
				iBRUser.setAlinmaId(msgParsed.get("AlinmaId"));
			}
			if (msgParsed.get("FirstName") != null) {
				name.setFirstName((msgParsed.get("FirstName")));
			}
			if (msgParsed.get("FatherName") != null) {
				name.setFirstName((msgParsed.get("FatherName")));
			}
			if (msgParsed.get("FamilyName") != null) {
				name.setFirstName((msgParsed.get("FamilyName")));
			}
			if (msgParsed.get("LangPref") != null) {
				iBRUser.getInternetChannelInfo().setPreferredLang(new EntityDefaultKey(msgParsed.get("LangPref")));
			}
			if (msgParsed.get("Segment") != null) {
				iBRUser.setSegment(new EntityDefaultKey(msgParsed.get("Segment")));
			}
			if (msgParsed.get("MobileNum") != null) {
				mobileInfo.setMobileNumber((msgParsed.get("MobileNum")));
			}
			if (msgParsed.get("Email") != null) {
				userContact.setEmail((msgParsed.get("Email")));
			}
			CustomerIdentificationResMsgCore msgCore = new CustomerIdentificationResMsgCore();
			msgResBody.setBodyCore(msgCore);
			RegistrationInfo registrationInfo = new RegistrationInfo();
			registrationInfo.setUser(iBRUser);
			registrationInfo.getUser().getUserContact().setMobile(mobileInfo);
			registrationInfo.getUser().setEnglishName(name);
			msgCore.setRegistrationInfo(registrationInfo);
			msgResBody.setBodyCore(msgCore);
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		return msgResBody;
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
