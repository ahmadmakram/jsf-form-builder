/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.ExchangeRateReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRateCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		ExchangeRateReqMsgCore exchangeRateReqMsgCore = (ExchangeRateReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (exchangeRateReqMsgCore == null) {
				return;
			}
			marshallingHelper.createNode(xmlWriter, "FuncId", exchangeRateReqMsgCore.getFunctionId(), false, false);
			marshallingHelper.createNode(xmlWriter, "Dimen", exchangeRateReqMsgCore.getExchangeRateDimensions()[0], false, false);
			marshallingHelper.createNode(xmlWriter, "Dimen", exchangeRateReqMsgCore.getExchangeRateDimensions()[1], false, false);
			marshallingHelper.createNode(xmlWriter, "Dimen", exchangeRateReqMsgCore.getExchangeRateDimensions()[2], false, false);
			xmlWriter.writeStartElement("SrcCurAmt");
			marshallingHelper.createNode(xmlWriter, "Amt", exchangeRateReqMsgCore.getCurrecnyAmountSource(), false, false);
			marshallingHelper.createNode(xmlWriter, "CurCode", exchangeRateReqMsgCore.getCurrecnySource(), false, false);
			xmlWriter.writeStartElement("AccId");
			marshallingHelper.createNode(xmlWriter, "AcctNum", exchangeRateReqMsgCore.getAccountNumberSource(), false, false);
			xmlWriter.writeEndElement();
			xmlWriter.writeEndElement();
			xmlWriter.writeStartElement("TargCurAmt");
			marshallingHelper.createNode(xmlWriter, "Amt", exchangeRateReqMsgCore.getCurrecnyAmountTarget(), false, false);
			marshallingHelper.createNode(xmlWriter, "CurCode", exchangeRateReqMsgCore.getCurrecnyTarget(), false, false);
			xmlWriter.writeStartElement("AccId");
			marshallingHelper.createNode(xmlWriter, "AcctNum", exchangeRateReqMsgCore.getAccountNumberTarger(), false, false);
			xmlWriter.writeEndElement();
			xmlWriter.writeEndElement();
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}
}
