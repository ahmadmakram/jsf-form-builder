package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.ChannelInfo;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.response.UserDetailsInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.Name;
import com.ejada.commons.domain.lov.ChannelId;

import com.ejada.commons.exceptions.UnmarshallingException;

public class UserDetailsInquiryCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		UserDetailsInquiryResMsgCore msgCore = new UserDetailsInquiryResMsgCore();
		ResponseMessageBody<UserDetailsInquiryResMsgCore> msgResBody = new ResponseMessageBody<UserDetailsInquiryResMsgCore>();
		msgResBody.setBodyCore(msgCore);
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			TadawulUser tadawulUser = null;
			if (context != null && context.getAssociatedBOs() != null) {
				tadawulUser = (TadawulUser) context.getAssociatedBOs().get(TadawulUser.class.getName());
			}
			if (tadawulUser == null) {
				tadawulUser = new TadawulUser();
			}
			if (msgParsed.get("UsrInfo/UsrId") != null) {
				tadawulUser.setUserId(msgParsed.get("UsrInfo/UsrId"));
			}
			if (msgParsed.get("UsrInfo/UsrStatus") != null) {
				tadawulUser.setUserStatus(msgParsed.get("UsrInfo/UsrStatus"));
			}
			if (msgParsed.get("UsrInfo/Gender") != null) {
				tadawulUser.setGender(new EntityDefaultKey(msgParsed.get("UsrInfo/Gender")));
			}
			if (msgParsed.get("UsrInfo/TitlePrefix") != null) {
				tadawulUser.setTitle(new EntityDefaultKey(msgParsed.get("UsrInfo/TitlePrefix")));
			}
			setNames(msgParsed, tadawulUser);
			setUserContact(msgParsed, tadawulUser);
			// /here the channelList
			String repetition = "UsrChansList/UsrChanInfo/";
			int i = 0;
			while (msgParsed.get(repetition + "ChanId") != null) {
				ChannelInfo channelInfo = tadawulUser.createChannelInfo();
				if (msgParsed.get(repetition + "ChanId") != null) {
					ChannelId channelId = ChannelId.getByCode(msgParsed.get(repetition + "ChanId"));
					setChannelInfo(msgParsed, repetition, channelInfo);
					tadawulUser.addChannelInfo(channelId, channelInfo);
				}
				i++;
				repetition = "UsrChansList/UsrChanInfo[" + i + "]/";
			}
			// end here the channelList
			msgCore.setTadawulUser(tadawulUser);
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		return msgResBody;
	}

	/**
	 * @param msgParsed
	 * @param iBRUser
	 */
	private void setChannelInfo(Hashtable<String, String> msgParsed, String repetition, ChannelInfo channelInfo) {
		if (msgParsed.get(repetition + "ChanId") != null) {
			channelInfo.setChannelId(new EntityDefaultKey(msgParsed.get(repetition + "ChanId")));
		}
		if (msgParsed.get(repetition + "LoginName") != null) {
			channelInfo.getUserCredential().setLoginName(msgParsed.get(repetition + "LoginName"));
		}
		if (msgParsed.get(repetition + "ChanStatus") != null) {
			channelInfo.setChannelStatus(new EntityDefaultKey(msgParsed.get(repetition + "ChanStatus")));
		}
		if (msgParsed.get(repetition + "LangPref") != null) {
			channelInfo.setPreferredLang(new EntityDefaultKey(msgParsed.get(repetition + "LangPref")));
		}
		if (msgParsed.get(repetition + "DfltChanUsrAcctNum") != null) {
			channelInfo.setDefaultUserAccountNumber(msgParsed.get(repetition + "DfltChanUsrAcctNum"));
		}
		if (msgParsed.get(repetition + "SecHint") != null) {
			channelInfo.setSecurityHint(msgParsed.get(repetition + "SecHint"));
		}
		if (msgParsed.get(repetition + "VacationStatus") != null) {
			channelInfo.setVacationStatus(new EntityDefaultKey(msgParsed.get(repetition + "SecHint")));
		}
		if (msgParsed.get(repetition + "VacationFromDt") != null) {
			channelInfo.setVacationFromDate(msgParsed.get(repetition + "VacationFromDt"));
		}
		if (msgParsed.get(repetition + "VacationToDt") != null) {
			channelInfo.setVacationToDate(msgParsed.get(repetition + "VacationToDt"));
		}
		if (msgParsed.get(repetition + "ActivationFromChan") != null) {
			channelInfo.setActivationChannel(msgParsed.get(repetition + "ActivationFromChan"));
		}
		if (msgParsed.get(repetition + "NumOfFailedLogins") != null) {
			int numberInt = Integer.parseInt(msgParsed.get(repetition + "NumOfFailedLogins"));
			channelInfo.setNumberOfFailedLogins(numberInt);
		}
		if (msgParsed.get(repetition + "RgstrTmstmp") != null) {
			CombinedDate combinedDate = getAppropriateTimeStamp(msgParsed.get(repetition + "RgstrTmstmp"));
			channelInfo.setRegstrationDateTime(combinedDate);
		}
		if (msgParsed.get(repetition + "LastFailedLoginTmstmp") != null) {
			CombinedDate combinedDate = getAppropriateTimeStamp(msgParsed.get(repetition + "LastFailedLoginTmstmp"));
			channelInfo.setLastFailedLoginDateTime(combinedDate);
		}
		if (msgParsed.get(repetition + "LastSuccLoginTmstmp") != null) {
			CombinedDate combinedDate = getAppropriateTimeStamp(msgParsed.get(repetition + "LastSuccLoginTmstmp"));
			channelInfo.setLastSuccessLoginDateTime(combinedDate);
		}
		if (msgParsed.get(repetition + "LastPswdChangeTmstmp") != null) {
			CombinedDate combinedDate = getAppropriateTimeStamp(msgParsed.get(repetition + "LastPswdChangeTmstmp"));
			channelInfo.setLastPasswordChangeDateTime(combinedDate);
		}
		if (msgParsed.get(repetition + "WelcomeMsg") != null) {
			channelInfo.setWelcomeMessage(msgParsed.get(repetition + "WelcomeMsg"));
		}
		if (msgParsed.get(repetition + "DispMrktngMsg") != null) {
			channelInfo.setDisplayMessage(msgParsed.get(repetition + "DispMrktngMsg"));
		}
		if (msgParsed.get(repetition + "ThemeId") != null) {
			channelInfo.setThemeId(msgParsed.get(repetition + "ThemeId"));
		}
		if (msgParsed.get(repetition + "SessTimeout") != null) {
			channelInfo.setSessionTimeout(new Integer(msgParsed.get(repetition + "SessTimeout")));
		}
		if (msgParsed.get(repetition + "ShowSessHist") != null) {
			if (msgParsed.get(repetition + "ShowSessHist").equalsIgnoreCase("Y")) {
				channelInfo.setShowSessionHistory(true);
			} else {
				channelInfo.setShowSessionHistory(null);
			}
		}
	}

	/**
	 * @param msgParsed
	 * @param tadawulUser
	 */
	private void setUserContact(Hashtable<String, String> msgParsed, TadawulUser tadawulUser) {
		if (msgParsed.get("UsrInfo/UsrContacts/Addr") != null) {
			tadawulUser.getUserContact().setAddress(msgParsed.get("UsrInfo/UsrContacts/Addr"));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/POBox") != null) {
			tadawulUser.getUserContact().setPoBox(msgParsed.get("UsrInfo/UsrContacts/POBox"));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/PostalCode") != null) {
			tadawulUser.getUserContact().setPostalCode(msgParsed.get("UsrInfo/UsrContacts/PostalCode"));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/City") != null) {
			tadawulUser.getUserContact().setCity(new EntityDefaultKey(msgParsed.get("UsrInfo/UsrContacts/City")));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/TownCountry") != null) {
			tadawulUser.getUserContact().setCountry(new EntityDefaultKey(msgParsed.get("UsrInfo/UsrContacts/TownCountry")));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/MobileNum") != null) {
			tadawulUser.getUserContact().getMobile().setMobileNumber(msgParsed.get("UsrInfo/UsrContacts/MobileNum"));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/PhoneNum") != null) {
			tadawulUser.getUserContact().getPhone().setPhoneNumber(msgParsed.get("UsrInfo/UsrContacts/PhoneNum"));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/PhoneExtension") != null) {
			tadawulUser.getUserContact().getPhone().setPhoneExtension(msgParsed.get("UsrInfo/UsrContacts/PhoneExtension"));
		}
		if (msgParsed.get("UsrInfo/UsrContacts/FaxNum") != null) {
			tadawulUser.getUserContact().getFax().setFaxNumber(msgParsed.get("UsrInfo/UsrContacts/FaxNum"));
		}
		msgParsed.get("UsrInfo/UsrContacts/");
		if (msgParsed.get("UsrInfo/UsrContacts/Email") != null) {
			tadawulUser.getUserContact().setEmail(msgParsed.get("UsrInfo/UsrContacts/Email"));
		}
	}

	/**
	 * @param msgParsed
	 * @param tadawulUser
	 */
	private void setNames(Hashtable<String, String> msgParsed, TadawulUser tadawulUser) {
		Name arabicName = new Name();
		if (msgParsed.get("UsrInfo/UsrNameAr/FirstName") != null) {
			arabicName.setFirstName(msgParsed.get("UsrInfo/UsrNameAr/FirstName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameAr/FatherName") != null) {
			arabicName.setSecondName(msgParsed.get("UsrInfo/UsrNameAr/FatherName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameAr/FamilyName") != null) {
			arabicName.setFamilyName(msgParsed.get("UsrInfo/UsrNameAr/FamilyName"));
		}
		tadawulUser.setArabicName(arabicName);
		Name englishName = new Name();
		if (msgParsed.get("UsrInfo/UsrNameEn/FirstName") != null) {
			englishName.setFirstName(msgParsed.get("UsrInfo/UsrNameEn/FirstName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameEn/FatherName") != null) {
			englishName.setSecondName(msgParsed.get("UsrInfo/UsrNameEn/FatherName"));
		}
		if (msgParsed.get("UsrInfo/UsrNameEn/FamilyName") != null) {
			englishName.setFamilyName(msgParsed.get("UsrInfo/UsrNameEn/FamilyName"));
		}
		tadawulUser.setEnglishName(englishName);
	}

	private CombinedDate getAppropriateTimeStamp(String message) {
		String dateTimeString = message;
		CombinedDate dateTimeStamp = new CombinedDate();
		dateTimeStamp.setDateTime(dateTimeString);
		return dateTimeStamp;
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
