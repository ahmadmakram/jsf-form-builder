/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messages.broker.RequestMessage;
import com.ejada.commons.dao.messages.broker.RequestMessageBody;
import com.ejada.commons.dao.messages.broker.RequestMessageHeader;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.ContextFactory;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MsgMarshaller;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class LoggingDataMarshaller extends MsgMarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgMarshaller#appendMsgStart (javax.xml.stream.XMLStreamWriter)
	 */
	@Override
	public void appendMsgStart(XMLStreamWriter xmlWriter) throws XMLStreamException {
		xmlWriter.writeStartElement("LoggingDataRs");
	}

	@Override
	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		RequestMessage requestMessage = (RequestMessage) obj;
		Context newContext;
		if (context != null) {
			newContext = context.appendContextChild(requestMessage);
		} else {
			newContext = ContextFactory.createContext(requestMessage);
		}
		try {
			// Call appender for the parent request message tag.
			appendMsgStart(xmlWriter);
			// Get the message body marshaller
			Marshaller bodyMarshaller = marshallingConfig.getMarshaller(ContextFactory.createContext(RequestMessageBody.class));
			// call the message body marshaller
			bodyMarshaller.marshal(xmlWriter, requestMessage.getMessageBody(), newContext);
			// Call appender for the request message ending tag
			xmlWriter.writeEndElement();
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}
}
