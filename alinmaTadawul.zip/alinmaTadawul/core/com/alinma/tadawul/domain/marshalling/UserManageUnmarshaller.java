package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.UserManageResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class UserManageUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new UserManageResMsg();
	}

	@Override
	public String getElementString() {
		return "UsrMngRs";
	}
}
