package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.UsersInquiryResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class UsersInquiryUnmarshaller extends MsgUnmarshaller {

	@Override
	@SuppressWarnings("unchecked")
	protected ResponseMessage createResponseMessage() {
		return new UsersInquiryResMsg();
	}

	@Override
	public String getElementString() {
		return "UsrsInqRs";
	}
}
