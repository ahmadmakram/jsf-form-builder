/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.lov.CustomerId;
import com.alinma.tadawul.domain.lov.ParameterName;
import com.alinma.tadawul.market.domain.messages.response.ManageCustomerResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;

import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.lov.ServiceMessageLevel;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.ejada.commons.services.ServiceMessageParameter;
import com.ejada.commons.services.ServiceReturnMessage;

/**
 * @author M. Ali Hammam
 * 
 */
public class ManageCustomerCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			// read the tag of Body
			xmlReader.next();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			TadawulUser customer = null;
			List<ServiceReturnMessage> messages = new ArrayList<ServiceReturnMessage>(0);
			if (context != null && context.getAssociatedBOs() != null) {
				customer = (TadawulUser) context.getAssociatedBOs().get(TadawulUser.class.getName());
			}
			if (customer == null) {
				customer = new TadawulUser();
			}
			String repetition = "StatusCodesList/StatusCodeInfo/";
			String statusCode = msgParsed.get(repetition + "StatusCode");
			if (statusCode != null) // has errors
			{
				ServiceReturnMessage msg;
				List<ServiceMessageParameter> params = null;
				String paramValue;
				for (int i = 1; statusCode != null; i++) {
					if (statusCode != null && !statusCode.equals("W700101")) {
						paramValue = msgParsed.get(repetition + "StatusSubCode");
						if (paramValue != null && !paramValue.trim().equals("")) {
							params = new ArrayList<ServiceMessageParameter>();
							params.add(new ServiceMessageParameter(ParameterName.SUB_STATUS.getCode(), paramValue.trim()));
						}
						msg = new ServiceReturnMessage(statusCode.trim(), ServiceMessageLevel.getByCode(statusCode.charAt(0)), params);
						messages.add(msg);
					}
					repetition = "StatusCodesList/StatusCodeInfo[" + i + "]/";
					statusCode = msgParsed.get(repetition + "StatusCode");
					params = null; // nullify the parameters for the next
								   // iteration.
				}
			}
			CustomerId customerId = customer.getCustomerStartingInfo().getDefaultIdDoc().getCustomerId();
			if (msgParsed.get("PartyId") != null && !msgParsed.get("PartyId").equals("")) {
				customerId.setPartyId(msgParsed.get("PartyId"));
			}
			if (msgParsed.get("AlinmaId") != null && !msgParsed.get("AlinmaId").equals("")) {
				customerId.setAlinmaId(msgParsed.get("AlinmaId"));
			}
			if (msgParsed.get("PartyStatusCode") != null && !msgParsed.get("PartyStatusCode").equals("")) {
				customer.getCustomerStartingInfo().getBankInfo().setCustomerStatus(new EntityDefaultKey(msgParsed.get("PartyStatusCode")));
			}
			if (msgParsed.get("PartyTypeCode") != null && !msgParsed.get("PartyTypeCode").equals("")) {
				customerId.setPartyType(new EntityDefaultKey(msgParsed.get("PartyTypeCode")));
			}
			if (msgParsed.get("CIF") != null && !msgParsed.get("CIF").equals("")) {
				customerId.setCIF(msgParsed.get("CIF"));
			}
			if (msgParsed.get("RecVersion") != null && !msgParsed.get("RecVersion").equals("")) {
				customer.getCustomerStartingInfo().getBankInfo().setRecordVersion(new Integer(msgParsed.get("RecVersion")));
			}
			ManageCustomerResMsgCore msgCore = new ManageCustomerResMsgCore();
			msgCore.setCustomer(customer);
			msgCore.setMessages(messages);
			if (msgParsed.get("T24CustName") != null) {
				msgCore.setT24CustName(msgParsed.get("T24CustName"));
			}
			ResponseMessageBody<ManageCustomerResMsgCore> resMsgBody = new ResponseMessageBody<ManageCustomerResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException("Error at unmarshalling");
		}
	}
}
