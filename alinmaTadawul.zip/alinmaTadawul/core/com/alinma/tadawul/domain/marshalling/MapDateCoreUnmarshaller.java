/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.lov.ServiceMessageLevel;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.alinma.tadawul.domain.lov.ServiceStatus;
import com.alinma.tadawul.domain.messages.response.DateMappingResMsgCore;

/**
 * @author M. Ali Hammam
 * 
 */
public class MapDateCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString()
	 */
	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax.xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			// read the tag of Body
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			List<String> dates = new ArrayList<String>(0);
			String repetition = "DataMapngsRsList/DataMapngRsInfo/";
			int i = 0;
			String date = msgParsed.get(repetition + "TargVal");
			while (date != null) {
				if (msgParsed.get(repetition + "MapngStatus") != null && msgParsed.get(repetition + "MapngStatus").startsWith(ServiceStatus.SUCCESS.getCode())) {
					if (date.length() < 8) {
						date = null;
					} else {
						String year = date.substring(0, 4);
						String month = date.substring(4, 6);
						String day = date.substring(6, 8);
						date = year + "-" + month + "-" + day;
					}
					dates.add(date);
				} else {
					dates.add(null);
				}
				i++;
				repetition = "DataMapngsRsList/DataMapngRsInfo[" + i + "]/";
				date = msgParsed.get(repetition + "TargVal");
			}
			DateMappingResMsgCore msgCore = new DateMappingResMsgCore();
			msgCore.setDateMapped(dates);
			ResponseMessageBody<DateMappingResMsgCore> resMsgBody = new ResponseMessageBody<DateMappingResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException("Error at unmarshalling");
		}
	}
}
