/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.response.ManageRegistrationResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.User;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Administrator
 * 
 */
public class ManageRegistrationCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString ()
	 */
	public String getElementString() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax .xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		ManageRegistrationResMsgCore msgCore = new ManageRegistrationResMsgCore();
		ResponseMessageBody<ManageRegistrationResMsgCore> msgResBody = new ResponseMessageBody<ManageRegistrationResMsgCore>();
		msgResBody.setBodyCore(msgCore);
		// read the tag of Body
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			if (msgParsed.get("UsrId") != null) {
				TadawulUser user = new TadawulUser();
				user.setUserId(msgParsed.get("UsrId"));
				msgCore.setUser(user);
			}
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
		return msgResBody;
	}
}
