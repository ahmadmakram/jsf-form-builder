/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

//import com.alinma.tadawul.domain.Complaint;
import com.alinma.tadawul.domain.CurrencyInfo;
//import com.alinma.tadawul.domain.messages.response.ComplaintDetailsInquiryResMsgCore;
import com.alinma.tadawul.domain.messages.response.ExchangeRateResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRateCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			ExchangeRateResMsgCore exchangeRateResMsgCore = new ExchangeRateResMsgCore();
			CurrencyInfo currencyInfo = CurrencyInfo.createCurrencyInfo();
			currencyInfo.setAmountSource(msgParsed.get("SrcCurAmt/Amt"));
			currencyInfo.setAmountSourceLocal(msgParsed.get("SrcCurAmt/AmtLcl"));
			currencyInfo.setAmountTarget(msgParsed.get("TargCurAmt/Amt"));
			currencyInfo.setAmountTargetLocal(msgParsed.get("TargCurAmt/AmtLcl"));
			currencyInfo.setBuyRateSource(msgParsed.get("SrcCurAmt/CurRate"));
			currencyInfo.setCurrencySource(new EntityDefaultKey(msgParsed.get("SrcCurAmt/CurCode")));
			currencyInfo.setCurrencyTarget(new EntityDefaultKey(msgParsed.get("TargCurAmt/CurCode")));
			currencyInfo.setSellRateTarget(msgParsed.get("TargCurAmt/CurRate"));
			exchangeRateResMsgCore.setCurrencyInfo(currencyInfo);
			ResponseMessageBody<ExchangeRateResMsgCore> resMsgBody = new ResponseMessageBody<ExchangeRateResMsgCore>();
			resMsgBody.setBodyCore(exchangeRateResMsgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}
}
