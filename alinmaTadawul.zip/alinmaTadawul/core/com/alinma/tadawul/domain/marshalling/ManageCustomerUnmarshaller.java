package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.market.domain.messages.response.ManageCustomerResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class ManageCustomerUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new ManageCustomerResMsg();
	}

	@Override
	public String getElementString() {
		// TODO Auto-generated method stub
		return "PartyMngRs";
	}
}
