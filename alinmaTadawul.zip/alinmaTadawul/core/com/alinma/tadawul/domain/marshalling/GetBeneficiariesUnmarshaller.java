package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.GetBeneficiariesResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiariesUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new GetBeneficiariesResMsg();
	}

	@Override
	public String getElementString() {
		return "BensInqRs";
	}
}
