package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.GetBeneficiaryDetailsResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiaryDetailsUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new GetBeneficiaryDetailsResMsg();
	}

	@Override
	public String getElementString() {
		return "BenDtlsInqRs";
	}
}
