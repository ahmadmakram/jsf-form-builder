package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
/**
 * @author Khalid AlQahtani
 *
 */
import com.ejada.commons.dao.messaging.marshalling.MsgMarshaller;

public class GetBeneficiariesMarshaller extends MsgMarshaller {

	@Override
	public void appendMsgStart(XMLStreamWriter xmlWriter) throws XMLStreamException {
		xmlWriter.writeStartElement("BensInqRq");
	}
}
