package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.request.UserDetailsInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.domain.lov.ChannelId;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Hani Younis
 * 
 */
public class UserDetailsInquiryCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		UserDetailsInquiryReqMsgCore userDetailsInquiryReqMsgCore = (UserDetailsInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingManageUserInfo(xmlWriter, userDetailsInquiryReqMsgCore, marshallingHelper);
		} catch (XMLStreamException ex) {
			throw new MarshallingException(ex);
		}
	}

	/**
	 * @param xmlWriter
	 * @param registrationInfo
	 * @param marshallingHelper
	 * @throws XMLStreamException
	 */
	private void marshallingManageUserInfo(XMLStreamWriter xmlWriter, UserDetailsInquiryReqMsgCore userDetailsInquiryReqMsgCore, MarshallingHelper marshallingHelper) throws XMLStreamException {
		TadawulUser ibrUser = userDetailsInquiryReqMsgCore.getTadawulUser();
		if (ibrUser == null) {
			return;
		}
		if (ibrUser.getUserId() != null) {
			marshallingHelper.createNode(xmlWriter, "UsrId", ibrUser.getUserId(), false, false);
		} else if (ibrUser.getCif() != null) {
			marshallingHelper.createNode(xmlWriter, "CIF", ibrUser.getCif(), false, false);
		} else if (ibrUser.getInternetChannelInfo().getUserCredential().getLoginName() != null) {
			xmlWriter.writeStartElement("ChanLoginName");
			marshallingHelper.createNode(xmlWriter, "ChanId", userDetailsInquiryReqMsgCore.getChannelId().getCode(), false, false);
			marshallingHelper.createNode(xmlWriter, "LoginName", ibrUser.getInternetChannelInfo().getUserCredential().getLoginName(), false, false);
			xmlWriter.writeEndElement();
		} else if (ibrUser.getChannelsInfo().get(ChannelId.USSD) != null) {
			xmlWriter.writeStartElement("ChanLoginName");
			marshallingHelper.createNode(xmlWriter, "ChanId", userDetailsInquiryReqMsgCore.getChannelId().getCode(), false, false);
			marshallingHelper.createNode(xmlWriter, "LoginName", ibrUser.getChannelsInfo().get(ChannelId.USSD).getUserCredential().getLoginName(), false, false);
			xmlWriter.writeEndElement();
		}
	}
}
