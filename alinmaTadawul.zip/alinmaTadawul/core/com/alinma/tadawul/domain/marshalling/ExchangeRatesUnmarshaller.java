/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.ExchangeRatesResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Hani Younis
 * 
 */
public class ExchangeRatesUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ExchangeRatesResMsg createResponseMessage() {
		return new ExchangeRatesResMsg();
	}

	@Override
	public String getElementString() {
		return "ExRatesInqRs";
	}
}
