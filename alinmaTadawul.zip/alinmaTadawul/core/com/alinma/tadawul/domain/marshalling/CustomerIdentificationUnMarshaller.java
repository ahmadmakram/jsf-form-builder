package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.CustomerIdentificationResMsg;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Khalid AlQahtani
 * 
 */
public class CustomerIdentificationUnMarshaller extends MsgUnmarshaller {

	@Override
	public String getElementString() {
		return "CustIdentRs";
	}

	@Override
	protected ResponseMessage createResponseMessage() {
		return new CustomerIdentificationResMsg();
	}
}
