package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.StatementDetailsInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		StatementDetailsInquiryReqMsgCore statementDetailsInquiryReqMsgCore = (StatementDetailsInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		String function = (String) context.getAssociatedBOs().get(String.class.getName());
		try {
			if (statementDetailsInquiryReqMsgCore.getAccountNum() != null) {
				xmlWriter.writeStartElement("AcctId");
				marshallingHelper.createNode(xmlWriter, "AcctNum", statementDetailsInquiryReqMsgCore.getAccountNum());
				if (statementDetailsInquiryReqMsgCore.getAccountType() != null) {
					marshallingHelper.createNode(xmlWriter, "AcctType", statementDetailsInquiryReqMsgCore.getAccountType());
				}
				xmlWriter.writeEndElement();
			}
			if (statementDetailsInquiryReqMsgCore.getCardNum() != null) {
				xmlWriter.writeStartElement("CardId");
				marshallingHelper.createNode(xmlWriter, "CardNum", statementDetailsInquiryReqMsgCore.getCardNum());
				if (statementDetailsInquiryReqMsgCore.getCardType() != null) {
					marshallingHelper.createNode(xmlWriter, "CardType", statementDetailsInquiryReqMsgCore.getCardType());
				}
				xmlWriter.writeEndElement();
			}
			if (statementDetailsInquiryReqMsgCore.getStatementCycle() != null) {
				if (statementDetailsInquiryReqMsgCore.getStatementCycle().getStartDate() != null) {
					marshallingHelper.createNode(xmlWriter, "FromDt", statementDetailsInquiryReqMsgCore.getStatementCycle().getStartDate().getDate() != null ? statementDetailsInquiryReqMsgCore
							.getStatementCycle().getStartDate().getDate() : null);
				}
				if (statementDetailsInquiryReqMsgCore.getStatementCycle().getEndDate() != null) {
					marshallingHelper.createNode(xmlWriter, "ToDt", statementDetailsInquiryReqMsgCore.getStatementCycle().getEndDate().getDate() != null ? statementDetailsInquiryReqMsgCore
							.getStatementCycle().getEndDate().getDate() : null);
				}
			}
			if (statementDetailsInquiryReqMsgCore.getPaginationInRec() != null) {
				xmlWriter.writeStartElement("RecCtrlIn");
				Integer size = statementDetailsInquiryReqMsgCore.getPaginationInRec().getPageSize();
				marshallingHelper.createNode(xmlWriter, "MaxRecs", (size != null) ? size.toString() : "");
				Integer offset = statementDetailsInquiryReqMsgCore.getPaginationInRec().getPageOffset();
				marshallingHelper.createNode(xmlWriter, "Offset", (offset != null) ? offset.toString() : "");
				xmlWriter.writeEndElement();
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
