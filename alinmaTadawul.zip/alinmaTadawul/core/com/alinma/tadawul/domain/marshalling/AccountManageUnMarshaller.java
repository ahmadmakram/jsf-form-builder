package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.AccountManageResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class AccountManageUnMarshaller extends MsgUnmarshaller {

	@Override
	public String getElementString() {
		return "AcctMngRs";
	}

	@Override
	protected AccountManageResMsg createResponseMessage() {
		return new AccountManageResMsg();
	}
}
