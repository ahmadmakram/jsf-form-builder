package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.UserDetailsInquiryResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

public class UserDetailsInquiryUnmarshaller extends MsgUnmarshaller {

	@Override
	protected UserDetailsInquiryResMsg createResponseMessage() {
		return new UserDetailsInquiryResMsg();
	}

	@Override
	public String getElementString() {
		return "UsrDtlsInqRs";
	}
}
