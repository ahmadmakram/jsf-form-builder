/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;
import com.alinma.tadawul.domain.messages.response.ManageRegistrationResMsg;

/**
 * @author Hani Younis
 * 
 */
public class ManageRegistrationUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected ManageRegistrationResMsg createResponseMessage() {
		return new ManageRegistrationResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		return "UsrRgstrtnRs";
	}
}
