package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;
import com.alinma.tadawul.domain.LogData;
import com.alinma.tadawul.domain.messages.request.LoggingDataReqMsgCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class LoggingDataCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		LoggingDataReqMsgCore loggingDataReqMsgCore = (LoggingDataReqMsgCore) obj;
		LogData logData = loggingDataReqMsgCore.getLogData();
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "TransactionNumber", logData.getTransactionNumber());
			marshallingHelper.createNode(xmlWriter, "MessageType", logData.getMessageType());
			marshallingHelper.createNode(xmlWriter, "CreationTypeStamp", logData.getCreationTypeStamp());
			marshallingHelper.createNode(xmlWriter, "ChannelId", logData.getChannelId());
			marshallingHelper.createNode(xmlWriter, "AlinmaId", logData.getAlinmaId());
			marshallingHelper.createNode(xmlWriter, "FunctionId", logData.getFunctionId());
			marshallingHelper.createNode(xmlWriter, "BranchId", logData.getBranchId());
			marshallingHelper.createNode(xmlWriter, "RequestId", logData.getRequestId());
			marshallingHelper.createNode(xmlWriter, "StatusCode", logData.getStatusCode());
			marshallingHelper.createNode(xmlWriter, "ExceptionMessage", logData.getExceptionMessage());
			marshallingHelper.createNode(xmlWriter, "Comment", logData.getComment());
			marshallingHelper.createNode(xmlWriter, "MessageId", logData.getMessageId());
			marshallingHelper.createNode(xmlWriter, "ConccuentLoginedUser", logData.getConccuentLoginedUser());
			marshallingHelper.createNode(xmlWriter, "SessionRef", logData.getSessionRef());
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
