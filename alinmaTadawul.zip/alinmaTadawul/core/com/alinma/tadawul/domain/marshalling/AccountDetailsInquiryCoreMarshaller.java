package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.messages.request.AccountDetailsInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class AccountDetailsInquiryCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		AccountDetailsInquiryReqMsgCore getAccountReqMsgCore = (AccountDetailsInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (getAccountReqMsgCore.getAccount().getAccountNumber() != null) {
				marshalAccountNum(marshallingHelper, xmlWriter, getAccountReqMsgCore.getAccount());
			}
			if (getAccountReqMsgCore.getAccount().getIban() != null) {
				marshalIban(marshallingHelper, xmlWriter, getAccountReqMsgCore.getAccount());
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}

	private void marshalAccountNum(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, Account account) throws XMLStreamException {
		xmlWriter.writeStartElement("AcctId");
		marshallingHelper.createNode(xmlWriter, "AcctNum", account.getAccountNumber());
		if (account.getAccountType() != null) {
			marshallingHelper.createNode(xmlWriter, "AcctType", account.getAccountType().getCode());
		}
		xmlWriter.writeEndElement();
	}

	private void marshalIban(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, Account account) throws XMLStreamException {
		if (account.getIban() != null) {
			marshallingHelper.createNode(xmlWriter, "IBAN", account.getIban());
		}
	}
}
