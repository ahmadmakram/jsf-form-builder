package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.alinma.tadawul.domain.RegistrationInfo;
import com.alinma.tadawul.domain.messages.request.CustomerIdentificationReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class CustomerIdentificationCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		CustomerIdentificationReqMsgCore customerIdentificationReqMsgCore = (CustomerIdentificationReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (customerIdentificationReqMsgCore.getRegistrationInfo() == null) {
				return;
			}
			marshalcustomerIdentification(marshallingHelper, xmlWriter, customerIdentificationReqMsgCore.getRegistrationInfo());
			marshalcustomerIdentificationPOI(marshallingHelper, xmlWriter, customerIdentificationReqMsgCore.getRegistrationInfo());
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}

	private void marshalcustomerIdentification(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, RegistrationInfo registrationInfo) throws XMLStreamException {
		if (registrationInfo.getAccount().getAccountNumber() != null) {
			marshallingHelper.createNode(xmlWriter, "AcctNum", registrationInfo.getAccount().getAccountNumber(), false, false);
		}
	}

	private void marshalcustomerIdentificationPOI(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, RegistrationInfo registrationInfo) throws XMLStreamException {
		xmlWriter.writeStartElement("POI");
		if (registrationInfo.getUser().getIdDocKey().getIdNumber() != null) {
			marshallingHelper.createNode(xmlWriter, "POINum", registrationInfo.getUser().getIdDocKey().getIdNumber(), false, false);
		}
		if (registrationInfo.getUser().getIdDocKey().getIdDocType() != null) {
			marshallingHelper.createNode(xmlWriter, "POIType", registrationInfo.getUser().getIdDocKey().getIdDocType().getCode(), false, false);
		}
		xmlWriter.writeEndElement();
	}
}
