package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.UpdateRetainedMsgReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * 
 * @author mahamoda
 * 
 */
public class UpdateRetainedMsgsCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		UpdateRetainedMsgReqMsgCore updateRetainedMsgReqMsgCore = (UpdateRetainedMsgReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "MsgId", updateRetainedMsgReqMsgCore.getRetainedMsg().getMsgId().getCode());
			if (updateRetainedMsgReqMsgCore.getRetainedMsg().getReadMsg()) {
				marshallingHelper.createNode(xmlWriter, "MsgRead", "Y");
			} else {
				marshallingHelper.createNode(xmlWriter, "MsgRead", "N");
			}
			if (updateRetainedMsgReqMsgCore.getRetainedMsg().getDeletedMsg()) {
				marshallingHelper.createNode(xmlWriter, "MsgDeleted", "Y");
			} else {
				marshallingHelper.createNode(xmlWriter, "MsgDeleted", "N");
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
