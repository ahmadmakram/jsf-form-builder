/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.User;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.alinma.tadawul.domain.LogData;
import com.alinma.tadawul.domain.messages.response.UserAuthenticationResMsgCore;
import com.alinma.tadawul.domain.messages.response.LoggingDataResMsgCore;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class LoggingDataCoreUnmarshaller implements Unmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#getElementString ()
	 */
	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.Unmarshaller#unmarshal(javax .xml.stream.XMLStreamReader, com.ejada.commons.dao.messaging.marshalling.Context)
	 */
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			LogData logData = null;
			if (context != null && context.getAssociatedBOs() != null) {
				logData = (LogData) context.getAssociatedBOs().get(LogData.class.getName());
			}
			if (logData == null) {
				logData = new LogData();
			}
			if (msgParsed.get("Body/TransactionNumber") != null) {
				logData.setTransactionNumber(msgParsed.get("Body/TransactionNumber"));
			}
			if (msgParsed.get("Body/MessageType") != null) {
				logData.setMessageType(msgParsed.get("Body/MessageType"));
			}
			if (msgParsed.get("Body/CreationTypeStamp") != null) {
				logData.setCreationTypeStamp(msgParsed.get("Body/CreationTypeStamp"));
			}
			if (msgParsed.get("Body/ChannelId") != null) {
				logData.setChannelId(msgParsed.get("Body/ChannelId"));
			}
			if (msgParsed.get("Body/AlinmaId") != null) {
				logData.setAlinmaId(msgParsed.get("Body/AlinmaId"));
			}
			if (msgParsed.get("Body/FunctionId") != null) {
				logData.setFunctionId(msgParsed.get("Body/FunctionId"));
			}
			if (msgParsed.get("Body/BranchId") != null) {
				logData.setBranchId(msgParsed.get("Body/BranchId"));
			}
			if (msgParsed.get("Body/RequestId") != null) {
				logData.setRequestId(msgParsed.get("Body/RequestId"));
			}
			if (msgParsed.get("Body/StatusCode") != null) {
				logData.setStatusCode(msgParsed.get("Body/StatusCode"));
			}
			if (msgParsed.get("Body/ExceptionMessage") != null) {
				logData.setExceptionMessage(msgParsed.get("Body/ExceptionMessage"));
			}
			if (msgParsed.get("Body/Comment") != null) {
				logData.setComment(msgParsed.get("Body/Comment"));
			}
			if (msgParsed.get("Body/MessageId") != null) {
				logData.setMessageId(msgParsed.get("Body/MessageId"));
			}
			if (msgParsed.get("Body/ConccuentLoginedUser") != null) {
				logData.setConccuentLoginedUser(msgParsed.get("Body/ConccuentLoginedUser"));
			}
			if (msgParsed.get("Body/SessionRef") != null) {
				logData.setSessionRef(msgParsed.get("Body/SessionRef"));
			}
			LoggingDataResMsgCore msgCore = new LoggingDataResMsgCore();
			msgCore.setLogData(logData);
			ResponseMessageBody<LoggingDataResMsgCore> resMsgBody = new ResponseMessageBody<LoggingDataResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}
}
