package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.messages.request.GetRetainedMsgsReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

public class GetRetainedMsgsCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetRetainedMsgsReqMsgCore retainedMsgsReqMsgCore = (GetRetainedMsgsReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshallingHelper.createNode(xmlWriter, "NotificationMethod", retainedMsgsReqMsgCore.getRetainedMsg().getNotificationMethod().getCode());
			marshallingHelper.createNode(xmlWriter, "UsrId", retainedMsgsReqMsgCore.getUserId(), false, false);
			if (retainedMsgsReqMsgCore.getRetainedMsg().getReadMsg() != null) {
				if (retainedMsgsReqMsgCore.getRetainedMsg().getReadMsg()) {
					marshallingHelper.createNode(xmlWriter, "IncReadMsg", "Y");
				} else {
					marshallingHelper.createNode(xmlWriter, "IncReadMsg", "N");
				}
			}
			if (retainedMsgsReqMsgCore.getRetainedMsg().getDeletedMsg()) {
				marshallingHelper.createNode(xmlWriter, "IncDeletedMsg", "Y");
			} else {
				marshallingHelper.createNode(xmlWriter, "IncDeletedMsg", "N");
			}
			if (retainedMsgsReqMsgCore.getPaginationInRec() != null) {
				xmlWriter.writeStartElement("RecCtrlIn");
				marshallingHelper.createNode(xmlWriter, "MaxRecs", retainedMsgsReqMsgCore.getPaginationInRec().getPageSize().toString());
				marshallingHelper.createNode(xmlWriter, "Offset", retainedMsgsReqMsgCore.getPaginationInRec().getPageOffset().toString());
				xmlWriter.writeEndElement();
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
