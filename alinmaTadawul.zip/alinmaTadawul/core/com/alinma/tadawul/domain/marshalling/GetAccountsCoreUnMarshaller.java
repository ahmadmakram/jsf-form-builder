/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.response.GetAccountsResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author mbrins
 * 
 */
public class GetAccountsCoreUnMarshaller implements Unmarshaller {

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			List<Account> accounts = TadawulUser.createAccountsList();
			PaginationOutRec pagination = null;
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			if (msgParsed.get("RecCtrlOut/SentRecs") != null) {
				pagination = new PaginationOutRec(new Integer(msgParsed.get("RecCtrlOut/MatchedRecs")), new Integer(msgParsed.get("RecCtrlOut/SentRecs")));
			} else {
				throw new UnmarshallingException("RecCtrlOut/SentRecs has not been sent");
			}
			String repetition = "AcctsList/AcctInfo/";
			for (int i = 1; i <= pagination.getCurrentResultSetSize(); i++) {
				Account account = TadawulUser.createAccount();
				if (msgParsed.get(repetition + "IsSubUsrEnabled") != null) {
					account.setSubUsrEnabled(msgParsed.get(repetition + "IsSubUsrEnabled").equalsIgnoreCase("y"));
				}
				if (msgParsed.get(repetition + "AcctFuncsAccess") != null) {
					account.setAcctFuncsAccess(msgParsed.get(repetition + "AcctFuncsAccess"));
				}
				if (msgParsed.get(repetition + "AcctDtls/AcctId/AcctNum") != null) {
					account.setAccountNumber(msgParsed.get(repetition + "AcctDtls/AcctId/AcctNum"));
				}
				if (msgParsed.get(repetition + "AcctDtls/AcctId/AcctType") != null) {
					account.setAccountType(new EntityDefaultKey(msgParsed.get(repetition + "AcctDtls/AcctId/AcctType")));
				}
				if (msgParsed.get(repetition + "AcctDtls/IBAN") != null) {
					account.setIban(msgParsed.get(repetition + "AcctDtls/IBAN"));
				}
				if (msgParsed.get(repetition + "AcctDtls/AcctName") != null) {
					account.setAccountName(msgParsed.get(repetition + "AcctDtls/AcctName"));
				}
				if (msgParsed.get(repetition + "AcctDtls/ShortDesc") != null) {
					account.setShortDesc(msgParsed.get(repetition + "AcctDtls/ShortDesc"));
				}
				if (msgParsed.get(repetition + "AcctDtls/AcctNickname") != null) {
					account.setAccountNickName(msgParsed.get(repetition + "AcctDtls/AcctNickname"));
				}
				if (msgParsed.get(repetition + "AcctDtls/AcctStatus") != null) {
					account.setAccountStatus(new EntityDefaultKey(msgParsed.get(repetition + "AcctDtls/AcctStatus")));
				}
				if (msgParsed.get(repetition + "AcctDtls/AcctCur") != null) {
					account.setAccountCurrency(new EntityDefaultKey(msgParsed.get(repetition + "AcctDtls/AcctCur")));
				}
				if (msgParsed.get(repetition + "AcctDtls/AvailBal") != null) {
					account.setAvailableBalance(new Double(msgParsed.get(repetition + "AcctDtls/AvailBal").replace(",", "")));
				} else {
					account.setAvailableBalance(new Double("0"));
				}
				if (msgParsed.get(repetition + "AcctDtls/LedgerBal") != null) {
					account.setLedgerBalance(new Double(msgParsed.get(repetition + "AcctDtls/LedgerBal").replace(",", "")));
				}
				if (msgParsed.get(repetition + "AcctDtls/CurrBal") != null) {
					account.setCurrentBalance(new Double(msgParsed.get(repetition + "AcctDtls/CurrBal").replace(",", "")));
				}
				accounts.add(account);
				repetition = "AcctsList/AcctInfo[" + i + "]/";
			}
			GetAccountsResMsgCore coreMsg = new GetAccountsResMsgCore();
			coreMsg.setAccounts(accounts);
			coreMsg.setPaginationOut(pagination);
			ResponseMessageBody<GetAccountsResMsgCore> msgBody = new ResponseMessageBody<GetAccountsResMsgCore>();
			msgBody.setBodyCore(coreMsg);
			return msgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException("Error at unmarshalling");
		}
	}
}
