/**
 *
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messages.broker.ResponseMessageHeader;
import com.ejada.commons.dao.messages.broker.ResponseMessageStatusCode;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.ContextFactory;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.alinma.tadawul.domain.messages.request.LoggingDataReqMsg;
import com.alinma.tadawul.domain.messages.response.UserAuthenticationResMsg;
import com.alinma.tadawul.domain.messages.response.LoggingDataResMsg;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class LoggingDataUnmarshaller extends MsgUnmarshaller {

	@Override
	protected ResponseMessage createResponseMessage() {
		return new LoggingDataResMsg();
	}

	@Override
	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		Context newContext;
		if (context == null) {
			newContext = ContextFactory.createContext(getElementString());
		} else {
			newContext = context.appendContextChild(getElementString());
		}
		// Create the response message
		ResponseMessage responseMessage = createResponseMessage();
		ResponseMessageBody responseMessageBody;
		try {
			Context unmarshallerBodyContext = newContext.appendContextChild("Body");
			// Find the unmarshaller for the body
			Unmarshaller responseMsgBodyUnmarshaller = marshallingConfig.getUnmarshaller(unmarshallerBodyContext);
			// unmarshall the body
			responseMessageBody = (ResponseMessageBody) responseMsgBodyUnmarshaller.unmarshal(xmlReader, newContext);
			// Set the message body inside the response message
			responseMessage.setMessageBody(responseMessageBody);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		// }
		try {
			xmlReader.close();
		} catch (XMLStreamException ex) {
			ex.printStackTrace();
		}
		return responseMessage;
	}

	@Override
	public String getElementString() {
		return "LoggingDataRs";
	}
}
