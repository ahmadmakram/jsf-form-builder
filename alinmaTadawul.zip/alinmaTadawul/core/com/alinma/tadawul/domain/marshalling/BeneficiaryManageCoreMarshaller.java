package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.alinma.tadawul.domain.messages.request.BeneficiaryManageReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class BeneficiaryManageCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		BeneficiaryManageReqMsgCore reqMsgCore = (BeneficiaryManageReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		String function = "";
		function = (String) context.getAssociatedBOs().get(String.class.getName());
		try {
			if (!function.equalsIgnoreCase("addBeneficiary")) {
				marshallingHelper.createNode(xmlWriter, "BenCode", reqMsgCore.getBeneficiary().getCode(), true, true);
			}
			if (function.equalsIgnoreCase("addBeneficiary") || function.equals("modifyBeneficiary")) {
				if (reqMsgCore.getBeneficiary().getBeneficiaryType() != null) {
					marshallingHelper.createNode(xmlWriter, "BenType", reqMsgCore.getBeneficiary().getBeneficiaryType().getCode(), true, true);
				}
				marshallingHelper.createNode(xmlWriter, "Nickname", reqMsgCore.getBeneficiary().getNickName(), true, true);
				if (reqMsgCore.getBeneficiary().getBeneficiaryType() != null) {
					if (reqMsgCore.getBeneficiary().getBeneficiaryType().getCode().equalsIgnoreCase("1")) {
						xmlWriter.writeStartElement("AcctId");
						marshallingHelper.createNode(xmlWriter, "AcctNum", reqMsgCore.getBeneficiary().getAccount().getAccountNumber(), true, true);
						if (reqMsgCore.getBeneficiary().getAccount().getAccountType() != null) {
							marshallingHelper.createNode(xmlWriter, "AcctType", reqMsgCore.getBeneficiary().getAccount().getAccountType().getCode(), true, true);
						}
						xmlWriter.writeEndElement();
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
