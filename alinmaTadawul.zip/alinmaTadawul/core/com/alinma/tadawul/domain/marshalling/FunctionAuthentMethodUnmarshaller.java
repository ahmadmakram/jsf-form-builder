/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import com.alinma.tadawul.domain.messages.response.FunctionAuthentMethodResMsg;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;

/**
 * @author Hani Younis
 * 
 */
public class FunctionAuthentMethodUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected FunctionAuthentMethodResMsg createResponseMessage() {
		return new FunctionAuthentMethodResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		return "FuncAuthentMethodInqRs";
	}
}
