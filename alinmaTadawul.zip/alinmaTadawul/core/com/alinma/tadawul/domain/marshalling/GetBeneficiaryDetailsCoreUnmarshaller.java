package com.alinma.tadawul.domain.marshalling;

import java.util.Hashtable;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.Beneficiary;
import com.alinma.tadawul.domain.lov.BeneficiaryStatus;
import com.alinma.tadawul.domain.lov.BeneficiaryType;
import com.alinma.tadawul.domain.lov.DetailsOfCharge;
import com.alinma.tadawul.domain.lov.FundTransferPurpose;
import com.alinma.tadawul.domain.messages.response.GetBeneficiaryDetailsResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * 
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiaryDetailsCoreUnmarshaller implements Unmarshaller {

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		try {
			MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			GetBeneficiaryDetailsResMsgCore msgCore = new GetBeneficiaryDetailsResMsgCore();
			Beneficiary beneficiary = null;
			if (context != null && context.getAssociatedBOs() != null) {
				beneficiary = (Beneficiary) context.getAssociatedBOs().get(Beneficiary.class.getName());
			}
			if (beneficiary == null) {
				beneficiary = new Beneficiary();
			}
			if (msgParsed.get("BenCode") != null) {
				beneficiary.setCode(msgParsed.get("BenCode"));
			}
			if (msgParsed.get("BenType") != null) {
				beneficiary.setBeneficiaryType(BeneficiaryType.getByCode(msgParsed.get("BenType")));
			}
			if (msgParsed.get("Nickname") != null) {
				beneficiary.setNickName(msgParsed.get("Nickname"));
			}
			if (msgParsed.get("FullName") != null) {
				beneficiary.getName().setFullName(msgParsed.get("FullName"));
			}
			if (msgParsed.get("CountryCode") != null) {
				beneficiary.setCountry(new EntityDefaultKey(msgParsed.get("CountryCode")));
			}
			if (msgParsed.get("Addr") != null) {
				beneficiary.setAddress(msgParsed.get("Addr"));
			}
			if (msgParsed.get("PhoneNum") != null) {
				beneficiary.setPhoneNum(msgParsed.get("PhoneNum"));
			}
			if (msgParsed.get("POI/POINum") != null) {
				beneficiary.getIdDocKey().setIdNumber((msgParsed.get("POI/POINum")));
			}
			if (msgParsed.get("POI/POIType") != null) {
				beneficiary.getIdDocKey().setIdDocType(new EntityDefaultKey(msgParsed.get("POI/POIType")));
			}
			if (msgParsed.get("CurCode") != null) {
				beneficiary.setCurrency(new EntityDefaultKey(msgParsed.get("CurCode")));
			}
			if (msgParsed.get("DfltAmt") != null) {
				beneficiary.setDefualtAmount((msgParsed.get("DfltAmt")));
			}
			if (msgParsed.get("BenType") != null && msgParsed.get("BenType").equalsIgnoreCase("1")) {
				if (msgParsed.get("AcctId/AcctNum") != null) {
					beneficiary.getAccount().setAccountNumber(msgParsed.get("AcctId/AcctNum"));
				}
				if (msgParsed.get("AcctId/AcctType") != null) {
					beneficiary.getAccount().setAccountType(new EntityDefaultKey(msgParsed.get("AcctId/AcctType")));
				}
			} else {
				if (msgParsed.get("BenAcctNum") != null) {
					beneficiary.getAccount().setAccountNumber(msgParsed.get("BenAcctNum"));
				}
			}
			if (msgParsed.get("IsIBAN") != null && msgParsed.get("IsIBAN").equalsIgnoreCase("Y")) {
				beneficiary.setIban(true);
			} else if (msgParsed.get("IsIBAN") != null && msgParsed.get("IsIBAN").equalsIgnoreCase("N")) {
				beneficiary.setIban(false);
			}
			if (msgParsed.get("FundXferCoCode") != null) {
				beneficiary.setFundTransferCompany(new EntityDefaultKey(msgParsed.get("FundXferCoCode")));
			}
			if (msgParsed.get("FundXferCoSubCategoryCode") != null) {
				beneficiary.setFundTransferSubCateogry(new EntityDefaultKey(msgParsed.get("FundXferCoSubCategoryCode")));
			}
			if (msgParsed.get("BenBankDtl/BankCode") != null) {
				beneficiary.getBank().setCode(new EntityDefaultKey(msgParsed.get("BenBankDtl/BankCode")));
			}
			if (msgParsed.get("BenBankDtl/BankName") != null) {
				beneficiary.getBank().setBankName(msgParsed.get("BenBankDtl/BankName"));
			}
			if (msgParsed.get("BenBankDtl/BranchName") != null) {
				beneficiary.getBank().setBranchId(new EntityDefaultKey(msgParsed.get("BenBankDtl/BankName")));
			}
			if (msgParsed.get("BenBankDtl/Addr") != null) {
				beneficiary.getBank().setAddress(msgParsed.get("BenBankDtl/Addr"));
			}
			if (msgParsed.get("BenBankDtl/CrrpndngBank") != null) {
				beneficiary.setCorresponding(msgParsed.get("BenBankDtl/CrrpndngBank"));
			}
			if (msgParsed.get("BenBankDtl/IntermediateBankCode") != null) {
				beneficiary.setIntermediateCode(msgParsed.get("BenBankDtl/IntermediateBankCode"));
			}
			if (msgParsed.get("FundXferPurpose") != null) {
				beneficiary.setFundTransferPurpose((FundTransferPurpose.getByCode(msgParsed.get("FundXferPurpose"))));
			}
			if (msgParsed.get("DtlOfCharge") != null) {
				beneficiary.setDetailsOfCharge(DetailsOfCharge.getByCode(msgParsed.get("DtlOfCharge")));
			}
			if (msgParsed.get("BenStatus") != null) {
				beneficiary.setStatus(BeneficiaryStatus.getByCode(msgParsed.get("BenStatus")));
			}
			if (msgParsed.get("PmtDesc") != null) {
				beneficiary.setPaymentDesc(msgParsed.get("PmtDesc"));
			}
			if (msgParsed.get("RejectionReason") != null) {
				beneficiary.setRejectReason(msgParsed.get("RejectionReason"));
			}
			msgCore.setBeneficiary(beneficiary);
			ResponseMessageBody<GetBeneficiaryDetailsResMsgCore> resMsgBody = new ResponseMessageBody<GetBeneficiaryDetailsResMsgCore>();
			resMsgBody.setBodyCore(msgCore);
			return resMsgBody;
		} catch (UnmarshallingException e) {
			throw e;
		} catch (XMLStreamException e) {
			throw new UnmarshallingException(e);
		}
	}

	public String getElementString() {
		// TODO Auto-generated method stub
		return null;
	}
}
