package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.alinma.tadawul.domain.messages.request.GetBeneficiaryDetailsReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class GetBeneficiaryDetailsCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		GetBeneficiaryDetailsReqMsgCore ReqMsgCore = (GetBeneficiaryDetailsReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			if (ReqMsgCore.getBeneficiary().getCode() != null) {
				marshallingHelper.createNode(xmlWriter, "BenCode", ReqMsgCore.getBeneficiary().getCode());
			}
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}
}
