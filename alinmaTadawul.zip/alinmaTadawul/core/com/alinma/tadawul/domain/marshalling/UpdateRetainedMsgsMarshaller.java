package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.ejada.commons.dao.messaging.marshalling.MsgMarshaller;

/**
 * 
 * @author mahamoda
 * 
 */
public class UpdateRetainedMsgsMarshaller extends MsgMarshaller {

	@Override
	public void appendMsgStart(XMLStreamWriter xmlWriter) throws XMLStreamException {
		xmlWriter.writeStartElement("RetainedMsgMngRq");
	}
}
