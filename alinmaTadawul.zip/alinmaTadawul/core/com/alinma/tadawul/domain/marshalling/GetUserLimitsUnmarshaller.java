/**
 * 
 */
package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamReader;

import com.ejada.commons.dao.messages.MessageBodyCore;
import com.ejada.commons.dao.messages.broker.ResponseMessage;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.exceptions.UnmarshallingException;
import com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller;
import com.alinma.tadawul.domain.messages.response.ManageRegistrationResMsg;
import com.alinma.tadawul.domain.messages.response.GetUserLimitsResMsg;

/**
 * @author Hani Younis
 * 
 */
public class GetUserLimitsUnmarshaller extends MsgUnmarshaller {

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#createResponseMessage()
	 */
	@Override
	protected GetUserLimitsResMsg createResponseMessage() {
		return new GetUserLimitsResMsg();
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.dao.messaging.marshalling.MsgUnmarshaller#getElementString()
	 */
	@Override
	public String getElementString() {
		return "UsrLimitsInqRs";
	}
}
