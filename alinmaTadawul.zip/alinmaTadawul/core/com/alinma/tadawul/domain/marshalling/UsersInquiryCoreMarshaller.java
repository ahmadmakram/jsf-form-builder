package com.alinma.tadawul.domain.marshalling;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.alinma.tadawul.domain.TadawulUser;
import com.alinma.tadawul.domain.messages.request.UsersInquiryReqMsgCore;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.Marshaller;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.exceptions.MarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class UsersInquiryCoreMarshaller implements Marshaller {

	public void marshal(XMLStreamWriter xmlWriter, Object obj, Context context) throws MarshallingException {
		UsersInquiryReqMsgCore usersInquiryReqMsgCore = (UsersInquiryReqMsgCore) obj;
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		try {
			marshalUserID(marshallingHelper, xmlWriter, usersInquiryReqMsgCore.getTadawulUser());
		} catch (XMLStreamException e) {
			throw new MarshallingException(e);
		}
	}

	private void marshalUserID(MarshallingHelper marshallingHelper, XMLStreamWriter xmlWriter, TadawulUser tadawulUser) throws XMLStreamException {
		if (tadawulUser.getUserId() != null) {
			marshallingHelper.createNode(xmlWriter, "UsrId", tadawulUser.getUserId());
		}
	}
}
