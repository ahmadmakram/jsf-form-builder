package com.alinma.tadawul.domain.marshalling;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.alinma.tadawul.domain.AccountTransaction;
import com.alinma.tadawul.domain.StatementCycle;
import com.alinma.tadawul.domain.StatementDetails;
import com.alinma.tadawul.domain.lov.TransactionType;
import com.alinma.tadawul.domain.messages.response.StatementDetailsInquiryResMsgCore;
import com.ejada.commons.dao.messages.broker.ResponseMessageBody;
import com.ejada.commons.dao.messaging.marshalling.Context;
import com.ejada.commons.dao.messaging.marshalling.MarshallingHelper;
import com.ejada.commons.dao.messaging.marshalling.Unmarshaller;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.PaginationOutRec;
import com.ejada.commons.exceptions.UnmarshallingException;

/**
 * @author Khalid AlQahtani
 * 
 */
public class StatementDetailsInquiryCoreUnmarshaller implements Unmarshaller {

	public String getElementString() {
		return null;
	}

	public Object unmarshal(XMLStreamReader xmlReader, Context context) throws UnmarshallingException {
		MarshallingHelper marshallingHelper = MarshallingHelper.getInstance();
		StatementDetailsInquiryResMsgCore msgCore = new StatementDetailsInquiryResMsgCore();
		try {
			Hashtable<String, String> msgParsed = marshallingHelper.parseXML(xmlReader);
			StatementDetails statementDetails = new StatementDetails();
			PaginationOutRec pagination = null;
			AccountTransaction accountTransaction;
			StatementCycle statementCycle = new StatementCycle();
			List<AccountTransaction> accountTransactionlist = new ArrayList<AccountTransaction>();
			CombinedDate startDate = new CombinedDate();
			CombinedDate endDate = new CombinedDate();
			if (msgParsed.get("RecCtrlOut/SentRecs") != null) {
				pagination = new PaginationOutRec(new Integer(msgParsed.get("RecCtrlOut/MatchedRecs")), new Integer(msgParsed.get("RecCtrlOut/SentRecs")));
			}
			if (msgParsed.get("AcctId/AcctNum") != null) {
				statementDetails.setAccountNum(msgParsed.get("AcctNum"));
			}
			if (msgParsed.get("AcctId/AcctType") != null) {
				statementDetails.setAccountType(new EntityDefaultKey(msgParsed.get("AcctId/AcctType")));
			}
			if (msgParsed.get("CustInfo/AlinmaId") != null) {
				statementDetails.setAlinmaId(msgParsed.get("CustInfo/AlinmaId"));
			}
			if (msgParsed.get("CustInfo/FullName") != null) {
				statementDetails.setFullName(msgParsed.get("CustInfo/FullName"));
			}
			if (msgParsed.get("CustInfo/BranchId") != null) {
				statementDetails.setBranchId(msgParsed.get("CustInfo/BranchId"));
			}
			if (msgParsed.get("CustInfo/Addr") != null) {
				statementDetails.setAddress(msgParsed.get("CustInfo/Addr"));
			}
			if (msgParsed.get("FromDt") != null) {
				startDate.setDate(msgParsed.get("FromDt"));
			}
			if (msgParsed.get("ToDt") != null) {
				endDate.setDate(msgParsed.get("ToDt"));
			}
			if (msgParsed.get("AcctCur") != null) {
				statementDetails.setAccountCurr(new EntityDefaultKey(msgParsed.get("AcctCur")));
			}
			if (msgParsed.get("OpeningBal") != null) {
				statementDetails.setOpeningBal(msgParsed.get("OpeningBal"));
			}
			if (msgParsed.get("ClosingBal") != null) {
				statementDetails.setClosingBal(msgParsed.get("ClosingBal"));
			}
			if (msgParsed.get("TotalDebitAmt") != null) {
				statementDetails.setTotalDebitAmt(msgParsed.get("TotalDebitAmt"));
			}
			if (msgParsed.get("TotalCreditAmt") != null) {
				statementDetails.setTotalCreditAmt(msgParsed.get("TotalCreditAmt"));
			}
			if (msgParsed.get("CardNum") != null) {
				statementDetails.setCardNum(msgParsed.get("CardNum"));
			}
			if (msgParsed.get("AcctCreditLimit") != null) {
				statementDetails.setAcctCreditLimit(msgParsed.get("AcctCreditLimit"));
			}
			if (msgParsed.get("TotalCashAdvance") != null) {
				statementDetails.setTotalCashAdvance(msgParsed.get("TotalCashAdvance"));
			}
			if (msgParsed.get("NumOfCashAdvance") != null) {
				statementDetails.setNumOfCashAdvance(msgParsed.get("NumOfCashAdvance"));
			}
			if (msgParsed.get("TotalPurchases") != null) {
				statementDetails.setTotalPurchases(msgParsed.get("TotalPurchases"));
			}
			if (msgParsed.get("NumOfPurchases") != null) {
				statementDetails.setTotalPurchases(msgParsed.get("NumOfPurchases"));
			}
			String repetition = "TrnsList/StmtTrnInfo/";
			int i = 1;
			while (msgParsed.get(repetition + "TrnRefNum") != null) {
				accountTransaction = new AccountTransaction();
				accountTransaction.setTransactionReferenceNumber(msgParsed.get(repetition + "TrnRefNum"));
				if (msgParsed.get(repetition + "TrnCode") != null) {
					accountTransaction.setTransactionCode(new EntityDefaultKey(msgParsed.get(repetition + "TrnCode")));
				}
				if (msgParsed.get(repetition + "TrnType") != null) {
					accountTransaction.setTransactionType(TransactionType.getByCode((msgParsed.get(repetition + "TrnType"))));
				}
				if (msgParsed.get(repetition + "CurAmt/Amt") != null) {
					accountTransaction.getAmount().setAmount((msgParsed.get(repetition + "CurAmt/Amt")));
				}
				if (msgParsed.get(repetition + "CurAmt/CurCode") != null) {
					accountTransaction.getAmount().setCurrencyCode(new EntityDefaultKey(msgParsed.get(repetition + "CurAmt/CurCode")));
				}
				if (msgParsed.get(repetition + "CurAmt/CurRate") != null) {
					accountTransaction.getAmount().setCurrencyRate((msgParsed.get(repetition + "CurAmt/CurRate")));
				}
				if (msgParsed.get(repetition + "CurAmt/AmtLcl") != null) {
					accountTransaction.getAmount().setLocalAmount((msgParsed.get(repetition + "CurAmt/AmtLcl")));
				}
				if (msgParsed.get(repetition + "StmtEntryId") != null) {
					accountTransaction.setStatementIdentifier((msgParsed.get(repetition + "StmtEntryId")));
				}
				CombinedDate transactionDateTime = null;
				if (msgParsed.get(repetition + "TrnDt") != null && msgParsed.get(repetition + "TrnTm") != null) {
					transactionDateTime = new CombinedDate(msgParsed.get(repetition + "TrnDt"), msgParsed.get(repetition + "TrnTm"));
				}
				if (msgParsed.get(repetition + "TrnDtHjr") != null) {
					if (transactionDateTime != null) {
						transactionDateTime.setHijriDate(msgParsed.get(repetition + "TrnDtHjr"));
					}
				}
				accountTransaction.setTransactionDateTime(transactionDateTime);
				String narrativeRepate = repetition + "TrnNarr";
				int j = 1;
				List<String> narrativeTrans = null;
				if (msgParsed.get(narrativeRepate) != null) {
					narrativeTrans = new ArrayList<String>();
					while (msgParsed.get(narrativeRepate) != null) {
						narrativeTrans.add(msgParsed.get(narrativeRepate));
						if (accountTransaction.getDescription() != null && accountTransaction.getDescription().length() > 0)
							accountTransaction.setDescription(accountTransaction.getDescription() + " - " + msgParsed.get(narrativeRepate));
						else {
							accountTransaction.setDescription(msgParsed.get(narrativeRepate));
						}
						narrativeRepate = repetition + "TrnNarr[" + j + "]/";
						j++;
					}
					accountTransaction.setTransactionNarrative(narrativeTrans);
				}
				if (msgParsed.get(repetition + "ChanId") != null) {
					// accountTransaction.setChannelId(ChannelId.getByCode(msgParsed.get(repetition
					// + "ChanId")));
					accountTransaction.setChannelId(new EntityDefaultKey(msgParsed.get(repetition + "ChanId")));
				}
				accountTransactionlist.add(accountTransaction);
				repetition = "TrnsList/StmtTrnInfo[" + i + "]/";
				i++;
			}
			statementCycle.setStartDate(startDate);
			statementCycle.setEndDate(endDate);
			statementDetails.setStatementCycle(statementCycle);
			statementDetails.setAccountTransactions(accountTransactionlist);
			ResponseMessageBody<StatementDetailsInquiryResMsgCore> msgResBody = new ResponseMessageBody<StatementDetailsInquiryResMsgCore>();
			msgCore.setStatementDetails(statementDetails);
			msgCore.setPaginationOutRec(pagination);
			msgResBody.setBodyCore(msgCore);
			return msgResBody;
		} catch (XMLStreamException ex) {
			throw new UnmarshallingException(ex);
		}
	}
}
