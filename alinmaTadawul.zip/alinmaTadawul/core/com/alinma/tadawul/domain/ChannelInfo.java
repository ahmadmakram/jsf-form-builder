package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

public class ChannelInfo extends BusinessObject {

	private EntityKey channelId;
	private EntityKey preferredLang;
	private String defaultUserAccountNumber;
	private EntityKey vacationStatus;
	private String vacationFromDate;
	private String vacationToDate;
	private UserCredential userCredential;
	private String securityHint;
	private String welcomeMessage;
	private String displayMessage;
	private EntityKey channelStatus;
	private String activationChannel;
	private int numberOfFailedLogins;
	private CombinedDate regstrationDateTime;
	private CombinedDate lastFailedLoginDateTime;
	private CombinedDate lastSuccessLoginDateTime;
	private CombinedDate lastPasswordChangeDateTime;
	private Boolean displayMarketingMsg;
	private String themeId;
	private Integer sessionTimeout;
	private Boolean showSessionHistory;

	public EntityKey getPreferredLang() {
		return preferredLang;
	}

	public void setPreferredLang(EntityKey preferredLang) {
		this.preferredLang = preferredLang;
	}

	public String getDefaultUserAccountNumber() {
		return defaultUserAccountNumber;
	}

	public void setDefaultUserAccountNumber(String defaultUserAccountNumber) {
		this.defaultUserAccountNumber = defaultUserAccountNumber;
	}

	public EntityKey getVacationStatus() {
		return vacationStatus;
	}

	public void setVacationStatus(EntityKey vacationStatus) {
		this.vacationStatus = vacationStatus;
	}

	public String getVacationFromDate() {
		return vacationFromDate;
	}

	public void setVacationFromDate(String vacationFromDate) {
		this.vacationFromDate = vacationFromDate;
	}

	public String getVacationToDate() {
		return vacationToDate;
	}

	public void setVacationToDate(String vacationToDate) {
		this.vacationToDate = vacationToDate;
	}

	public EntityKey getChannelId() {
		return channelId;
	}

	public void setChannelId(EntityKey channelId) {
		this.channelId = channelId;
	}

	public UserCredential getUserCredential() {
		if (this.userCredential == null) {
			this.userCredential = new UserCredential();
		}
		return userCredential;
	}

	public void setUserCredential(UserCredential userCredential) {
		this.userCredential = userCredential;
	}

	public String getSecurityHint() {
		return securityHint;
	}

	public void setSecurityHint(String securityHint) {
		this.securityHint = securityHint;
	}

	public String getWelcomeMessage() {
		return welcomeMessage;
	}

	public void setWelcomeMessage(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}

	public String getDisplayMessage() {
		return displayMessage;
	}

	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}

	public EntityKey getChannelStatus() {
		return channelStatus;
	}

	public void setChannelStatus(EntityKey channelStatus) {
		this.channelStatus = channelStatus;
	}

	public String getActivationChannel() {
		return activationChannel;
	}

	public void setActivationChannel(String activationChannel) {
		this.activationChannel = activationChannel;
	}

	public CombinedDate getRegstrationDateTime() {
		return regstrationDateTime;
	}

	public void setRegstrationDateTime(CombinedDate regstrationDateTime) {
		this.regstrationDateTime = regstrationDateTime;
	}

	public CombinedDate getLastFailedLoginDateTime() {
		return lastFailedLoginDateTime;
	}

	public void setLastFailedLoginDateTime(CombinedDate lastFailedLoginDateTime) {
		this.lastFailedLoginDateTime = lastFailedLoginDateTime;
	}

	public CombinedDate getLastSuccessLoginDateTime() {
		return lastSuccessLoginDateTime;
	}

	public void setLastSuccessLoginDateTime(CombinedDate lastSuccessLoginDateTime) {
		this.lastSuccessLoginDateTime = lastSuccessLoginDateTime;
	}

	public CombinedDate getLastPasswordChangeDateTime() {
		return lastPasswordChangeDateTime;
	}

	public void setLastPasswordChangeDateTime(CombinedDate lastPasswordChangeDateTime) {
		this.lastPasswordChangeDateTime = lastPasswordChangeDateTime;
	}

	public void setNumberOfFailedLogins(int numberOfFailedLogins) {
		this.numberOfFailedLogins = numberOfFailedLogins;
	}

	public int getNumberOfFailedLogins() {
		return numberOfFailedLogins;
	}

	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (userCredential != null) {
			userCredential.CommitUpdates();
		}
	}

	public static ChannelInfo createChannelInfo() {
		return new ChannelInfo();
	}

	public void setDispalyMarketingMsg(Boolean DispalyMarketingMsg) {
		this.displayMarketingMsg = DispalyMarketingMsg;
	}

	public Boolean getDispalyMarketingMsg() {
		return displayMarketingMsg;
	}

	public String getThemeId() {
		return themeId;
	}

	public void setThemeId(String themeId) {
		this.themeId = themeId;
	}

	public Integer getSessionTimeout() {
		return sessionTimeout;
	}

	public void setSessionTimeout(Integer sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	public Boolean getShowSessionHistory() {
		return showSessionHistory;
	}

	public void setShowSessionHistory(Boolean showSessionHistory) {
		this.showSessionHistory = showSessionHistory;
	}
}
