package com.alinma.tadawul.domain;

import org.hibernate.validator.NotNull;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.Language;
import com.ejada.commons.domain.Name;
import com.ejada.commons.services.ServiceReturnRec;

public class CustomerPersonalInfo extends BusinessObject {

	private EntityKey title;
	private EntityKey gender;
	private CombinedDate dateOfBirth;
	private EntityKey nationality;
	private EntityKey maritalStatus;
	private String placeOfBirth;
	private Boolean blindWitness;
	private Boolean illiterate;
	private Boolean minor;
	private Boolean veiledWoman;
	private Boolean politicallyExposed;
	private Boolean mentalyDisabled;
	private Boolean incompetentSaudi;
	private Boolean specialChild;
	private EntityKey nameLanguage;
	private Name customerNameEn;
	private Name customerNameAr;
	private Float age = Float.valueOf(0);
	private EntityKey totalAnnualIncome;
	private EntityKey netWorth;
	private Boolean directorOfficer;
	private Boolean selfActivity;

	@NotNull(message = "{customerPersonalInfo.titleRequired}")
	public EntityKey getTitle() {
		return title;
	}

	public void setTitle(EntityKey title) {
		this.title = title;
	}

	public EntityKey getGender() {
		return gender;
	}

	public void setGender(EntityKey gender) {
		this.gender = gender;
	}

	public CombinedDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(CombinedDate dateOfBirth) {
		// if(dateOfBirth != null){
		// if (!dateOfBirth.equals(this.dateOfBirth)) {
		// ServiceReturnRec<Float> returnRec =
		// CustomerAgeInquiryFactory.getService().getCustomerAge(dateOfBirth, null);
		// if(returnRec.successfulReturn()) {
		// age = returnRec.getReturnedObject();
		// } else {
		// age = Float.valueOf(0);
		// }
		// }
		// } else {
		// age = Float.valueOf(0);
		// }
		this.dateOfBirth = dateOfBirth;
	}

	@NotNull(message = "{customerPersonalInfo.nationalityRequired}")
	public EntityKey getNationality() {
		return nationality;
	}

	public void setNationality(EntityKey nationality) {
		this.nationality = nationality;
	}

	public EntityKey getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(EntityKey maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public Boolean getBlindWitness() {
		return blindWitness;
	}

	public void setBlindWitness(Boolean blindWitness) {
		this.blindWitness = blindWitness;
	}

	public Boolean getIlliterate() {
		return illiterate;
	}

	public void setIlliterate(Boolean illiterate) {
		this.illiterate = illiterate;
	}

	public Boolean getMinor() {
		return minor;
	}

	public void setMinor(Boolean minor) {
		this.minor = minor;
	}

	public Boolean getVeiledWoman() {
		return veiledWoman;
	}

	public void setVeiledWoman(Boolean veiledWoman) {
		this.veiledWoman = veiledWoman;
	}

	public Boolean getPoliticallyExposed() {
		return politicallyExposed;
	}

	public void setPoliticallyExposed(Boolean politicallyExposed) {
		this.politicallyExposed = politicallyExposed;
	}

	public Boolean getMentalyDisabled() {
		return mentalyDisabled;
	}

	public void setMentalyDisabled(Boolean mentalyDisabled) {
		this.mentalyDisabled = mentalyDisabled;
	}

	public Boolean getIncompetentSaudi() {
		return incompetentSaudi;
	}

	public void setIncompetentSaudi(Boolean incompetentSaudi) {
		this.incompetentSaudi = incompetentSaudi;
	}

	public Boolean getSpecialChild() {
		return specialChild;
	}

	public void setSpecialChild(Boolean specialChild) {
		this.specialChild = specialChild;
	}

	@NotNull(message = "{customerPersonalInfo.nameLanguageRequired}")
	public EntityKey getNameLanguage() {
		return nameLanguage;
	}

	public void setNameLanguage(EntityKey nameLanguage) {
		this.nameLanguage = nameLanguage;
	}

	public Name getCustomerNameEn() {
		if (this.customerNameEn == null) {
			this.customerNameEn = createCustomerNameEn();
		}
		return customerNameEn;
	}

	public Name createCustomerNameEn() {
		return (Name) ApplicationContextFactory.getApplicationContext().getBean("name");
	}

	public void setCustomerNameEn(Name customerNameEn) {
		this.customerNameEn = customerNameEn;
	}

	public Name getCustomerNameAr() {
		if (this.customerNameAr == null) {
			this.customerNameAr = createCustomerNameAr();
		}
		return customerNameAr;
	}

	public Name createCustomerNameAr() {
		return (Name) ApplicationContextFactory.getApplicationContext().getBean("name");
	}

	public void setCustomerNameAr(Name customerNameAr) {
		this.customerNameAr = customerNameAr;
	}

	@NotNull(message = "{customerPersonalInfo.totalAnnualIncomeRequired}")
	public EntityKey getTotalAnnualIncome() {
		return totalAnnualIncome;
	}

	public void setTotalAnnualIncome(EntityKey totalAnnualIncome) {
		this.totalAnnualIncome = totalAnnualIncome;
	}

	@NotNull(message = "{customerPersonalInfo.netWorthRequired}")
	public EntityKey getNetWorth() {
		return netWorth;
	}

	public void setNetWorth(EntityKey netWorth) {
		this.netWorth = netWorth;
	}

	public Boolean getSelfActivity() {
		return selfActivity;
	}

	public void setSelfActivity(Boolean selfActivity) {
		this.selfActivity = selfActivity;
	}

	public Boolean getDirectorOfficer() {
		return directorOfficer;
	}

	public void setDirectorOfficer(Boolean directorOfficer) {
		this.directorOfficer = directorOfficer;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (customerNameEn != null) {
			customerNameEn.CommitUpdates();
		}
		if (customerNameAr != null) {
			customerNameAr.CommitUpdates();
		}
	}

	public Name getDefaultCustomerName() {
		if (this.getNameLanguage() != null && this.getNameLanguage().equals(Language.ARABIC)) {
			return getCustomerNameAr();
		} else {
			return getCustomerNameEn();
		}
	}

	/**
	 * @return the age
	 */
	public Float getAge() {
		return age;
	}
}
