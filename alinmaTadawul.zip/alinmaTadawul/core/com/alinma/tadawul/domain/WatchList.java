package com.alinma.tadawul.domain;

import java.util.ArrayList;
import java.util.List;

public class WatchList {

	private String listId;
	private String nickName;
	private List<Symbol> symbols = new ArrayList<Symbol>();
	private Boolean defaultValue;
	private int symbolsCount;
	private String type;
	private String nickNameAr;

	public int getSymbolsCount() {
		if (symbols != null) {
			symbolsCount = symbols.size();
		}
		return symbolsCount;
	}

	public Boolean getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(Boolean defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getListId() {
		return listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String neckName) {
		this.nickName = neckName;
	}

	public List<Symbol> getSymbols() {
		return symbols;
	}

	public void setSymbols(List<Symbol> symbols) {
		this.symbols = symbols;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getNickNameAr() {
		return nickNameAr;
	}

	public void setNickNameAr(String nickNameAr) {
		this.nickNameAr = nickNameAr;
	}
}
