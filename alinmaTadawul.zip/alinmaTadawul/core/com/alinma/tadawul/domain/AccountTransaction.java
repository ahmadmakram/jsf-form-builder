package com.alinma.tadawul.domain;

import java.util.ArrayList;
import java.util.List;

import com.alinma.tadawul.domain.lov.TransactionType;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.lov.ChannelId;

/**
 * 
 * @author Hani Younis
 * 
 */
public class AccountTransaction {

	private String transactionReferenceNumber;
	private EntityKey transactionCode;
	private TransactionType transactionType;
	private Amount amount;
	private String statementIdentifier;
	private CombinedDate transactionDateTime;
	private EntityKey channelId;
	private List<String> transactionNarrative;
	private String description;
	private String memo;
	private double runningBalance;

	public String getTransactionReferenceNumber() {
		return transactionReferenceNumber;
	}

	public void setTransactionReferenceNumber(String transactionReferenceNumber) {
		this.transactionReferenceNumber = transactionReferenceNumber;
	}

	public EntityKey getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(EntityKey transactionCode) {
		this.transactionCode = transactionCode;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public void setStatementIdentifier(String statementIdentifier) {
		this.statementIdentifier = statementIdentifier;
	}

	public String getStatementIdentifier() {
		return statementIdentifier;
	}

	public CombinedDate getTransactionDateTime() {
		return transactionDateTime;
	}

	public void setTransactionDateTime(CombinedDate transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	public EntityKey getChannelId() {
		return channelId;
	}

	public void setChannelId(EntityKey channelId) {
		this.channelId = channelId;
	}

	public void setTransactionNarrative(List<String> transactionNarrative) {
		this.transactionNarrative = transactionNarrative;
	}

	public List<String> getTransactionNarrative() {
		if (transactionNarrative == null) {
			transactionNarrative = new ArrayList<String>();
		}
		return transactionNarrative;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public Amount getAmount() {
		if (amount == null) {
			amount = createAmount();
		}
		return amount;
	}

	private Amount createAmount() {
		// TODO Auto-generated method stub
		return new Amount();
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public double getRunningBalance() {
		return runningBalance;
	}

	public void setRunningBalance(double runningBalance) {
		this.runningBalance = runningBalance;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}
}
