/**
 * 
 */
package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;

/**
 * The class holds the user credential information.
 * 
 * @author Waleed Tayea
 * 
 */
public class UserCredential extends BusinessObject {

	private String loginName; // Login name
	private String password;
	private String oldPassword;
	private String repeatedPassword;

	public UserCredential() {
	}

	public UserCredential(String loginName, String password) {
		super();
		this.loginName = loginName;
		this.password = password;
	}

	/**
	 * @return the userName
	 */
	public String getLoginName() {
		return loginName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setLoginName(String userId) {
		this.loginName = userId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setRepeatedPassword(String repeatedPassword) {
		this.repeatedPassword = repeatedPassword;
	}

	public String getRepeatedPassword() {
		return repeatedPassword;
	}
}
