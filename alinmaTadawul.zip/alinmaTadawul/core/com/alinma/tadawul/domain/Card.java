package com.alinma.tadawul.domain;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import com.alinma.tadawul.domain.lov.CardShipCode;
import com.alinma.tadawul.domain.lov.DepositType;
import com.alinma.tadawul.domain.lov.PinIssueShipCode;
import com.alinma.tadawul.domain.lov.PinMailingCode;
import com.alinma.tadawul.domain.lov.PinShipCode;
import com.alinma.tadawul.domain.lov.RequestMailingCode;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public class Card extends BusinessObject {

	private String cardNumber;
	private String cardPIN;
	private EntityKey cardType;
	private String custodialBusinessUnitId;
	private EntityKey status;
	private String nickname;
	private CombinedDate activationDateTime;
	private CombinedDate expiryDate;
	private CombinedDate issueDate;
	private EntityKey classId;
	private Boolean reIssueSupported;
	private CardShipCode cardShipCode;
	private PinMailingCode pinMailingCode;
	private PinShipCode pinShipCode;
	private PinIssueShipCode pinIssueShipCode;
	private RequestMailingCode requestMailingCode;
	private String customerNumberPaymentManager;
	private EntityKey businessUnitId;
	private Boolean activeFlag;
	private CombinedDate StatusTimeStamp;
	private String activationElementCode;
	private String activationResultCode;
	private String activationAttemptsNumber;
	private Boolean annualFeeAbate;
	private CombinedDate nextAnnualFeeDate;
	private String linkedAccountsCount;
	private CombinedDate effectiveDate;
	private CombinedDate openDate;
	private String issueNumber;
	private EntityKey defaultLimitID;
	private EntityKey cardLimitID;
	private CombinedDate lastMaintenanceTimeStamp;
	private DepositType depositTypeCode;
	private Boolean generatePinFlag;
	private Boolean addressVerificationRequiredFlag;
	private String dueAmount;
	private String availableBalance;
	private String outstandingBalance;
	private EntityKey printingBranchId;
	private String printerId;
	private String PINPadId;
	private String PINPadPAN;
	private String affiliatedAccountNumber;
	private String cardDueAmountDate;
	private String cardBillingDate;
	private String cardCreditLimit;
	private CardLinkedName cardLinkedName;
	private List<CardLinkedAccount> cardLinkedAccounts;
	private Boolean creditCard;

	public String getCustomerNumberPaymentManager() {
		return customerNumberPaymentManager;
	}

	public void setCustomerNumberPaymentManager(String customerNumberPaymentManager) {
		this.customerNumberPaymentManager = customerNumberPaymentManager;
	}

	public EntityKey getBusinessUnitId() {
		return businessUnitId;
	}

	public void setBusinessUnitId(EntityKey businessUnitId) {
		this.businessUnitId = businessUnitId;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public CombinedDate getStatusTimeStamp() {
		return StatusTimeStamp;
	}

	public void setStatusTimeStamp(CombinedDate statusTimeStamp) {
		StatusTimeStamp = statusTimeStamp;
	}

	public String getActivationElementCode() {
		return activationElementCode;
	}

	public void setActivationElementCode(String activationElementCode) {
		this.activationElementCode = activationElementCode;
	}

	public String getActivationResultCode() {
		return activationResultCode;
	}

	public void setActivationResultCode(String activationResultCode) {
		this.activationResultCode = activationResultCode;
	}

	public String getActivationAttemptsNumber() {
		return activationAttemptsNumber;
	}

	public void setActivationAttemptsNumber(String activationAttemptsNumber) {
		this.activationAttemptsNumber = activationAttemptsNumber;
	}

	public Boolean getAnnualFeeAbate() {
		return annualFeeAbate;
	}

	public void setAnnualFeeAbate(Boolean annualFeeAbate) {
		this.annualFeeAbate = annualFeeAbate;
	}

	public CombinedDate getNextAnnualFeeDate() {
		return nextAnnualFeeDate;
	}

	public void setNextAnnualFeeDate(CombinedDate nextAnnualFeeDate) {
		this.nextAnnualFeeDate = nextAnnualFeeDate;
	}

	public String getLinkedAccountsCount() {
		return linkedAccountsCount;
	}

	public void setLinkedAccountsCount(String linkedAccountsCount) {
		this.linkedAccountsCount = linkedAccountsCount;
	}

	public CombinedDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(CombinedDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public CombinedDate getOpenDate() {
		return openDate;
	}

	public void setOpenDate(CombinedDate openDate) {
		this.openDate = openDate;
	}

	public String getIssueNumber() {
		return issueNumber;
	}

	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}

	public EntityKey getDefaultLimitID() {
		return defaultLimitID;
	}

	public void setDefaultLimitID(EntityKey defaultLimitID) {
		this.defaultLimitID = defaultLimitID;
	}

	public EntityKey getCardLimitID() {
		return cardLimitID;
	}

	public void setCardLimitID(EntityKey cardLimitID) {
		this.cardLimitID = cardLimitID;
	}

	public CombinedDate getLastMaintenanceTimeStamp() {
		return lastMaintenanceTimeStamp;
	}

	public void setLastMaintenanceTimeStamp(CombinedDate lastMaintenanceTimeStamp) {
		this.lastMaintenanceTimeStamp = lastMaintenanceTimeStamp;
	}

	public DepositType getDepositTypeCode() {
		return depositTypeCode;
	}

	public void setDepositTypeCode(DepositType depositTypeCode) {
		this.depositTypeCode = depositTypeCode;
	}

	public Boolean getGeneratePinFlag() {
		return generatePinFlag;
	}

	public void setGeneratePinFlag(Boolean generatePinFlag) {
		this.generatePinFlag = generatePinFlag;
	}

	public Boolean getAddressVerificationRequiredFlag() {
		return addressVerificationRequiredFlag;
	}

	public void setAddressVerificationRequiredFlag(Boolean addressVerificationRequiredFlag) {
		this.addressVerificationRequiredFlag = addressVerificationRequiredFlag;
	}

	public String getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(String dueAmount) {
		this.dueAmount = dueAmount;
	}

	public String getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	public String getOutstandingBalance() {
		return outstandingBalance;
	}

	public void setOutstandingBalance(String outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	public EntityKey getPrintingBranchId() {
		return printingBranchId;
	}

	public void setPrintingBranchId(EntityKey printingBranchId) {
		this.printingBranchId = printingBranchId;
	}

	public String getPrinterId() {
		return printerId;
	}

	public void setPrinterId(String printerId) {
		this.printerId = printerId;
	}

	public String getPINPadId() {
		return PINPadId;
	}

	public void setPINPadId(String padId) {
		PINPadId = padId;
	}

	public String getPINPadPAN() {
		return PINPadPAN;
	}

	public void setPINPadPAN(String padPAN) {
		PINPadPAN = padPAN;
	}

	public String getAffiliatedAccountNumber() {
		return affiliatedAccountNumber;
	}

	public void setAffiliatedAccountNumber(String affiliatedAccountNumber) {
		this.affiliatedAccountNumber = affiliatedAccountNumber;
	}

	public String getCardDueAmountDate() {
		return cardDueAmountDate;
	}

	public String getCardDueAmountFullDate() {
		String cardDueAmountFullDate = "";
		if (cardDueAmountDate != null) {
			cardDueAmountFullDate = figureFullDate(cardDueAmountDate);
		}
		return cardDueAmountFullDate;
	}

	private String figureFullDate(String cardDate) {
		String dateFullDate;
		Calendar calendar = GregorianCalendar.getInstance();
		int today = calendar.get(Calendar.DAY_OF_MONTH);
		if (Integer.parseInt(cardDate) < today) {
			calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + 1);
			calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(cardDate));
		} else {
			calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(cardDate));
		}
		Date date = new Date(calendar.getTimeInMillis());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFullDate = dateFormat.format(date);
		return dateFullDate;
	}

	public void setCardDueAmountDate(String cardDueAmountDate) {
		this.cardDueAmountDate = cardDueAmountDate;
	}

	public String getCardBillingDate() {
		return cardBillingDate;
	}

	public String getCardBillingFullDate() {
		String cardBillingFullDate = "";
		if (cardBillingDate != null) {
			cardBillingFullDate = figureFullDate(cardBillingDate);
		}
		return cardBillingFullDate;
	}

	public void setCardBillingDate(String cardBillingDate) {
		this.cardBillingDate = cardBillingDate;
	}

	public String getCardCreditLimit() {
		return cardCreditLimit;
	}

	public void setCardCreditLimit(String cardCreditLimit) {
		this.cardCreditLimit = cardCreditLimit;
	}

	public CardLinkedName getCardLinkedName() {
		return cardLinkedName;
	}

	public void setCardLinkedName(CardLinkedName cardLinkedName) {
		this.cardLinkedName = cardLinkedName;
	}

	public Card(String cardNum, String cardPIN) {
		this.cardNumber = cardNum;
		this.cardPIN = cardPIN;
	}

	public Card() {
		// Auto-generated constructor stub
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public String getMaskedCardNumber() {
		if (cardNumber != null) {
			int len = cardNumber.length();
			return "xxxx xxxx xxxx " + cardNumber.substring(len - 4, len);
		} else {
			return "";
		}
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardPIN() {
		return cardPIN;
	}

	public void setCardPIN(String cardPIN) {
		this.cardPIN = cardPIN;
	}

	public EntityKey getCardType() {
		return cardType;
	}

	public void setCardType(EntityKey cardType) {
		this.cardType = cardType;
	}

	public String getCustodialBusinessUnitId() {
		return custodialBusinessUnitId;
	}

	public void setCustodialBusinessUnitId(String custodialBusinessUnitId) {
		this.custodialBusinessUnitId = custodialBusinessUnitId;
	}

	public EntityKey getStatus() {
		return status;
	}

	public void setStatus(EntityKey status) {
		this.status = status;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public CombinedDate getActivationDateTime() {
		return activationDateTime;
	}

	public void setActivationDateTime(CombinedDate activationDateTime) {
		this.activationDateTime = activationDateTime;
	}

	public CombinedDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(CombinedDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public CombinedDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(CombinedDate issueDate) {
		this.issueDate = issueDate;
	}

	public EntityKey getClassId() {
		return classId;
	}

	public void setClassId(EntityKey classId) {
		this.classId = classId;
	}

	public Boolean getReIssueSupported() {
		return reIssueSupported;
	}

	public void setReIssueSupported(Boolean reIssueSupported) {
		this.reIssueSupported = reIssueSupported;
	}

	public CardShipCode getCardShipCode() {
		return cardShipCode;
	}

	public void setCardShipCode(CardShipCode cardShipCode) {
		this.cardShipCode = cardShipCode;
	}

	public PinMailingCode getPinMailingCode() {
		return pinMailingCode;
	}

	public void setPinMailingCode(PinMailingCode pinMailingCode) {
		this.pinMailingCode = pinMailingCode;
	}

	public PinShipCode getPinShipCode() {
		return pinShipCode;
	}

	public void setPinShipCode(PinShipCode pinShipCode) {
		this.pinShipCode = pinShipCode;
	}

	public RequestMailingCode getRequestMailingCode() {
		return requestMailingCode;
	}

	public void setRequestMailingCode(RequestMailingCode requestMailingCode) {
		this.requestMailingCode = requestMailingCode;
	}

	public void setPinIssueShipCode(PinIssueShipCode pinIssueShipCode) {
		this.pinIssueShipCode = pinIssueShipCode;
	}

	public PinIssueShipCode getPinIssueShipCode() {
		return pinIssueShipCode;
	}

	public static Card createCard() {
		return new Card();
	}

	public void setCardLinkedAccounts(List<CardLinkedAccount> cardLinkedAccount) {
		this.cardLinkedAccounts = cardLinkedAccount;
	}

	public List<CardLinkedAccount> getCardLinkedAccounts() {
		return cardLinkedAccounts;
	}

	public Boolean getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(Boolean creditCard) {
		this.creditCard = creditCard;
	}
}
