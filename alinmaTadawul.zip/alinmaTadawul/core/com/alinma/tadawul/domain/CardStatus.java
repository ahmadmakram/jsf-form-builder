package com.alinma.tadawul.domain;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Khalid AlQahtani
 * 
 */
public enum CardStatus implements EntityKey {
	OPEN_NORMAL("0", true), OPEN_UNRESTRICTED("100", true), LOST("600", true), STOLEN("700", true), CLOSED("800", false), INACTIVE("inactive", false), BLOCKED("90", false), PICKUP("900", false), RESTRICTED(
			"400", false), PENDING_ACTIVATION("500", false);

	private String code;
	private boolean main;
	private static Map<String, CardStatus> map;
	static {
		map = new Hashtable<String, CardStatus>();
		for (CardStatus value : CardStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	CardStatus(String code, boolean main) {
		this.code = code;
		this.main = main;
	}

	public String getCode() {
		return code;
	}

	public boolean isMain() {
		return main;
	}

	public static CardStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
