package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.lov.CustomerId;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.IdDocKey;
import com.ejada.commons.domain.Name;

public class PartyRelation extends DateAwareEntityImpl {

	private SurrogateKey surrogateKey;
	private SurrogateKey relationContactSurrogateKey;
	private CustomerId customerId;
	private EntityKey legalEntity;
	private EntityKey sublegalEntity;
	private Name name;
	private CombinedDate idDocIssueDate;
	private CombinedDate idDocExpiryDate;
	private IdDocKey idDocKey;
	private EntityKey issueCountry;
	private String issuePlace;
	private Boolean regularIqama = false;
	private EntityKey gender;
	private EntityKey nationality;
	private CombinedDate dateOfBirth;
	private EntityKey relationType;
	private String note;
	private CombinedDate startDate;
	private EntityKey role;
	private EntityKey trustLevel;
	private EntityKey status;
	private MobileInfo mobile;
	private PhoneInfo phone;
	private FaxInfo fax;

	public MobileInfo getMobile() {
		if (mobile == null) {
			mobile = createMobile();
		}
		return mobile;
	}

	public MobileInfo createMobile() {
		return (MobileInfo) ApplicationContextFactory.getApplicationContext().getBean("mobileInfo");
	}

	public void setMobile(MobileInfo mobile) {
		this.mobile = mobile;
	}

	public PhoneInfo getPhone() {
		if (phone == null) {
			phone = createPhone();
		}
		return phone;
	}

	public PhoneInfo createPhone() {
		return (PhoneInfo) ApplicationContextFactory.getApplicationContext().getBean("phoneInfo");
	}

	public void setPhone(PhoneInfo phone) {
		this.phone = phone;
	}

	public FaxInfo getFax() {
		if (fax == null) {
			fax = createFax();
		}
		return fax;
	}

	public FaxInfo createFax() {
		return (FaxInfo) ApplicationContextFactory.getApplicationContext().getBean("faxInfo");
	}

	public void setFax(FaxInfo fax) {
		this.fax = fax;
	}

	public CustomerId getCustomerId() {
		if (customerId == null) {
			customerId = createCustomerId();
		}
		return customerId;
	}

	public CustomerId createCustomerId() {
		return (CustomerId) ApplicationContextFactory.getApplicationContext().getBean("customerId");
	}

	public void setCustomerId(CustomerId customerId) {
		this.customerId = customerId;
	}

	public EntityKey getLegalEntity() {
		return legalEntity;
	}

	public void setLegalEntity(EntityKey legalEntity) {
		this.legalEntity = legalEntity;
	}

	public EntityKey getSublegalEntity() {
		return sublegalEntity;
	}

	public void setSublegalEntity(EntityKey sublegalEntity) {
		this.sublegalEntity = sublegalEntity;
	}

	public Name getName() {
		if (name == null) {
			name = createName();
		}
		return name;
	}

	public Name createName() {
		return (Name) ApplicationContextFactory.getApplicationContext().getBean("name");
	}

	public void setName(Name name) {
		this.name = name;
	}

	public IdDocKey getIdDocKey() {
		if (idDocKey == null) {
			idDocKey = createIdDocKey();
		}
		return idDocKey;
	}

	public IdDocKey createIdDocKey() {
		return (IdDocKey) ApplicationContextFactory.getApplicationContext().getBean("idDocKey");
	}

	public void setIdDocKey(IdDocKey idDocKey) {
		this.idDocKey = idDocKey;
	}

	public EntityKey getIssueCountry() {
		return issueCountry;
	}

	public void setIssueCountry(EntityKey issueCountry) {
		this.issueCountry = issueCountry;
	}

	public String getIssuePlace() {
		return issuePlace;
	}

	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}

	public Boolean getRegularIqama() {
		return regularIqama;
	}

	public void setRegularIqama(Boolean regularIqama) {
		this.regularIqama = regularIqama;
	}

	public EntityKey getGender() {
		return gender;
	}

	public void setGender(EntityKey gender) {
		this.gender = gender;
	}

	public EntityKey getNationality() {
		return nationality;
	}

	public void setNationality(EntityKey nationality) {
		this.nationality = nationality;
	}

	public CombinedDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(CombinedDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public EntityKey getRelationType() {
		return relationType;
	}

	public void setRelationType(EntityKey relationType) {
		this.relationType = relationType;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public CombinedDate getStartDate() {
		return startDate;
	}

	public void setStartDate(CombinedDate startDate) {
		this.startDate = startDate;
	}

	public EntityKey getRole() {
		return role;
	}

	public void setRole(EntityKey role) {
		this.role = role;
	}

	public EntityKey getTrustLevel() {
		return trustLevel;
	}

	public void setTrustLevel(EntityKey trustLevel) {
		this.trustLevel = trustLevel;
	}

	public EntityKey getStatus() {
		return status;
	}

	public void setStatus(EntityKey status) {
		this.status = status;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		// TODO Auto-generated method stub
		super.CommitUpdates();
		if (customerId != null) {
			customerId.CommitUpdates();
		}
		if (name != null) {
			name.CommitUpdates();
		}
		if (idDocKey != null) {
			idDocKey.CommitUpdates();
		}
	}

	/**
	 * @return the idDocIssueDate
	 */
	public CombinedDate getIdDocIssueDate() {
		return idDocIssueDate;
	}

	/**
	 * @param idDocIssueDate
	 *            the idDocIssueDate to set
	 */
	public void setIdDocIssueDate(CombinedDate idDocIssueDate) {
		this.idDocIssueDate = idDocIssueDate;
	}

	/**
	 * @return the idDocExpiryDate
	 */
	public CombinedDate getIdDocExpiryDate() {
		return idDocExpiryDate;
	}

	/**
	 * @param idDocExpiryDate
	 *            the idDocExpiryDate to set
	 */
	public void setIdDocExpiryDate(CombinedDate idDocExpiryDate) {
		this.idDocExpiryDate = idDocExpiryDate;
	}

	public SurrogateKey getRelationContactSurrogateKey() {
		if (relationContactSurrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			relationContactSurrogateKey = new SurrogateKey(key);
		}
		return relationContactSurrogateKey;
	}

	public void setRelationContactSurrogateKey(SurrogateKey relationContactSurrogateKey) {
		this.relationContactSurrogateKey = relationContactSurrogateKey;
	}
}
