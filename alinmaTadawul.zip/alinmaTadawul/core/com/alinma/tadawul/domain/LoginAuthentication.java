package com.alinma.tadawul.domain;

import java.sql.Time;
import java.util.List;
import java.util.Map;

public class LoginAuthentication {

	private Map<String, String> authentGrpsNames;
	private Map<String, List<FunctionAuthentMethod>> funAuthentGrps;
	private List<String> authGroupsKeysList;
	private List<TransactionCredential> transactionCredentialList;
	private boolean AuthenticateInputs = false;
	private boolean AuthenticationOptions = false;
	private boolean AdviceMsg = false;
	private String loginNameTemp;
	private TadawulUser tempUser;
	private int tokenTrials;
	private Time validTokenRemaining;

	public boolean isShowAuthenticateInputs() {
		return AuthenticateInputs;
	}

	public void setShowAuthenticateInputs(boolean showAuthenticateInputs) {
		this.AuthenticateInputs = showAuthenticateInputs;
	}

	public boolean isShowAuthenticationOptions() {
		return AuthenticationOptions;
	}

	public void setShowAuthenticationOptions(boolean showAuthenticationOptions) {
		this.AuthenticationOptions = showAuthenticationOptions;
	}

	public boolean isShowAdviceMsg() {
		return AdviceMsg;
	}

	public void setShowAdviceMsg(boolean showAdviceMsg) {
		this.AdviceMsg = showAdviceMsg;
	}

	public Map<String, String> getAuthentGrpsNames() {
		return authentGrpsNames;
	}

	public void setAuthentGrpsNames(Map<String, String> authentGrpsNames) {
		this.authentGrpsNames = authentGrpsNames;
	}

	public Map<String, List<FunctionAuthentMethod>> getFunAuthentGrps() {
		return funAuthentGrps;
	}

	public void setFunAuthentGrps(Map<String, List<FunctionAuthentMethod>> funAuthentGrps) {
		this.funAuthentGrps = funAuthentGrps;
	}

	public List<String> getAuthGroupsKeysList() {
		return authGroupsKeysList;
	}

	public void setAuthGroupsKeysList(List<String> authGroupsList) {
		this.authGroupsKeysList = authGroupsList;
	}

	public List<TransactionCredential> getTransactionCredentialList() {
		return transactionCredentialList;
	}

	public void setTransactionCredentialList(List<TransactionCredential> transactionCredentialList) {
		this.transactionCredentialList = transactionCredentialList;
	}

	public String getLoginNameTemp() {
		return loginNameTemp;
	}

	public void setLoginNameTemp(String loginNameTemp) {
		this.loginNameTemp = loginNameTemp;
	}

	public TadawulUser getTempUser() {
		return tempUser;
	}

	public void setTempUser(TadawulUser tempUser) {
		this.tempUser = tempUser;
	}

	public int getTokenTrials() {
		return tokenTrials;
	}

	public void setTokenTrials(int tokenTrials) {
		this.tokenTrials = tokenTrials;
	}

	public Time getValidTokenRemaining() {
		return validTokenRemaining;
	}

	public void setValidTokenRemaining(Time validTokenRemaining) {
		this.validTokenRemaining = validTokenRemaining;
	}
}
