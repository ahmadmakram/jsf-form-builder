/**
 * 
 */
package com.alinma.tadawul.domain;

import com.alinma.tadawul.market.domain.lov.CustLimitType;
import com.ejada.commons.domain.BusinessObject;

/**
 * @author Mahmoud Al Selwadi
 * 
 */
public class Customerlimit extends BusinessObject {

	private Amount minimumLimit;
	private Amount usageAmount;
	private Amount availableLimit;
	private Amount stpMinimumLimit;
	private Amount stpAvailableLimit;
	private String numOftrans;
	private CustLimitType custLimitType;

	public CustLimitType getCustLimitType() {
		return custLimitType;
	}

	public void setCustLimitType(CustLimitType custLimitType) {
		this.custLimitType = custLimitType;
	}

	public Amount getMinimumLimit() {
		if (minimumLimit == null) {
			minimumLimit = new Amount();
		}
		return minimumLimit;
	}

	public void setMinimumLimit(Amount minimumLimit) {
		this.minimumLimit = minimumLimit;
	}

	public Amount getUsageAmount() {
		if (usageAmount == null) {
			usageAmount = new Amount();
		}
		return usageAmount;
	}

	public void setUsageAmount(Amount usageAmount) {
		this.usageAmount = usageAmount;
	}

	public Amount getAvailableLimit() {
		if (availableLimit == null) {
			availableLimit = new Amount();
		}
		return availableLimit;
	}

	public void setAvailableLimit(Amount availableLimit) {
		this.availableLimit = availableLimit;
	}

	public String getNumOftrans() {
		return numOftrans;
	}

	public void setNumOftrans(String numOftrans) {
		this.numOftrans = numOftrans;
	}

	public Amount getStpMinimumLimit() {
		if (stpMinimumLimit == null) {
			stpMinimumLimit = new Amount();
		}
		return stpMinimumLimit;
	}

	public void setStpMinimumLimit(Amount stpMinimumLimit) {
		this.stpMinimumLimit = stpMinimumLimit;
	}

	public Amount getStpAvailableLimit() {
		if (stpAvailableLimit == null) {
			stpAvailableLimit = new Amount();
		}
		return stpAvailableLimit;
	}

	public void setStpAvailableLimit(Amount stpAvailableLimit) {
		this.stpAvailableLimit = stpAvailableLimit;
	}
}
