package com.alinma.tadawul.domain.investment;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotEmpty;
import org.hibernate.validator.Pattern;

import com.alinma.tadawul.domain.SurrogateKey;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class InvestmentBankInfo extends BusinessObject {

	private SurrogateKey surrogateKey;
	private EntityKey bankId;
	private String branchName;
	private String mainAccountNumber;
	private String mainAccountIban;

	// @NotEmpty(message="{investmentBankInfo.branchName}")
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	// @NotNull(message="{investmentBankInfo.bankNameRequired}")
	public EntityKey getBankId() {
		return bankId;
	}

	public void setBankId(EntityKey bankId) {
		this.bankId = bankId;
	}

	// @NotEmpty(message="{investmentBankInfo.mainAccountNumRequired}")
	public String getMainAccountNumber() {
		return mainAccountNumber;
	}

	public void setMainAccountNumber(String mainAccountNumber) {
		this.mainAccountNumber = mainAccountNumber;
	}

	@NotEmpty(message = "{investmentBankInfo.mainAccountNumRequired}")
	@Length(min = 24, max = 24, message = "{account.invalidIbanFormat}")
	@Pattern(regex = "\\D\\D(\\d)*", message = "{account.invalidIbanFormat}")
	public String getMainAccountIban() {
		return mainAccountIban;
	}

	public void setMainAccountIban(String mainAccountIban) {
		this.mainAccountIban = mainAccountIban;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}
}
