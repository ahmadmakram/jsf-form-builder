package com.alinma.tadawul.domain.investment;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.RiskPercentage;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class InvestmentInfo extends BusinessObject {

	private String sharesAmount;
	private String debitInstAmount;
	private String foreignExchangeAmount;
	private String depositsAmount;
	private String tradeFinanceAmount;
	private String investmentFundsAmount;
	private String commoditiesAmount;
	private String realEstateAmount;
	private String contractDiffAndOptAmount; // Contract For Difference and Options
	private String total;
	private EntityKey investmentRisk;// Customers appetite for risk;
	private EntityKey investmentObjective;
	private EntityKey investmentExperience;
	private InvestmentAssets preferredInvestmentAssets;
	private RiskPercentage sharesRisk;
	private RiskPercentage debitInstRisk;
	private RiskPercentage investmentFundsRisk;
	private RiskPercentage tradeFinanceRisk;
	private RiskPercentage commoditiesRisk;
	private RiskPercentage optionsRisk;
	private String otherFinancialInfo;

	public InvestmentInfo() {
		sharesAmount = "0";
		debitInstAmount = "0";
		foreignExchangeAmount = "0";
		depositsAmount = "0";
		tradeFinanceAmount = "0";
		investmentFundsAmount = "0";
		commoditiesAmount = "0";
		realEstateAmount = "0";
		contractDiffAndOptAmount = "0";
	}

	public String getSharesAmount() {
		return sharesAmount;
	}

	public void setSharesAmount(String sharesAmount) {
		this.sharesAmount = sharesAmount;
	}

	public String getDebitInstAmount() {
		return debitInstAmount;
	}

	public void setDebitInstAmount(String debitInstAmount) {
		this.debitInstAmount = debitInstAmount;
	}

	public String getForeignExchangeAmount() {
		return foreignExchangeAmount;
	}

	public void setForeignExchangeAmount(String foreignExchangeAmount) {
		this.foreignExchangeAmount = foreignExchangeAmount;
	}

	public String getDepositsAmount() {
		return depositsAmount;
	}

	public void setDepositsAmount(String depositsAmount) {
		this.depositsAmount = depositsAmount;
	}

	public String getTradeFinanceAmount() {
		return tradeFinanceAmount;
	}

	public void setTradeFinanceAmount(String tradeFinanceAmount) {
		this.tradeFinanceAmount = tradeFinanceAmount;
	}

	// @Min(value=1,message="{investmentInfo.investmentFundsAmountShouldBeGreaterThanZero}")
	public String getInvestmentFundsAmount() {
		return investmentFundsAmount;
	}

	public void setInvestmentFundsAmount(String investmentFundsAmount) {
		this.investmentFundsAmount = investmentFundsAmount;
	}

	// @Min(value=1,message="{investmentInfo.commoditiesAmountShouldBeGreaterThanZero}")
	public String getCommoditiesAmount() {
		return commoditiesAmount;
	}

	public void setCommoditiesAmount(String commoditiesAmount) {
		this.commoditiesAmount = commoditiesAmount;
	}

	// @Min(value=1,message="{investmentInfo.realEstateAmountShouldBeGreaterThanZero}")
	public String getRealEstateAmount() {
		return realEstateAmount;
	}

	public void setRealEstateAmount(String realEstateAmount) {
		this.realEstateAmount = realEstateAmount;
	}

	// @Min(value=1,message="{investmentInfo.contractDiffAndOptAmountShouldBeGreaterThanZero}")
	public String getContractDiffAndOptAmount() {
		return contractDiffAndOptAmount;
	}

	public void setContractDiffAndOptAmount(String contractDiffAndOptAmount) {
		this.contractDiffAndOptAmount = contractDiffAndOptAmount;
	}

	public String getTotal() {
		//
		// total=this.getSharesAmount()
		// +this.getDebitInstAmount()
		// +this.getDepositsAmount()
		// +this.getTradeFinanceAmount()
		// +this.getInvestmentFundsAmount()
		// +this.getCommoditiesAmount()
		// +this.getRealEstateAmount()
		// +this.getContractDiffAndOptAmount()
		// +this.getForeignExchangeAmount();
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public InvestmentAssets getPreferredInvestmentAssets() {
		if (this.preferredInvestmentAssets == null) {
			this.preferredInvestmentAssets = createPreferredInvestmentAssets();
		}
		return preferredInvestmentAssets;
	}

	private InvestmentAssets createPreferredInvestmentAssets() {
		return (InvestmentAssets) ApplicationContextFactory.getApplicationContext().getBean("investmentAssets");
	}

	public void setPreferredInvestmentAssets(InvestmentAssets preferredInvestmentAssets) {
		this.preferredInvestmentAssets = preferredInvestmentAssets;
	}

	public EntityKey getInvestmentRisk() {
		return investmentRisk;
	}

	public void setInvestmentRisk(EntityKey investmentRisk) {
		this.investmentRisk = investmentRisk;
	}

	public EntityKey getInvestmentObjective() {
		return investmentObjective;
	}

	public void setInvestmentObjective(EntityKey investmentObjective) {
		this.investmentObjective = investmentObjective;
	}

	public EntityKey getInvestmentExperience() {
		return investmentExperience;
	}

	public void setInvestmentExperience(EntityKey investmentExperience) {
		this.investmentExperience = investmentExperience;
	}

	private RiskPercentage createRiskPercentage() {
		return (RiskPercentage) ApplicationContextFactory.getApplicationContext().getBean("riskPercentage");
	}

	public RiskPercentage getSharesRisk() {
		if (sharesRisk == null) {
			this.sharesRisk = createRiskPercentage();
			// TODO:set the default zero here
		}
		return sharesRisk;
	}

	public void setSharesRisk(RiskPercentage sharesRisk) {
		this.sharesRisk = sharesRisk;
	}

	public RiskPercentage getDebitInstRisk() {
		if (debitInstRisk == null) {
			this.debitInstRisk = createRiskPercentage();
			// TODO:set the default zero here
		}
		return debitInstRisk;
	}

	public void setDebitInstRisk(RiskPercentage debitInstRisk) {
		this.debitInstRisk = debitInstRisk;
	}

	public RiskPercentage getInvestmentFundsRisk() {
		if (investmentFundsRisk == null) {
			this.investmentFundsRisk = createRiskPercentage();
			// TODO:set the default zero here
		}
		return investmentFundsRisk;
	}

	public void setInvestmentFundsRisk(RiskPercentage investmentFundsRisk) {
		this.investmentFundsRisk = investmentFundsRisk;
	}

	public RiskPercentage getTradeFinanceRisk() {
		if (tradeFinanceRisk == null) {
			this.tradeFinanceRisk = createRiskPercentage();
			// TODO:set the default zero here
		}
		return tradeFinanceRisk;
	}

	public void setTradeFinanceRisk(RiskPercentage tradeFinanceRisk) {
		this.tradeFinanceRisk = tradeFinanceRisk;
	}

	public RiskPercentage getCommoditiesRisk() {
		if (commoditiesRisk == null) {
			this.commoditiesRisk = createRiskPercentage();
			// TODO:set the default zero here
		}
		return commoditiesRisk;
	}

	public void setCommoditiesRisk(RiskPercentage commoditiesRisk) {
		this.commoditiesRisk = commoditiesRisk;
	}

	public RiskPercentage getOptionsRisk() {
		if (optionsRisk == null) {
			this.optionsRisk = createRiskPercentage();
			// TODO:set the default zero here
		}
		return optionsRisk;
	}

	public void setOptionsRisk(RiskPercentage optionsRisk) {
		this.optionsRisk = optionsRisk;
	}

	public String getOtherFinancialInfo() {
		return otherFinancialInfo;
	}

	public void setOtherFinancialInfo(String otherFinancialInfo) {
		this.otherFinancialInfo = otherFinancialInfo;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (sharesRisk != null) {
			sharesRisk.CommitUpdates();
		}
		if (debitInstRisk != null) {
			debitInstRisk.CommitUpdates();
		}
		if (investmentFundsRisk != null) {
			investmentFundsRisk.CommitUpdates();
		}
		if (tradeFinanceRisk != null) {
			tradeFinanceRisk.CommitUpdates();
		}
		if (commoditiesRisk != null) {
			commoditiesRisk.CommitUpdates();
		}
		if (optionsRisk != null) {
			optionsRisk.CommitUpdates();
		}
		if (preferredInvestmentAssets != null) {
			preferredInvestmentAssets.CommitUpdates();
		}
	}
}
