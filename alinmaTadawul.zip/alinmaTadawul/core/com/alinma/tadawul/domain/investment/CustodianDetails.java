package com.alinma.tadawul.domain.investment;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.CustomerAddress;
import com.alinma.tadawul.domain.FaxInfo;
import com.alinma.tadawul.domain.PhoneInfo;
import com.alinma.tadawul.domain.SurrogateKey;
import com.alinma.tadawul.domain.lov.AddressIndicator;
import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class CustodianDetails extends BusinessObject {

	private SurrogateKey surrogateKey;
	private Boolean alinmaCustodian;
	private EntityKey custodianId;
	private String custodianName;
	private String accountNumber;
	private String accountIBAN;
	private String accountName;
	private PhoneInfo phone;
	private FaxInfo fax;
	private CustomerAddress workAddress;
	private EntityKey forwardCertifcate;
	private String forwardCertifcateOtherDesc;
	private EntityKey forwardDivindands;
	private String forwardDivindandsOtherDesc;
	private EntityKey ForwardSaleProceeds;
	private String forwardSaleProceedsOtherDesc;

	public Boolean getAlinmaCustodian() {
		return alinmaCustodian;
	}

	public void setAlinmaCustodian(Boolean alinmaCustodian) {
		this.alinmaCustodian = alinmaCustodian;
	}

	public EntityKey getCustodianId() {
		return custodianId;
	}

	public void setCustodianId(EntityKey custodianId) {
		this.custodianId = custodianId;
	}

	public String getCustodianName() {
		return custodianName;
	}

	public void setCustodianName(String custodianName) {
		this.custodianName = custodianName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public EntityKey getForwardCertifcate() {
		return forwardCertifcate;
	}

	public void setForwardCertifcate(EntityKey forwardCertifcate) {
		this.forwardCertifcate = forwardCertifcate;
	}

	public String getForwardCertifcateOtherDesc() {
		return forwardCertifcateOtherDesc;
	}

	public void setForwardCertifcateOtherDesc(String forwardCertifcateOtherDesc) {
		this.forwardCertifcateOtherDesc = forwardCertifcateOtherDesc;
	}

	public EntityKey getForwardDivindands() {
		return forwardDivindands;
	}

	public void setForwardDivindands(EntityKey forwardDivindands) {
		this.forwardDivindands = forwardDivindands;
	}

	public String getForwardDivindandsOtherDesc() {
		return forwardDivindandsOtherDesc;
	}

	public void setForwardDivindandsOtherDesc(String forwardDivindandsOtherDesc) {
		this.forwardDivindandsOtherDesc = forwardDivindandsOtherDesc;
	}

	public EntityKey getForwardSaleProceeds() {
		return ForwardSaleProceeds;
	}

	public void setForwardSaleProceeds(EntityKey forwardSaleProceeds) {
		ForwardSaleProceeds = forwardSaleProceeds;
	}

	public String getForwardSaleProceedsOtherDesc() {
		return forwardSaleProceedsOtherDesc;
	}

	public void setForwardSaleProceedsOtherDesc(String forwardSaleProceedsOtherDesc) {
		this.forwardSaleProceedsOtherDesc = forwardSaleProceedsOtherDesc;
	}

	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountIBAN() {
		return accountIBAN;
	}

	public void setAccountIBAN(String accountIBAN) {
		this.accountIBAN = accountIBAN;
	}

	public PhoneInfo getPhone() {
		if (phone == null) {
			phone = createPhone();
		}
		return phone;
	}

	public PhoneInfo createPhone() {
		return (PhoneInfo) ApplicationContextFactory.getApplicationContext().getBean("phoneInfo");
	}

	public void setPhone(PhoneInfo phone) {
		this.phone = phone;
	}

	public FaxInfo getFax() {
		if (fax == null) {
			fax = createFax();
		}
		return fax;
	}

	public FaxInfo createFax() {
		return (FaxInfo) ApplicationContextFactory.getApplicationContext().getBean("faxInfo");
	}

	public void setFax(FaxInfo fax) {
		this.fax = fax;
	}

	public CustomerAddress getWorkAddress() {
		if (workAddress == null) {
			workAddress = createWorkAddress();
			workAddress.setAddressType(AddressIndicator.DESCRIPTIVE);
		}
		return workAddress;
	}

	public CustomerAddress createWorkAddress() {
		return (CustomerAddress) ApplicationContextFactory.getApplicationContext().getBean("customerAddress");
	}

	public void setWorkAddress(CustomerAddress workAddress) {
		this.workAddress = workAddress;
	}
}
