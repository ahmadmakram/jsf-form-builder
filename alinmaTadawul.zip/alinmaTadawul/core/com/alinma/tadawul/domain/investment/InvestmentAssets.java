package com.alinma.tadawul.domain.investment;

import com.ejada.commons.domain.BusinessObject;

public class InvestmentAssets extends BusinessObject {

	private Boolean SARInvestmentAsset;
	private Boolean USDInvestmentAsset;
	private Boolean EUROInvestmentAsset;
	private Boolean otherInvestmentAsset;
	private String otherInvestmentAssetDesc;

	public Boolean getSARInvestmentAsset() {
		return SARInvestmentAsset;
	}

	public void setSARInvestmentAsset(Boolean investmentAsset) {
		SARInvestmentAsset = investmentAsset;
	}

	public Boolean getUSDInvestmentAsset() {
		return USDInvestmentAsset;
	}

	public void setUSDInvestmentAsset(Boolean investmentAsset) {
		USDInvestmentAsset = investmentAsset;
	}

	public Boolean getEUROInvestmentAsset() {
		return EUROInvestmentAsset;
	}

	public void setEUROInvestmentAsset(Boolean investmentAsset) {
		EUROInvestmentAsset = investmentAsset;
	}

	public Boolean getOtherInvestmentAsset() {
		return otherInvestmentAsset;
	}

	public void setOtherInvestmentAsset(Boolean otherInvestmentAsset) {
		this.otherInvestmentAsset = otherInvestmentAsset;
	}

	public String getOtherInvestmentAssetDesc() {
		return otherInvestmentAssetDesc;
	}

	public void setOtherInvestmentAssetDesc(String otherInvestmentAssetDesc) {
		this.otherInvestmentAssetDesc = otherInvestmentAssetDesc;
	}
}
