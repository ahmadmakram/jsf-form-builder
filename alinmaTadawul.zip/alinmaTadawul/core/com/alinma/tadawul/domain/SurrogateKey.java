/**
 * 
 */
package com.alinma.tadawul.domain;

import java.io.Serializable;

import com.ejada.commons.domain.EntityKey;

/**
 * The surrogate key for the objects obtained from the Backend. It will be used as a key for the disconnected objects that needs to be identified in the backend after it is send againg from the
 * Frontend.
 * 
 * @author Waleed Tayea
 * 
 */
public class SurrogateKey implements Serializable {

	String key;

	public SurrogateKey(String key) {
		this.key = key;
	}

	public String getKey() {
		// TODO Auto-generated method stub
		return key;
	}
}
