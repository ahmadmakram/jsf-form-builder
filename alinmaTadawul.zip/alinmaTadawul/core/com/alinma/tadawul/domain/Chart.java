package com.alinma.tadawul.domain;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author mgahmed
 * 
 */
public class Chart {

	public class Point implements Comparable<Point> {

		private String x;
		private String Y;
		private String link;

		public String getX() {
			return x;
		}

		public void setX(String x) {
			this.x = x;
		}

		public String getY() {
			return Y;
		}

		public void setY(String y) {
			Y = y;
		}

		public int compareTo(Point o) {
			return this.x.compareTo(o.x);
		}

		public String getLink() {
			return link;
		}

		public void setLink(String link) {
			this.link = link;
		}
	};

	public class Series {

		private List<Point> data;
		private String name;
		private String type;

		public List<Point> getData() {
			return data;
		}

		public void setData(List<Point> data) {
			this.data = data;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}
	};

	private String chartId;
	private List<Chart> linkedCharts;
	private List<Series> data;
	private List<String> axisXCategories;
	private List<Double> axisYCategories;
	private boolean onclickSupport = false;

	public List<Series> getData() {
		return data;
	}

	public void setData(List<Series> data) {
		this.data = data;
		for (Series sers : data) {
			Collections.sort(sers.getData());
		}
	}

	public List<String> getAxisXCategories() {
		return axisXCategories;
	}

	public void setAxisXCategories(List<String> axisXCategories) {
		this.axisXCategories = axisXCategories;
		Collections.sort(this.axisXCategories);
	}

	public List<Double> getAxisYCategories() {
		return axisYCategories;
	}

	public void setAxisYCategories(List<Double> axisYCategories) {
		this.axisYCategories = axisYCategories;
		Collections.sort(this.axisYCategories);
	}

	public String getCategoriesString() {
		StringBuilder data = new StringBuilder("[{\"category\":[");
		int i = 0;
		for (String category : this.getAxisXCategories()) {
			data.append("{");
			data.append("\"label\":");
			data.append("\"");
			data.append(category);
			data.append("\",");
			data.append("\"x\":");
			data.append("\"");
			data.append(i);
			data.append("\"},");
			i++;
		}
		if (data.length() > 1) {
			data.setLength(data.length() - 1);
		}
		data.append("]}]");
		return data.toString();
	}

	public String parseData(Series plotSeries) {
		StringBuilder data = new StringBuilder("[");
		List<Point> plotData = plotSeries.getData();
		if (plotData != null)
			for (Point point : plotData) {
				data.append("{");
				data.append("\"label\":");
				data.append("\"");
				data.append(point.getX());
				data.append("\",");
				if (this.getLinkedCharts() != null && this.getLinkedCharts().size() > 0) {
					data.append("\"link\":");
					data.append("\"");
					data.append("newchart-xml-" + point.getX());
					data.append("\",");
				} else if (onclickSupport) {
					data.append("\"link\":");
					data.append("\"");
					data.append("JavaScript:filterTable(\'" + plotSeries.name + "\',\'" + point.getX() + "\')"); // filterTable(type,channel)
					data.append("\",");
				}
				DecimalFormat df = new DecimalFormat("#.##");
				data.append("\"tooltext\":");
				data.append("\"");
				data.append(point.getX() + " = " + df.format(Double.parseDouble(point.getY())));
				data.append("\",");
				data.append("\"x\":");
				data.append("\"");
				data.append(axisXCategories.indexOf(point.getX()));
				data.append("\",");
				String show = "1";
				String Value = point.getY();
				if (point.getY().equals("0") || Double.parseDouble(point.getY()) == 0d) {
					show = "0";
					Value = "";
				}
				data.append("\"showValue\":");
				data.append("\"");
				data.append(show);
				data.append("\",");
				data.append("\"showLabel\":");
				data.append("\"");
				data.append(show);
				data.append("\",");
				data.append("\"value\":");
				data.append("\"");
				data.append(Value);
				data.append("\"},");
			}
		if (data.length() > 1) {
			data.setLength(data.length() - 1);
		}
		data.append("]");
		return data.toString();
	}

	public String getLinkedChartsJSON() {
		StringBuilder linked = new StringBuilder("[");
		if (getLinkedCharts() != null)
			for (Chart child : getLinkedCharts()) {
				linked.append("{");
				linked.append("\"id\":");
				linked.append("\"");
				linked.append(child.chartId);
				linked.append("\",");
				linked.append("\"linkedchart\":");
				linked.append("{");
				linked.append("\"chart\":");
				linked.append("{");
				linked.append("\"DOMId\":");
				linked.append("\"");
				linked.append(child.getChartId());
				linked.append("\",");
				linked.append("\"xaxisname\":");
				linked.append("\"");
				linked.append(child.getChartId());
				linked.append("\",");
				linked.append("\"bgColor\":");
				linked.append("\"");
				linked.append("#F4F2F0");
				linked.append("\"");
				linked.append("},");
				linked.append("\"data\":");
				linked.append(child.getSingleParseData());
				linked.append("}");
				linked.append("},");
			}
		if (linked.length() > 1) {
			linked.setLength(linked.length() - 1);
		}
		linked.append("]");
		return linked.toString();
	}

	private List<Point> fillMissedXPoints(List<Point> padded) {
		// TODO fill items in gategory x with zero y
		if (padded == null || padded.size() == 0) {
			padded = new ArrayList<Point>();
		}
		for (int i = 0; i < axisXCategories.size(); i++) {
			if (i >= padded.size() || !padded.get(i).getX().equals(axisXCategories.get(i))) {
				Point p = new Point();
				p.setX(axisXCategories.get(i));
				p.setY("0");
				padded.add(i, p);
			}
		}
		return padded;
	}

	public String getSingleParseData() {
		return parseData(this.data.get(0));
	}

	public String parseSeries(Series plotSeries) {
		StringBuilder series = new StringBuilder("{");
		// series.append("type:'");
		// series.append(plotSeries.getType());
		// series.append("',");
		series.append("\"seriesname\":\"");
		series.append((plotSeries.getName() == null || plotSeries.getName().equals("")) ? "-" : plotSeries.getName());
		series.append("\",");
		series.append("\"data\":");
		plotSeries.setData(fillMissedXPoints(plotSeries.getData()));
		series.append(parseData(plotSeries));
		series.append("}");
		return series.toString();
	}

	public String getSeriesToPlot() {
		StringBuilder seriesToPlot = new StringBuilder("[");
		for (Series series : this.getData()) {
			seriesToPlot.append(parseSeries(series));
			seriesToPlot.append(",");
		}
		if (seriesToPlot.length() > 1) {
			seriesToPlot.setLength(seriesToPlot.length() - 1);
		}
		seriesToPlot.append("]");
		return seriesToPlot.toString();
	}

	public List<Chart> getLinkedCharts() {
		return linkedCharts;
	}

	public void setLinkedCharts(List<Chart> linkedCharts) {
		this.linkedCharts = linkedCharts;
	}

	public String getChartId() {
		return chartId;
	}

	public void setChartId(String chartId) {
		this.chartId = chartId;
	}

	public boolean isOnclickSupport() {
		return onclickSupport;
	}

	public void setOnclickSupport(boolean onclickSupport) {
		this.onclickSupport = onclickSupport;
	}
}
