package com.alinma.tadawul.domain;

import com.ejada.commons.domain.User;

/**
 * 
 * @author Mahmoud Al Selwadi
 * 
 */
public class IBRAdminUser extends User {
}
