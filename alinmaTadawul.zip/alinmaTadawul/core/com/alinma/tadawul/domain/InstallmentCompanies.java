package com.alinma.tadawul.domain;

import org.hibernate.validator.NotEmpty;

import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.BusinessObject;

public class InstallmentCompanies extends BusinessObject {

	private SurrogateKey surrogateKey;
	private String companyName;
	private Float creditAmount;
	private String creditPeriod;
	private Float creditOutstanding;
	private Float creditMonthlyPayment;

	@NotEmpty(message = "{installmentRelation.companyName.required}")
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Float getCreditAmount() {
		return creditAmount;
	}

	public void setCreditAmount(Float creditAmount) {
		this.creditAmount = creditAmount;
	}

	public String getCreditPeriod() {
		return creditPeriod;
	}

	public void setCreditPeriod(String creditPeriod) {
		this.creditPeriod = creditPeriod;
	}

	public Float getCreditOutstanding() {
		return creditOutstanding;
	}

	public void setCreditOutstanding(Float creditOutstanding) {
		this.creditOutstanding = creditOutstanding;
	}

	public Float getCreditMonthlyPayment() {
		return creditMonthlyPayment;
	}

	public void setCreditMonthlyPayment(Float creditMonthlyPayment) {
		this.creditMonthlyPayment = creditMonthlyPayment;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}
}
