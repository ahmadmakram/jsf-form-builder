package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class DefaultAddressContacts extends BusinessObject {

	private EntityKey defaultAddress;
	private EntityKey defaultContact;
	private EntityKey preferredContactMethod;

	public EntityKey getDefaultAddress() {
		return defaultAddress;
	}

	public void setDefaultAddress(EntityKey defaultAddress) {
		this.defaultAddress = defaultAddress;
	}

	public EntityKey getDefaultContact() {
		return defaultContact;
	}

	public void setDefaultContact(EntityKey defaultContact) {
		this.defaultContact = defaultContact;
	}

	public EntityKey getPreferredContactMethod() {
		return preferredContactMethod;
	}

	public void setPreferredContactMethod(EntityKey preferredContactMethod) {
		this.preferredContactMethod = preferredContactMethod;
	}
}
