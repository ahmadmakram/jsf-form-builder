/**
 * 
 */
package com.alinma.tadawul.domain;

import org.hibernate.validator.NotNull;

import com.alinma.tadawul.services.Impl.SurrogateKeyInquiryFactory;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 * 
 */
public class CustomerNote extends DateAwareEntityImpl {

	private SurrogateKey surrogateKey;
	private EntityKey relationManagerId;
	private String comments;
	private CombinedDate noteDate;
	private CombinedDate expiryDate;
	private EntityKey trustLevel; // TODO WT: name it trustLevel

	// private EntityStatus status;
	// private EmployeeId noteWriterEmployeeId;
	@NotNull(message = "{customerNote.relationManagerId.required}")
	public EntityKey getRelationManagerId() {
		return relationManagerId;
	}

	public void setRelationManagerId(EntityKey relationManagerId) {
		this.relationManagerId = relationManagerId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public CombinedDate getNoteDate() {
		return noteDate;
	}

	public void setNoteDate(CombinedDate noteDate) {
		this.noteDate = noteDate;
	}

	public CombinedDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(CombinedDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public EntityKey getTrustLevel() {
		return trustLevel;
	}

	public void setTrustLevel(EntityKey trustLevel) {
		this.trustLevel = trustLevel;
	}

	/**
	 * @return the surrogateKey
	 */
	public SurrogateKey getSurrogateKey() {
		if (surrogateKey == null) {
			String key = SurrogateKeyInquiryFactory.getService().getNextSurrogateKey();
			surrogateKey = new SurrogateKey(key);
		}
		return surrogateKey;
	}

	/**
	 * @param surrogateKey
	 *            the surrogateKey to set
	 */
	public void setSurrogateKey(SurrogateKey surrogateKey) {
		this.surrogateKey = surrogateKey;
	}
}
