package com.alinma.tadawul.domain;

import java.util.List;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.ReserveDeletedList;

public class CustomerComplementaryAdditionalInfo extends BusinessObject {

	private List<BankAccount> otherBanksAccounts;
	private List<InstallmentCompanies> installmentCompanies;
	private List<CustomerNote> customerNotes;
	private List<CustomerAltName> alternativeNames;
	private List<PartyRelation> otherPartiesRelations;

	public List<BankAccount> getOtherBanksAccounts() {
		if (this.otherBanksAccounts == null) {
			this.otherBanksAccounts = new ReserveDeletedList<BankAccount>();
		}
		return otherBanksAccounts;
	}

	public void setOtherBanksAccounts(List<BankAccount> otherBanksAccounts) {
		this.otherBanksAccounts = otherBanksAccounts;
	}

	public void addOtherBankAccount() {
		if (this.otherBanksAccounts == null) {
			this.otherBanksAccounts = new ReserveDeletedList<BankAccount>();
		}
		this.otherBanksAccounts.add(createOtherBankAccount());
	}

	public BankAccount createOtherBankAccount() {
		return (BankAccount) ApplicationContextFactory.getApplicationContext().getBean("bankAccount");
	}

	public List<InstallmentCompanies> getInstallmentCompanies() {
		if (this.installmentCompanies == null) {
			this.installmentCompanies = new ReserveDeletedList<InstallmentCompanies>();
		}
		return installmentCompanies;
	}

	public void setInstallmentCompanies(List<InstallmentCompanies> installmentCompanies) {
		this.installmentCompanies = installmentCompanies;
	}

	public void addInstallmentCompany() {
		if (this.installmentCompanies == null) {
			this.installmentCompanies = new ReserveDeletedList<InstallmentCompanies>();
		}
		this.installmentCompanies.add(createInstallmentCompany());
	}

	public InstallmentCompanies createInstallmentCompany() {
		return (InstallmentCompanies) ApplicationContextFactory.getApplicationContext().getBean("installmentCompanies");
	}

	public List<CustomerNote> getCustomerNotes() {
		if (this.customerNotes == null) {
			this.customerNotes = new ReserveDeletedList<CustomerNote>();
		}
		return customerNotes;
	}

	public void setCustomerNotes(List<CustomerNote> customerNotes) {
		this.customerNotes = customerNotes;
	}

	public void addCustomerNote() {
		if (this.customerNotes == null) {
			this.customerNotes = new ReserveDeletedList<CustomerNote>();
		}
		this.customerNotes.add(createCustomerNote());
	}

	public CustomerNote createCustomerNote() {
		return (CustomerNote) ApplicationContextFactory.getApplicationContext().getBean("customerNote");
	}

	public List<CustomerAltName> getAlternativeNames() {
		if (this.alternativeNames == null) {
			this.alternativeNames = new ReserveDeletedList<CustomerAltName>();
		}
		return alternativeNames;
	}

	public void setAlternativeNames(List<CustomerAltName> alternativeNames) {
		this.alternativeNames = alternativeNames;
	}

	public void addAlternativeName() {
		if (this.alternativeNames == null) {
			this.alternativeNames = new ReserveDeletedList<CustomerAltName>();
		}
		this.alternativeNames.add(createAlternativeName());
	}

	public CustomerAltName createAlternativeName() {
		return (CustomerAltName) ApplicationContextFactory.getApplicationContext().getBean("customerAltName");
	}

	public List<PartyRelation> getOtherPartiesRelations() {
		if (this.otherPartiesRelations == null) {
			this.otherPartiesRelations = new ReserveDeletedList<PartyRelation>();
		}
		return otherPartiesRelations;
	}

	public void setOtherPartiesRelations(List<PartyRelation> otherPartiesRelations) {
		this.otherPartiesRelations = otherPartiesRelations;
	}

	public void addOtherPartyRelation() {
		if (this.otherPartiesRelations == null) {
			this.otherPartiesRelations = new ReserveDeletedList<PartyRelation>();
		}
		this.otherPartiesRelations.add(createOtherPartyRelation());
	}

	public PartyRelation createOtherPartyRelation() {
		return (PartyRelation) ApplicationContextFactory.getApplicationContext().getBean("partyRelation");
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (otherBanksAccounts != null) {
			((ReserveDeletedList<BankAccount>) otherBanksAccounts).CommitUpdates();
		}
		if (installmentCompanies != null) {
			((ReserveDeletedList<InstallmentCompanies>) installmentCompanies).CommitUpdates();
		}
		if (customerNotes != null) {
			((ReserveDeletedList<CustomerNote>) customerNotes).CommitUpdates();
		}
		if (alternativeNames != null) {
			((ReserveDeletedList<CustomerAltName>) alternativeNames).CommitUpdates();
		}
		if (otherPartiesRelations != null) {
			((ReserveDeletedList<PartyRelation>) otherPartiesRelations).CommitUpdates();
		}
	}
}
