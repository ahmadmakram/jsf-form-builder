package com.alinma.tadawul.domain;

import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Hani Younis
 * 
 */
public class UserLimit {

	public static final int DIMENSOIONSSIZE = 3;
	private EntityKey channelId;
	private EntityKey functionID;
	private EntityKey currencyGroup;
	private String[] limitsDimensions = new String[DIMENSOIONSSIZE];
	private Double amountLimit;
	private Double dailyAmountLimit;
	private Double limitOnNumberOftransactionsPerDay;
	private Double percentageAmountLimit;
	private Double percentageDailyAmountLimit;
	private Double percentageLimitPerDay;
	private Double nonSTPAmountLimit;
	private Double dailyNonSTPAmountLimit;
	private Double availableDailyAmountLimit;
	private Double availableLimitPerDay;

	public EntityKey getChannelId() {
		return channelId;
	}

	public void setChannelId(EntityKey channelId) {
		this.channelId = channelId;
	}

	public EntityKey getFunctionID() {
		return functionID;
	}

	public void setFunctionID(EntityKey functionID) {
		this.functionID = functionID;
	}

	public EntityKey getCurrencyGroup() {
		return currencyGroup;
	}

	public void setCurrencyGroup(EntityKey currencyGroup) {
		this.currencyGroup = currencyGroup;
	}

	public String[] getLimitsDimensions() {
		return limitsDimensions;
	}

	public void setLimitsDimensions(String[] limitsDimensions) {
		this.limitsDimensions = limitsDimensions;
	}

	public EntityKey[] getLimitsDimensionsEntityList() {
		EntityKey[] limitsDimensionsEntityList = new EntityDefaultKey[limitsDimensions.length];
		for (int i = 0; i < limitsDimensions.length; i++) {
			limitsDimensionsEntityList[i] = new EntityDefaultKey(limitsDimensions[i]);
		}
		return limitsDimensionsEntityList;
	}

	public Double getAmountLimit() {
		return amountLimit;
	}

	public void setAmountLimit(Double amountLimit) {
		this.amountLimit = amountLimit;
	}

	public Double getAmountLimitNum() {
		return amountLimit;
	}

	public void setAmountLimitInt(Double amountLimit) {
		this.amountLimit = amountLimit;
	}

	public Double getDailyAmountLimit() {
		return dailyAmountLimit;
	}

	public void setDailyAmountLimit(Double dailyAmountLimit) {
		this.dailyAmountLimit = dailyAmountLimit;
	}

	public Double getLimitOnNumberOftransactionsPerDay() {
		return limitOnNumberOftransactionsPerDay;
	}

	public void setLimitOnNumberOftransactionsPerDay(Double limitOnNumberOftransactionsPerDay) {
		this.limitOnNumberOftransactionsPerDay = limitOnNumberOftransactionsPerDay;
	}

	public Double getPercentageAmountLimit() {
		return percentageAmountLimit;
	}

	public void setPercentageAmountLimit(Double percentageAmountLimit) {
		this.percentageAmountLimit = percentageAmountLimit;
	}

	public Double getPercentageDailyAmountLimit() {
		return percentageDailyAmountLimit;
	}

	public void setPercentageDailyAmountLimit(Double percentageDailyAmountLimit) {
		this.percentageDailyAmountLimit = percentageDailyAmountLimit;
	}

	public Double getPercentageLimitPerDay() {
		return percentageLimitPerDay;
	}

	public void setPercentageLimitPerDay(Double percentageLimitPerDay) {
		this.percentageLimitPerDay = percentageLimitPerDay;
	}

	public Double getNonSTPAmountLimit() {
		return nonSTPAmountLimit;
	}

	public void setNonSTPAmountLimit(Double nonSTPAmountLimit) {
		this.nonSTPAmountLimit = nonSTPAmountLimit;
	}

	public Double getDailyNonSTPAmountLimit() {
		return dailyNonSTPAmountLimit;
	}

	public void setDailyNonSTPAmountLimit(Double dailyNonSTPAmountLimit) {
		this.dailyNonSTPAmountLimit = dailyNonSTPAmountLimit;
	}

	public Double getAvailableDailyAmountLimit() {
		return availableDailyAmountLimit;
	}

	public void setAvailableDailyAmountLimit(Double availableDailyAmountLimit) {
		this.availableDailyAmountLimit = availableDailyAmountLimit;
	}

	public Double getAvailableLimitPerDay() {
		return availableLimitPerDay;
	}

	public void setAvailableLimitPerDay(Double availableLimitPerDay) {
		this.availableLimitPerDay = availableLimitPerDay;
	}
}
