package com.alinma.tadawul.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * Holds the mobile information record
 * 
 * @author Hani Younis
 * 
 */
public class MobileInfo extends BusinessObject {

	private EntityKey mobileCountryCode;
	private String mobileNumber;

	public EntityKey getMobileCountryCode() {
		return mobileCountryCode;
	}

	public void setMobileCountryCode(EntityKey mobileCountryCode) {
		this.mobileCountryCode = mobileCountryCode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFullMobileNumber() {
		String fullMobileNumber = "";
		if (mobileCountryCode != null && mobileCountryCode.getCode() != null) {
			fullMobileNumber += mobileCountryCode.getCode() + "-";
		}
		fullMobileNumber += (mobileNumber == null ? "" : mobileNumber);
		return fullMobileNumber;
	}

	public String getCallingMobileNumber() {
		String fullMobileNumber = "";
		if (mobileCountryCode != null && mobileCountryCode.getCode() != null) {
			fullMobileNumber += mobileCountryCode.getCode();
		}
		fullMobileNumber += (mobileNumber == null ? "" : mobileNumber);
		return fullMobileNumber;
	}

	public static MobileInfo createMobileInfo() {
		return new MobileInfo();
	}
}
