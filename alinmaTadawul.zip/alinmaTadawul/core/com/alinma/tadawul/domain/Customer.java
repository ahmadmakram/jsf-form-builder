package com.alinma.tadawul.domain;

import java.util.ArrayList;
import java.util.List;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.domain.ReserveDeletedList;
import com.ejada.commons.domain.lov.RecordStatus;
import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.lov.BackendGroups;
import com.alinma.tadawul.domain.lov.Country;

public class Customer extends BusinessObject {

	private CustomerStartingInfo customerStartingInfo;
	private CustomerEssentialInfo customerEssentialInfo;
	private CustomerComplementaryInfo customerComplementaryInfo;
	private CustomerCapitalMarketAuthorityInfo customerCapitalMarketAuthorityInfo;
	private List<BackendGroups> retrievedBackendGroups;
	private List<CustomerProduct> selectedCustomerProducts;
	private CustomerIdDoc generalAgreement;
	private boolean allBackendGroupsRetrieved = false;

	public CustomerStartingInfo getCustomerStartingInfo() {
		if (customerStartingInfo == null) {
			this.customerStartingInfo = createCustomerStartingInfo();
		}
		return customerStartingInfo;
	}

	public CustomerStartingInfo createCustomerStartingInfo() {
		return (CustomerStartingInfo) ApplicationContextFactory.getApplicationContext().getBean("customerStartingInfo");
	}

	public void setCustomerStartingInfo(CustomerStartingInfo customerStartingInfo) {
		this.customerStartingInfo = customerStartingInfo;
	}

	public CustomerEssentialInfo getCustomerEssentialInfo() {
		if (customerEssentialInfo == null) {
			this.customerEssentialInfo = createCustomerEssentialInfo();
		}
		return customerEssentialInfo;
	}

	public CustomerEssentialInfo createCustomerEssentialInfo() {
		return (CustomerEssentialInfo) ApplicationContextFactory.getApplicationContext().getBean("customerEssentialInfo");
	}

	public void setCustomerEssentialInfo(CustomerEssentialInfo customerEssentialInfo) {
		this.customerEssentialInfo = customerEssentialInfo;
	}

	public CustomerComplementaryInfo getCustomerComplementaryInfo() {
		if (customerComplementaryInfo == null) {
			this.customerComplementaryInfo = createCustomerComplementaryInfo();
		}
		return customerComplementaryInfo;
	}

	public CustomerComplementaryInfo createCustomerComplementaryInfo() {
		return (CustomerComplementaryInfo) ApplicationContextFactory.getApplicationContext().getBean("customerComplementaryInfo");
	}

	public void setCustomerComplementaryInfo(CustomerComplementaryInfo customerComplementaryInfo) {
		this.customerComplementaryInfo = customerComplementaryInfo;
	}

	public List<CustomerProduct> getSelectedCustomerProducts() {
		if (selectedCustomerProducts == null) {
			this.selectedCustomerProducts = new ReserveDeletedList<CustomerProduct>();
		}
		return selectedCustomerProducts;
	}

	public void setSelectedCustomerProducts(List<CustomerProduct> selectedCustomerProducts) {
		this.selectedCustomerProducts = selectedCustomerProducts;
	}

	public void addSelectedCustomerProduct() {
		if (this.selectedCustomerProducts == null) {
			this.selectedCustomerProducts = new ReserveDeletedList<CustomerProduct>();
		}
		this.selectedCustomerProducts.add(createSelectedCustomerProduct());
	}

	public CustomerProduct createSelectedCustomerProduct() {
		return (CustomerProduct) ApplicationContextFactory.getApplicationContext().getBean("customerProduct");
	}

	/**
	 * @return the retrievedBackendGroups
	 */
	public List<BackendGroups> getRetrievedBackendGroups() {
		if (retrievedBackendGroups == null) {
			retrievedBackendGroups = new ArrayList<BackendGroups>();
		}
		return retrievedBackendGroups;
	}

	/**
	 * @param retrievedBackendGroups
	 *            the retrievedBackendGroups to set
	 */
	public void setRetrievedBackendGroups(List<BackendGroups> retrievedBackendGroups) {
		this.retrievedBackendGroups = retrievedBackendGroups;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ejada.commons.domain.BusinessObject#CommitUpdates()
	 */
	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (customerStartingInfo != null) {
			customerStartingInfo.CommitUpdates();
		}
		if (customerEssentialInfo != null) {
			customerEssentialInfo.CommitUpdates();
		}
		if (customerComplementaryInfo != null) {
			customerComplementaryInfo.CommitUpdates();
		}
		if (customerCapitalMarketAuthorityInfo != null) {
			customerCapitalMarketAuthorityInfo.CommitUpdates();
		}
		if (selectedCustomerProducts != null) {
			((ReserveDeletedList<CustomerProduct>) selectedCustomerProducts).CommitUpdates();
		}
	}

	public void commitGeneralAgreementUpdates() {
		if (generalAgreement != null && RecordStatus.DELETE.equals(generalAgreement.getRecordStatus())) {
			generalAgreement = null;
		} else if (generalAgreement != null) {
			generalAgreement.CommitUpdates();
		}
	}

	/**
	 * @return the allBackendGroupsRetrieved
	 */
	public boolean isAllBackendGroupsRetrieved() {
		return allBackendGroupsRetrieved;
	}

	/**
	 * @param allBackendGroupsRetrieved
	 *            the allBackendGroupsRetrieved to set
	 */
	public void setAllBackendGroupsRetrieved(boolean allBackendGroupsRetrieved) {
		this.allBackendGroupsRetrieved = allBackendGroupsRetrieved;
	}

	public CustomerCapitalMarketAuthorityInfo getCustomerCapitalMarketAuthorityInfo() {
		if (customerCapitalMarketAuthorityInfo == null) {
			this.customerCapitalMarketAuthorityInfo = createCustomerCapitalMarketAuthorityInfo();
		}
		return customerCapitalMarketAuthorityInfo;
	}

	private CustomerCapitalMarketAuthorityInfo createCustomerCapitalMarketAuthorityInfo() {
		return (CustomerCapitalMarketAuthorityInfo) ApplicationContextFactory.getApplicationContext().getBean("customerCapitalMarketAuthorityInfo");
	}

	public void setCustomerCapitalMarketAuthorityInfo(CustomerCapitalMarketAuthorityInfo customerCMAInfo) {
		this.customerCapitalMarketAuthorityInfo = customerCapitalMarketAuthorityInfo;
	}

	public void setGeneralAgreement(CustomerIdDoc generalAgreement) {
		this.generalAgreement = generalAgreement;
	}

	public CustomerIdDoc getGeneralAgreement() {
		if (generalAgreement == null) {
			generalAgreement = createGeneralAgreement();
		}
		return generalAgreement;
	}

	public CustomerIdDoc createGeneralAgreement() {
		CustomerIdDoc generalAgreementDoc = (CustomerIdDoc) ApplicationContextFactory.getApplicationContext().getBean("generalAgreementDoc");
		EntityKey issueCountry = Country.SAUDIARABIA;
		generalAgreementDoc.setIssueCountry(issueCountry);
		// generalAgreementDoc.setIssuePlace("jeddah");
		CombinedDate endEffectiveDate = new CombinedDate();
		endEffectiveDate.setDate("2050-01-01");
		endEffectiveDate.setDate("1450-01-01");
		generalAgreementDoc.setEndEffectiveDate(endEffectiveDate);
		CombinedDate startEffectiveDate = new CombinedDate();
		// make start day yesterday:
		long oneDay = (long) 1000.0 * 60 * 60 * 24;
		java.util.Date yesterday = new java.util.Date(System.currentTimeMillis() - oneDay);
		startEffectiveDate.setGregorianDate(yesterday);
		generalAgreementDoc.setStartEffectiveDate(startEffectiveDate);
		return generalAgreementDoc;
	}
}
