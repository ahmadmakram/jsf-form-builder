package com.alinma.tadawul.domain;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum AllowedAccess implements EntityKey {
	NO_RESTRICTIONS_OWNER("1"), NO_RESTRICTIONS_NON_OWNER("2"), DEPOSIT_ONLY("3"), LINKED_NO_ACCESS("4"), INQUIRY_ONLY_NON_OWNER("5"), DEPOSIT_ONLY_OWNER("6"), LINKED_NO_ACCESS_OWNER("7"), INQUIRY_ONLY_OWNER(
			"8");

	private String code;
	private static Map<String, AllowedAccess> map;
	static {
		map = new Hashtable<String, AllowedAccess>();
		for (AllowedAccess value : AllowedAccess.values()) {
			map.put(value.getCode(), value);
		}
	}

	AllowedAccess(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	public static AllowedAccess getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
