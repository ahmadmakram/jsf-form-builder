/**
 * 
 */
package com.alinma.tadawul.domain.keys;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * @author Waleed Tayea
 */
public class EmployeeId extends BusinessObject implements EntityKey {

	private String employeeId;

	public EmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getCode() {
		return employeeId;
	}
}
