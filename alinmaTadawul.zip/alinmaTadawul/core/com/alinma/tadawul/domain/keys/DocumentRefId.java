package com.alinma.tadawul.domain.keys;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * The reference Id for documents. Most probable the Id will refer to ECM stored document
 * 
 * @author Waleed Tayea
 * 
 */
public class DocumentRefId extends BusinessObject implements EntityKey {

	private String refId;

	/**
	 * Gets the document reference Id.
	 * 
	 * @return
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Returns the document reference Id as the key code of this entity.
	 */
	public String getCode() {
		return refId;
	}

	/**
	 * Sets the document reference Id
	 * 
	 * @param refId
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}
}
