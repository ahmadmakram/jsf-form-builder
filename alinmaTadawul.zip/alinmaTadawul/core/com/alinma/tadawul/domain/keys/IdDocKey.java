/**
 * 
 */
package com.alinma.tadawul.domain.keys;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;
import com.ejada.commons.validations.annotations.RegularExpression;

/**
 * 
 * @author Waleed Tayea
 * 
 */
public class IdDocKey extends BusinessObject {

	private String idNumber;
	private EntityKey idDocType;

	/**
	 * @return the idNumber
	 */
	@RegularExpression(regexIndex = "idNo", message = "{idDoc.invalidIdNumber}")
	public String getIdNumber() {
		return idNumber;
	}

	/**
	 * @param idNumber
	 *            the idNumber to set
	 */
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	/**
	 * @return the idDocType
	 */
	public EntityKey getIdDocType() {
		return idDocType;
	}

	/**
	 * @param idDocType
	 *            the idDocType to set
	 */
	public void setIdDocType(EntityKey idDocType) {
		this.idDocType = idDocType;
	}
}
