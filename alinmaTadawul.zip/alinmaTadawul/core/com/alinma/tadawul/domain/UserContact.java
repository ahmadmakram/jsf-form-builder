package com.alinma.tadawul.domain;

import com.alinma.tadawul.ApplicationContextFactory;
import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Hani Younis
 * 
 */
public class UserContact extends BusinessObject {

	private String address;
	private String poBox;
	private String postalCode;
	private EntityKey city;
	private EntityKey country;
	private String email;
	private MobileInfo mobile;
	private PhoneInfo phone;
	private FaxInfo fax;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPoBox() {
		return poBox;
	}

	public void setPoBox(String poBox) {
		this.poBox = poBox;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public EntityKey getCity() {
		return city;
	}

	public void setCity(EntityKey city) {
		this.city = city;
	}

	public EntityKey getCountry() {
		return country;
	}

	public void setCountry(EntityKey country) {
		this.country = country;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFax(FaxInfo fax) {
		this.fax = fax;
	}

	public MobileInfo getMobile() {
		if (mobile == null) {
			mobile = createMobile();
		}
		return mobile;
	}

	public MobileInfo createMobile() {
		return (MobileInfo) ApplicationContextFactory.getApplicationContext().getBean("mobileInfo");
	}

	public void setMobile(MobileInfo mobile) {
		this.mobile = mobile;
	}

	public PhoneInfo getPhone() {
		if (phone == null) {
			phone = createPhone();
		}
		return phone;
	}

	public PhoneInfo createPhone() {
		return (PhoneInfo) ApplicationContextFactory.getApplicationContext().getBean("phoneInfo");
	}

	public void setPhone(PhoneInfo phone) {
		this.phone = phone;
	}

	public FaxInfo getFax() {
		if (fax == null) {
			fax = createFax();
		}
		return fax;
	}

	public FaxInfo createFax() {
		return (FaxInfo) ApplicationContextFactory.getApplicationContext().getBean("faxInfo");
	}

	@Override
	public void CommitUpdates() {
		super.CommitUpdates();
		if (mobile != null) {
			mobile.CommitUpdates();
		}
		if (fax != null) {
			fax.CommitUpdates();
		}
		if (phone != null) {
			phone.CommitUpdates();
		}
	}
}
