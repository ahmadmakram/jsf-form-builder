package com.alinma.tadawul;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Get Spring application context
 * 
 * @author Waleed Tayea
 * 
 */
public class ApplicationContextFactory {

	private static final String[] SPRING_CONFIG_FILES = new String[] { "/WEB-INF/core/tadawul-context-factory.xml", "/WEB-INF/core/model-beans.xml" };
	protected static ApplicationContext ac = null;

	public static ApplicationContext getApplicationContext() {
		if (ac == null) {
			ac = new ClassPathXmlApplicationContext(SPRING_CONFIG_FILES);
		}
		return ac;
	}
}
