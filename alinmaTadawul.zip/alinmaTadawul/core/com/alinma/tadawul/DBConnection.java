package com.alinma.tadawul;

import org.springframework.context.ApplicationContext;
import org.springframework.util.StopWatch;

import com.alinma.tadawul.services.SurrogateKeyInquiry;

public class DBConnection {

	public static void main(String[] args) {
		ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
		SurrogateKeyInquiry surrogateKeyInquiry = (SurrogateKeyInquiry) ac.getBean("SurrogateKeyInquiry");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		String returnRec = null;
		returnRec = surrogateKeyInquiry.getNextSurrogateKey();
		System.out.println(returnRec);
		returnRec = surrogateKeyInquiry.getNextSurrogateKey();
		System.out.println(returnRec);
		stopWatch.stop();
		System.out.println("Overall Execution toke:" + stopWatch.getTotalTimeMillis() + " Millis");
	}
}
