package com.alinma.tadawul.market.comet.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerChannel;
import org.springframework.context.ApplicationContext;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.market.domain.StockQuote;
import com.alinma.tadawul.market.services.dao.StockMarketWatchDao;
import com.google.gson.Gson;

@LocalBean
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Startup
public class StockQuotesTimerService {

	private static final Logger LOGGER = Logger.getLogger("stockQuotesTimerAppender");
	private BayeuxServer bayeuxServer = null;
	private LocalSession session = null;
	private StockMarketWatchDao stockMarketWatchDao;
	private String lastupdateDateTimeLive;
	private String lastupdateDateTimeDelayed;
	private ConcurrentHashMap<String, StockQuote> stockLiveQuotesMap = new ConcurrentHashMap<String, StockQuote>();
	private ConcurrentHashMap<String, StockQuote> stockDelayedQuotesMap = new ConcurrentHashMap<String, StockQuote>();
	private HashMap<String, ServerChannel> stockChannelMap = new HashMap<String, ServerChannel>();

	@PostConstruct
	public void init() {
		try {
			LOGGER.info("StockQuotesTimerService --->init method has been started.");
			ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
			bayeuxServer = TadawulBayeuxServer.bayeuxServer;
			LOGGER.info("StockQuotesTimerService --->init  bayeuxServer=" + bayeuxServer);
			this.session = bayeuxServer.newLocalSession("StockQuotesTimerService");
			this.session.handshake();
			stockMarketWatchDao = (StockMarketWatchDao) ac.getBean("StockMarketWatchDao");
			initializeMapPrice();
			processMarketInitialization();
			LOGGER.info("StockQuotesTimerService --->init method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.error("StockQuotesTimerService --->init method has been failed :" + ExceptionUtils.getFullStackTrace(e));
			// e.printStackTrace();
		}
	}

	// subscribed user , push update , onuser subscribe to wild channel push data from memory
	@Schedule(dayOfWeek = "0-4", hour = "8", persistent = true)
	public void processMarketInitialization() {
		try {
			LOGGER.info("StockQuotesTimerService --->processMarketInitialization method has been started.");
			ArrayList<String> list = stockMarketWatchDao.getAllSymbols();
			for (int i = 0; i < list.size(); i++) {
				String symbol = list.get(i);
				// System.out.println("symbol="+symbol);
				stockChannelMap.put(symbol, CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_QUOTES_LIVE + symbol));
				stockChannelMap.put(symbol + "*", CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_QUOTES_DELAYED + symbol));
			}
			LOGGER.info("StockQuotesTimerService --->processMarketInitialization method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.error("StockQuotesTimerService --->processMarketInitialization method has been failed :" + ExceptionUtils.getStackTrace(e));
			// e.printStackTrace();
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "09-14", minute = "*", second = "0/1", persistent = false)
	public void processStockQuotesLiveUpdate() {
		try {
			LOGGER.debug("StockQuotesTimerService --->processStockQuotesLiveUpdate method has been started.");
			StockQuote stockQuote = null;
			Gson gson = new Gson();
			if (lastupdateDateTimeLive == null)
				lastupdateDateTimeLive = DateFormatUtils.format(new Date(), "dd-MM-yyyy") + " 00 00 00";
			List<StockQuote> list = stockMarketWatchDao.getStockQuotesGreaterLastUpdate(lastupdateDateTimeLive, "TDWL");
			for (int i = 0; i < list.size(); i++) {
				stockQuote = list.get(i);
				if (i == 0)
					lastupdateDateTimeLive = stockQuote.getLastUpdatedTime();
				stockLiveQuotesMap.put(stockQuote.getSymbol(), stockQuote);
				stockChannelMap.get(stockQuote.getSymbol()).publish(session, gson.toJson(stockQuote));
			}
			LOGGER.debug("StockQuotesTimerService --->processStockQuotesLiveUpdate list size=" + list.size() + " lastupdateDateTimeLive=" + lastupdateDateTimeLive);
			LOGGER.debug("StockQuotesTimerService --->processStockQuotesLiveUpdate method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.error("StockQuotesTimerService --->processStockQuotesLiveUpdate method has been failed :" + ExceptionUtils.getStackTrace(e));
			// e.printStackTrace();
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "09-15", minute = "*", second = "0/3", persistent = false)
	public void processStockQuotesDelayedUpdate() {
		try {
			LOGGER.debug("StockQuotesTimerService --->processStockQuotesDelayedUpdate method has been started.");
			StockQuote stockQuote = null;
			Gson gson = new Gson();
			if (lastupdateDateTimeDelayed == null)
				lastupdateDateTimeDelayed = DateFormatUtils.format(new Date(), "dd-MM-yyyy") + " 00 00 00";
			List<StockQuote> list = stockMarketWatchDao.getStockQuotesGreaterLastUpdate(lastupdateDateTimeDelayed, "TDWL*");
			for (int i = 0; i < list.size(); i++) {
				stockQuote = list.get(i);
				if (i == 0)
					lastupdateDateTimeDelayed = stockQuote.getLastUpdatedTime();
				stockDelayedQuotesMap.put(stockQuote.getSymbol(), stockQuote);
				stockChannelMap.get(stockQuote.getSymbol() + "*").publish(session, gson.toJson(stockQuote));
			}
			LOGGER.debug("StockQuotesTimerService --->processStockQuotesDelayedUpdate list size=" + list.size() + " lastupdateDateTimeDelayed=" + lastupdateDateTimeDelayed);
			LOGGER.debug("StockQuotesTimerService --->processStockQuotesDelayedUpdate method has been completed.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("StockQuotesTimerService --->processStockQuotesDelayedUpdate method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	public Map<String, StockQuote> getStockQuoteMap(String exchangeCode) {
		if (exchangeCode.equals("TDWL")) {
			return stockLiveQuotesMap;
		} else {
			return stockDelayedQuotesMap;
		}
	}

	public StockQuote getStockQuote(String exchangeCode, String symbol) {
		if (exchangeCode.equals("TDWL")) {
			return stockLiveQuotesMap.get(symbol);
		} else {
			return stockDelayedQuotesMap.get(symbol);
		}
	}

	private void initializeMapPrice() {
		List<StockQuote> list = stockMarketWatchDao.getStockQuotesGreaterLastUpdate(null, "TDWL");
		LOGGER.debug("initializeMapPrice getStockQuotesGreaterLastUpdate for tdwl size=" + list.size());
		StockQuote stockQuote = null;
		for (int i = 0; i < list.size(); i++) {
			stockQuote = list.get(i);
			if (i == 0)
				lastupdateDateTimeLive = stockQuote.getLastUpdatedTime();
			stockLiveQuotesMap.put(stockQuote.getSymbol(), stockQuote);
		}
		list = stockMarketWatchDao.getStockQuotesGreaterLastUpdate(null, "TDWL*");
		LOGGER.debug("initializeMapPrice getStockQuotesGreaterLastUpdate for tdwl* size=" + list.size());
		stockQuote = null;
		for (int i = 0; i < list.size(); i++) {
			stockQuote = list.get(i);
			if (i == 0)
				lastupdateDateTimeDelayed = stockQuote.getLastUpdatedTime();
			stockDelayedQuotesMap.put(stockQuote.getSymbol(), stockQuote);
		}
		LOGGER.debug("initializeMapPrice method has been completed with stockDelayedQuotesMap size=" + stockDelayedQuotesMap.size() + " stockLiveQuotesMap size=" + stockLiveQuotesMap.size());
	}
}
