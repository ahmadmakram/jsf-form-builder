package com.alinma.tadawul.market.comet.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;

import javax.annotation.PostConstruct;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerChannel;
import org.springframework.context.ApplicationContext;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.messages.response.TradeOrdMngResMsgCore;
import com.alinma.tadawul.market.domain.OrderTrade;
import com.alinma.tadawul.market.domain.messages.request.TradeOrdMngReqMsgCore;
import com.alinma.tadawul.market.services.OrderTradeManage;
import com.alinma.tadawul.services.TadawulServiceRequestRec;
import com.ejada.commons.services.ServiceReturnRec;
import com.ejada.jsf.utils.ResourceBundleUtils;

@LocalBean
@Stateless
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class PortfolioLiquidationService {

	private BayeuxServer bayeuxServer = null;
	private LocalSession session = null;
	private OrderTradeManage orderTradeManage;

	@PostConstruct
	public void init() {
		try {
			ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
			bayeuxServer = TadawulBayeuxServer.bayeuxServer;
			this.session = bayeuxServer.newLocalSession("PortfolioLiquidationService");
			this.session.handshake();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Asynchronous
	public void liquidPortfolio(List<OrderTrade> orderTrades, TadawulServiceRequestRec tadServRec) {
		ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
		orderTradeManage = (OrderTradeManage) ac.getBean("OrderTradeManage");
		String channelName = "/alinma/PortfoloLiquidation/" + tadServRec.getTadawulUser().getUserId();
		ServerChannel channel = CometDUtil.createNonPersistentServerChannel(bayeuxServer, channelName);
		int rowNo;
		ServiceReturnRec<TradeOrdMngResMsgCore> serviceRes = new ServiceReturnRec<TradeOrdMngResMsgCore>();
		Map<String, String> data = new HashMap<String, String>(orderTrades.size());
		for (int i = 0; i < orderTrades.size(); i++) {
			TradeOrdMngReqMsgCore msgCore = new TradeOrdMngReqMsgCore();
			msgCore.setOrderTrade(orderTrades.get(i));
			serviceRes = orderTradeManage.createOrder(msgCore, tadServRec);
			String serviceReturnMessage = "";
			if (serviceRes.getMessages() != null && !serviceRes.getMessages().isEmpty())
				serviceReturnMessage = serviceRes.getMessages().get(0).getMessageText();
			rowNo = i + 1;
			data.put(rowNo + "", serviceReturnMessage);
			channel.publish(session, data);
		}
	}
}
