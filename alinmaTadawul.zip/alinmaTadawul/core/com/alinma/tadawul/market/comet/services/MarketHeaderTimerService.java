package com.alinma.tadawul.market.comet.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerChannel;
import org.springframework.context.ApplicationContext;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.market.domain.MarketHeader;
import com.alinma.tadawul.market.domain.lov.MarketStatusEnum;
import com.alinma.tadawul.market.services.dao.StockMarketWatchDao;
import com.google.gson.Gson;

@LocalBean
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
// @Startup
public class MarketHeaderTimerService {

	private static final Logger LOGGER = Logger.getLogger("marketHeaderTimerAppender");
	private BayeuxServer bayeuxServer = null;
	private LocalSession session = null;
	private ServerChannel liveChannel;
	private ServerChannel delayedChannel;
	private StockMarketWatchDao stockMarketWatchDao;
	private Gson gson = new Gson();
	private Map<String, ArrayList<MarketHeader>> map = new ConcurrentHashMap<String, ArrayList<MarketHeader>>();

	@PostConstruct
	public void init() {
		try {
			LOGGER.info("MarketHeaderTimerService --->init method has been started.");
			ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
			stockMarketWatchDao = (StockMarketWatchDao) ac.getBean("StockMarketWatchDao");
			bayeuxServer = TadawulBayeuxServer.bayeuxServer;
			// bayeuxServer.setSecurityPolicy(new CometDAuthenticator());
			this.session = bayeuxServer.newLocalSession("MarketHeaderTimerService");
			this.session.handshake();
			stockMarketWatchDao = (StockMarketWatchDao) ac.getBean("StockMarketWatchDao");
			liveChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_MARKET_HEADER);
			delayedChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_MARKET_HEADER + "/" + ChannelNamesIfc.DELAYED_CHANNEL_PREFIX);
			Map<String, ArrayList<MarketHeader>> tempMap = stockMarketWatchDao.getMarketHeaderDetails();
			map.putAll(tempMap);
			LOGGER.info("MarketHeaderTimerService --->init method has been completed.");
		} catch (Exception e) {
			LOGGER.error("MarketHeaderTimerService --->init method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "7", persistent = true)
	public void processMarketInitialization() {
		try {
			LOGGER.debug("MarketHeaderTimerService --->processMarketInitialization method has been started. " + new Date());
			liveChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_MARKET_HEADER);
			LOGGER.info("liveChannel has been created with channel ID= " + liveChannel.getId());
			delayedChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_MARKET_HEADER + "/" + ChannelNamesIfc.DELAYED_CHANNEL_PREFIX);
			LOGGER.info("delayedChannel has been created with channel ID= " + delayedChannel.getId());
		} catch (Exception e) {
			LOGGER.error("MarketHeaderTimerService --->processMarketInitialization method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
		LOGGER.debug("MarketHeaderTimerService --->processMarketInitialization method has been completed. " + new Date());
	}

	@Schedule(dayOfWeek = "0-4", hour = "08-17", minute = "*", second = "*/1", persistent = false)
	public void process() {
		try {
			LOGGER.debug("MarketHeaderTimerService --->process method has been started. " + new Date());
			Map<String, ArrayList<MarketHeader>> tempMap = stockMarketWatchDao.getMarketHeaderDetails();
			ArrayList<MarketHeader> livelist = tempMap.get("TDWL");
			ArrayList<MarketHeader> delayedList = tempMap.get("TDWL*");
			// map.putAll(tempMap);
			if (!livelist.equals(map.get("TDWL"))) {
				LOGGER.debug("previous TDWL list is not equals to database list , going to push data to clients");
				publishMessage(livelist, liveChannel);
				map.put("TDWL", livelist);
			} else
				LOGGER.debug("previous cached TDWL list is  equals to database list , Not going to push data to clients");
			if (!delayedList.equals(map.get("TDWL*"))) {
				LOGGER.debug("previous TDWL* list is not equals to database list , going to push data to clients");
				publishMessage(delayedList, delayedChannel);
				map.put("TDWL*", delayedList);
			} else
				LOGGER.debug("previous cached TDWL* list is  equals to database list , Not going to push data to clients");
			// publishMessage(delayedList, delayedChannel);
			LOGGER.debug("MarketHeaderTimerService --->process method result : livelist size=" + livelist.size() + " delayedList size=" + delayedList.size());
			LOGGER.debug("MarketHeaderTimerService --->process method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.error("MarketHeaderTimerService --->process method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	private void publishMessage(ArrayList<MarketHeader> list, ServerChannel channel) {
		if (list == null || list.size() == 0)
			return;
		MarketHeader marketHeader;
		LOGGER.debug("marketHeader start publish......+channel.getId()=" + channel.getId());
		Map<String, Object> data = new HashMap<String, Object>(list.size());
		for (int i = 0; i < list.size(); i++) {
			marketHeader = list.get(i);
			LOGGER.debug("marketHeader publish...." + gson.toJson(marketHeader));
			data.put(marketHeader.getSymbol(), gson.toJson(marketHeader));
		}
		LOGGER.debug("channel.getChannelId()" + channel.getChannelId());
		channel.publish(session, data);
	}

	public ArrayList<MarketHeader> getMarketHeader(String exchangeCode) {
		return map.get(exchangeCode);
	}

	public boolean isWorkingDay() {
		ArrayList<MarketHeader> list = map.get("TDWL");
		if (list != null && list.size() > 0)
			if (MarketStatusEnum.CLOSED.equals((list.get(0)).getMarketStatus()))
				return false;
		return true;
	}
}
