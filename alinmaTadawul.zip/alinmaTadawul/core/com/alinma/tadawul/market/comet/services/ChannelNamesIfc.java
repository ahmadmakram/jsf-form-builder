package com.alinma.tadawul.market.comet.services;

public interface ChannelNamesIfc {

	public static final String STOCK_QUOTES_LIVE = "/alinma/quotes/";
	public static final String STOCK_QUOTES_DELAYED = "/alinma/quotes/d/";
	public static final String STOCK_TRADES = "/alinma/trades";
	public static final String STOCK_MARKET_HEADER = "/alinma/marketHeader";
	public static final String STOCK_MARKET_DEPTH = "/alinma/marketDepth/";
	public static final String DELAYED_CHANNEL_PREFIX = "d";
	public static final String TOP_DOWN_TEN_LIVE = "/alinma/topDown10";
	public static final String TOP_DOWN_TEN_DELAYED = "/alinma/topDown10/d";
	
	public static final String PERCENT_CHANGE_SUMMARY_LIVE = "/alinma/percentChg";
	public static final String PERCENT_CHANGE_SUMMARY_DELAYED = "/alinma/percentChg/d";
}
