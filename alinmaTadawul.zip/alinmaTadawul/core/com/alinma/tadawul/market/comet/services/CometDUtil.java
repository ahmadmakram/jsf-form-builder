package com.alinma.tadawul.market.comet.services;

import org.cometd.bayeux.MarkedReference;
import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.ConfigurableServerChannel;
import org.cometd.bayeux.server.ServerChannel;

public class CometDUtil {

	public static ServerChannel createServerChannel(BayeuxServer bayeuxServer, String channelName) {
		MarkedReference<ServerChannel> ref = bayeuxServer.createChannelIfAbsent(channelName, new ServerChannel.Initializer() {

			public void configureChannel(ConfigurableServerChannel channel) {
				channel.setPersistent(true);
			}
		});
		return ref.getReference();
	}

	public static ServerChannel createNonPersistentServerChannel(BayeuxServer bayeuxServer, String channelName) {
		MarkedReference<ServerChannel> ref = bayeuxServer.createChannelIfAbsent(channelName, new ServerChannel.Initializer() {

			public void configureChannel(ConfigurableServerChannel channel) {
				channel.setPersistent(false);
			}
		});
		return ref.getReference();
	}
}
