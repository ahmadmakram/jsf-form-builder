package com.alinma.tadawul.market.comet.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerChannel;
import org.springframework.context.ApplicationContext;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.market.domain.MarketDepth;
import com.alinma.tadawul.market.domain.MarketTrade;
import com.alinma.tadawul.market.domain.TradesReturnObj;
import com.alinma.tadawul.market.services.dao.StockMarketWatchDao;
import com.alinma.utils.SizedStack;
import com.google.gson.Gson;

@LocalBean
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Startup
public class MarketDepthTimerService {

	private static final Logger LOGGER = Logger.getLogger("marketDepthTimerAppender");
	private final int MAX_NO_TRADES = 20;
	private BayeuxServer bayeuxServer = null;
	private LocalSession session = null;
	private StockMarketWatchDao stockMarketWatchDao;
	private HashMap<String, ServerChannel> stockChannelMap = new HashMap<String, ServerChannel>();
	private Map<String, MarketDepth> marketDepth = new ConcurrentHashMap<String, MarketDepth>();
	private Map<String, SizedStack<MarketTrade>> stockTrades = new LinkedHashMap<String, SizedStack<MarketTrade>>();
	private String stockTradesSequenceNo = "0";

	@PostConstruct
	public void init() {
		try {
			LOGGER.info("MarketDepthTimerService --->init method has been started.");
			ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
			bayeuxServer = TadawulBayeuxServer.bayeuxServer;
			this.session = bayeuxServer.newLocalSession("MarketDepthTimerService");
			this.session.handshake();
			stockMarketWatchDao = (StockMarketWatchDao) ac.getBean("StockMarketWatchDao");
			processMarketInitialization();
			initMarketDepth();
			getStockTrades(false);
			LOGGER.info("MarketDepthTimerService --->init method has been completed successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("MarketDepthTimerService --->init method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "8", persistent = true)
	public void processMarketInitialization() {
		try {
			LOGGER.info("MarketDepthTimerService --->processMarketInitialization method has been started. " + new Date());
			// initialize maps
			stockTradesSequenceNo = "0";
			stockTrades = new LinkedHashMap<String, SizedStack<MarketTrade>>();
			marketDepth = new ConcurrentHashMap<String, MarketDepth>();
			ArrayList<String> list = stockMarketWatchDao.getAllSymbols();
			LOGGER.info("MarketDepthTimerService --->processMarketInitialization  list of syymbol size=" + list.size());
			for (int i = 0; i < list.size(); i++) {
				String symbol = list.get(i);
				// System.out.println("symbol="+symbol);
				stockChannelMap.put(symbol, CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_MARKET_DEPTH + symbol));
			}
			LOGGER.info("MarketDepthTimerService --->processMarketInitialization method has been completed successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("MarketDepthTimerService --->processMarketInitialization method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	public void initMarketDepth() {
		Map<String, MarketDepth> marketDepthMap = stockMarketWatchDao.getMarketDepth();
		for (Map.Entry<String, MarketDepth> entry : marketDepthMap.entrySet()) {
			marketDepth.put(entry.getKey(), entry.getValue());
		}
		LOGGER.debug("MarketDepthTimerService --->initMarketDepth method has been completed with size=" + marketDepthMap.size());
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-14", minute = "*", second = "0/2", persistent = false)
	public void publishMarketDepth() {
		try {
			// System.out.println("publishMarketDepth");
			LOGGER.debug("MarketDepthTimerService --->publishMarketDepth method has been started.");
			Map<String, MarketDepth> marketDepthMap = stockMarketWatchDao.getMarketDepth();
			LOGGER.error("MarketDepthTimerService --->publishMarketDepth Map Size=" + marketDepthMap.size());
			Gson gson = new Gson();
			ServerChannel channel = null;
			for (Map.Entry<String, MarketDepth> entry : marketDepthMap.entrySet()) {
				if (!entry.getValue().equals(marketDepth.get(entry.getKey()))) {
					marketDepth.put(entry.getKey(), entry.getValue());
					channel = stockChannelMap.get(entry.getKey());
					if (channel != null)
						channel.publish(session, gson.toJson(entry.getValue()));
					else
						LOGGER.error("channel not found for symbol=" + entry.getKey());
				}
			}
			LOGGER.debug("MarketDepthTimerService --->publishMarketDepth method has been completed successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("MarketDepthTimerService --->processMarketInitialization method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	private SizedStack<MarketTrade> listToStack(List<MarketTrade> list, SizedStack<MarketTrade> stack) {
		ListIterator<MarketTrade> li = list.listIterator(list.size());
		while (li.hasPrevious()) {
			stack.push(li.previous());
		}
		return stack;
	}

	private void getStockTrades(boolean publish) {
		TradesReturnObj tradesReturnObj = stockMarketWatchDao.findAllSymbolTrades(stockTradesSequenceNo);
		stockTradesSequenceNo = "" + tradesReturnObj.getMaxSequence();
		Gson gson = new Gson();
		ServerChannel channel = null;
		SizedStack<MarketTrade> stack = null;
		LOGGER.error("MarketDepthTimerService --->publishStockTrades trades size=" + tradesReturnObj.getTrades().size() + " with Max Sequenence No=" + stockTradesSequenceNo);
		for (Map.Entry<String, List<MarketTrade>> entry : tradesReturnObj.getTrades().entrySet()) {
			if (stockTrades.containsKey(entry.getKey()))
				stack = stockTrades.get(entry.getKey());
			else
				stack = new SizedStack<MarketTrade>(MAX_NO_TRADES);
			stack = listToStack(entry.getValue(), stack);
			stockTrades.put(entry.getKey(), stack);
			if (publish) {
				channel = stockChannelMap.get(entry.getKey());
				if (channel != null)
					channel.publish(session, gson.toJson(stack));
				else
					LOGGER.error("channel not found in publishStockTrades for symbol=" + entry.getKey());
			}
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-14", minute = "*", second = "0/10", persistent = false)
	public void publishStockTrades() {
		try {
			// System.out.println("MarketDepthTimerService --->publishStockTrades method has been started.");
			LOGGER.debug("MarketDepthTimerService --->publishStockTrades method has been started.");
			getStockTrades(true);
			LOGGER.debug("MarketDepthTimerService --->publishStockTrades method has been completed successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("MarketDepthTimerService --->publishStockTrades method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	public SizedStack<MarketTrade> getyStockTrades(String symbol) {
		return this.stockTrades.get(symbol);
	}

	public MarketDepth getyMarketDepth(String symbol) {
		return this.marketDepth.get(symbol);
	}
}
