package com.alinma.tadawul.market.comet.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerChannel;
import org.springframework.context.ApplicationContext;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.domain.Symbol;
import com.alinma.tadawul.market.domain.PercentChangeSummary;
import com.alinma.tadawul.market.domain.StockQuote;
import com.alinma.tadawul.market.services.dao.StockMarketWatchDao;
import com.google.gson.Gson;

@LocalBean
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Startup
public class TopDownTenTimerService {

	private static final Logger LOGGER = Logger.getLogger("topDownTenTimerAppender");
	private StockMarketWatchDao stockMarketWatchDao;
	private ConcurrentHashMap<String, List<Symbol>> topDownLiveMap = new ConcurrentHashMap<String, List<Symbol>>();
	private ConcurrentHashMap<String, List<Symbol>> topDownDelayedMap = new ConcurrentHashMap<String, List<Symbol>>();
	private PercentChangeSummary percentChangeSummaryLive = new PercentChangeSummary();
//	private PercentChangeSummary percentChangeSummaryDelayed = new PercentChangeSummary();
	private final String TOP_TEN_Key = "top10";
	private final String DOWN_TEN_Key = "down10";
	private BayeuxServer bayeuxServer = null;
	private LocalSession session = null;
	private ServerChannel topDownLiveChannel;
	private ServerChannel topDownDelayedChannel;
	private ServerChannel percentChgeLiveChannel;
//	private ServerChannel percentChgeDelayedChannel;
	@EJB
	private StockQuotesTimerService stockQuotesTimerService;
	private Gson gson = new Gson();

	@PostConstruct
	public void init() {
		try {
			LOGGER.info("TopDown10TimerService --->init method has been started.");
			ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
			stockMarketWatchDao = (StockMarketWatchDao) ac.getBean("StockMarketWatchDao");
			bayeuxServer = TadawulBayeuxServer.bayeuxServer;
			LOGGER.info("StockQuotesTimerService --->init  bayeuxServer=" + bayeuxServer);
			this.session = bayeuxServer.newLocalSession("TopDownTenTimerService");
			this.session.handshake();
			topDownLiveChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.TOP_DOWN_TEN_LIVE);
			topDownDelayedChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.TOP_DOWN_TEN_DELAYED);
			percentChgeLiveChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.PERCENT_CHANGE_SUMMARY_LIVE);
//			percentChgeDelayedChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.PERCENT_CHANGE_SUMMARY_DELAYED);
			processLiveTopDown10Update();
			processDelayedTopDown10Update();
			LOGGER.info("TopDown10TimerService --->init method has been completed successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("TopDown10TimerService --->init method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "9", persistent = true)
	public void reset() {
		try {
			LOGGER.info("TopDown10TimerService --->reset method has been started.");
			topDownLiveMap.clear();
			topDownDelayedMap.clear();
			topDownLiveMap = new ConcurrentHashMap<String, List<Symbol>>();
			topDownDelayedMap = new ConcurrentHashMap<String, List<Symbol>>();
			percentChangeSummaryLive = new PercentChangeSummary();
//			percentChangeSummaryDelayed = new PercentChangeSummary();
			topDownLiveChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.TOP_DOWN_TEN_LIVE);
			topDownDelayedChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.TOP_DOWN_TEN_DELAYED);
			percentChgeLiveChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.PERCENT_CHANGE_SUMMARY_LIVE);
//			percentChgeDelayedChannel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.PERCENT_CHANGE_SUMMARY_DELAYED);
			LOGGER.info("TopDown10TimerService --->reset method has been completed.");
		} catch (Exception e) {
			LOGGER.error("TopDown10TimerService --->reset method has been failed :" + ExceptionUtils.getStackTrace(e));
			// e.printStackTrace();
		}
	}

	private void processPercentChangeUpdate(String exchangeCode) {
		try {
			Map<String, Object> data = new HashMap<String, Object>();
			PercentChangeSummary percSummary = stockMarketWatchDao.getPercentChangeSummary(exchangeCode);
			data.put("PercentChange", gson.toJson(percSummary));
			if (exchangeCode.equals("TDWL")) {
				if(!percSummary.equals(percentChangeSummaryLive)) {
					this.percentChangeSummaryLive = percSummary;
					percentChgeLiveChannel.publish(session, data);
				}
			} 
//			else {
//				if(!percSummary.equals(this.percentChangeSummaryDelayed)) {
//					this.percentChangeSummaryDelayed = percSummary;
//					percentChgeDelayedChannel.publish(session, gson.toJson(data));
//				}
//			}
		} catch (Exception e) {
			LOGGER.error("TopDown10TimerService --->processPercentChangeUpdate method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-14", minute = "*", second = "0/10", persistent = false)
	public void processLiveTopDown10Update() {
		try {
			LOGGER.debug("TopDown10TimerService --->processLiveStockQuotesUpdate method has been started.");
			processPercentChangeUpdate("TDWL");
			Map<String, Object> data = new HashMap<String, Object>();
			List<Symbol> topDown10 = getSymbolPriceList(stockMarketWatchDao.getTopDownTen("TDWL"), "TDWL");
			List<Symbol> lastTopDown10 = new ArrayList<Symbol>();
			if (topDownLiveMap.get(TOP_TEN_Key) != null)
				lastTopDown10.addAll(topDownLiveMap.get(TOP_TEN_Key));
			if (topDownLiveMap.get(DOWN_TEN_Key) != null)
				lastTopDown10.addAll(topDownLiveMap.get(DOWN_TEN_Key));
			List<Symbol> top10, down10;
			if (!isEqualList(topDown10, lastTopDown10)) {
				LOGGER.debug("TopDown10TimerService ---> topDown10 Live");
				top10 = topDown10.subList(0, 10);
				down10 = topDown10.subList(10, 20);
				topDownLiveMap.put(TOP_TEN_Key, top10);
				topDownLiveMap.put(DOWN_TEN_Key, down10);
				data.put(TOP_TEN_Key, gson.toJson(top10));
				data.put(DOWN_TEN_Key, gson.toJson(down10));
				topDownLiveChannel.publish(session, gson.toJson(data));
				LOGGER.debug("TopDown10TimerService --->TopDown10Live List changed ");
			}
			LOGGER.debug("TopDown10TimerService --->processLiveTopDown10Update method has been completed  successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("TopDown10TimerService --->processLiveTopDown10Update method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-15", minute = "*", second = "0/10", persistent = false)
	public void processDelayedTopDown10Update() {
		try {
			LOGGER.debug("TopDown10TimerService --->processDelayedTopDown10Update method has been started.");
//			processPercentChangeUpdate("TDWL*");
			Map<String, Object> data = new HashMap<String, Object>();
			List<Symbol> topDown10 = getSymbolPriceList(stockMarketWatchDao.getTopDownTen("TDWL*"), "TDWL*");
			List<Symbol> lastTopDown10 = new ArrayList<Symbol>();
			if (topDownDelayedMap.get(TOP_TEN_Key) != null)
				lastTopDown10.addAll(topDownDelayedMap.get(TOP_TEN_Key));
			if (topDownDelayedMap.get(DOWN_TEN_Key) != null)
				lastTopDown10.addAll(topDownDelayedMap.get(DOWN_TEN_Key));
			List<Symbol> top10, down10;
			if (!isEqualList(topDown10, lastTopDown10)) {
				LOGGER.debug("TopDown10TimerService ---> topDown10 Deylayed");
				top10 = topDown10.subList(0, 10);
				down10 = topDown10.subList(10, 20);
				topDownDelayedMap.put(TOP_TEN_Key, top10);
				topDownDelayedMap.put(DOWN_TEN_Key, down10);
				Gson gson = new Gson();
				data.put(TOP_TEN_Key, gson.toJson(top10));
				data.put(DOWN_TEN_Key, gson.toJson(down10));
				topDownDelayedChannel.publish(session, gson.toJson(data));
				LOGGER.debug("TopDown10TimerService --->TopDown10Delayed List changed ");
			}
			LOGGER.debug("TopDown10TimerService --->processDelayedTopDown10Update method has been completed  successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("TopDown10TimerService --->processDelayedTopDown10Update method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	public PercentChangeSummary getPercentChangeSummary(String exchangeCode) {
//		if (exchangeCode.equals("TDWL"))
			return percentChangeSummaryLive;
//		return percentChangeSummaryDelayed;
	}

	public List<Symbol> getTop10(String exchangeCode) {
		if (exchangeCode.equals("TDWL"))
			return topDownLiveMap.get(TOP_TEN_Key);
		return topDownDelayedMap.get(TOP_TEN_Key);
	}

	public List<Symbol> getDown10(String exchangeCode) {
		if (exchangeCode.equals("TDWL"))
			return topDownLiveMap.get(DOWN_TEN_Key);
		return topDownDelayedMap.get(DOWN_TEN_Key);
	}

	private List<Symbol> getSymbolPriceList(List<Symbol> symbolsWOPrice, String exchangeCode) {
		StockQuote stockQuote = new StockQuote();
		for (Symbol symbol : symbolsWOPrice) {
			stockQuote = stockQuotesTimerService.getStockQuote(exchangeCode, symbol.getId());
			if (stockQuote != null) {
				symbol.setOpen(stockQuote.getOpen() == null ? 0 : Float.parseFloat(stockQuote.getOpen()));
				symbol.setChange(stockQuote.getChange() == null ? 0 : Float.parseFloat(stockQuote.getChange()));
				symbol.setLastTradePrice(stockQuote.getLastTradedPrice() == null ? 0 : Float.parseFloat(stockQuote.getLastTradedPrice()));
				symbol.setPerce_change(stockQuote.getPercentChanged() == null ? 0 : Float.parseFloat(stockQuote.getPercentChanged()));
				symbol.setNoOfTrades(stockQuote.getNoOfTrades() == null ? 0 : Float.parseFloat(stockQuote.getNoOfTrades()));
				symbol.setVolume(stockQuote.getVolumn() == null ? 0 : Float.parseFloat(stockQuote.getVolumn()));
				symbol.setTurnOver(stockQuote.getTurnOver() == null ? 0 : Float.parseFloat(stockQuote.getTurnOver()));
				symbol.setMbp_bid1_qty(stockQuote.getBidQty() == null ? 0 : Float.parseFloat(stockQuote.getBidQty()));
				symbol.setMbp_bid1(stockQuote.getBidPrice() == null ? 0 : Float.parseFloat(stockQuote.getBidPrice()));
				symbol.setMbp_ask1_qty(stockQuote.getAskQty() == null ? 0 : Float.parseFloat(stockQuote.getAskQty()));
				symbol.setMbp_ask1(stockQuote.getAskPrice() == null ? 0 : Float.parseFloat(stockQuote.getAskPrice()));
				symbol.setVwap(stockQuote.getCachePercent() == null ? 0 : Float.parseFloat(stockQuote.getCachePercent()) * 100);
			}
		}
		return symbolsWOPrice;
	}

	private boolean isEqualList(List<Symbol> newList, List<Symbol> oldList) {
		if (oldList == null || oldList.isEmpty())
			return false;
		for (Symbol symbol : oldList) {
			if (!newList.contains(symbol)) {
				LOGGER.debug("TopDown10TimerService ---> TopDown 10 symbol not found>> index No: " + oldList.indexOf(symbol) + "  SymID=" + symbol.getId());
				return false;
			}
		}
		return true;
	}
}
