package com.alinma.tadawul.market.comet.services;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerChannel;
import org.springframework.context.ApplicationContext;
import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.market.domain.MarketTrade;
import com.alinma.tadawul.market.services.dao.StockMarketWatchDao;
import com.google.gson.Gson;

@LocalBean
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
// @Startup
public class MarketTradesTimerService {

	private static final Logger LOGGER = Logger.getLogger("MarketTradesTimerAppender");
	private String lastSequenceNo = "-1";
	private BayeuxServer bayeuxServer = null;
	private LocalSession session = null;
	private ServerChannel channel;
	private StockMarketWatchDao stockMarketWatchDao;
	private List<MarketTrade> list;
	@EJB
	private MarketHeaderTimerService marketHeaderTimerService;

	@PostConstruct
	public void init() {
		try {
			LOGGER.info("MarketTradesTimerService --->init method has been started.");
			ApplicationContext applicationContext = ApplicationContextFactory.getApplicationContext();
			bayeuxServer = TadawulBayeuxServer.bayeuxServer;
			this.session = bayeuxServer.newLocalSession("MarketTradesTimerService");
			this.session.handshake();//
			stockMarketWatchDao = (StockMarketWatchDao) applicationContext.getBean("StockMarketWatchDao");
			channel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_TRADES);
			loadLastMarketTrades();
			LOGGER.info("MarketTradesTimerService --->init method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.info("MarketTradesTimerService --->init method has been failed :" + ExceptionUtils.getStackTrace(e));
			// e.printStackTrace();
		}
	}

	private void loadLastMarketTrades() {
		LOGGER.info("MarketTradesTimerService --->loadLastMarketTrades method has been started.");
		lastSequenceNo = "-1";
		List<MarketTrade> dblist = stockMarketWatchDao.findNewTrades(lastSequenceNo);
		if (dblist.size() > 0) {
			this.list = dblist;
			lastSequenceNo = list.get(0).getSequenceNo();
		}
		LOGGER.info("MarketTradesTimerService --->loadLastMarketTrades list size=" + dblist.size() + " lastSequenceNo=" + lastSequenceNo);
	}

	@Schedule(dayOfWeek = "0-4", hour = "9", persistent = true)
	public void processMarketInitialization() {
		try {
			LOGGER.info("MarketTradesTimerService --->processMarketInitialization method has been started.");
			channel = CometDUtil.createServerChannel(bayeuxServer, ChannelNamesIfc.STOCK_TRADES);
			LOGGER.info("MarketTradesTimerService --->processMarketInitialization  trade channel has been created with channelId=" + channel.getId());
			if (marketHeaderTimerService.isWorkingDay()) {
				LOGGER.info("Today is Market working day ,going to assign lastSequenceNo to -1");
				lastSequenceNo = "-1";
			} else
				LOGGER.info("Today is not Market working day 1");
			LOGGER.info("MarketTradesTimerService --->processMarketInitialization method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.info("MarketTradesTimerService --->processMarketInitialization method has been failed :" + ExceptionUtils.getFullStackTrace(e));
			// e.printStackTrace();
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-14", minute = "*", second = "0/2", persistent = false)
	public void process() {
		try {
			LOGGER.debug("MarketTradesTimerService --->process method has been started successfully.");
			ApplicationContext applicationContext = ApplicationContextFactory.getApplicationContext();
			stockMarketWatchDao = (StockMarketWatchDao) applicationContext.getBean("StockMarketWatchDao");
			List<MarketTrade> dblist = stockMarketWatchDao.findNewTrades(lastSequenceNo);
			Gson gson = new Gson();
			if (dblist.size() > 0) {
				this.list = dblist;
				lastSequenceNo = list.get(0).getSequenceNo();
				LOGGER.debug("MarketTradesTimerService --->process going to publish to channelId=" + channel.getId());
				channel.publish(session, gson.toJson(dblist));
			}
			LOGGER.debug("MarketTradesTimerService --->process dblist size=" + dblist.size() + " lastSequenceNo=" + lastSequenceNo);
			LOGGER.debug("MarketTradesTimerService --->process method has been completed successfully.");
		} catch (Exception e) {
			LOGGER.info("MarketTradesTimerService --->process method has been failed :" + ExceptionUtils.getFullStackTrace(e));
			// e.printStackTrace();
		}
	}

	public List<MarketTrade> getMarketTrades() {
		return list;
	}
}
