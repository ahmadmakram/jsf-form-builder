package com.alinma.tadawul.market.comet.services;

import javax.inject.Inject;
import javax.inject.Singleton;

import org.cometd.annotation.Service;
import org.cometd.bayeux.server.BayeuxServer;

@Service
@Singleton
public class TadawulBayeuxServer {

	@Inject
	public static BayeuxServer bayeuxServer;

	public BayeuxServer getBayeuxServer() {
		return bayeuxServer;
	}
}
