package com.alinma.tadawul.market.comet.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;

import com.alinma.tadawul.ApplicationContextFactory;
import com.alinma.tadawul.market.domain.StockQuoteSimplified;
import com.alinma.tadawul.market.domain.StockQuoteSimplifiedCache;
import com.alinma.tadawul.market.services.dao.StockMarketWatchDao;

@LocalBean
@Singleton
@TransactionManagement(value = TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Startup
public class StockQuotesCacheTimerService {

	private static final Logger LOGGER = Logger.getLogger("stockQuotesCacheTimerAppender");
	private Map<String, List<StockQuoteSimplified>> stockQuotesLiveMap = new HashMap<String, List<StockQuoteSimplified>>();
	private Map<String, List<StockQuoteSimplified>> stockQuotesDelayedMap = new HashMap<String, List<StockQuoteSimplified>>();
	private StockMarketWatchDao stockMarketWatchDao;
	private String lastupdateDateTimeLive;
	private String lastupdateDateTimeDelayed;

	@PostConstruct
	public void init() {
		try {
			LOGGER.info("StockQuotesCacheTimerService --->init method has been started.");
			ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
			stockMarketWatchDao = (StockMarketWatchDao) ac.getBean("StockMarketWatchDao");
			processLiveStockQuotesUpdate();
			// processDelayedStockQuotesUpdate();
			LOGGER.info("StockQuotesCacheTimerService --->init method has been completed successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("StockQuotesCacheTimerService --->init method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "9", persistent = true)
	public void reset() {
		try {
			LOGGER.info("StockQuotesCacheTimerService --->reset method has been started.");
			stockQuotesLiveMap.clear();
			stockQuotesDelayedMap.clear();
			stockQuotesLiveMap = new ConcurrentHashMap<String, List<StockQuoteSimplified>>();
			stockQuotesDelayedMap = new ConcurrentHashMap<String, List<StockQuoteSimplified>>();
			lastupdateDateTimeLive = null;
			lastupdateDateTimeDelayed = null;
			LOGGER.info("StockQuotesCacheTimerService --->reset method has been completed.");
		} catch (Exception e) {
			LOGGER.error("StockQuotesCacheTimerService --->reset method has been failed :" + ExceptionUtils.getStackTrace(e));
			// e.printStackTrace();
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-14", minute = "*", second = "0/10", persistent = false)
	public void processLiveStockQuotesUpdate() {
		try {
			LOGGER.debug("StockQuotesCacheTimerService --->processLiveStockQuotesUpdate method has been started.");
			if (lastupdateDateTimeLive == null)
				lastupdateDateTimeLive = getStartDate(null);
			StockQuoteSimplifiedCache stockQuoteSimplifiedCache = stockMarketWatchDao.getStockQuotesTodayHisGreaterLastUpdate("TDWL", lastupdateDateTimeLive);
			Map<String, List<StockQuoteSimplified>> map = stockQuoteSimplifiedCache.getMap();
			for (Map.Entry<String, List<StockQuoteSimplified>> entry : map.entrySet()) {
				if (stockQuotesLiveMap.keySet().contains(entry.getKey())) {
					List<StockQuoteSimplified> list = stockQuotesLiveMap.get(entry.getKey());
					list.addAll(entry.getValue());
					stockQuotesLiveMap.put(entry.getKey(), list);
				} else
					stockQuotesLiveMap.put(entry.getKey(), entry.getValue());
			}
			if (map.size() > 0)
				lastupdateDateTimeLive = getStartDate(stockQuoteSimplifiedCache.getLastupdatedTime());
			LOGGER.debug("StockQuotesCacheTimerService --->processLiveStockQuotesUpdate stockQuotesLiveMap size=" + stockQuotesLiveMap.size() + " lastupdateDateTimeLive=" + lastupdateDateTimeLive);
			LOGGER.debug("StockQuotesCacheTimerService --->processLiveStockQuotesUpdate method has been completed  successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("StockQuotesCacheTimerService --->processLiveStockQuotesUpdate method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Schedule(dayOfWeek = "0-4", hour = "10-15", minute = "*", second = "0/10", persistent = false)
	public void processDelayedStockQuotesUpdate() {
		try {
			LOGGER.debug("StockQuotesCacheTimerService --->processDelayedStockQuotesUpdate method has been started ");
			if (lastupdateDateTimeDelayed == null)
				lastupdateDateTimeDelayed = getStartDate(null);
			StockQuoteSimplifiedCache stockQuoteSimplifiedCache = stockMarketWatchDao.getStockQuotesTodayHisGreaterLastUpdate("TDWL*", lastupdateDateTimeDelayed);
			Map<String, List<StockQuoteSimplified>> map = stockQuoteSimplifiedCache.getMap();
			for (Map.Entry<String, List<StockQuoteSimplified>> entry : map.entrySet()) {
				if (stockQuotesDelayedMap.keySet().contains(entry.getKey())) {
					List<StockQuoteSimplified> list = stockQuotesDelayedMap.get(entry.getKey());
					list.addAll(entry.getValue());
					stockQuotesDelayedMap.put(entry.getKey(), list);
				} else
					stockQuotesDelayedMap.put(entry.getKey(), entry.getValue());
			}
			if (map.size() > 0)
				lastupdateDateTimeDelayed = getStartDate(stockQuoteSimplifiedCache.getLastupdatedTime());
			LOGGER.debug("StockQuotesCacheTimerService --->processDelayedStockQuotesUpdate stockQuotesDelayedMap size=" + stockQuotesDelayedMap.size() + " lastupdateDateTimeDelayed="
					+ lastupdateDateTimeDelayed);
			LOGGER.debug("StockQuotesCacheTimerService --->processDelayedStockQuotesUpdate method has been completed  successfully.");
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error("StockQuotesCacheTimerService --->processDelayedStockQuotesUpdate method has been failed :" + ExceptionUtils.getStackTrace(e));
		}
	}

	private String getStartDate(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy ");
		return sdf.format(new Date()) + ((time == null) ? "09:00:00" : time);
	}

	public List<StockQuoteSimplified> getSymbolTodayHistory(String exchangeCode, String symbol) {
		if (exchangeCode.equals("TDWL"))
			return stockQuotesLiveMap.get(symbol);
		return stockQuotesDelayedMap.get(symbol);
	}

	public List<StockQuoteSimplified> getSymbolHistory(String symbol, String startDate, String endDate) {
		List<StockQuoteSimplified> stockQuotes = stockMarketWatchDao.getStockQuotesHistory(symbol, startDate, endDate);
		return stockQuotes;
	}

	public List<StockQuoteSimplified> getSymbolHistory(String symbol, String period) {
		List<StockQuoteSimplified> stockQuotes = stockMarketWatchDao.getStockQuotesHistory(symbol, period);
		return stockQuotes;
	}
}
