package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Omar Mohaidat
 * 
 */
public enum SubUserFlag implements EntityKey {
	SUB_USER("Y"), NOT_SUB_USER("N");

	private String code;
	private static Map<String, SubUserFlag> map;
	static {
		map = new Hashtable<String, SubUserFlag>();
		for (SubUserFlag value : SubUserFlag.values()) {
			map.put(value.getCode(), value);
		}
	}

	SubUserFlag(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static SubUserFlag getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
