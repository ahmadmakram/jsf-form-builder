package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum FeesIdEnum implements EntityKey {
	MUBASHER_FEES_ID("1"), INMA_FEES_ID("2"), TADAWUL_FEES_ID("3"), IDEAL_RATING_ID("4");

	private String code;
	private static Map<String, FeesIdEnum> map;
	static {
		map = new Hashtable<String, FeesIdEnum>();
		for (FeesIdEnum value : FeesIdEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	FeesIdEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static FeesIdEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
