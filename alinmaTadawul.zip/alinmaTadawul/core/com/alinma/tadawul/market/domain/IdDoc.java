package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.IdDocKey;

/**
 * 
 * @author Omar Mohaidat
 * 
 */
public class IdDoc extends BusinessObject {

	private IdDocKey docKey;
	private CombinedDate issueDate;
	private CombinedDate issueDateHijri;
	private String issuePlace;
	private CombinedDate expiryDate;
	private CombinedDate expiryDateHijri;

	public IdDocKey getDocKey() {
		return docKey;
	}

	public void setDocKey(IdDocKey docKey) {
		this.docKey = docKey;
	}

	public CombinedDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(CombinedDate issueDate) {
		this.issueDate = issueDate;
	}

	public CombinedDate getIssueDateHijri() {
		return issueDateHijri;
	}

	public void setIssueDateHijri(CombinedDate issueDateHijri) {
		this.issueDateHijri = issueDateHijri;
	}

	public String getIssuePlace() {
		return issuePlace;
	}

	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}

	public CombinedDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(CombinedDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public CombinedDate getExpiryDateHijri() {
		return expiryDateHijri;
	}

	public void setExpiryDateHijri(CombinedDate expiryDateHijri) {
		this.expiryDateHijri = expiryDateHijri;
	}
}
