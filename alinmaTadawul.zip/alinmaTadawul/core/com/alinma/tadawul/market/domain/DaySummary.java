package com.alinma.tadawul.market.domain;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class DaySummary {

	private String tradingVolume;
	private String lastClosing;
	private String turnover;
	private String openingPrice;
	private String numberOfTrades;
	private String highestPrice;
	private String averagePrice;
	private String lowestPrice;
	private String upperLimit;
	private String lowestLimit;
	private String highestPriceInFiftyTwoWeeks;
	private String lowestPriceInFiftyTwoWeeks;
	private String lastTradingTime;
	private String lastTradingPrice;
	private String lastTradingQuantity;
	private BestOrder bestOrder;

	public void setTradingVolume(String tradingVolume) {
		this.tradingVolume = tradingVolume;
	}

	public String getTradingVolume() {
		return tradingVolume;
	}

	public void setLastClosing(String lastClosing) {
		this.lastClosing = lastClosing;
	}

	public String getLastClosing() {
		return lastClosing;
	}

	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}

	public String getTurnover() {
		return turnover;
	}

	public void setOpeningPrice(String openingPrice) {
		this.openingPrice = openingPrice;
	}

	public String getOpeningPrice() {
		return openingPrice;
	}

	public void setNumberOfTrades(String numberOfTrades) {
		this.numberOfTrades = numberOfTrades;
	}

	public String getNumberOfTrades() {
		return numberOfTrades;
	}

	public void setHighestPrice(String highestPrice) {
		this.highestPrice = highestPrice;
	}

	public String getHighestPrice() {
		return highestPrice;
	}

	public void setAveragePrice(String averagePrice) {
		this.averagePrice = averagePrice;
	}

	public String getAveragePrice() {
		return averagePrice;
	}

	public void setLowestPrice(String lowestPrice) {
		this.lowestPrice = lowestPrice;
	}

	public String getLowestPrice() {
		return lowestPrice;
	}

	public void setLowestLimit(String lowestLimit) {
		this.lowestLimit = lowestLimit;
	}

	public String getLowestLimit() {
		return lowestLimit;
	}

	public void setLastTradingTime(String lastTradingTime) {
		this.lastTradingTime = lastTradingTime;
	}

	public String getLastTradingTime() {
		return lastTradingTime;
	}

	public void setLastTradingPrice(String lastTradingPrice) {
		this.lastTradingPrice = lastTradingPrice;
	}

	public String getLastTradingPrice() {
		return lastTradingPrice;
	}

	public void setLastTradingQuantity(String lastTradingQuantity) {
		this.lastTradingQuantity = lastTradingQuantity;
	}

	public String getLastTradingQuantity() {
		return lastTradingQuantity;
	}

	public void setHighestPriceInFiftyTwoWeeks(String highestPriceInFiftyTwoWeeks) {
		this.highestPriceInFiftyTwoWeeks = highestPriceInFiftyTwoWeeks;
	}

	public String getHighestPriceInFiftyTwoWeeks() {
		return highestPriceInFiftyTwoWeeks;
	}

	public void setLowestPriceInFiftyTwoWeeks(String lowestPriceInFiftyTwoWeeks) {
		this.lowestPriceInFiftyTwoWeeks = lowestPriceInFiftyTwoWeeks;
	}

	public String getLowestPriceInFiftyTwoWeeks() {
		return lowestPriceInFiftyTwoWeeks;
	}

	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

	public String getUpperLimit() {
		return upperLimit;
	}

	public void setBestOrder(BestOrder bestOrder) {
		this.bestOrder = bestOrder;
	}

	public BestOrder getBestOrder() {
		return bestOrder;
	}
}
