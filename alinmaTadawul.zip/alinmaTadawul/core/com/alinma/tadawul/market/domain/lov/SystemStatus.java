package com.alinma.tadawul.market.domain.lov;

public enum SystemStatus {
	INIT("1", "INIT"), MATCHED("2", "MATCHED"), EXECUTED("3", "EXECUTED"), FAILED("4", "FAILED"), EXPIRED("5", "EXPIRED");

	private String code;
	private String label;

	private SystemStatus(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
