package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum UserChannelStatus implements EntityKey {
	ACTIVE("A"), INACTIVE("I"), WIATING_FOR_ACTIVATION("W");

	private String code;
	private static Map<String, UserChannelStatus> map;
	static {
		map = new Hashtable<String, UserChannelStatus>();
		for (UserChannelStatus value : UserChannelStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	UserChannelStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static UserChannelStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
