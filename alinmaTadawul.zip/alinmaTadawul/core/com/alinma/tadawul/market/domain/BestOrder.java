package com.alinma.tadawul.market.domain;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class BestOrder {

	private String orderPrice;
	private String numberOfBestOrders;
	private String orderQuantity;
	private String offerPrice;
	private String numberOfBestOffers;
	private String offerQuantity;

	public void setOfferPrice(String offerPrice) {
		this.offerPrice = offerPrice;
	}

	public String getOfferPrice() {
		return offerPrice;
	}

	public void setOfferQuantity(String offerQuantity) {
		this.offerQuantity = offerQuantity;
	}

	public String getOfferQuantity() {
		return offerQuantity;
	}

	public void setNumberOfBestOffers(String numberOfBestOffers) {
		this.numberOfBestOffers = numberOfBestOffers;
	}

	public String getNumberOfBestOffers() {
		return numberOfBestOffers;
	}

	public void setOrderQuantity(String orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderPrice(String orderPrice) {
		this.orderPrice = orderPrice;
	}

	public String getOrderPrice() {
		return orderPrice;
	}

	public void setNumberOfBestOrders(String numberOfBestOrders) {
		this.numberOfBestOrders = numberOfBestOrders;
	}

	public String getNumberOfBestOrders() {
		return numberOfBestOrders;
	}
}
