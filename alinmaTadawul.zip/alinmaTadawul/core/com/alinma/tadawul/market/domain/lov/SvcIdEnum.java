package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum SvcIdEnum implements EntityKey {
	NET_PLUS_SERVICE_ID("1"), NET_PLUS_WITH_MD_SERVICE_ID("2"), PRO_V9_SERVICE_ID("3"), ITATHEER_SERVICE_ID("6"), TECHINAL_ANALYSIS_REPORT_SERVICE_ID("8"), ALINMA_LIVE_PRICE_SERVICE_ID("9");

	private String code;
	private static Map<String, SvcIdEnum> map;
	static {
		map = new Hashtable<String, SvcIdEnum>();
		for (SvcIdEnum value : SvcIdEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	SvcIdEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static SvcIdEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
