/**
 * 
 */
package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the channel Ids
 * 
 * @author Mohammad Suliman
 * 
 */
public enum TifType implements EntityKey {
	DAY("0"), AT_OPENING("2"), FILL_AND_KILL("3"), FILL_OR_KILL("4"), GOOD_TILL_DATE("6");

	private String code;
	private static Map<String, TifType> map;
	static {
		map = new Hashtable<String, TifType>();
		for (TifType value : TifType.values()) {
			map.put(value.getCode(), value);
		}
	}

	TifType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static TifType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
