package com.alinma.tadawul.market.domain;

import com.alinma.tadawul.domain.Account;
import com.alinma.tadawul.domain.Amount;

/*
 * Mahmoud Al Selwadi 
 */
public class CustBuyingPwr {

	private Account account;
	private Amount buyingPwrAmt;
	private Amount closingBalAmt;
	private Amount netSecurityAmt;
	private Amount margin;
	private Amount blockedAmt;
	private Amount usageAmt;
	private Amount avilLimitAmt;
	private Amount portfolioPostionAmt;
	private String currency;
	private String accountType;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Amount getBuyingPwrAmt() {
		return buyingPwrAmt;
	}

	public void setBuyingPwrAmt(Amount buyingPwrAmt) {
		this.buyingPwrAmt = buyingPwrAmt;
	}

	public Amount getClosingBalAmt() {
		return closingBalAmt;
	}

	public void setClosingBalAmt(Amount closingBalAmt) {
		this.closingBalAmt = closingBalAmt;
	}

	public Amount getNetSecurityAmt() {
		return netSecurityAmt;
	}

	public void setNetSecurityAmt(Amount netSecurityAmt) {
		this.netSecurityAmt = netSecurityAmt;
	}

	public Amount getBlockedAmt() {
		return blockedAmt;
	}

	public void setBlockedAmt(Amount blockedAmt) {
		this.blockedAmt = blockedAmt;
	}

	public Amount getUsageAmt() {
		return usageAmt;
	}

	public void setUsageAmt(Amount usageAmt) {
		this.usageAmt = usageAmt;
	}

	public Amount getAvilLimitAmt() {
		return avilLimitAmt;
	}

	public void setAvilLimitAmt(Amount avilLimitAmt) {
		this.avilLimitAmt = avilLimitAmt;
	}

	public Amount getPortfolioPostionAmt() {
		return portfolioPostionAmt;
	}

	public void setPortfolioPostionAmt(Amount portfolioPostionAmt) {
		this.portfolioPostionAmt = portfolioPostionAmt;
	}

	public Amount getMargin() {
		return margin;
	}

	public void setMargin(Amount margin) {
		this.margin = margin;
	}
}
