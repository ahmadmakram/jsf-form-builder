package com.alinma.tadawul.market.domain;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alinma.tadawul.market.domain.lov.MarketStatusEnum;

public class Market {

	protected String separatoer = ",";
	private String exchangeCode;
	private String shortDescriptionEng;
	private String shortDescriptionArabic;
	private String longDescriptionEng;
	private String longDescriptionArabic;
	private Double volume;
	private Double tradedValue;
	private Double trades;
	private Double indicator;
	private Double netChange;
	private Double perChange;
	private MarketStatusEnum status;
	private String lastActiveDate;
	private ConcurrentHashMap<String, MarketCategory> categories;

	public ConcurrentHashMap<String, MarketCategory> getCategories() {
		return categories;
	}

	public void setCategories(ConcurrentHashMap<String, MarketCategory> categories) {
		this.categories = categories;
	}

	public String getExchangeCode() {
		return exchangeCode;
	}

	public void setExchangeCode(String exchangeCode) {
		this.exchangeCode = exchangeCode;
	}

	public String getShortDescriptionEng() {
		return shortDescriptionEng;
	}

	public void setShortDescriptionEng(String shortDescriptionEng) {
		this.shortDescriptionEng = shortDescriptionEng;
	}

	public String getShortDescriptionArabic() {
		return shortDescriptionArabic;
	}

	public void setShortDescriptionArabic(String shortDescriptionArabic) {
		this.shortDescriptionArabic = shortDescriptionArabic;
	}

	public String getLongDescriptionEng() {
		return longDescriptionEng;
	}

	public void setLongDescriptionEng(String longDescriptionEng) {
		this.longDescriptionEng = longDescriptionEng;
	}

	public String getLongDescriptionArabic() {
		return longDescriptionArabic;
	}

	public void setLongDescriptionArabic(String longDescriptionArabic) {
		this.longDescriptionArabic = longDescriptionArabic;
	}

	public Double getVolume() {
		return volume;
	}

	public void setVolume(Double volume) {
		this.volume = volume;
	}

	public Double getTradedValue() {
		return tradedValue;
	}

	public void setTradedValue(Double tradedValue) {
		this.tradedValue = tradedValue;
	}

	public Double getTrades() {
		return trades;
	}

	public void setTrades(Double trades) {
		this.trades = trades;
	}

	public Double getIndicator() {
		return indicator;
	}

	public void setIndicator(Double indicator) {
		this.indicator = indicator;
	}

	public Double getNetChange() {
		return netChange;
	}

	public void setNetChange(Double netChange) {
		this.netChange = netChange;
	}

	public Double getPerChange() {
		return (perChange / 100);
	}

	public void setPerChange(Double perChange) {
		this.perChange = perChange;
	}

	public MarketStatusEnum getStatus() {
		return status;
	}

	public void setStatus(MarketStatusEnum status) {
		this.status = status;
	}

	public String getLastActiveDate() {
		if (lastActiveDate != null && lastActiveDate.length() > 0) {
			String timeOnly = lastActiveDate.substring(lastActiveDate.indexOf(' '), lastActiveDate.length());
			timeOnly = timeOnly.trim();
			String hour = timeOnly.substring(0, timeOnly.indexOf(":"));
			hour = (Integer.valueOf(hour) + 3) + "";
			if (hour.length() == 1) {
				hour = "0" + hour;
			}
			timeOnly = hour + timeOnly.substring(timeOnly.indexOf(":"));
			return timeOnly;
		}
		return lastActiveDate;
	}

	public void setLastActiveDate(String lastActiveDate) {
		this.lastActiveDate = lastActiveDate;
	}

	public String toString() {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(exchangeCode);
		stringBuffer.append(separatoer);
		stringBuffer.append(shortDescriptionEng);
		stringBuffer.append(separatoer);
		stringBuffer.append(shortDescriptionArabic);
		stringBuffer.append(separatoer);
		stringBuffer.append(longDescriptionEng);
		stringBuffer.append(separatoer);
		stringBuffer.append(longDescriptionArabic);
		stringBuffer.append(separatoer);
		stringBuffer.append(volume);
		stringBuffer.append(separatoer);
		stringBuffer.append(tradedValue);
		stringBuffer.append(separatoer);
		stringBuffer.append(trades);
		stringBuffer.append(separatoer);
		stringBuffer.append(indicator);
		stringBuffer.append(separatoer);
		stringBuffer.append(netChange);
		stringBuffer.append(separatoer);
		stringBuffer.append(perChange);
		stringBuffer.append(separatoer);
		stringBuffer.append(status == null ? "" : status.getCode());
		stringBuffer.append(separatoer);
		stringBuffer.append(lastActiveDate);
		stringBuffer.append(separatoer);
		if (categories != null) {
			for (MarketCategory marketCategory : categories.values()) {
				stringBuffer.append(marketCategory.toString());
			}
		}
		return stringBuffer.toString();
	}
}
