package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Wael nour-eldin
 * 
 */
public class Commisson {

	private EntityKey code;
	private EntityKey type;
	private String amount;
	private String currencyCode;

	public EntityKey getCode() {
		return code;
	}

	public void setCode(EntityKey code) {
		this.code = code;
	}

	public EntityKey getType() {
		return type;
	}

	public void setType(EntityKey type) {
		this.type = type;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
}
