package com.alinma.tadawul.market.domain.lov;

public enum MarketAlertActiveCodes {
	ACTIVE("1", "ACTIVE"), NOT_ACTIVE("0", "NOT_ACTIVE");

	private String code;
	private String label;

	private MarketAlertActiveCodes(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
