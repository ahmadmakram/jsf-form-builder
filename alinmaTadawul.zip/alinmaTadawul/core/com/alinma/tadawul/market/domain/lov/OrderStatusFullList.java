package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum OrderStatusFullList implements EntityKey {
	ORDER_ACKNOLEDGED("0"), PARTIALLY_FILLED_ORDER("1"), FULLY_FILLED_ORDER("2"), CANCELLED("4"), REPLACED("5"), REJECTED("8");

	private String code;
	private static Map<String, OrderStatusFullList> map;
	static {
		map = new Hashtable<String, OrderStatusFullList>();
		for (OrderStatusFullList value : OrderStatusFullList.values()) {
			map.put(value.getCode(), value);
		}
	}

	OrderStatusFullList(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static OrderStatusFullList getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
