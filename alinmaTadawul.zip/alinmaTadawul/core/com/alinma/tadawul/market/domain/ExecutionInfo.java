/**
 * 
 */
package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;

/**
 * @author MSuliman
 * 
 */
public class ExecutionInfo extends BusinessObject {

	private CombinedDate executionDateTime;
	private String executionRefNumber;
	private String executedQuantity;
	private String executedPrice;
	private String executedAmount;

	public CombinedDate getExecutionDateTime() {
		return executionDateTime;
	}

	public void setExecutionDateTime(CombinedDate executionDateTime) {
		this.executionDateTime = executionDateTime;
	}

	public String getExecutionRefNumber() {
		return executionRefNumber;
	}

	public void setExecutionRefNumber(String executionRefNumber) {
		this.executionRefNumber = executionRefNumber;
	}

	public String getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(String executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public String getExecutedPrice() {
		return executedPrice;
	}

	public void setExecutedPrice(String executedPrice) {
		this.executedPrice = executedPrice;
	}

	public String getExecutedAmount() {
		return executedAmount;
	}

	public void setExecutedAmount(String executedAmount) {
		this.executedAmount = executedAmount;
	}
}
