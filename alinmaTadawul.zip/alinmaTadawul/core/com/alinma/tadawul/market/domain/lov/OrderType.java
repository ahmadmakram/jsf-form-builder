/**
 * 
 */
package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the channel Ids
 * 
 * @author Mohammad Suliman
 * 
 */
public enum OrderType implements EntityKey {
	MARKET("1"), LIMIT("2");

	private String code;
	private static Map<String, OrderType> map;
	static {
		map = new Hashtable<String, OrderType>();
		for (OrderType value : OrderType.values()) {
			map.put(value.getCode(), value);
		}
	}

	OrderType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static OrderType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
