package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Wael nour-eldin
 * 
 */
public enum CommissonCodeEnum implements EntityKey {
	SUBSCIPTION("FSB"), REDEMPTION("FRD"), SWITCHIN("FSI"), SWITCHOUT("FSO");

	private String code;
	private static Map<String, CommissonCodeEnum> map;
	static {
		map = new Hashtable<String, CommissonCodeEnum>();
		for (CommissonCodeEnum value : CommissonCodeEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	CommissonCodeEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static CommissonCodeEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
