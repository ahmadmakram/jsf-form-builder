package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum PortfolioListType implements EntityKey {
	ALL("ALL"), LOCAL("LOCAL"), MUTUAL_FUNDS("MF");

	private String code;
	private static Map<String, PortfolioListType> map;
	static {
		map = new Hashtable<String, PortfolioListType>();
		for (PortfolioListType value : PortfolioListType.values()) {
			map.put(value.getCode(), value);
		}
	}

	PortfolioListType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static PortfolioListType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
