package com.alinma.tadawul.market.domain;

import java.util.Date;

import com.alinma.tadawul.market.domain.lov.SystemStatus;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;

public class MarketAlert {

	private String alertId;
	private String notificationMethod;
	private String qunatity;
	private int isActive;
	private String triggerSymbolType;
	private String triggerSymbolValue;
	private String frequencyType;
	private String criterionType;
	private String criterionRule;
	private String criterionValue1;
	private String criterionValue2;
	private String CIF;
	private String userId;
	private String userEmail;
	private String userMobileNo;
	private String preferedLang;
	private String systemStatus;
	private Date createdTime;
	private CombinedDate startDate;
	private CombinedDate endDate;
	private String lastHistoryId;
	private int versionNo;
	private int noOfThreads;// used for testing
	private EntityDefaultKey entityKey;
	private String isSuccess;
	private String errorCode;

	public String getAlertId() {
		return alertId;
	}

	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}

	public String getNotificationMethod() {
		return notificationMethod;
	}

	public void setNotificationMethod(String notificationMethod) {
		this.notificationMethod = notificationMethod;
	}

	public String getQunatity() {
		return qunatity;
	}

	public void setQunatity(String qunatity) {
		this.qunatity = qunatity;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public String getTriggerSymbolType() {
		return triggerSymbolType;
	}

	public void setTriggerSymbolType(String triggerSymbolType) {
		this.triggerSymbolType = triggerSymbolType;
	}

	public String getTriggerSymbolValue() {
		return triggerSymbolValue;
	}

	public void setTriggerSymbolValue(String triggerSymbolValue) {
		this.triggerSymbolValue = triggerSymbolValue;
	}

	public String getFrequencyType() {
		return frequencyType;
	}

	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	public String getCriterionType() {
		return criterionType;
	}

	public void setCriterionType(String criterionType) {
		this.criterionType = criterionType;
	}

	public String getCriterionRule() {
		return criterionRule;
	}

	public void setCriterionRule(String criterionRule) {
		this.criterionRule = criterionRule;
	}

	public String getCriterionValue1() {
		return criterionValue1;
	}

	public void setCriterionValue1(String criterionValue1) {
		this.criterionValue1 = criterionValue1;
	}

	public String getCriterionValue2() {
		return criterionValue2;
	}

	public void setCriterionValue2(String criterionValue2) {
		this.criterionValue2 = criterionValue2;
	}

	public String getCIF() {
		return CIF;
	}

	public void setCIF(String cIF) {
		CIF = cIF;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserMobileNo() {
		return userMobileNo;
	}

	public void setUserMobileNo(String userMobileNo) {
		this.userMobileNo = userMobileNo;
	}

	public String getPreferedLang() {
		return preferedLang;
	}

	public void setPreferedLang(String preferedLang) {
		this.preferedLang = preferedLang;
	}

	public String getSystemStatus() {
		if (systemStatus.equals(SystemStatus.EXECUTED.getCode())) {
			if (isSuccess.equals("1")) {
				return SystemStatus.EXECUTED.getCode();
			} else if (isSuccess.equals("0")) {
				return SystemStatus.FAILED.getCode();
			}
		} else if (systemStatus.equals(SystemStatus.INIT.getCode())) {
			if (endDate.getGregorianDate().compareTo(new Date()) < 0) {
				return SystemStatus.EXPIRED.getCode();
			}
		}
		return systemStatus;
	}

	public void setSystemStatus(String systemStatus) {
		this.systemStatus = systemStatus;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public String getLastHistoryId() {
		return lastHistoryId;
	}

	public void setLastHistoryId(String lastHistoryId) {
		this.lastHistoryId = lastHistoryId;
	}

	public int getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(int versionNo) {
		this.versionNo = versionNo;
	}

	public int getNoOfThreads() {
		return noOfThreads;
	}

	public void setNoOfThreads(int noOfThreads) {
		this.noOfThreads = noOfThreads;
	}

	public EntityDefaultKey getEntityKey() {
		return entityKey;
	}

	public void setEntityKey(EntityDefaultKey entityKey) {
		this.entityKey = entityKey;
	}

	public String getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(String isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	
	public CombinedDate getStartDate() {
		return startDate;
	}

	
	public void setStartDate(CombinedDate startDate) {
		this.startDate = startDate;
	}

	
	public CombinedDate getEndDate() {
		return endDate;
	}

	
	public void setEndDate(CombinedDate endDate) {
		this.endDate = endDate;
	}
}
