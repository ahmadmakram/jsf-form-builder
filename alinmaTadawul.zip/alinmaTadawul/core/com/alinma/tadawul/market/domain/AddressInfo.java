package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.EntityKey;

public class AddressInfo extends BusinessObject {

	private EntityKey addressType;
	private EntityKey city;
	private String postalCode;
	private String addPOBox;
	private String lineOne;
	private String lineTwo;
	private String lineThree;
	private String lineFour;
	private EntityKey countryCode;
	private String stateCode;

	public EntityKey getAddressType() {
		return addressType;
	}

	public void setAddressType(EntityKey addressType) {
		this.addressType = addressType;
	}

	public EntityKey getCity() {
		return city;
	}

	public void setCity(EntityKey city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getAddPOBox() {
		return addPOBox;
	}

	public void setAddPOBox(String addPOBox) {
		this.addPOBox = addPOBox;
	}

	public String getLineOne() {
		return lineOne;
	}

	public void setLineOne(String lineOne) {
		this.lineOne = lineOne;
	}

	public String getLineTwo() {
		return lineTwo;
	}

	public void setLineTwo(String lineTwo) {
		this.lineTwo = lineTwo;
	}

	public String getLineThree() {
		return lineThree;
	}

	public void setLineThree(String lineThree) {
		this.lineThree = lineThree;
	}

	public String getLineFour() {
		return lineFour;
	}

	public void setLineFour(String lineFour) {
		this.lineFour = lineFour;
	}

	public EntityKey getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(EntityKey countryCode) {
		this.countryCode = countryCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
}
