package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum IsPrimaryEnum implements EntityKey {
	PRIMARY("Y"), BACKUP("N");

	private String code;

	IsPrimaryEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	private static Map<String, IsPrimaryEnum> map;
	static {
		map = new Hashtable<String, IsPrimaryEnum>();
		for (IsPrimaryEnum value : IsPrimaryEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	public static IsPrimaryEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
