package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum ShowSessionHistoryFlag implements EntityKey {
	SHOW_SESSION_HISTORY("Y"), NOT_SHOW_SESSION_HISTORY("N");

	private String code;
	private static Map<String, ShowSessionHistoryFlag> map;
	static {
		map = new Hashtable<String, ShowSessionHistoryFlag>();
		for (ShowSessionHistoryFlag value : ShowSessionHistoryFlag.values()) {
			map.put(value.getCode(), value);
		}
	}

	ShowSessionHistoryFlag(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static ShowSessionHistoryFlag getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
