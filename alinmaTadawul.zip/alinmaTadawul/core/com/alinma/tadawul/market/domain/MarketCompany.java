package com.alinma.tadawul.market.domain;

import java.util.ArrayList;
import java.util.List;

/*
 * Hani Younis
 */
public class MarketCompany {

	private String separatoer = ",";
	private String openTd = "<td>";
	private String closeTd = "</td>";
	private Double bestBid; // BESTBIDPRICE
	private Double bestBidQuantity;// BESTBIDQUANTITY
	private Double change;// CHANGE
	private Double changePercentage; // needs equation: pending change/close *100
	private Double close;// TODAYSCLOSED CLOSE
	private String shortDescriptionEng; // SYMBOLDESCRIPTION_1
	private String shortDescriptionArabic;// //SYMBOLDESCRIPTION_2
	private String longDescriptionEng; // SYMBOLSHORTDESCRIPTION_1
	private String longDescriptionArabic;// SYMBOLSHORTDESCRIPTION_2
	private String direction;
	private String exchange;// EXCHANGECODE
	private Double high;// HIGH
	private Double last;// LASTTRADEPRICE
	private String lastTradeTime;
	private Double low;// LOW
	private Double bestOffer;// LASTASKPRICE
	private Double bestOfferQuantity;// still!!!
	private Double open;
	private String symbol;// SYMBOL
	private Double tradedValue;// TODAYSOPEN OPEN
	private Double trades;
	private Double volume;// VOLUME
	private String companyCategory;// INSTRUMENTTYPE
	private Double average;// average
	private String lastColor = "white";
	private String bestBidColor = "white";
	private String bestBidQuantityColor = "white";
	private String bestOfferColor = "white";
	private String bestOfferQuantityColor = "white";
	private String tradesColor = "white";
	private String volumeColor = "white";
	private String tradedValueColor = "white";
	private String averageColor = "white";
	private String highColor = "white";
	private String lowColor = "white";
	private String lastTradeTimeColor = "white";
	private boolean render;
	private Double mbo_bid1;
	private Double mbo_bid_qty1;
	private Double mbo_bid2;
	private Double mbo_bid_qty2;
	private Double mbo_bid3;
	private Double mbo_bid_qty3;
	private Double mbo_bid4;
	private Double mbo_bid_qty4;
	private Double mbo_bid5;
	private Double mbo_bid_qty5;
	private Double mbo_bid6;
	private Double mbo_bid_qty6;
	private Double mbo_bid7;
	private Double mbo_bid_qty7;
	private Double mbo_bid8;
	private Double mbo_bid_qty8;
	private Double mbo_bid9;
	private Double mbo_bid_qty9;
	private Double mbo_bid10;
	private Double mbo_bid_qty10;
	private Double mbo_ask1;
	private Double mbo_ask_qty1;
	private Double mbo_ask2;
	private Double mbo_ask_qty2;
	private Double mbo_ask3;
	private Double mbo_ask_qty3;
	private Double mbo_ask4;
	private Double mbo_ask_qty4;
	private Double mbo_ask5;
	private Double mbo_ask_qty5;
	private Double mbo_ask6;
	private Double mbo_ask_qty6;
	private Double mbo_ask7;
	private Double mbo_ask_qty7;
	private Double mbo_ask8;
	private Double mbo_ask_qty8;
	private Double mbo_ask9;
	private Double mbo_ask_qty9;
	private Double mbo_ask10;
	private Double mbo_ask_qty10;
	private Double mbp_bid1;
	private Double mbp_bid_qty1;
	private Double mbp_bid_splits1;
	private Double mbp_bid2;
	private Double mbp_bid_qty2;
	private Double mbp_bid_splits2;
	private Double mbp_bid3;
	private Double mbp_bid_qty3;
	private Double mbp_bid_splits3;
	private Double mbp_bid4;
	private Double mbp_bid_qty4;
	private Double mbp_bid_splits4;
	private Double mbp_bid5;
	private Double mbp_bid_qty5;
	private Double mbp_bid_splits5;
	private Double mbp_ask1;
	private Double mbp_ask_qty1;
	private Double mbp_ask_splits1;
	private Double mbp_ask2;
	private Double mbp_ask_qty2;
	private Double mbp_ask_splits2;
	private Double mbp_ask3;
	private Double mbp_ask_qty3;
	private Double mbp_ask_splits3;
	private Double mbp_ask4;
	private Double mbp_ask_qty4;
	private Double mbp_ask_splits4;
	private Double mbp_ask5;
	private Double mbp_ask_qty5;
	private Double mbp_ask_splits5;
	private List<Trade> tradesList;

	public List<Trade> getTradesList() {
		if (tradesList == null) {
			tradesList = new ArrayList<Trade>();
		}
		return tradesList;
	}

	public void setTradesList(List<Trade> tradesList) {
		this.tradesList = tradesList;
	}

	public Double getMbo_bid1() {
		return mbo_bid1;
	}

	public void setMbo_bid1(Double mbo_bid1) {
		this.mbo_bid1 = mbo_bid1;
	}

	public Double getMbo_bid_qty1() {
		return mbo_bid_qty1;
	}

	public void setMbo_bid_qty1(Double mbo_bid_qty1) {
		this.mbo_bid_qty1 = mbo_bid_qty1;
	}

	public Double getMbo_bid2() {
		return mbo_bid2;
	}

	public void setMbo_bid2(Double mbo_bid2) {
		this.mbo_bid2 = mbo_bid2;
	}

	public Double getMbo_bid_qty2() {
		return mbo_bid_qty2;
	}

	public void setMbo_bid_qty2(Double mbo_bid_qty2) {
		this.mbo_bid_qty2 = mbo_bid_qty2;
	}

	public Double getMbo_bid3() {
		return mbo_bid3;
	}

	public void setMbo_bid3(Double mbo_bid3) {
		this.mbo_bid3 = mbo_bid3;
	}

	public Double getMbo_bid_qty3() {
		return mbo_bid_qty3;
	}

	public void setMbo_bid_qty3(Double mbo_bid_qty3) {
		this.mbo_bid_qty3 = mbo_bid_qty3;
	}

	public Double getMbo_bid4() {
		return mbo_bid4;
	}

	public void setMbo_bid4(Double mbo_bid4) {
		this.mbo_bid4 = mbo_bid4;
	}

	public Double getMbo_bid_qty4() {
		return mbo_bid_qty4;
	}

	public void setMbo_bid_qty4(Double mbo_bid_qty4) {
		this.mbo_bid_qty4 = mbo_bid_qty4;
	}

	public Double getMbo_bid5() {
		return mbo_bid5;
	}

	public void setMbo_bid5(Double mbo_bid5) {
		this.mbo_bid5 = mbo_bid5;
	}

	public Double getMbo_bid_qty5() {
		return mbo_bid_qty5;
	}

	public void setMbo_bid_qty5(Double mbo_bid_qty5) {
		this.mbo_bid_qty5 = mbo_bid_qty5;
	}

	public Double getMbo_bid6() {
		return mbo_bid6;
	}

	public void setMbo_bid6(Double mbo_bid6) {
		this.mbo_bid6 = mbo_bid6;
	}

	public Double getMbo_bid_qty6() {
		return mbo_bid_qty6;
	}

	public void setMbo_bid_qty6(Double mbo_bid_qty6) {
		this.mbo_bid_qty6 = mbo_bid_qty6;
	}

	public Double getMbo_bid7() {
		return mbo_bid7;
	}

	public void setMbo_bid7(Double mbo_bid7) {
		this.mbo_bid7 = mbo_bid7;
	}

	public Double getMbo_bid_qty7() {
		return mbo_bid_qty7;
	}

	public void setMbo_bid_qty7(Double mbo_bid_qty7) {
		this.mbo_bid_qty7 = mbo_bid_qty7;
	}

	public Double getMbo_bid8() {
		return mbo_bid8;
	}

	public void setMbo_bid8(Double mbo_bid8) {
		this.mbo_bid8 = mbo_bid8;
	}

	public Double getMbo_bid_qty8() {
		return mbo_bid_qty8;
	}

	public void setMbo_bid_qty8(Double mbo_bid_qty8) {
		this.mbo_bid_qty8 = mbo_bid_qty8;
	}

	public Double getMbo_bid9() {
		return mbo_bid9;
	}

	public void setMbo_bid9(Double mbo_bid9) {
		this.mbo_bid9 = mbo_bid9;
	}

	public Double getMbo_bid_qty9() {
		return mbo_bid_qty9;
	}

	public void setMbo_bid_qty9(Double mbo_bid_qty9) {
		this.mbo_bid_qty9 = mbo_bid_qty9;
	}

	public Double getMbo_bid10() {
		return mbo_bid10;
	}

	public void setMbo_bid10(Double mbo_bid10) {
		this.mbo_bid10 = mbo_bid10;
	}

	public Double getMbo_bid_qty10() {
		return mbo_bid_qty10;
	}

	public void setMbo_bid_qty10(Double mbo_bid_qty10) {
		this.mbo_bid_qty10 = mbo_bid_qty10;
	}

	public Double getMbo_ask1() {
		return mbo_ask1;
	}

	public void setMbo_ask1(Double mbo_ask1) {
		this.mbo_ask1 = mbo_ask1;
	}

	public Double getMbo_ask_qty1() {
		return mbo_ask_qty1;
	}

	public void setMbo_ask_qty1(Double mbo_ask_qty1) {
		this.mbo_ask_qty1 = mbo_ask_qty1;
	}

	public Double getMbo_ask2() {
		return mbo_ask2;
	}

	public void setMbo_ask2(Double mbo_ask2) {
		this.mbo_ask2 = mbo_ask2;
	}

	public Double getMbo_ask_qty2() {
		return mbo_ask_qty2;
	}

	public void setMbo_ask_qty2(Double mbo_ask_qty2) {
		this.mbo_ask_qty2 = mbo_ask_qty2;
	}

	public Double getMbo_ask3() {
		return mbo_ask3;
	}

	public void setMbo_ask3(Double mbo_ask3) {
		this.mbo_ask3 = mbo_ask3;
	}

	public Double getMbo_ask_qty3() {
		return mbo_ask_qty3;
	}

	public void setMbo_ask_qty3(Double mbo_ask_qty3) {
		this.mbo_ask_qty3 = mbo_ask_qty3;
	}

	public Double getMbo_ask4() {
		return mbo_ask4;
	}

	public void setMbo_ask4(Double mbo_ask4) {
		this.mbo_ask4 = mbo_ask4;
	}

	public Double getMbo_ask_qty4() {
		return mbo_ask_qty4;
	}

	public void setMbo_ask_qty4(Double mbo_ask_qty4) {
		this.mbo_ask_qty4 = mbo_ask_qty4;
	}

	public Double getMbo_ask5() {
		return mbo_ask5;
	}

	public void setMbo_ask5(Double mbo_ask5) {
		this.mbo_ask5 = mbo_ask5;
	}

	public Double getMbo_ask_qty5() {
		return mbo_ask_qty5;
	}

	public void setMbo_ask_qty5(Double mbo_ask_qty5) {
		this.mbo_ask_qty5 = mbo_ask_qty5;
	}

	public Double getMbo_ask6() {
		return mbo_ask6;
	}

	public void setMbo_ask6(Double mbo_ask6) {
		this.mbo_ask6 = mbo_ask6;
	}

	public Double getMbo_ask_qty6() {
		return mbo_ask_qty6;
	}

	public void setMbo_ask_qty6(Double mbo_ask_qty6) {
		this.mbo_ask_qty6 = mbo_ask_qty6;
	}

	public Double getMbo_ask7() {
		return mbo_ask7;
	}

	public void setMbo_ask7(Double mbo_ask7) {
		this.mbo_ask7 = mbo_ask7;
	}

	public Double getMbo_ask_qty7() {
		return mbo_ask_qty7;
	}

	public void setMbo_ask_qty7(Double mbo_ask_qty7) {
		this.mbo_ask_qty7 = mbo_ask_qty7;
	}

	public Double getMbo_ask8() {
		return mbo_ask8;
	}

	public void setMbo_ask8(Double mbo_ask8) {
		this.mbo_ask8 = mbo_ask8;
	}

	public Double getMbo_ask_qty8() {
		return mbo_ask_qty8;
	}

	public void setMbo_ask_qty8(Double mbo_ask_qty8) {
		this.mbo_ask_qty8 = mbo_ask_qty8;
	}

	public Double getMbo_ask9() {
		return mbo_ask9;
	}

	public void setMbo_ask9(Double mbo_ask9) {
		this.mbo_ask9 = mbo_ask9;
	}

	public Double getMbo_ask_qty9() {
		return mbo_ask_qty9;
	}

	public void setMbo_ask_qty9(Double mbo_ask_qty9) {
		this.mbo_ask_qty9 = mbo_ask_qty9;
	}

	public Double getMbo_ask10() {
		return mbo_ask10;
	}

	public void setMbo_ask10(Double mbo_ask10) {
		this.mbo_ask10 = mbo_ask10;
	}

	public Double getMbo_ask_qty10() {
		return mbo_ask_qty10;
	}

	public void setMbo_ask_qty10(Double mbo_ask_qty10) {
		this.mbo_ask_qty10 = mbo_ask_qty10;
	}

	public Double getMbp_bid1() {
		return mbp_bid1;
	}

	public void setMbp_bid1(Double mbp_bid1) {
		this.mbp_bid1 = mbp_bid1;
	}

	public Double getMbp_bid_qty1() {
		return mbp_bid_qty1;
	}

	public void setMbp_bid_qty1(Double mbp_bid_qty1) {
		this.mbp_bid_qty1 = mbp_bid_qty1;
	}

	public Double getMbp_bid_splits1() {
		return mbp_bid_splits1;
	}

	public void setMbp_bid_splits1(Double mbp_bid_splits1) {
		this.mbp_bid_splits1 = mbp_bid_splits1;
	}

	public Double getMbp_bid2() {
		return mbp_bid2;
	}

	public void setMbp_bid2(Double mbp_bid2) {
		this.mbp_bid2 = mbp_bid2;
	}

	public Double getMbp_bid_qty2() {
		return mbp_bid_qty2;
	}

	public void setMbp_bid_qty2(Double mbp_bid_qty2) {
		this.mbp_bid_qty2 = mbp_bid_qty2;
	}

	public Double getMbp_bid_splits2() {
		return mbp_bid_splits2;
	}

	public void setMbp_bid_splits2(Double mbp_bid_splits2) {
		this.mbp_bid_splits2 = mbp_bid_splits2;
	}

	public Double getMbp_bid3() {
		return mbp_bid3;
	}

	public void setMbp_bid3(Double mbp_bid3) {
		this.mbp_bid3 = mbp_bid3;
	}

	public Double getMbp_bid_qty3() {
		return mbp_bid_qty3;
	}

	public void setMbp_bid_qty3(Double mbp_bid_qty3) {
		this.mbp_bid_qty3 = mbp_bid_qty3;
	}

	public Double getMbp_bid_splits3() {
		return mbp_bid_splits3;
	}

	public void setMbp_bid_splits3(Double mbp_bid_splits3) {
		this.mbp_bid_splits3 = mbp_bid_splits3;
	}

	public Double getMbp_bid4() {
		return mbp_bid4;
	}

	public void setMbp_bid4(Double mbp_bid4) {
		this.mbp_bid4 = mbp_bid4;
	}

	public Double getMbp_bid_qty4() {
		return mbp_bid_qty4;
	}

	public void setMbp_bid_qty4(Double mbp_bid_qty4) {
		this.mbp_bid_qty4 = mbp_bid_qty4;
	}

	public Double getMbp_bid_splits4() {
		return mbp_bid_splits4;
	}

	public void setMbp_bid_splits4(Double mbp_bid_splits4) {
		this.mbp_bid_splits4 = mbp_bid_splits4;
	}

	public Double getMbp_bid5() {
		return mbp_bid5;
	}

	public void setMbp_bid5(Double mbp_bid5) {
		this.mbp_bid5 = mbp_bid5;
	}

	public Double getMbp_bid_qty5() {
		return mbp_bid_qty5;
	}

	public void setMbp_bid_qty5(Double mbp_bid_qty5) {
		this.mbp_bid_qty5 = mbp_bid_qty5;
	}

	public Double getMbp_bid_splits5() {
		return mbp_bid_splits5;
	}

	public void setMbp_bid_splits5(Double mbp_bid_splits5) {
		this.mbp_bid_splits5 = mbp_bid_splits5;
	}

	public Double getMbp_ask1() {
		return mbp_ask1;
	}

	public void setMbp_ask1(Double mbp_ask1) {
		this.mbp_ask1 = mbp_ask1;
	}

	public Double getMbp_ask_qty1() {
		return mbp_ask_qty1;
	}

	public void setMbp_ask_qty1(Double mbp_ask_qty1) {
		this.mbp_ask_qty1 = mbp_ask_qty1;
	}

	public Double getMbp_ask_splits1() {
		return mbp_ask_splits1;
	}

	public void setMbp_ask_splits1(Double mbp_ask_splits1) {
		this.mbp_ask_splits1 = mbp_ask_splits1;
	}

	public Double getMbp_ask2() {
		return mbp_ask2;
	}

	public void setMbp_ask2(Double mbp_ask2) {
		this.mbp_ask2 = mbp_ask2;
	}

	public Double getMbp_ask_qty2() {
		return mbp_ask_qty2;
	}

	public void setMbp_ask_qty2(Double mbp_ask_qty2) {
		this.mbp_ask_qty2 = mbp_ask_qty2;
	}

	public Double getMbp_ask_splits2() {
		return mbp_ask_splits2;
	}

	public void setMbp_ask_splits2(Double mbp_ask_splits2) {
		this.mbp_ask_splits2 = mbp_ask_splits2;
	}

	public Double getMbp_ask3() {
		return mbp_ask3;
	}

	public void setMbp_ask3(Double mbp_ask3) {
		this.mbp_ask3 = mbp_ask3;
	}

	public Double getMbp_ask_qty3() {
		return mbp_ask_qty3;
	}

	public void setMbp_ask_qty3(Double mbp_ask_qty3) {
		this.mbp_ask_qty3 = mbp_ask_qty3;
	}

	public Double getMbp_ask_splits3() {
		return mbp_ask_splits3;
	}

	public void setMbp_ask_splits3(Double mbp_ask_splits3) {
		this.mbp_ask_splits3 = mbp_ask_splits3;
	}

	public Double getMbp_ask4() {
		return mbp_ask4;
	}

	public void setMbp_ask4(Double mbp_ask4) {
		this.mbp_ask4 = mbp_ask4;
	}

	public Double getMbp_ask_qty4() {
		return mbp_ask_qty4;
	}

	public void setMbp_ask_qty4(Double mbp_ask_qty4) {
		this.mbp_ask_qty4 = mbp_ask_qty4;
	}

	public Double getMbp_ask_splits4() {
		return mbp_ask_splits4;
	}

	public void setMbp_ask_splits4(Double mbp_ask_splits4) {
		this.mbp_ask_splits4 = mbp_ask_splits4;
	}

	public Double getMbp_ask5() {
		return mbp_ask5;
	}

	public void setMbp_ask5(Double mbp_ask5) {
		this.mbp_ask5 = mbp_ask5;
	}

	public Double getMbp_ask_qty5() {
		return mbp_ask_qty5;
	}

	public void setMbp_ask_qty5(Double mbp_ask_qty5) {
		this.mbp_ask_qty5 = mbp_ask_qty5;
	}

	public Double getMbp_ask_splits5() {
		return mbp_ask_splits5;
	}

	public void setMbp_ask_splits5(Double mbp_ask_splits5) {
		this.mbp_ask_splits5 = mbp_ask_splits5;
	}

	public boolean isRender() {
		return render;
	}

	public void setRender(boolean render) {
		this.render = render;
	}

	public String getLastColor() {
		return lastColor;
	}

	public void setLastColor(String lastColor) {
		this.lastColor = lastColor;
	}

	public String getBestBidColor() {
		return bestBidColor;
	}

	public void setBestBidColor(String bestBidColor) {
		this.bestBidColor = bestBidColor;
	}

	public String getBestBidQuantityColor() {
		return bestBidQuantityColor;
	}

	public void setBestBidQuantityColor(String bestBidQuantityColor) {
		this.bestBidQuantityColor = bestBidQuantityColor;
	}

	public String getBestOfferColor() {
		return bestOfferColor;
	}

	public void setBestOfferColor(String bestOfferColor) {
		this.bestOfferColor = bestOfferColor;
	}

	public String getBestOfferQuantityColor() {
		return bestOfferQuantityColor;
	}

	public void setBestOfferQuantityColor(String bestOfferQuantityColor) {
		this.bestOfferQuantityColor = bestOfferQuantityColor;
	}

	public String getTradesColor() {
		return tradesColor;
	}

	public void setTradesColor(String tradesColor) {
		this.tradesColor = tradesColor;
	}

	public String getVolumeColor() {
		return volumeColor;
	}

	public void setVolumeColor(String volumeColor) {
		this.volumeColor = volumeColor;
	}

	public String getTradedValueColor() {
		return tradedValueColor;
	}

	public void setTradedValueColor(String tradedValueColor) {
		this.tradedValueColor = tradedValueColor;
	}

	public String getAverageColor() {
		return averageColor;
	}

	public void setAverageColor(String averageColor) {
		this.averageColor = averageColor;
	}

	public String getHighColor() {
		return highColor;
	}

	public void setHighColor(String highColor) {
		this.highColor = highColor;
	}

	public String getLowColor() {
		return lowColor;
	}

	public void setLowColor(String lowColor) {
		this.lowColor = lowColor;
	}

	public String getLastTradeTimeColor() {
		return lastTradeTimeColor;
	}

	public void setLastTradeTimeColor(String lastTradeTimeColor) {
		this.lastTradeTimeColor = lastTradeTimeColor;
	}

	private boolean appear = true;

	public boolean isAppear() {
		return appear;
	}

	public void setAppear(boolean appear) {
		this.appear = appear;
	}

	public Double getBestBid() {
		return bestBid;
	}

	public void setBestBid(Double bestBid) {
		this.bestBid = bestBid;
	}

	public Double getBestBidQuantity() {
		return bestBidQuantity;
	}

	public void setBestBidQuantity(Double bestBidQuantity) {
		this.bestBidQuantity = bestBidQuantity;
	}

	public Double getBestOffer() {
		return bestOffer;
	}

	public void setBestOffer(Double bestOffer) {
		this.bestOffer = bestOffer;
	}

	public Double getBestOfferQuantity() {
		return bestOfferQuantity;
	}

	public void setBestOfferQuantity(Double bestOfferQuantity) {
		this.bestOfferQuantity = bestOfferQuantity;
	}

	public Double getChange() {
		return change;
	}

	public void setChange(Double change) {
		this.change = change;
	}

	public Double getChangePercentage() {
		return (changePercentage / 100);
	}

	public void setChangePercentage(Double changePercentage) {
		this.changePercentage = changePercentage;
	}

	public Double getClose() {
		return close;
	}

	public void setClose(Double close) {
		this.close = close;
	}

	public String getShortDescriptionEng() {
		return shortDescriptionEng;
	}

	public void setShortDescriptionEng(String shortDescriptionEng) {
		this.shortDescriptionEng = shortDescriptionEng;
	}

	public String getShortDescriptionArabic() {
		return shortDescriptionArabic;
	}

	public void setShortDescriptionArabic(String shortDescriptionArabic) {
		this.shortDescriptionArabic = shortDescriptionArabic;
	}

	public String getLongDescriptionEng() {
		return longDescriptionEng;
	}

	public void setLongDescriptionEng(String longDescriptionEng) {
		this.longDescriptionEng = longDescriptionEng;
	}

	public String getLongDescriptionArabic() {
		return longDescriptionArabic;
	}

	public void setLongDescriptionArabic(String longDescriptionArabic) {
		this.longDescriptionArabic = longDescriptionArabic;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getExchange() {
		return exchange;
	}

	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	public Double getHigh() {
		return high;
	}

	public void setHigh(Double high) {
		this.high = high;
	}

	public Double getLast() {
		return last;
	}

	public void setLast(Double last) {
		this.last = last;
	}

	public String getLastTradeTime() {
		if (lastTradeTime != null && lastTradeTime.length() > 0) {
			String timeOnly = lastTradeTime.substring(lastTradeTime.indexOf(' '), lastTradeTime.length());
			timeOnly = timeOnly.trim();
			String hour = timeOnly.substring(0, timeOnly.indexOf(":"));
			hour = (Integer.valueOf(hour) + 3) + "";
			if (hour.length() == 1) {
				hour = "0" + hour;
			}
			timeOnly = hour + timeOnly.substring(timeOnly.indexOf(":"));
			return timeOnly;
		}
		return lastTradeTime;
	}

	public void setLastTradeTime(String lastTradeTime) {
		this.lastTradeTime = lastTradeTime;
	}

	public Double getLow() {
		return low;
	}

	public void setLow(Double low) {
		this.low = low;
	}

	public Double getOpen() {
		return open;
	}

	public void setOpen(Double open) {
		this.open = open;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public Double getTradedValue() {
		return tradedValue;
	}

	public void setTradedValue(Double tradedValue) {
		this.tradedValue = tradedValue;
	}

	public Double getTrades() {
		return trades;
	}

	public void setTrades(Double trades) {
		this.trades = trades;
	}

	public Double getVolume() {
		return volume;
	}

	public void setVolume(Double volume) {
		this.volume = volume;
	}

	public String getCompanyCategory() {
		return companyCategory;
	}

	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}

	public Double getAverage() {
		return average;
	}

	public void setAverage(Double average) {
		this.average = average;
	}

	public String toString() {
		StringBuffer toString = new StringBuffer();
		toString.append(this.getSymbol());
		toString.append(separatoer);
		toString.append(this.getShortDescriptionEng());
		toString.append(separatoer);
		toString.append(this.getShortDescriptionArabic());
		toString.append(separatoer);
		toString.append(this.getClose().doubleValue());
		toString.append(separatoer);
		toString.append(this.getOpen().doubleValue());
		toString.append(separatoer);
		toString.append(this.getLast().doubleValue());
		toString.append(separatoer);
		toString.append(this.getChange().doubleValue());
		toString.append(separatoer);
		toString.append(this.getChangePercentage().doubleValue());
		toString.append(separatoer);
		toString.append(this.getBestBid().doubleValue());
		toString.append(separatoer);
		toString.append(this.getBestBidQuantity().doubleValue());
		toString.append(separatoer);
		toString.append(this.getBestOffer().doubleValue());
		toString.append(separatoer);
		toString.append(this.getBestOfferQuantity().doubleValue());
		toString.append(separatoer);
		toString.append(this.getTrades().doubleValue());
		toString.append(separatoer);
		toString.append(this.getTradedValue().doubleValue());
		toString.append(separatoer);
		toString.append(this.getAverage().doubleValue());
		toString.append(separatoer);
		toString.append(this.getHigh().doubleValue());
		toString.append(separatoer);
		toString.append(this.getLow().doubleValue());
		toString.append(separatoer);
		toString.append(this.getLastTradeTime());
		toString.append(separatoer);
		toString.append(this.getVolume());
		toString.append(separatoer);
		toString.append(this.getMbo_bid1());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty1());
		toString.append(separatoer);
		toString.append(this.getMbo_ask1());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty1());
		toString.append(separatoer);
		toString.append(this.getMbo_bid2());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty2());
		toString.append(separatoer);
		toString.append(this.getMbo_ask2());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty2());
		toString.append(separatoer);
		toString.append(this.getMbo_bid3());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty3());
		toString.append(separatoer);
		toString.append(this.getMbo_ask3());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty3());
		toString.append(separatoer);
		toString.append(this.getMbo_bid4());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty4());
		toString.append(separatoer);
		toString.append(this.getMbo_ask4());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty4());
		toString.append(separatoer);
		toString.append(this.getMbo_bid5());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty5());
		toString.append(separatoer);
		toString.append(this.getMbo_ask5());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty5());
		toString.append(separatoer);
		toString.append(this.getMbo_bid6());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty6());
		toString.append(separatoer);
		toString.append(this.getMbo_ask6());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty6());
		toString.append(separatoer);
		toString.append(this.getMbo_bid7());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty7());
		toString.append(separatoer);
		toString.append(this.getMbo_ask7());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty7());
		toString.append(separatoer);
		toString.append(this.getMbo_bid8());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty8());
		toString.append(separatoer);
		toString.append(this.getMbo_ask8());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty8());
		toString.append(separatoer);
		toString.append(this.getMbo_bid9());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty9());
		toString.append(separatoer);
		toString.append(this.getMbo_ask9());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty9());
		toString.append(separatoer);
		toString.append(this.getMbo_bid10());
		toString.append(separatoer);
		toString.append(this.getMbo_bid_qty10());
		toString.append(separatoer);
		toString.append(this.getMbo_ask10());
		toString.append(separatoer);
		toString.append(this.getMbo_ask_qty10());
		toString.append(separatoer);
		toString.append(this.getMbp_bid1());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_qty1());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_splits1());
		toString.append(separatoer);
		toString.append(this.getMbp_ask1());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_qty1());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_splits1());
		toString.append(separatoer);
		toString.append(this.getMbp_bid2());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_qty2());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_splits2());
		toString.append(separatoer);
		toString.append(this.getMbp_ask2());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_qty2());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_splits2());
		toString.append(separatoer);
		toString.append(this.getMbp_bid3());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_qty3());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_splits3());
		toString.append(separatoer);
		toString.append(this.getMbp_ask3());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_qty3());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_splits3());
		toString.append(separatoer);
		toString.append(this.getMbp_bid4());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_qty4());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_splits4());
		toString.append(separatoer);
		toString.append(this.getMbp_ask4());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_qty4());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_splits4());
		toString.append(separatoer);
		toString.append(this.getMbp_bid5());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_qty5());
		toString.append(separatoer);
		toString.append(this.getMbp_bid_splits5());
		toString.append(separatoer);
		toString.append(this.getMbp_ask5());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_qty5());
		toString.append(separatoer);
		toString.append(this.getMbp_ask_splits5());
		return toString.toString();
	}
	// public String toString(){
	// StringBuffer toString = new StringBuffer();
	// toString.append(openTd);
	// toString.append(this.getSymbol());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getShortDescriptionEng());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getShortDescriptionArabic());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getClose().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getOpen().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getLast().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getChange().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getChangePercentage().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getBestBid().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getBestBidQuantity().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getBestOffer().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getBestOfferQuantity().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getTrades().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getTradedValue().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getAverage().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getHigh().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getLow().doubleValue());
	// toString.append(closeTd);
	// toString.append(openTd);
	// toString.append(this.getLastTradeTime());
	// toString.append(closeTd);
	//
	// return toString.toString();
	// }
	// trades,direction,lastTradeTime,last from other table as live feeds for the first time
	// will be empty
	// s.SYMBOL,
	// s.EXCHANGECODE,
	// m.INSTRUMENTTYPE,
	// s.CURRENCY,
	// s.PREVIOUSCLOSED,
	// s.MINPRICE,
	// s.MAXPRICE,
	// s.LASTTRADEPRICE,
	// 1 ACCESSLEVEL,
	// '-' NATIONALITY,
	// m.SECTOR,
	// s.ASSETCLASS,
	// s.BESTBIDPRICE,
	// m.SYMBOLDESCRIPTION_1 AS LONGDESC_1,
	// m.SYMBOLDESCRIPTION_2 AS LONGDESC_2,
	// m.SYMBOLSHORTDESCRIPTION_1 SHORTDESC_1,
	// m.SYMBOLSHORTDESCRIPTION_2 SHORTDESC_2,
	// s.VOLUME,
	// s.HIGH,
	// s.LOW,
	// s.BESTASKPRICE,
	// s.CHANGE,
	// s.BESTBIDQUANTITY,
	// s.BESTASKQUANTITY,
	// s.TODAYSOPEN OPEN,
	// s.TODAYSCLOSED CLOSE,
	// s.LASTASKPRICE,
	// s.LASTBIDPRICE
	//
	//
}
