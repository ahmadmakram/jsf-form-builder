package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum MutualFundOrderStatus implements EntityKey {
	EXECUTED("Executed"), NEW("New");

	private String code;
	private static Map<String, MutualFundOrderStatus> map;
	static {
		map = new Hashtable<String, MutualFundOrderStatus>();
		for (MutualFundOrderStatus value : MutualFundOrderStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	MutualFundOrderStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MutualFundOrderStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
