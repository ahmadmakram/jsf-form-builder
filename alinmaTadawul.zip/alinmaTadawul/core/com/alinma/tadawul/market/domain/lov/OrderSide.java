/**
 * 
 */
package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the channel Ids
 * 
 * @author Mohammad Suliman
 * 
 */
public enum OrderSide implements EntityKey {
	SELL("SSL"), BUY("SPR");

	private String code;
	private static Map<String, OrderSide> map;
	static {
		map = new Hashtable<String, OrderSide>();
		for (OrderSide value : OrderSide.values()) {
			map.put(value.getCode(), value);
		}
	}

	OrderSide(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static OrderSide getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
