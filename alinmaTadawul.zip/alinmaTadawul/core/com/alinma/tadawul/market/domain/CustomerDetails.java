package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.BusinessObject;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Omar Mohaidat
 * 
 */
public class CustomerDetails extends BusinessObject {

	private String cif;
	private String alinmaId;
	private EntityKey customerType;
	private IdDoc idDoc;
	private String firstName;
	private String fatherName;
	private String grandFatherName;
	private String grandGrandFatherName;
	private String shortName;
	private String nickName;
	private String familyName;
	private String fullName;
	private EntityKey language;
	private EntityKey gender;
	private CombinedDate birthDate;
	private CombinedDate birthDateHijri;
	private String birthPlace;
	private EntityKey nationality;
	private CombinedDate openDate;
	private CombinedDate opneDateHijri;
	private String employerName;
	private String jobTitle;
	private EntityKey maritalStatus;
	private EntityKey sector;
	private EntityKey custSAMAStatus;
	private EntityKey customerStatus;
	private EntityKey legalStatus;
	private EntityKey segment;
	private EntityKey branchId;
	private EntityKey country;
	private String email;
	private String imageId;
	private AddressInfo addressInfo;
	private PhoneInformation phoneInfo;
	private RelationshipManagerInfo relationshipManagerInfo;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getAlinmaId() {
		return alinmaId;
	}

	public void setAlinmaId(String alinmaId) {
		this.alinmaId = alinmaId;
	}

	public EntityKey getCustomerType() {
		return customerType;
	}

	public void setCustomerType(EntityKey customerType) {
		this.customerType = customerType;
	}

	public IdDoc getIdDoc() {
		return idDoc;
	}

	public void setIdDoc(IdDoc idDoc) {
		this.idDoc = idDoc;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getGrandFatherName() {
		return grandFatherName;
	}

	public void setGrandFatherName(String grandFatherName) {
		this.grandFatherName = grandFatherName;
	}

	public String getGrandGrandFatherName() {
		return grandGrandFatherName;
	}

	public void setGrandGrandFatherName(String grandGrandFatherName) {
		this.grandGrandFatherName = grandGrandFatherName;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public EntityKey getLanguage() {
		return language;
	}

	public void setLanguage(EntityKey language) {
		this.language = language;
	}

	public EntityKey getGender() {
		return gender;
	}

	public void setGender(EntityKey gender) {
		this.gender = gender;
	}

	public CombinedDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(CombinedDate birthDate) {
		this.birthDate = birthDate;
	}

	public CombinedDate getBirthDateHijri() {
		return birthDateHijri;
	}

	public void setBirthDateHijri(CombinedDate birthDateHijri) {
		this.birthDateHijri = birthDateHijri;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	public EntityKey getNationality() {
		return nationality;
	}

	public void setNationality(EntityKey nationality) {
		this.nationality = nationality;
	}

	public CombinedDate getOpenDate() {
		return openDate;
	}

	public void setOpenDate(CombinedDate openDate) {
		this.openDate = openDate;
	}

	public CombinedDate getOpneDateHijri() {
		return opneDateHijri;
	}

	public void setOpneDateHijri(CombinedDate opneDateHijri) {
		this.opneDateHijri = opneDateHijri;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public EntityKey getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(EntityKey maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public EntityKey getSector() {
		return sector;
	}

	public void setSector(EntityKey sector) {
		this.sector = sector;
	}

	public EntityKey getCustSAMAStatus() {
		return custSAMAStatus;
	}

	public void setCustSAMAStatus(EntityKey custSAMAStatus) {
		this.custSAMAStatus = custSAMAStatus;
	}

	public EntityKey getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(EntityKey customerStatus) {
		this.customerStatus = customerStatus;
	}

	public EntityKey getLegalStatus() {
		return legalStatus;
	}

	public void setLegalStatus(EntityKey legalStatus) {
		this.legalStatus = legalStatus;
	}

	public EntityKey getSegment() {
		return segment;
	}

	public void setSegment(EntityKey segment) {
		this.segment = segment;
	}

	public EntityKey getBranchId() {
		return branchId;
	}

	public void setBranchId(EntityKey branchId) {
		this.branchId = branchId;
	}

	public EntityKey getCountry() {
		return country;
	}

	public void setCountry(EntityKey country) {
		this.country = country;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public AddressInfo getAddressInfo() {
		return addressInfo;
	}

	public void setAddressInfo(AddressInfo addressInfo) {
		this.addressInfo = addressInfo;
	}

	public PhoneInformation getPhoneInfo() {
		return phoneInfo;
	}

	public void setPhoneInfo(PhoneInformation phoneInfo) {
		this.phoneInfo = phoneInfo;
	}

	public RelationshipManagerInfo getRelationshipManagerInfo() {
		return relationshipManagerInfo;
	}

	public void setRelationshipManagerInfo(RelationshipManagerInfo relationshipManagerInfo) {
		this.relationshipManagerInfo = relationshipManagerInfo;
	}
}
