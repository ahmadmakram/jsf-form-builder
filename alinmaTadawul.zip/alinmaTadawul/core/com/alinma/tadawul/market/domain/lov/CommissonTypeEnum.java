package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Wael nour-eldin
 * 
 */
public enum CommissonTypeEnum implements EntityKey {
	PERCENTAGE("P"), AMOUNT("A");

	private String code;
	private static Map<String, CommissonTypeEnum> map;
	static {
		map = new Hashtable<String, CommissonTypeEnum>();
		for (CommissonTypeEnum value : CommissonTypeEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	CommissonTypeEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static CommissonTypeEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
