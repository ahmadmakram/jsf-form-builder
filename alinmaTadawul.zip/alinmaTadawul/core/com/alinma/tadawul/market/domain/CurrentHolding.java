package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.lov.CurrencyCode;

public class CurrentHolding {

	private String units;
	private String amount;
	private CurrencyCode currencyCode;

	public CurrentHolding() {
	}

	public CurrentHolding(String units, String amount, CurrencyCode currencyCode) {
		this.units = units;
		this.amount = amount;
		this.currencyCode = currencyCode;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public CurrencyCode getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(CurrencyCode currencyCode) {
		this.currencyCode = currencyCode;
	}
}
