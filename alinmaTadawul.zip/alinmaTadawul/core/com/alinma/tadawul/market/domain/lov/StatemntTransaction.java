package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Wael nour-eldin
 * 
 */
public enum StatemntTransaction implements EntityKey {
	SELL("SSL"), BUY("SPR"), TRANSFER_IN("TRI"), TRANSFER_OUT("TRO");

	private String code;
	private static Map<String, StatemntTransaction> map;
	static {
		map = new Hashtable<String, StatemntTransaction>();
		for (StatemntTransaction value : StatemntTransaction.values()) {
			map.put(value.getCode(), value);
		}
	}

	StatemntTransaction(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static StatemntTransaction getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
