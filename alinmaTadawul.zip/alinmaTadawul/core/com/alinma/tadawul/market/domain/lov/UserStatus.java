package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum UserStatus implements EntityKey {
	ENABLED("0"), DISABLED_BY_BANK("1"), DISABLED_BY_MAIN_USER("2"), MAIN_USER_IS_DISABLED("3"), DELETED_BY_BANK("4"), DELETED_BY_MAIN_USER("5"), DELETED_BY_BANK_BECAUSE_MAIN_USER_IS_DELETED("6"), PENDING_APPROVAL_USING_MAKER_CHECKER_MECHANISM(
			"7");

	private String code;
	private static Map<String, UserStatus> map;
	static {
		map = new Hashtable<String, UserStatus>();
		for (UserStatus value : UserStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	UserStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static UserStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
