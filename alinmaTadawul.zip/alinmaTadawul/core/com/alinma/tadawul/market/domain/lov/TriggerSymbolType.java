package com.alinma.tadawul.market.domain.lov;

public enum TriggerSymbolType {
	TASI("1", "TASI"), SECTOR("2", "SECTOR"), SYMBOL("3", "SYMBOL");

	private String code;
	private String label;

	private TriggerSymbolType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
