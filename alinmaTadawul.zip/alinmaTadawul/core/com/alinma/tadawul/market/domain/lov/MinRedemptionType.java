package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum MinRedemptionType {
	UNIT("Unit"), AMOUNT("Amount");

	private String code;
	private static Map<String, MinRedemptionType> map;
	static {
		map = new Hashtable<String, MinRedemptionType>();
		for (MinRedemptionType value : MinRedemptionType.values()) {
			map.put(value.getCode(), value);
		}
	}

	MinRedemptionType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MinRedemptionType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
