package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Wael nour-eldin
 * 
 */
public enum MinRedemptionIndicatorEnum implements EntityKey {
	UNITS("U"), AMOUNT("V");

	private String code;
	private static Map<String, MinRedemptionIndicatorEnum> map;
	static {
		map = new Hashtable<String, MinRedemptionIndicatorEnum>();
		for (MinRedemptionIndicatorEnum value : MinRedemptionIndicatorEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	MinRedemptionIndicatorEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MinRedemptionIndicatorEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
