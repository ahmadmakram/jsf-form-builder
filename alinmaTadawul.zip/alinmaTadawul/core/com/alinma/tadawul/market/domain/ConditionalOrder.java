package com.alinma.tadawul.market.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.alinma.tadawul.market.domain.lov.OrderSide;
import com.alinma.tadawul.market.domain.lov.OrderType;
import com.alinma.tadawul.market.domain.lov.SystemStatus;
import com.alinma.tadawul.market.domain.lov.TifType;
import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;

public class ConditionalOrder {

	private String orderId;
	private String CIF;
	private String userId;
	private Date createdTime;
	private String systemStatus;
	private CombinedDate startDate;
	private CombinedDate endDate;
	private int isActive;
	private String triggerSymbolType;
	private String triggerSymbolValue;
	private String criterionType;
	private String criterionRule;
	private String criterionValue1;
	private String criterionValue2;
	private String userEmail;
	private String userMobileNo;
	private String preferedLang;
	private String lastHistoryId;
	private int versionNo;
	private String orderSide;
	private int orderType;
	private String portfolioNo;
	private String symbol;
	private int timeInForce;
	private int quantity;
	private int disclosedQunatity;
	private double price;
	private CombinedDate orderEndDate;
	private String orderTypeValue;
	private String timeInForceValue;
	private String orderSideValue;
	private EntityDefaultKey symbolEntityKey;
	private EntityDefaultKey entityKey;
	private String isSuccess;
	private String errorCode;
	private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCIF() {
		return CIF;
	}

	public void setCIF(String cIF) {
		CIF = cIF;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getSystemStatus() {
		if (systemStatus.equals(SystemStatus.EXECUTED.getCode())) {
			if (isSuccess.equals("1")) {
				return SystemStatus.EXECUTED.getCode();
			} else if (isSuccess.equals("0")) {
				return SystemStatus.FAILED.getCode();
			}
		} else if (systemStatus.equals(SystemStatus.INIT.getCode())) {
			CombinedDate todayCombined = new CombinedDate(simpleDateFormat.format(new Date()));
			if (endDate.getGregorianDate().compareTo(todayCombined.getGregorianDate()) < 0) {
				return SystemStatus.EXPIRED.getCode();
			}
		}
		return systemStatus;
	}

	public void setSystemStatus(String systemStatus) {
		this.systemStatus = systemStatus;
	}

	public CombinedDate getStartDate() {
		return startDate;
	}

	public void setStartDate(CombinedDate startDate) {
		this.startDate = startDate;
	}

	public CombinedDate getEndDate() {
		return endDate;
	}

	public void setEndDate(CombinedDate endDate) {
		this.endDate = endDate;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public String getTriggerSymbolType() {
		return triggerSymbolType;
	}

	public void setTriggerSymbolType(String triggerSymbolType) {
		this.triggerSymbolType = triggerSymbolType;
	}

	public String getTriggerSymbolValue() {
		return triggerSymbolValue;
	}

	public void setTriggerSymbolValue(String triggerSymbolValue) {
		this.triggerSymbolValue = triggerSymbolValue;
	}

	public String getCriterionType() {
		return criterionType;
	}

	public void setCriterionType(String criterionType) {
		this.criterionType = criterionType;
	}

	public String getCriterionRule() {
		return criterionRule;
	}

	public void setCriterionRule(String criterionRule) {
		this.criterionRule = criterionRule;
	}

	public String getCriterionValue1() {
		return criterionValue1;
	}

	public void setCriterionValue1(String criterionValue1) {
		this.criterionValue1 = criterionValue1;
	}

	public String getCriterionValue2() {
		return criterionValue2;
	}

	public void setCriterionValue2(String criterionValue2) {
		this.criterionValue2 = criterionValue2;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserMobileNo() {
		return userMobileNo;
	}

	public void setUserMobileNo(String userMobileNo) {
		this.userMobileNo = userMobileNo;
	}

	public String getPreferedLang() {
		return preferedLang;
	}

	public void setPreferedLang(String preferedLang) {
		this.preferedLang = preferedLang;
	}

	public String getLastHistoryId() {
		return lastHistoryId;
	}

	public void setLastHistoryId(String lastHistoryId) {
		this.lastHistoryId = lastHistoryId;
	}

	public int getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(int versionNo) {
		this.versionNo = versionNo;
	}

	public String getOrderSide() {
		return orderSide;
	}

	public void setOrderSide(String orderSide) {
		this.orderSide = orderSide;
	}

	public int getOrderType() {
		return orderType;
	}

	public void setOrderType(int orderType) {
		this.orderType = orderType;
	}

	public String getPortfolioNo() {
		return portfolioNo;
	}

	public void setPortfolioNo(String portfolioNo) {
		this.portfolioNo = portfolioNo;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public int getTimeInForce() {
		return timeInForce;
	}

	public void setTimeInForce(int timeInForce) {
		this.timeInForce = timeInForce;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getDisclosedQunatity() {
		return disclosedQunatity;
	}

	public void setDisclosedQunatity(int disclosedQunatity) {
		this.disclosedQunatity = disclosedQunatity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public CombinedDate getOrderEndDate() {
		return orderEndDate;
	}

	public void setOrderEndDate(CombinedDate orderEndDate) {
		this.orderEndDate = orderEndDate;
	}

	public String getOrderTypeValue() {
		orderTypeValue = OrderType.getByCode(getOrderType() + "").name();
		return orderTypeValue;
	}

	public void setOrderTypeValue(String orderTypeValue) {
		this.orderTypeValue = orderTypeValue;
	}

	public String getTimeInForceValue() {
		timeInForceValue = TifType.getByCode(getTimeInForce() + "").name();
		;
		return timeInForceValue;
	}

	public void setTimeInForceValue(String timeInForceValue) {
		this.timeInForceValue = timeInForceValue;
	}

	public String getOrderSideValue() {
		orderSideValue = OrderSide.getByCode(getOrderSide()).name();
		return orderSideValue;
	}

	public void setOrderSideValue(String orderSideValue) {
		this.orderSideValue = orderSideValue;
	}

	public EntityDefaultKey getSymbolEntityKey() {
		return symbolEntityKey;
	}

	public void setSymbolEntityKey(EntityDefaultKey symbolEntityKey) {
		this.symbolEntityKey = symbolEntityKey;
	}

	public EntityDefaultKey getEntityKey() {
		return entityKey;
	}

	public void setEntityKey(EntityDefaultKey entityKey) {
		this.entityKey = entityKey;
	}

	public String getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(String isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
