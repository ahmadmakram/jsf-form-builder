package com.alinma.tadawul.market.domain;

import com.ejada.commons.domain.CombinedDate;

public class DateRange {

	private CombinedDate startDate;
	private CombinedDate endDate;

	public CombinedDate getStartDate() {
		return startDate;
	}

	public void setStartDate(CombinedDate startDate) {
		this.startDate = startDate;
	}

	public CombinedDate getEndDate() {
		return endDate;
	}

	public void setEndDate(CombinedDate endDate) {
		this.endDate = endDate;
	}
}
