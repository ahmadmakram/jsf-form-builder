package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum MarketsEnum implements EntityKey {
	TADAWUL("TASI");

	private String code;
	private static Map<String, MarketsEnum> map;
	static {
		map = new Hashtable<String, MarketsEnum>();
		for (MarketsEnum value : MarketsEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	MarketsEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MarketsEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
