package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Omar Mohaidat
 * 
 */
public enum SubscriptionStatus implements EntityKey {
	SUBSCRIBED("S"), NOT_SUBSCRIBED("N"), INACTIVE("I"), SUBSCRIPTION_EXPIRED("E");

	private String code;
	private static Map<String, SubscriptionStatus> map;
	static {
		map = new Hashtable<String, SubscriptionStatus>();
		for (SubscriptionStatus value : SubscriptionStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	SubscriptionStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static SubscriptionStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
