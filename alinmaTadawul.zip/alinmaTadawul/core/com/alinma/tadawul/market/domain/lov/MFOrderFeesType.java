package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum MFOrderFeesType implements EntityKey {
	PERCENTAGE("PERCENTAGE"), VALUE("VALUE");

	private String code;
	private static Map<String, MFOrderFeesType> map;
	static {
		map = new Hashtable<String, MFOrderFeesType>();
		for (MFOrderFeesType value : MFOrderFeesType.values()) {
			map.put(value.getCode(), value);
		}
	}

	MFOrderFeesType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MFOrderFeesType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
