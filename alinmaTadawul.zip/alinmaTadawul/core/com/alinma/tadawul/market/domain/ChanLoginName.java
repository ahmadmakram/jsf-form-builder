package com.alinma.tadawul.market.domain;

/**
 * 
 * @author Omar Mohaidat
 * 
 */
public class ChanLoginName {

	private String chanId;
	private String loginName;

	public String getChanId() {
		return chanId;
	}

	public void setChanId(String chanId) {
		this.chanId = chanId;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
}
