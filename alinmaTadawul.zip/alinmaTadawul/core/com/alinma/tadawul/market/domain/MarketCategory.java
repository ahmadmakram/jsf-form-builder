package com.alinma.tadawul.market.domain;

import java.util.List;

public class MarketCategory extends Market {

	String innerSeparatoer = "$";
	private String categorySymbol;
	private List<String> symbols;

	public String getCategorySymbol() {
		return categorySymbol;
	}

	public void setCategorySymbol(String categorySymbol) {
		this.categorySymbol = categorySymbol;
	}

	public List<String> getSymbols() {
		return symbols;
	}

	public void setSymbols(List<String> symbols) {
		this.symbols = symbols;
	}

	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString());
		stringBuffer.append(separatoer);
		stringBuffer.append(categorySymbol);
		stringBuffer.append(separatoer);
		if (symbols != null && symbols.size() > 0) {
			for (String symbol : symbols) {
				stringBuffer.append(symbol);
				stringBuffer.append(innerSeparatoer);
			}
		}
		return stringBuffer.toString();
	}
}
