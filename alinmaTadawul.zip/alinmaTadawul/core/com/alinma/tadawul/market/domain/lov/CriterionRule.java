package com.alinma.tadawul.market.domain.lov;

public enum CriterionRule {
	LESS_THAN("1", "LESS_THAN"), GREATER_THAN("2", "GREATER_THAN"), RANGE("3", "RANGE");

	private String code;
	private String label;

	private CriterionRule(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
