package com.alinma.tadawul.market.domain.lov;

public enum PreferedLanguage {
	ARABIC("1", "ARABIC"), ENGLISH("2", "ENGLISH");

	private String code;
	private String label;

	private PreferedLanguage(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
