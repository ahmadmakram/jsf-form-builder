package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the channel Ids
 * 
 * @author Mohammad Suliman
 * 
 */
public enum OrderStatus implements EntityKey {
	NEW("NEW"), ORDER_ACKNOLEDGED("0"), PARTIALLY_FILLED_ORDER("1"), FULLY_FILLED_ORDER("2"), CANCELLED("4"), REPLACED("5"), PENDING_FOR_CANCEL("6"), REJECTED("8"), SUSPENDED("9"), PENDING_NEW("A"), CALCULATED(
			"B"), PENDING_MODIFICATION("E"), EXPIRY_ORDER("C"), ACCEPTED_FOR_BIDDING("D"), NOT_ACKNOWLEDGED("O"), UNPLACED("U"), WITH_TRIGGER("X"), PRIVATE("Z");

	private String code;
	private static Map<String, OrderStatus> map;
	static {
		map = new Hashtable<String, OrderStatus>();
		for (OrderStatus value : OrderStatus.values()) {
			map.put(value.getCode(), value);
		}
	}

	OrderStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static OrderStatus getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
