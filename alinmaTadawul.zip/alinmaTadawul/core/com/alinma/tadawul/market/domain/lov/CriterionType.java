package com.alinma.tadawul.market.domain.lov;

public enum CriterionType {
	PRICE("1", "PRICE"), CHANGE("2", "CHANGE"), CHANGE_PERCENTAGE("3", "CHANGE_PERCENTAGE");

	private String code;
	private String label;

	private CriterionType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
