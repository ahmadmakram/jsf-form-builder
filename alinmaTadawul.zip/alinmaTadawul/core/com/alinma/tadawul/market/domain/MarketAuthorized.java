package com.alinma.tadawul.market.domain;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Abdallah
 * 
 */
public enum MarketAuthorized implements EntityKey {
	YES("Y"), NO("N");

	private String code;
	private static Map<String, MarketAuthorized> map;
	static {
		map = new Hashtable<String, MarketAuthorized>();
		for (MarketAuthorized value : MarketAuthorized.values()) {
			map.put(value.getCode(), value);
		}
	}

	MarketAuthorized(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MarketAuthorized getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
