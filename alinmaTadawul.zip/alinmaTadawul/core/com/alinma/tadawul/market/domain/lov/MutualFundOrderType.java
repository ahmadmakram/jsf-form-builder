package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum MutualFundOrderType implements EntityKey {
	SUBSCRIPTION("FSB"), REDEMPTION("FRD"), ADDITION("FSA");

	private String code;
	private static Map<String, MutualFundOrderType> map;
	static {
		map = new Hashtable<String, MutualFundOrderType>();
		for (MutualFundOrderType value : MutualFundOrderType.values()) {
			map.put(value.getCode(), value);
		}
	}

	MutualFundOrderType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MutualFundOrderType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
