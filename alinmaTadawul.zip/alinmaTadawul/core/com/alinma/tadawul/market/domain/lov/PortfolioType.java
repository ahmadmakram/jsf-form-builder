package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public enum PortfolioType implements EntityKey {
	LOCAL_BROKERAGE("IP"), MUTUAL_FUND("MP"), INTERNATIONAL_BROKERAGE_PORTFOLIO("EP");

	private String code;
	private static Map<String, PortfolioType> map;
	static {
		map = new Hashtable<String, PortfolioType>();
		for (PortfolioType value : PortfolioType.values()) {
			map.put(value.getCode(), value);
		}
	}

	PortfolioType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static PortfolioType getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
