package com.alinma.tadawul.market.domain.lov;

public enum FrequencyType {
	ONCE_PER_DAY("1", "ONCE_PER_DAY"), ONCE_PER_PERIOD("2", "ONCE_PER_PERIOD");

	private String code;
	private String label;

	private FrequencyType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
