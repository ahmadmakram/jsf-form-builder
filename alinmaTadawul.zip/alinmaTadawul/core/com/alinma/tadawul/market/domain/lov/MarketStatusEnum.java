package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * @author Wael nour-eldin
 * 
 */
public enum MarketStatusEnum implements EntityKey {
	MAINTENANCE("0"), PREOPEN("1"), OPEN("2"), CLOSED("3"), PRECLOSED("4");

	private String code;
	private static Map<String, MarketStatusEnum> map;
	static {
		map = new Hashtable<String, MarketStatusEnum>();
		for (MarketStatusEnum value : MarketStatusEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	MarketStatusEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static MarketStatusEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
