package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

public enum QuarterEnum implements EntityKey {
	FIRST("1"), SECOND("2"), THIRD("3"), FOURTH("4");

	private String code;
	private static Map<String, QuarterEnum> map;
	static {
		map = new Hashtable<String, QuarterEnum>();
		for (QuarterEnum value : QuarterEnum.values()) {
			map.put(value.getCode(), value);
		}
	}

	QuarterEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static QuarterEnum getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
