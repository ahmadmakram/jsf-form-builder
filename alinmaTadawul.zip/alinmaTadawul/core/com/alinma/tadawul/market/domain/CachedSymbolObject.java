package com.alinma.tadawul.market.domain;

import com.alinma.tadawul.domain.lov.LOVTypeImpl;
import com.ejada.commons.domain.lov.LOVList;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class CachedSymbolObject {

	private LOVList<LOVTypeImpl> lovList;
	private boolean cachingPeriodExpired;

	public LOVList<LOVTypeImpl> getLovList() {
		return lovList;
	}

	public void setLovList(LOVList<LOVTypeImpl> lovList) {
		this.lovList = lovList;
	}

	public boolean isCachingPeriodExpired() {
		return cachingPeriodExpired;
	}

	public void setCachingPeriodExpired(boolean cachingPeriodExpired) {
		this.cachingPeriodExpired = cachingPeriodExpired;
	}
}
