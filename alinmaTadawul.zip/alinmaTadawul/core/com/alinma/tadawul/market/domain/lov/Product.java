/**
 * 
 */
package com.alinma.tadawul.market.domain.lov;

import java.util.Hashtable;
import java.util.Map;

import com.ejada.commons.domain.EntityKey;

/**
 * An enumeration for the channel Ids
 * 
 * @author Mohammad Suliman
 * 
 */
public enum Product implements EntityKey {
	LOCAL_EQUITY("LE");

	private String code;
	private static Map<String, Product> map;
	static {
		map = new Hashtable<String, Product>();
		for (Product value : Product.values()) {
			map.put(value.getCode(), value);
		}
	}

	Product(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static Product getByCode(String code) {
		if (map == null) {
			return null;
		}
		return map.get(code);
	}
}
