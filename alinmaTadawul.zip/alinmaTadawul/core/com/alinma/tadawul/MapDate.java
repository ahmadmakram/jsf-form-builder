package com.alinma.tadawul;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.util.StopWatch;

import com.ejada.commons.domain.CombinedDate;
import com.ejada.commons.domain.EntityDefaultKey;
import com.ejada.commons.domain.User;
import com.ejada.commons.services.ServiceMessageParameter;
import com.ejada.commons.services.ServiceRequestRec;
import com.ejada.commons.services.ServiceReturnMessage;
import com.ejada.commons.services.ServiceReturnRec;
import com.alinma.tadawul.domain.UserCredential;
import com.alinma.tadawul.services.CombinedDateCompare;
import com.alinma.tadawul.services.DateMapping;
import com.alinma.tadawul.services.UserAuthenticationManage;

public class MapDate {

	public static void main(String[] args) {
		ApplicationContext ac = ApplicationContextFactory.getApplicationContext();
		DateMapping mapping = (DateMapping) ac.getBean("DateMapping");
		CombinedDateCompare compare = (CombinedDateCompare) ac.getBean("CombinedDateCompare");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		// create context
		ServiceRequestRec context = new ServiceRequestRec();
		context.setLangPreferred(new EntityDefaultKey("En"));
		List<String> dates = new ArrayList<String>(0);
		dates.add("14301120");
		dates.add("14301220");
		ServiceReturnRec<List<String>> returnRec = null;
		returnRec = mapping.getGregorianFromHijriDate(dates, context);
		CombinedDate date1 = new CombinedDate();
		date1.setHijriDate("1430-01-01");
		CombinedDate date2 = new CombinedDate();
		date1.setGregorianDate(new Date());
		ServiceReturnRec<Integer> compareReturnRec = compare.compareTo(date1, date2, context);
		System.out.println("Compare Result" + compareReturnRec.getReturnedObject());
		for (ServiceReturnMessage msg : returnRec.getMessages()) {
			System.out.println(msg.getMessageText());
			for (ServiceMessageParameter msgParam : msg.getParameters().values()) {
				System.out.println(msgParam.getName());
				System.out.println(msgParam.getValueKey());
			}
		}
		stopWatch.stop();
		System.out.println("Overall Execution toke:" + stopWatch.getTotalTimeMillis() + " Millis");
	}
}
