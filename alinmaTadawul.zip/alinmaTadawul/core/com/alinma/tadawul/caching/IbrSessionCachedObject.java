package com.alinma.tadawul.caching;

import java.util.HashMap;
import java.util.Map;

import com.ejada.commons.services.SessionCachedObject;

public class IbrSessionCachedObject implements SessionCachedObject {

	public static final String FUNCTION_GROUPS = "FUNCTION_GROUPS";
	private Map<String, Object> cachedObjects;

	public Map<String, Object> getCahedObjects() {
		if (cachedObjects == null) {
			cachedObjects = new HashMap<String, Object>();
		}
		return cachedObjects;
	}

	public Object getCahedObject(String ObjectName) {
		return getCahedObjects().get(ObjectName);
	}

	public void setCahedObject(String ObjectName, Object objectValue) {
		getCahedObjects().put(ObjectName, objectValue);
	}
}
