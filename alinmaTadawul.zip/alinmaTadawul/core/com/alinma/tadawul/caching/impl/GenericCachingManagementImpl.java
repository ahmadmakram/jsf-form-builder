package com.alinma.tadawul.caching.impl;

import java.util.Hashtable;

import com.alinma.tadawul.caching.CachingManagement;

/**
 * 
 * @author Sami Ata Abdallah
 * 
 */
public class GenericCachingManagementImpl<GenericCachedObject> implements CachingManagement<Object> {

	private static Hashtable<String, CachedObject<Object>> cachedObjectMap;
	private String expirationPeriod;

	@Override
	public void addCachedObject(Object object, String key, String name) {
		CachedObject<Object> cachedObject = new CachedObject<Object>();
		cachedObject.setCachedObject(object);
		cachedObject.setLastTimeStamp(System.currentTimeMillis());
		cachedObject.setCachedName(name);
		if (cachedObjectMap == null) {
			cachedObjectMap = new Hashtable<String, CachedObject<Object>>(0);
		}
		cachedObjectMap.put(key, cachedObject);
	}

	@Override
	public Object getCachedObject(String key) {
		if (cachedObjectMap == null) {
			return null;
		}
		CachedObject<Object> cachedObject = cachedObjectMap.get(key);
		if (cachedObject == null) {
			return null;
		}
		if (System.currentTimeMillis() - cachedObject.getLastTimeStamp() >= Long.parseLong(expirationPeriod)) {
			removeCachedObject(key);
			return null;
		}
		return cachedObject.getCachedObject();
	}

	public void removeCachedObject(String key) {
		if (cachedObjectMap == null)
			return;
		cachedObjectMap.remove(key);
	}

	@Override
	public void addCachedSymbolObject(Object object, String key, String name) {
		// TODO Auto-generated method stub
	}

	@Override
	public Object getCachedSymbolObject(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Hashtable<String, CachedObject<Object>> getCachedObjectMap() {
		return cachedObjectMap;
	}

	public static void setCachedObjectMap(Hashtable<String, CachedObject<Object>> cachedObjectMap) {
		GenericCachingManagementImpl.cachedObjectMap = cachedObjectMap;
	}

	public String getExpirationPeriod() {
		return expirationPeriod;
	}

	public void setExpirationPeriod(String expirationPeriod) {
		this.expirationPeriod = expirationPeriod;
	}
}
