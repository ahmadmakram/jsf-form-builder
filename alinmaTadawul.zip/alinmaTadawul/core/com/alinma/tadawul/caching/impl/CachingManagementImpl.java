package com.alinma.tadawul.caching.impl;

import com.alinma.tadawul.caching.CachingManagement;
import com.alinma.tadawul.market.domain.CachedSymbolObject;
import com.ejada.commons.domain.lov.LOVList;
import com.ejada.commons.domain.lov.LOVType;

/**
 * @author M. Ali Hammam
 * 
 */
public class CachingManagementImpl<CL> implements CachingManagement {

	public void addCachedObject(Object object, String key, String name) {
		// TODO assume we will know the suitable caching class from class name of CL object
		LOVList<LOVType> list = (LOVList<LOVType>) object;
		CachedObject<LOVList<LOVType>> cachedObject = new CachedObject<LOVList<LOVType>>();
		cachedObject.setCachedObject(list);
		cachedObject.setLastTimeStamp(System.currentTimeMillis());
		cachedObject.setCachedName(name);
		LOVCacheImpl cacheImpl = new LOVCacheImpl();
		cacheImpl.addLOV(cachedObject, key);
	}

	public Object getCachedObject(String key) {
		LOVCacheImpl cacheImpl = new LOVCacheImpl();
		CachedObject cachedObj = cacheImpl.getLOV(key);
		if (cachedObj == null)
			return null;
		if (cachedObj.getLastTimeStamp() - System.currentTimeMillis() < -3600000) {
			cacheImpl.removeLOV(key);
			return null;
		}
		return cachedObj.getCachedObject();
	}

	public void addCachedSymbolObject(Object object, String key, String name) {
		CachedSymbolObject cachedSymbolObject = (CachedSymbolObject) object;
		cachedSymbolObject.setCachingPeriodExpired(false);
		CachedObject<CachedSymbolObject> cachedObject = new CachedObject<CachedSymbolObject>();
		cachedObject.setCachedObject(cachedSymbolObject);
		cachedObject.setLastTimeStamp(System.currentTimeMillis());
		cachedObject.setCachedName(name);
		LOVCacheImpl cacheImpl = new LOVCacheImpl();
		cacheImpl.removeLOV(key);
		cacheImpl.addCachedObject(cachedObject, key);
	}

	public Object getCachedSymbolObject(String key) {
		LOVCacheImpl cacheImpl = new LOVCacheImpl();
		CachedObject<CachedSymbolObject> cachedObj = cacheImpl.getCachedSymbolObject(key);
		if (cachedObj == null)
			return null;
		if (cachedObj.getLastTimeStamp() - System.currentTimeMillis() < -3600000) {
			cachedObj.getCachedObject().setCachingPeriodExpired(true);
		}
		return cachedObj.getCachedObject();
	}
}
