package com.alinma.tadawul.caching.impl;

import java.util.Hashtable;

import com.alinma.tadawul.caching.LOVCache;
import com.alinma.tadawul.domain.lov.LOVTypeImpl;
import com.alinma.tadawul.market.domain.CachedSymbolObject;
import com.ejada.commons.domain.lov.LOVList;
import com.ejada.commons.domain.lov.LOVType;

/**
 * @author M. Ali Hammam
 * 
 */
public class LOVCacheImpl implements LOVCache {

	private static Hashtable<String, CachedObject<LOVList<LOVType>>> hashedLOVs;
	private static Hashtable<String, CachedObject<CachedSymbolObject>> hashedSymbolObject;

	/*
	 * (non-Javadoc)
	 * @see com.alinma.tadawul.caching.LOVCache#addLOV(com.alinma.tadawul.caching.impl.CachedObject, java.lang.String)
	 */
	public void addLOV(CachedObject<LOVList<LOVType>> cachedObject, String key) {
		if (hashedLOVs == null)
			hashedLOVs = new Hashtable<String, CachedObject<LOVList<LOVType>>>(0);
		hashedLOVs.put(key, cachedObject);
	}

	public void addCachedObject(CachedObject<CachedSymbolObject> cachedObject, String key) {
		if (hashedSymbolObject == null)
			hashedSymbolObject = new Hashtable<String, CachedObject<CachedSymbolObject>>(0);
		hashedSymbolObject.put(key, cachedObject);
	}

	/*
	 * (non-Javadoc)
	 * @see com.alinma.tadawul.caching.LOVCache#getLOV(java.lang.String)
	 */
	public CachedObject<LOVList<LOVType>> getLOV(String key) {
		if (hashedLOVs == null)
			return null;
		CachedObject<LOVList<LOVType>> cachedObject = hashedLOVs.get(key);
		if (cachedObject == null)
			return null;
		return cachedObject;
	}

	public CachedObject<CachedSymbolObject> getCachedSymbolObject(String key) {
		if (hashedSymbolObject == null)
			return null;
		CachedObject<CachedSymbolObject> cachedObject = hashedSymbolObject.get(key);
		if (cachedObject == null)
			return null;
		return cachedObject;
	}

	/*
	 * (non-Javadoc)
	 * @see com.alinma.tadawul.caching.LOVCache#removeLOV(java.lang.String)
	 */
	public void removeLOV(String key) {
		if (hashedLOVs == null)
			return;
		hashedLOVs.remove(key);
	}

	/**
	 * @return the hashedLOVs
	 */
	public Hashtable<String, CachedObject<LOVList<LOVType>>> getHashedLOVs() {
		return hashedLOVs;
	}

	/**
	 * @param hashedLOVs
	 *            the hashedLOVs to set
	 */
	public void setHashedLOVs(Hashtable<String, CachedObject<LOVList<LOVType>>> hashedLOVs) {
		this.hashedLOVs = hashedLOVs;
	}

	public static String generateKey(LOVTypeImpl lovType, String lovCode1, String lovCode2, String lovCode3, String lovCode4, String lang) {
		String key = "";
		key += lovType != null ? lovType.getCode() : "";
		key += "-";
		key += lovCode1 != null ? lovCode1 : "";
		key += "-";
		key += lovCode2 != null ? lovCode2 : "";
		key += "-";
		key += lovCode3 != null ? lovCode3 : "";
		key += "-";
		key += lovCode4 != null ? lovCode4 : "";
		key += "-";
		key += lang != null ? lang : "";
		return key;
	}

	public static String generateKey(String lovTypeCode, String lovCode1, String lovCode2, String lovCode3, String lovCode4, String lang) {
		String key = "";
		key += lovTypeCode != null ? lovTypeCode : "";
		key += "-";
		key += lovCode1 != null ? lovCode1 : "";
		key += "-";
		key += lovCode2 != null ? lovCode2 : "";
		key += "-";
		key += lovCode3 != null ? lovCode3 : "";
		key += "-";
		key += lovCode4 != null ? lovCode4 : "";
		key += "-";
		key += lang != null ? lang : "";
		return key;
	}

	public static Hashtable<String, CachedObject<CachedSymbolObject>> getHashedSymbolObject() {
		return hashedSymbolObject;
	}

	public static void setHashedSymbolObject(Hashtable<String, CachedObject<CachedSymbolObject>> hashedSymbolObject) {
		LOVCacheImpl.hashedSymbolObject = hashedSymbolObject;
	}
}
