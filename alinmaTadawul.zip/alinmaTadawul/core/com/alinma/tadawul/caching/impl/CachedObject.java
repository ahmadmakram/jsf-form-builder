package com.alinma.tadawul.caching.impl;

/**
 * @author M. Ali Hammam
 * 
 */
public class CachedObject<CL> {

	protected CL cachedObject;
	protected long lastTimeStamp;
	protected String cachedName;

	/**
	 * @return the lastTimeStamp
	 */
	public long getLastTimeStamp() {
		return lastTimeStamp;
	}

	/**
	 * @param lastTimeStamp
	 *            the lastTimeStamp to set
	 */
	public void setLastTimeStamp(long lastTimeStamp) {
		this.lastTimeStamp = lastTimeStamp;
	}

	/**
	 * @return the cachedObject
	 */
	public CL getCachedObject() {
		return cachedObject;
	}

	/**
	 * @param cachedObject
	 *            the cachedObject to set
	 */
	public void setCachedObject(CL cachedObject) {
		this.cachedObject = cachedObject;
	}

	public String getCachedName() {
		return cachedName;
	}

	public void setCachedName(String cachedName) {
		this.cachedName = cachedName;
	}
}
