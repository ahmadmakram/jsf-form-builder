package com.alinma.tadawul.caching;

/**
 * @author M. Ali Hammam
 * @param <CL>
 * 
 */
public interface CachingManagement<CL> {

	/**
	 * add LOVList as cached object to the hash
	 * 
	 * @param cachedObject
	 * @param key
	 */
	public void addCachedObject(Object object, String key, String name);

	/**
	 * get cachedObject from cache map by certain key
	 * 
	 * @param key
	 * @return
	 */
	public CL getCachedObject(String key);

	public void addCachedSymbolObject(Object object, String key, String name);

	public CL getCachedSymbolObject(String key);
}
