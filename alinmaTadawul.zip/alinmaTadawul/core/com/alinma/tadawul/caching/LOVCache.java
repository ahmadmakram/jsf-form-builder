/**
 * 
 */
package com.alinma.tadawul.caching;

import com.ejada.commons.domain.lov.LOVList;
import com.ejada.commons.domain.lov.LOVType;
import com.alinma.tadawul.caching.impl.CachedObject;

/**
 * @author M. Ali Hammam
 * 
 */
public interface LOVCache {

	/**
	 * add LOVList as cached object to the hash
	 * 
	 * @param cachedObject
	 * @param key
	 */
	public void addLOV(CachedObject<LOVList<LOVType>> cachedObject, String key);

	/**
	 * remove LOVList from cache map by certain key
	 * 
	 * @param key
	 */
	public void removeLOV(String key);

	/**
	 * get LOVList from cache map by certain key
	 * 
	 * @param key
	 * @return
	 */
	public CachedObject<LOVList<LOVType>> getLOV(String key);
}
